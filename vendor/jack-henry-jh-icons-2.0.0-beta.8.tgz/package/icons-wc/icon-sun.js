/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconSun extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path d="M16.264 20.99a.75.75 0 0 1-1.4.539l-1.144-2.973a6.807 6.807 0 0 0 1.4-.54l1.144 2.974Zm-5.214-2.28a6.733 6.733 0 0 0 1.5.045l-.037 1.258a.751.751 0 0 1-1.5-.044l.037-1.259Zm-3.78-1.856c.355.346.75.658 1.183.923l-1.955 2.512a.75.75 0 0 1-1.184-.92l1.956-2.515Zm-.311-6.416a5.278 5.278 0 1 1 10.083 3.126 5.278 5.278 0 0 1-10.083-3.126Zm12.171 5.257a.751.751 0 0 1-.811 1.261l-1.059-.68c.313-.384.586-.806.812-1.262l1.058.68ZM5.691 14.474c.183.467.418.912.7 1.328l-1.227.646a.752.752 0 0 1-.7-1.328l1.227-.646Zm7.428-6.082a3.778 3.778 0 1 0 2.489 4.727l.054-.187a3.778 3.778 0 0 0-2.359-4.478l-.184-.062Zm8.96 4.343a.75.75 0 0 1-.22 1.484l-3.306-.49.017-.057c.121-.476.187-.954.204-1.428l3.305.49ZM2.142 9.78l3.306.49a6.69 6.69 0 0 0-.22 1.484l-3.307-.49a.751.751 0 0 1 .221-1.484Zm16.695-2.229a.751.751 0 0 1 .699 1.328l-1.226.645a6.82 6.82 0 0 0-.7-1.328l1.227-.645ZM4.645 7.27a.75.75 0 0 1 1.036-.226l1.06.682a6.727 6.727 0 0 0-.812 1.26l-1.058-.68a.75.75 0 0 1-.226-1.036Zm12.858-3.56a.75.75 0 0 1 1.184.922L16.73 7.145a6.733 6.733 0 0 0-1.183-.922l1.956-2.512ZM8.167 2.04a.75.75 0 0 1 .97.43l1.143 2.974a6.809 6.809 0 0 0-1.4.539L7.735 3.01a.751.751 0 0 1 .43-.97Zm4.093 1.217c.414.013.74.359.728.772l-.038 1.258a6.731 6.731 0 0 0-1.5-.044l.039-1.258a.75.75 0 0 1 .771-.728Z"/> </svg> 
    `;
  }
}

customElements.define('jh-icon-sun', JhIconSun);