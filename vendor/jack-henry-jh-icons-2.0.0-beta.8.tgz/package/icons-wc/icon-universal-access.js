/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconUniversalAccess extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path d="M12 2.25c5.385 0 9.75 4.365 9.75 9.75s-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12 6.615 2.25 12 2.25Zm0 1.5a8.25 8.25 0 1 0 0 16.5 8.25 8.25 0 0 0 0-16.5Zm3.763 4.538a.75.75 0 1 1 .473 1.424h-.002l-.007.003-.026.009-.1.032a45.963 45.963 0 0 1-1.52.465c-.4.114-.833.228-1.237.322a4.836 4.836 0 0 0-.251 1.827c.009.189.028.357.048.496.192.607.432 1.249.678 1.85a40.848 40.848 0 0 0 1.01 2.26l.069.141.017.036.005.01v.001a.751.751 0 0 1-1.34.671l-.002-.001v-.003l-.007-.01a24.11 24.11 0 0 1-.093-.19l-.26-.549a41.928 41.928 0 0 1-.787-1.798 30.69 30.69 0 0 1-.4-1.034h-.061c-.13.353-.265.703-.4 1.034a41.928 41.928 0 0 1-1.122 2.496l-.02.04-.005.011-.001.003-.001.001-.038.067a.75.75 0 0 1-1.304-.738l.001-.002.005-.009.018-.036.069-.141a40.793 40.793 0 0 0 1.009-2.26 25.73 25.73 0 0 0 .645-1.748c.02-.156.04-.355.047-.585a5.745 5.745 0 0 0-.23-1.843 24.439 24.439 0 0 1-1.224-.32 44.734 44.734 0 0 1-1.52-.464l-.1-.032-.027-.01-.006-.001-.002-.001a.751.751 0 0 1 .473-1.424v.001h.002l.03.01.094.031a40.215 40.215 0 0 0 1.468.45c.43.122.884.242 1.285.331.42.093.724.139.884.139.16 0 .465-.046.884-.139.401-.089.855-.209 1.285-.332a43.285 43.285 0 0 0 1.468-.449l.094-.031.03-.01h.002ZM12 5.75a1.4 1.4 0 1 1 0 2.801 1.4 1.4 0 0 1 0-2.801Z"/> </svg> 
    `;
  }
}

customElements.define('jh-icon-universal-access', JhIconUniversalAccess);