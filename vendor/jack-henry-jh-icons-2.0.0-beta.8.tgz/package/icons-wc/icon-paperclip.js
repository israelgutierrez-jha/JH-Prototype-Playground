/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconPaperclip extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M16.034 4.693c-.527-.03-1.116.147-1.68.71L6.93 12.828c-.917.916-1.227 1.903-1.174 2.806.054.921.491 1.814 1.174 2.497.682.682 1.576 1.12 2.497 1.174.902.053 1.89-.257 2.806-1.174l6.01-6.01a.75.75 0 0 1 1.061 1.06l-6.01 6.01c-1.205 1.205-2.604 1.69-3.955 1.61-1.333-.077-2.561-.701-3.47-1.61-.908-.908-1.532-2.136-1.61-3.469-.08-1.351.406-2.75 1.61-3.955l7.425-7.425c.85-.85 1.852-1.204 2.828-1.146.957.056 1.832.503 2.475 1.146.643.644 1.09 1.518 1.146 2.475.058.976-.295 1.978-1.146 2.829l-7.425 7.424c-.497.497-1.1.718-1.7.682a2.303 2.303 0 0 1-1.481-.682 2.302 2.302 0 0 1-.683-1.48c-.035-.6.185-1.204.683-1.702L14 7.878a.75.75 0 0 1 1.06 1.06l-6.01 6.011c-.21.21-.254.401-.245.552.01.17.093.356.245.508a.805.805 0 0 0 .508.246c.152.009.343-.036.553-.246l7.424-7.424c.563-.563.741-1.153.71-1.68-.032-.545-.292-1.085-.71-1.502-.417-.417-.957-.678-1.502-.71Z" clip-rule="evenodd"/> </svg> 
    `;
  }
}

customElements.define('jh-icon-paperclip', JhIconPaperclip);