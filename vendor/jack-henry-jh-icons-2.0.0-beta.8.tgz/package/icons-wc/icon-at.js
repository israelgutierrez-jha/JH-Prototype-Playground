/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconAt extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75V21v.75h.043c.024 0 .06 0 .105-.002a13.761 13.761 0 0 0 1.583-.13c.463-.066.98-.168 1.46-.328.466-.156.97-.39 1.34-.76a.75.75 0 1 0-1.061-1.06c-.13.13-.377.271-.754.397a7.029 7.029 0 0 1-1.197.266 12.295 12.295 0 0 1-1.493.117H12A8.25 8.25 0 1 1 20.25 12c0 1.093-.325 1.851-.757 2.356a2.708 2.708 0 0 1-1.616.904c-.601.1-1.163-.008-1.549-.243-.362-.222-.578-.554-.578-1.017V8a.75.75 0 0 0-1.5 0v.375c-.729-.696-1.679-1.125-2.75-1.125-2.438 0-4.25 2.224-4.25 4.75s1.812 4.75 4.25 4.75c1.235 0 2.31-.57 3.07-1.463.23.421.57.761.976 1.01.74.451 1.678.593 2.577.443a4.209 4.209 0 0 0 2.509-1.408c.693-.808 1.118-1.925 1.118-3.332A9.75 9.75 0 0 0 12 2.25ZM14.25 12c0-1.892-1.322-3.25-2.75-3.25S8.75 10.108 8.75 12s1.322 3.25 2.75 3.25 2.75-1.358 2.75-3.25Z" clip-rule="evenodd"/> </svg> 
    `;
  }
}

customElements.define('jh-icon-at', JhIconAt);