/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconBroom extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path d="M18.559 2.84a1.75 1.75 0 0 1 2.438-.279l.165.13a1.75 1.75 0 0 1 .319 2.432l-6.849 9.074c.996 1.004 1.227 2.543.61 3.818-.179.37-.35.74-.484 1.058-.34.807-.768 1.561-1.42 2.06-.691.53-1.537.704-2.54.538-.586-.097-1.24-.389-1.887-.762a17.22 17.22 0 0 1-2.073-1.44c-1.41-1.124-2.858-2.542-3.95-3.886a.751.751 0 0 1 .693-1.215c.947.14 1.475-.11 1.845-.401a4.34 4.34 0 0 0 .56-.555c.156-.176.382-.446.63-.624.282-.202.604-.46.925-.729 1.084-.907 2.635-1.084 3.865-.374l7.153-8.845ZM7.454 14.036a4.5 4.5 0 0 0-.344.37 5.776 5.776 0 0 1-.755.74c-.352.277-.775.51-1.29.643.2.214.408.426.62.637.091.015.215.031.358.031.319 0 .69-.073 1.016-.328a.75.75 0 1 1 .923 1.183 2.95 2.95 0 0 1-.844.458 19.192 19.192 0 0 0 1.542 1.206l.006.002c.139.015.344.027.587.007a3.013 3.013 0 0 0 1.71-.707.75.75 0 0 1 .965 1.15 4.56 4.56 0 0 1-1.15.703c.089.026.17.047.245.06.679.111 1.083-.018 1.382-.248.318-.243.604-.665.895-1.325l-5.866-4.582Zm3.41-.916c-.623-.486-1.51-.496-2.192-.036l5.284 4.128c.293-.761.072-1.62-.553-2.108l-2.54-1.984Zm9.21-9.377a.25.25 0 0 0-.348.04l-7.115 8.799.856.669 6.818-9.031a.251.251 0 0 0-.047-.348l-.164-.129Z"/> </svg> 
    `;
  }
}

customElements.define('jh-icon-broom', JhIconBroom);