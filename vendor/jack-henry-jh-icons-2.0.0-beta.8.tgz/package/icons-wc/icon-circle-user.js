/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconCircleUser extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3.75 12a8.25 8.25 0 1 1 14.992 4.757 2.353 2.353 0 0 0-.631-1.46c-.38-.409-.874-.667-1.336-.85-.424-.168-.882-.294-1.28-.405l-.108-.03c-.447-.123-.796-.227-1.058-.352a.44.44 0 0 1-.203-.21 4.833 4.833 0 0 0 1.293-3.083l.001-.017v-.032c0-.342 0-1.305-.399-2.201a3.08 3.08 0 0 0-1.05-1.302c-.518-.36-1.173-.56-1.971-.56s-1.453.2-1.971.56a3.08 3.08 0 0 0-1.05 1.302c-.4.896-.4 1.86-.399 2.2v.052a4.85 4.85 0 0 0 1.247 3.03.867.867 0 0 1-.225.296c-.253.118-.582.22-.994.337l-.146.042c-.388.11-.829.235-1.237.396-.46.182-.952.438-1.333.841-.358.38-.588.861-.634 1.447a8.212 8.212 0 0 1-1.508-4.756Zm3 6.364A8.216 8.216 0 0 0 12 20.251a8.216 8.216 0 0 0 5.25-1.887v-1.39c0-.311-.096-.503-.237-.655-.162-.174-.419-.33-.79-.477a11.378 11.378 0 0 0-1.142-.358l-.095-.026c-.426-.118-.908-.254-1.311-.448l-.007-.003a1.94 1.94 0 0 1-1.076-1.891l.023-.297.22-.2a3.33 3.33 0 0 0 1.085-2.302c0-.34-.011-1.012-.269-1.59a1.583 1.583 0 0 0-.535-.68c-.233-.16-.58-.293-1.116-.293-.537 0-.883.132-1.116.294-.237.165-.41.397-.535.679-.257.578-.269 1.25-.269 1.59a3.35 3.35 0 0 0 1.078 2.295l.267.246-.027.363a2.352 2.352 0 0 1-.955 1.718l-.05.037-.056.028c-.405.204-.889.347-1.317.47l-.148.041c-.397.114-.762.217-1.095.349-.373.148-.632.304-.793.475-.14.15-.234.335-.234.635v1.39ZM12 2.251a9.75 9.75 0 0 0-9.75 9.75c0 5.384 4.365 9.75 9.75 9.75s9.75-4.366 9.75-9.75A9.75 9.75 0 0 0 12 2.251Z" clip-rule="evenodd"/> </svg> 
    `;
  }
}

customElements.define('jh-icon-circle-user', JhIconCircleUser);