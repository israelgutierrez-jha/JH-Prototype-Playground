/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconVaultClock extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path d="M19.75 3a.75.75 0 0 1 .75.75v3h1.25v3H20.5v4h1.25v3H20.5v3a.75.75 0 0 1-.75.75h-1v1.25h-3V20.5h-8v1.25h-3V20.5h-1a.75.75 0 0 1-.75-.75v-16A.75.75 0 0 1 3.75 3h16ZM4.5 19H19V4.5H4.5V19Zm7.25-13.75a6.5 6.5 0 1 1-.001 13.001A6.5 6.5 0 0 1 11.75 5.25Zm0 1.5a5 5 0 1 0 .001 10.001A5 5 0 0 0 11.75 6.75Zm0 1.25a.75.75 0 0 1 .75.75v2.592l1.594 1.028a.75.75 0 1 1-.813 1.26l-1.937-1.25a.302.302 0 0 1-.006-.004l-.02-.015a.752.752 0 0 1-.093-.076l-.005-.005a.747.747 0 0 1-.219-.504l-.001-.01V8.75a.75.75 0 0 1 .75-.75Z"/> </svg> 
    `;
  }
}

customElements.define('jh-icon-vault-clock', JhIconVaultClock);