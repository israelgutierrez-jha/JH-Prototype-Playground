/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconUser extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M9.26 3.525c.705-.49 1.61-.775 2.74-.775 1.13 0 2.035.285 2.74.775.7.486 1.154 1.14 1.445 1.796.565 1.27.565 2.65.565 3.161V8.5c0 .61-.158 1.468-.505 2.333-.305.76-.774 1.57-1.458 2.233.023.137.056.25.103.345.07.145.19.29.446.418.427.214.985.385 1.65.574l.213.06c.585.166 1.231.349 1.827.585.669.264 1.348.623 1.864 1.17.537.57.86 1.309.86 2.24V20.5a.75.75 0 0 1-1.5 0v-2.042c0-.548-.177-.918-.452-1.211-.297-.316-.742-.575-1.324-.805-.52-.206-1.09-.367-1.686-.536l-.212-.06c-.647-.184-1.339-.389-1.911-.675-.54-.27-.903-.65-1.124-1.104-.211-.434-.269-.888-.285-1.276l-.015-.372.287-.237c.604-.5 1.04-1.197 1.325-1.908.286-.714.397-1.383.397-1.774 0-.504-.007-1.606-.435-2.57-.209-.469-.506-.879-.93-1.173-.42-.292-1.016-.507-1.885-.507-.87 0-1.465.215-1.885.507-.424.294-.721.704-.93 1.173-.428.964-.435 2.066-.435 2.57 0 .391.11 1.054.393 1.763.281.705.712 1.399 1.31 1.903l.323.27-.064.418c-.04.258-.126.684-.312 1.11-.18.413-.5.925-1.065 1.207-.572.286-1.264.49-1.91.675l-.213.06c-.596.169-1.166.33-1.686.536-.581.23-1.027.489-1.324.805-.275.293-.452.663-.452 1.211V20.5a.75.75 0 0 1-1.5 0v-2.042c0-.931.323-1.67.86-2.24.516-.547 1.195-.906 1.864-1.17.596-.236 1.242-.419 1.827-.585l.212-.06c.666-.19 1.224-.36 1.652-.574.112-.056.243-.198.361-.467.052-.118.092-.241.124-.359-.653-.655-1.105-1.443-1.4-2.184-.343-.858-.5-1.71-.5-2.319v-.018c0-.51 0-1.89.565-3.161.291-.657.744-1.31 1.445-1.796Z" clip-rule="evenodd"/> </svg> 
    `;
  }
}

customElements.define('jh-icon-user', JhIconUser);