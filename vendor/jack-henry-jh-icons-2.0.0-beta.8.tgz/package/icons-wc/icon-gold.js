/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconGold extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path d="M14.746 9c.224 0 .422.138.493.342l1.735 5a.497.497 0 0 1-.33.633.542.542 0 0 1-.164.025h2.766c.224 0 .422.138.493.342l1.735 5a.497.497 0 0 1-.33.633.542.542 0 0 1-.164.025h-8.96l-.017-.002-.024.002H3.021a.51.51 0 0 1-.521-.5c0-.054.009-.107.026-.158l1.735-5A.519.519 0 0 1 4.754 15H7.52a.51.51 0 0 1-.52-.5c0-.054.009-.107.026-.158l1.735-5A.519.519 0 0 1 9.254 9h5.492ZM4.406 19.5h6.188l-1.04-3H5.446l-1.04 3Zm9 0h6.188l-1.04-3h-4.108l-1.04 3Zm-3.16-4.5c.224 0 .422.138.493.342L12 18.976l1.26-3.634a.519.519 0 0 1 .494-.342h-3.508Zm-1.34-1.5h6.188l-1.04-3H9.946l-1.04 3ZM3.852 9.814l1.764.424a.5.5 0 0 1-.232.973l-1.766-.424a.5.5 0 0 1 .234-.973Zm16.771 0a.5.5 0 0 1 .233.973l-1.765.424a.5.5 0 0 1-.233-.973l1.765-.424ZM5.853 5.128a.5.5 0 0 1 .706.038l1.795 2a.5.5 0 1 1-.744.668l-1.796-2a.5.5 0 0 1 .039-.706Zm12.063.038a.5.5 0 0 1 .744.668l-1.796 2a.5.5 0 0 1-.744-.668l1.796-2ZM12 4a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 12 4Z"/> </svg> 
    `;
  }
}

customElements.define('jh-icon-gold', JhIconGold);