/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconAppleWhole extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="m15.852 2.843-.749-.043-.05-.748.847-.056-.048.847Zm-3.758 4.614a2.19 2.19 0 0 0 2.472-.731c.623-.664.924-1.69 1.08-2.422a11.138 11.138 0 0 0 .204-1.424l.001-.026v-.01l-.748-.044-.05-.748h-.01l-.025.002a7.297 7.297 0 0 0-.394.04c-.255.03-.606.078-.988.156a7.73 7.73 0 0 0-1.206.339c-.378.145-.787.35-1.104.65a2.41 2.41 0 0 0-.755 1.11c-.47-.666-1.048-1.293-1.756-1.78a.75.75 0 0 0-.85 1.237c1.132.777 1.907 2.101 2.404 3.311.12.291.22.57.305.825a8.108 8.108 0 0 0-.84-.402c-.395-.158-.848-.29-1.304-.29-1.48 0-2.704.631-3.534 1.765-.81 1.106-1.206 2.635-1.206 4.405 0 1.757.37 3.84 1.242 5.514C5.91 20.617 7.37 22 9.54 22c.863 0 1.525-.38 1.971-.687.112-.077.216-.153.304-.218l.002-.001a9.42 9.42 0 0 1 .198-.144c.058.039.124.085.206.143l.01.008c.092.064.198.14.314.215.46.304 1.136.674 2.005.674 2.158 0 3.594-1.397 4.45-3.078.853-1.674 1.21-3.753 1.21-5.492 0-1.759-.39-3.286-1.192-4.395C18.196 7.89 16.98 7.25 15.5 7.25c-.45 0-.901.133-1.293.29-.4.16-.791.368-1.134.563-.173.098-.337.196-.486.284l-.027.016-.162.096a14.209 14.209 0 0 0-.304-1.042Zm2.148-3.794a9.673 9.673 0 0 0-.307.057 6.278 6.278 0 0 0-.969.27c-.306.117-.51.24-.619.347l-.026.025-.028.022a.911.911 0 0 0-.087 1.338l.034.036.03.041a.69.69 0 0 0 1.116 0l.033-.044.038-.04c.322-.328.567-.996.721-1.722a9.05 9.05 0 0 0 .064-.33ZM6.206 9.9c-.562.768-.916 1.95-.916 3.519 0 1.583.34 3.414 1.073 4.82.728 1.398 1.768 2.26 3.177 2.26.407 0 .76-.175 1.122-.423.09-.062.174-.124.263-.19l.014-.01c.081-.06.17-.125.256-.184.09-.06.2-.13.319-.186a1.18 1.18 0 0 1 .496-.117c.205 0 .376.062.491.114.12.054.23.121.32.18.085.057.175.12.257.178l.02.014c.09.064.18.126.272.188.374.246.75.426 1.18.426 1.382 0 2.4-.858 3.114-2.26.718-1.408 1.046-3.239 1.046-4.81 0-1.56-.35-2.744-.908-3.515C17.264 9.16 16.5 8.75 15.5 8.75c-.175 0-.42.056-.734.182-.307.123-.63.292-.951.475-.16.09-.314.182-.463.27l-.03.018c-.137.081-.272.161-.395.231a4.74 4.74 0 0 1-.392.204 1.32 1.32 0 0 1-.525.13c-.227 0-.43-.088-.526-.131a4.628 4.628 0 0 1-.389-.205 24.042 24.042 0 0 1-.38-.225l-.04-.024c-.147-.088-.299-.18-.456-.27a7.711 7.711 0 0 0-.943-.473c-.313-.125-.562-.182-.746-.182-1.01 0-1.78.409-2.324 1.15Z" clip-rule="evenodd"/> </svg> 
    `;
  }
}

customElements.define('jh-icon-apple-whole', JhIconAppleWhole);