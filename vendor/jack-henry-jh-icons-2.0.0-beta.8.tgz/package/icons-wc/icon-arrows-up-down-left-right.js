/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconArrowsUpDownLeftRight extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="m12 1.94.53.53 3 3a.75.75 0 0 1-1.06 1.06l-1.72-1.72v6.44h6.44l-1.72-1.72a.75.75 0 0 1 1.06-1.06l3 3 .53.53-.53.53-3 3a.75.75 0 1 1-1.06-1.06l1.72-1.72h-6.44v6.44l1.72-1.72a.75.75 0 1 1 1.06 1.06l-3 3-.53.53-.53-.53-3-3a.75.75 0 1 1 1.06-1.06l1.72 1.72v-6.44H4.81l1.72 1.72a.75.75 0 1 1-1.06 1.06l-3-3-.53-.53.53-.53 3-3a.75.75 0 0 1 1.06 1.06l-1.72 1.72h6.44V4.81L9.53 6.53a.75.75 0 1 1-1.06-1.06l3-3 .53-.53Z" clip-rule="evenodd"/> </svg> 
    `;
  }
}

customElements.define('jh-icon-arrows-up-down-left-right', JhIconArrowsUpDownLeftRight);