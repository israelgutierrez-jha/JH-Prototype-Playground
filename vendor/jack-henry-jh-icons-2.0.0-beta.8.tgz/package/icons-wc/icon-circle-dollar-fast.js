/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconCircleDollarFast extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path d="M14.23 4.256a7.75 7.75 0 1 1-7.975 7.994h.87c.22 0 .43-.037.627-.102a6.252 6.252 0 0 0 5.27 6.026 6.251 6.251 0 0 0 1.955-12.347 6.309 6.309 0 0 0-.751-.072 1.992 1.992 0 0 0 .003-1.5Zm1.253 3.17-.141.893c.269.124.522.293.733.514.413.432.642 1.034.531 1.73l-.117.74-1.481-.235.117-.74a.499.499 0 0 0-.135-.459c-.126-.132-.343-.246-.608-.288-.265-.042-.506 0-.667.086a.5.5 0 0 0-.269.395c-.065.41.03.598.136.727.151.184.393.333.791.562.344.197.846.475 1.203.91.403.492.584 1.12.458 1.914a1.997 1.997 0 0 1-1.04 1.48 2.392 2.392 0 0 1-.855.261l-.142.894-1.481-.236.14-.892a2.39 2.39 0 0 1-.732-.513 1.996 1.996 0 0 1-.531-1.73l.117-.74 1.481.234-.117.74a.5.5 0 0 0 .134.46c.125.13.338.242.598.285l.018.003c.261.04.5 0 .66-.086a.501.501 0 0 0 .269-.396c.065-.41-.03-.597-.136-.726-.151-.185-.393-.333-.791-.562-.344-.197-.845-.475-1.203-.91-.403-.492-.585-1.12-.46-1.914a1.998 1.998 0 0 1 1.042-1.48c.268-.145.56-.229.854-.263l.143-.893 1.481.236ZM7.125 9.5a.75.75 0 0 1 0 1.5H4.312a.75.75 0 0 1 0-1.5h2.813ZM8.438 7a.75.75 0 0 1 0 1.5H2.875a.75.75 0 0 1 0-1.5h5.563Zm3.937-2.75a.75.75 0 0 1 0 1.5H4.312a.75.75 0 0 1 0-1.5h8.063Z"/> </svg> 
    `;
  }
}

customElements.define('jh-icon-circle-dollar-fast', JhIconCircleDollarFast);