/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconHandshake extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M19.53 6.67a.75.75 0 0 0-.987-.315c-.124.06-.339.08-.808-.06a11.223 11.223 0 0 1-.75-.267l-.068-.026c-.257-.098-.543-.208-.839-.306-.648-.215-1.406-.401-2.235-.352a4.444 4.444 0 0 0-1.856.534c-1.531.202-2.416-.025-2.887-.244a1.722 1.722 0 0 1-.468-.305.72.72 0 0 1-.07-.075L8.56 5.25a.75.75 0 0 0-1.163-.128L2.278 10.24a.75.75 0 0 0 .007 1.068c.15.147.368.363.57.565a1.973 1.973 0 0 0 1.317 3.18c.05.426.238.839.565 1.165.326.327.739.515 1.164.565a1.973 1.973 0 0 0 3.208 1.296l2.068 2.067a1.955 1.955 0 0 0 3.182-.62 1.954 1.954 0 0 0 2.277-1.144 1.954 1.954 0 0 0 2.327-1.338 1.955 1.955 0 0 0 1.532-3.331l-.44-.442 1.714-.933a.75.75 0 0 0 .3-1.018l-2.54-4.65Zm-9.353 10.355 2.06 2.06a.455.455 0 0 0 .645-.641l-.002-.002-1.202-1.203-.003-.002-.223-.223a.75.75 0 0 1 1.061-1.06l.226.225 1.202 1.202.004.004.565.565a.455.455 0 0 0 .643-.643l-2.725-2.725-.003-.003-.124-.124a.75.75 0 0 1 1.06-1.06l.128.126 2.725 2.725.555.556a.455.455 0 0 0 .645-.642l-.001-.001-3.917-3.917-.066-.066a.75.75 0 0 1 1.06-1.06l.065.064.002.002 3.916 3.916.002.001.316.317a.455.455 0 0 0 .643-.643L14.061 9.4a3.201 3.201 0 0 0-.507.27c-.494.322-1.07.89-1.366 1.9a.75.75 0 0 1-.19.32 1.68 1.68 0 0 1-.892.49 1.384 1.384 0 0 1-.975-.196c-.53-.329-.815-.946-.912-1.554-.15-.948.1-2.127.94-3.206-.705-.066-1.26-.229-1.692-.43a3.529 3.529 0 0 1-.523-.298L3.871 10.77l.146.146.136.137a1.97 1.97 0 0 1 2.177 1.191 1.971 1.971 0 0 1 2.288 1.163 1.971 1.971 0 0 1 1.868 3.31l-.309.309Zm-1.988-1.47-.663.663a.472.472 0 1 0 .668.668l1.231-1.231a.472.472 0 1 0-.668-.668l-.568.568Zm-1.06-1.06a.472.472 0 0 0-.668-.669l-.562.561-.102.102a.472.472 0 0 0 .668.669l.664-.664Zm-2.29-1.168-.102.102a.473.473 0 0 1-.668-.668l.102-.102a.473.473 0 0 1 .668.668Zm14.11-1.162 1.443-.785-1.903-3.486c-.423.033-.834-.058-1.185-.163a12.549 12.549 0 0 1-.854-.302l-.064-.024c-.263-.1-.518-.198-.781-.286-.569-.189-1.118-.31-1.672-.277a2.968 2.968 0 0 0-1.345.418c-.139.081-.28.175-.425.285-1.319 1.006-1.57 2.17-1.462 2.85.035.221.1.358.151.434.438-1.219 1.2-1.97 1.882-2.415.365-.239.706-.389.959-.48a3.79 3.79 0 0 1 .437-.128l.01-.002.005-.001h.002l.045.232-.044-.233a.75.75 0 0 1 .784.353c.02.016.039.033.057.051l3.96 3.96Z" clip-rule="evenodd"/> </svg> 
    `;
  }
}

customElements.define('jh-icon-handshake', JhIconHandshake);