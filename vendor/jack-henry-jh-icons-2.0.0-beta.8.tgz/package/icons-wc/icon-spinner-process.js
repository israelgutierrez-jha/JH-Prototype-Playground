/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconSpinnerProcess extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path d="M19.629 10.64a7.75 7.75 0 0 1-5.138 8.698c.004.053.009.107.009.162a2.5 2.5 0 1 1-.55-1.563 6.25 6.25 0 0 0 4.195-7.075c.364.031.73.002 1.085-.09l.155-.043c.083-.026.164-.057.244-.09ZM5.873 5.083a2.5 2.5 0 0 1 2.5 2.5 2.497 2.497 0 0 1-2.318 2.49 6.25 6.25 0 0 0 3.273 7.577 3.248 3.248 0 0 0-.547 1.399A7.749 7.749 0 0 1 4.59 9.726a2.496 2.496 0 0 1-1.217-2.143 2.5 2.5 0 0 1 2.5-2.5ZM12 4.25a7.71 7.71 0 0 1 4.683 1.577 2.5 2.5 0 1 1-.722 1.342A6.218 6.218 0 0 0 12 5.75a6.221 6.221 0 0 0-3.049.793 3.25 3.25 0 0 0-.794-1.272A7.712 7.712 0 0 1 12 4.25Z"/> </svg> 
    `;
  }
}

customElements.define('jh-icon-spinner-process', JhIconSpinnerProcess);