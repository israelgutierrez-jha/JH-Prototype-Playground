/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconFileLock extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path d="M6.97 10.75c1.52 0 2.718 1.263 2.718 2.775v1.334c.59.282.997.882.997 1.579V19.5a1.75 1.75 0 0 1-1.75 1.75H5.312a1.75 1.75 0 0 1-1.75-1.75v-3.063c0-.567.27-1.07.689-1.39v-1.522c0-1.512 1.198-2.775 2.72-2.775ZM13 3.25c.048 0 .095.005.14.014h.01c.014.004.027.01.041.013.034.01.067.017.098.03.014.006.027.015.04.022.03.015.06.03.088.048l.014.01a.75.75 0 0 1 .1.083l5 5a.748.748 0 0 1 .219.53v10A1.75 1.75 0 0 1 17 20.75h-5.614c.192-.375.3-.8.3-1.25v-.25H17a.25.25 0 0 0 .25-.25V9.75H14A1.75 1.75 0 0 1 12.25 8V4.75H7a.25.25 0 0 0-.25.25v4.757a3.64 3.64 0 0 0-1.5.419V5c0-.966.784-1.75 1.75-1.75h6ZM5.31 16.188a.25.25 0 0 0-.25.25V19.5c0 .138.112.25.25.25h3.626a.25.25 0 0 0 .25-.25v-3.063a.25.25 0 0 0-.25-.25H5.31Zm1.66-3.938c-.654 0-1.219.551-1.219 1.275v1.162h2.437v-1.162c0-.723-.565-1.274-1.218-1.275ZM13.75 8c0 .138.112.25.25.25h2.19l-2.44-2.44V8Z"/> </svg> 
    `;
  }
}

customElements.define('jh-icon-file-lock', JhIconFileLock);