/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconBugFilled extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path d="M3.209 8.967a.75.75 0 0 1 1.038.216l.775 1.182a1.25 1.25 0 0 0 1.704.377l.147-.093a5.63 5.63 0 0 0 1.254 1.678c.808.75 1.892 1.352 3.123 1.527v8.016c-1.216-.018-1.932-.185-3.563-1.612-.333-.292-.64-.684-.921-1.132a6.577 6.577 0 0 1-.335-.602c-.31.147-.556.42-.662.77l-.425 1.422a.751.751 0 0 1-1.438-.432l.427-1.42a2.747 2.747 0 0 1 1.6-1.758 7.395 7.395 0 0 1-.157-2.197 1.25 1.25 0 0 0-.738.368l-1.505 1.55a.75.75 0 0 1-1.076-1.045l1.505-1.55a2.75 2.75 0 0 1 1.972-.834h.086c.081-.329.178-.657.291-.982a2.747 2.747 0 0 1-2.544-1.229l-.774-1.182a.75.75 0 0 1 .216-1.038Zm16.544.216a.75.75 0 0 1 1.254.822l-.775 1.182a2.748 2.748 0 0 1-2.567 1.227c.111.326.207.654.285.984h.115a2.75 2.75 0 0 1 1.973.834l1.505 1.55a.75.75 0 0 1-1.076 1.045l-1.505-1.55a1.251 1.251 0 0 0-.777-.373 7.624 7.624 0 0 1-.154 2.187 2.749 2.749 0 0 1 1.636 1.772l.427 1.421a.751.751 0 0 1-1.438.432l-.426-1.422a1.248 1.248 0 0 0-.682-.778c-.1.211-.21.42-.335.626-.28.463-.582.853-.9 1.116-1.478 1.22-2.302 1.53-3.563 1.598v-8.01c1.208-.185 2.271-.78 3.066-1.519a5.624 5.624 0 0 0 1.266-1.704l.192.12a1.25 1.25 0 0 0 1.703-.378l.776-1.182Zm-4.485-.399c.393.02.554.087.61.127.016.01.022.018.03.033.01.023.03.085.03.213-.001.546-.378 1.361-1.142 2.072-.745.691-1.749 1.178-2.824 1.178-1.076 0-2.08-.487-2.825-1.178-.764-.71-1.14-1.526-1.141-2.072 0-.128.02-.19.03-.213a.07.07 0 0 1 .028-.033c.057-.04.218-.107.61-.127.377-.019.84.008 1.415.044.56.036 1.204.08 1.883.08s1.323-.044 1.882-.08c.575-.036 1.039-.063 1.415-.044Zm1.877-6.472a1 1 0 1 1-.568 1.824c-.52.102-.73.134-1.139.305a.298.298 0 0 0-.062.068c-.056.074-.12.187-.202.364-.11.236-.262.604-.469.974a2.954 2.954 0 0 1 .255 1.431c-.38.002-.79.027-1.2.053-.57.036-1.165.076-1.788.076s-1.22-.04-1.788-.076c-.39-.025-.781-.048-1.145-.052a2.953 2.953 0 0 1 .31-1.548c-.175-.33-.307-.646-.407-.858a2.148 2.148 0 0 0-.202-.364.296.296 0 0 0-.062-.068c-.409-.171-.62-.203-1.14-.305A1 1 0 1 1 7.71 2.64c.554.108.968.174 1.55.419.593.25.874.824 1.04 1.177l.14.306a2.955 2.955 0 0 1 3.21.055l.166-.36c.166-.354.447-.929 1.04-1.178.58-.245.995-.311 1.548-.42a.999.999 0 0 1 .74-.326Z"/> </svg> 
    `;
  }
}

customElements.define('jh-icon-bug-filled', JhIconBugFilled);