/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconPiggyBank extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M13 3.469a1 1 0 1 0 0 2 1 1 0 0 0 0-2Zm-2.5 1a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0ZM7.245 7.032c-.497-.277-.776-.229-.888-.164-.113.065-.295.284-.302.86-.007.549.16 1.27.538 2.027a.75.75 0 0 1-.099.82c-.304.359-.561.76-.761 1.191a.75.75 0 0 1-.444.397l-1.789.596v1.665l1.469.49a.75.75 0 0 1 .484.505c.2.7.544 1.342.998 1.891a.75.75 0 0 1-.048 1.008l-.842.842 1.06 1.061 1.185-1.185a.75.75 0 0 1 .8-.169 5.234 5.234 0 0 0 1.894.352H14a5.23 5.23 0 0 0 2.08-.428.75.75 0 0 1 .827.158l1.272 1.272.88-.881-.989-.99a.75.75 0 0 1-.044-1.012A5.25 5.25 0 0 0 14 8.718h-3.5a5.28 5.28 0 0 0-1.008.097.75.75 0 0 1-.767-.32c-.466-.698-1.004-1.198-1.48-1.463Zm2.445.235C9.18 6.6 8.587 6.062 7.975 5.722c-.706-.394-1.595-.6-2.368-.153-.777.449-1.042 1.327-1.052 2.14-.009.706.166 1.496.495 2.277-.198.27-.376.554-.532.853l-2.005.668A.75.75 0 0 0 2 12.22v2.746c0 .322.207.61.513.711l1.62.54c.189.534.443 1.037.752 1.5l-.915.914a.75.75 0 0 0 0 1.06l2.121 2.122a.75.75 0 0 0 1.06 0l1.385-1.384a6.75 6.75 0 0 0 1.964.29H14a6.74 6.74 0 0 0 2.191-.363l1.457 1.457a.75.75 0 0 0 1.061 0l1.942-1.942a.75.75 0 0 0 0-1.06l-1.06-1.06a6.719 6.719 0 0 0 1.154-3.531h.505a.75.75 0 0 0 0-1.5h-.616A6.752 6.752 0 0 0 14 7.219h-3.5c-.274 0-.544.016-.81.048Zm.81 3.452a.75.75 0 0 1 .75-.75h3.5a.75.75 0 0 1 0 1.5h-3.5a.75.75 0 0 1-.75-.75Zm-2.5 2.5a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z" clip-rule="evenodd"/> </svg> 
    `;
  }
}

customElements.define('jh-icon-piggy-bank', JhIconPiggyBank);