/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconBuildingDome extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path d="M12 2.25a.75.75 0 0 1 .75.75v1.073A1.75 1.75 0 0 1 14 5.75v1.33a6.242 6.242 0 0 1 4.096 4.554c.088.04.173.08.253.124.207.113.415.257.58.442.169.19.321.461.321.8a1.2 1.2 0 0 1-.315.794c-.057.064-.12.121-.185.176v2.35a8.107 8.107 0 0 1 1.371.404c.25.104.498.235.696.406.194.167.433.457.433.87 0 .356-.18.623-.349.791a1.74 1.74 0 0 1-.151.132V22h-1.5v-3.96l.044-.023a10.046 10.046 0 0 0-1.414-.34c-1.483-.261-3.563-.427-5.88-.427-2.317 0-4.396.166-5.88.428a10.05 10.05 0 0 0-1.415.339l.045.022V22h-1.5v-3.077a1.621 1.621 0 0 1-.151-.132A1.119 1.119 0 0 1 2.75 18c0-.413.24-.703.433-.87.198-.171.447-.302.696-.406.37-.155.837-.288 1.371-.404v-2.35a1.675 1.675 0 0 1-.185-.176A1.2 1.2 0 0 1 4.75 13c0-.339.152-.61.321-.8a2.14 2.14 0 0 1 .58-.442c.08-.043.164-.084.252-.124A6.246 6.246 0 0 1 10 7.08V5.75a1.75 1.75 0 0 1 1.25-1.677V3a.75.75 0 0 1 .75-.75ZM7.5 18.5a.75.75 0 0 1 .75.75V22h-1.5v-2.75a.75.75 0 0 1 .75-.75Zm3-.25a.75.75 0 0 1 .75.75v3h-1.5v-3a.75.75 0 0 1 .75-.75Zm3 0a.75.75 0 0 1 .75.75v3h-1.5v-3a.75.75 0 0 1 .75-.75Zm3 .25a.75.75 0 0 1 .75.75V22h-1.5v-2.75a.75.75 0 0 1 .75-.75ZM12 12.25c-1.755 0-3.321.165-4.428.42-.46.106-.812.223-1.057.335l.235.13v2.93c1.471-.198 3.29-.315 5.25-.315s3.779.117 5.25.315v-2.93l.234-.13a5.791 5.791 0 0 0-1.056-.335c-1.107-.255-2.673-.42-4.428-.42Zm-3.35 1a.75.75 0 0 1 .75.75v.5a.75.75 0 0 1-1.5 0V14a.75.75 0 0 1 .75-.75Zm6.7 0a.75.75 0 0 1 .75.75v.5a.75.75 0 0 1-1.5 0V14a.75.75 0 0 1 .75-.75ZM12 13a.75.75 0 0 1 .75.75v.5a.75.75 0 0 1-1.5 0v-.5A.75.75 0 0 1 12 13Zm0-4.75c-1.26 0-2.468.5-3.358 1.392a4.73 4.73 0 0 0-1.001 1.481c1.195-.235 2.717-.373 4.359-.373 1.641 0 3.162.138 4.356.373A4.72 4.72 0 0 0 12 8.25Zm-.25-2.75a.25.25 0 0 0-.25.25v1h1v-1a.25.25 0 0 0-.25-.25h-.5Z"/> </svg> 
    `;
  }
}

customElements.define('jh-icon-building-dome', JhIconBuildingDome);