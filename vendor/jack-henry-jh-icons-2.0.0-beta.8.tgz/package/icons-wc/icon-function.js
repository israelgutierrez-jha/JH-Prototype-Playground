/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconFunction extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path d="M7.24 6.123a1.75 1.75 0 0 1 2.77-1.082l.83.623a.75.75 0 0 1-.899 1.2l-.832-.623a.25.25 0 0 0-.395.154L8.279 8.75H9.5a.75.75 0 0 1 0 1.5H8.003l-1.418 7.679a1.75 1.75 0 0 1-2.794 1.063l-.75-.582a.751.751 0 0 1 .92-1.184l.75.582a.25.25 0 0 0 .4-.152l1.367-7.406H5.5a.75.75 0 0 1 0-1.5h1.254l.485-2.627Zm4.777 3.457a.75.75 0 0 1 1.043 1.078 4.289 4.289 0 0 0-1.31 3.092 4.29 4.29 0 0 0 1.31 3.092.75.75 0 0 1-1.043 1.078 5.79 5.79 0 0 1-1.767-4.17 5.79 5.79 0 0 1 1.767-4.17Zm7.014.019a.75.75 0 0 1 1.06-.018 5.79 5.79 0 0 1 1.766 4.169 5.79 5.79 0 0 1-1.765 4.169.75.75 0 0 1-1.043-1.077 4.29 4.29 0 0 0 1.308-3.092c0-1.213-.5-2.308-1.308-3.09a.751.751 0 0 1-.018-1.061Zm-1.811 2.12a.75.75 0 1 1 1.06 1.061l-.97.97.97.97a.75.75 0 1 1-1.06 1.06l-.97-.97-.97.97a.75.75 0 0 1-1.06-1.06l.97-.97-.97-.97a.75.75 0 0 1 1.06-1.06l.97.97.97-.97Z"/> </svg> 
    `;
  }
}

customElements.define('jh-icon-function', JhIconFunction);