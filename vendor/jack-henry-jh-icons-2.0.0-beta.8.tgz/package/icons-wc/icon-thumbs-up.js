/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconThumbsUp extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path d="M13.254 4.225c.305-.056.606-.014.894.088.505.18.996.498 1.327 1.021.332.525.451 1.176.363 1.923-.075.633-.335 1.3-.587 1.835.23-.021.475-.042.728-.058a16.07 16.07 0 0 1 1.788-.028c.537.027 1.14.103 1.577.328.785.406 1.28 1.173 1.313 1.967.017.402-.087.819-.345 1.175a1.81 1.81 0 0 1-.15.18c.258.43.358.926.267 1.417a1.974 1.974 0 0 1-.763 1.217 2.41 2.41 0 0 1 .02 1.434c-.135.458-.443.95-.912 1.249.026.097.045.197.054.299.044.48-.106.92-.367 1.278-.504.691-1.415 1.096-2.384 1.196a.763.763 0 0 1-.077.005c-1.129 0-1.934.05-2.745.078-.81.027-1.588.028-2.588-.083-1.02-.113-2.01-.379-2.734-.61-.157-.05-.302-.1-.433-.146V20a.75.75 0 0 1-.75.75h-4A.75.75 0 0 1 2 20v-9a.75.75 0 0 1 .75-.75h4c.024 0 .047 0 .07.003l.131-.066c.174-.089.42-.22.702-.387.572-.338 1.268-.805 1.828-1.341a6.563 6.563 0 0 0 1.141-1.439c.254-.42.525-.94.924-1.4l.233-.277.226-.267c.145-.168.312-.35.502-.5a1.67 1.67 0 0 1 .747-.351Zm.25 1.482a.406.406 0 0 0-.069.046c-.072.057-.163.15-.295.304-.065.074-.132.155-.21.248-.075.09-.16.191-.25.296-.288.332-.454.664-.775 1.195a8.055 8.055 0 0 1-1.386 1.746c-.679.649-1.484 1.183-2.102 1.549-.312.184-.584.33-.78.43-.05.027-.097.049-.137.069v6.802l.085.034c.192.073.47.174.805.281.674.215 1.56.45 2.443.548.903.1 1.604.1 2.371.075.753-.025 1.606-.077 2.741-.08.695-.076 1.134-.35 1.303-.583.076-.105.093-.189.087-.26-.007-.076-.048-.217-.227-.41a.75.75 0 0 1 .648-1.253.322.322 0 0 0 .267-.074.772.772 0 0 0 .225-.373.874.874 0 0 0 .019-.46c-.03-.112-.077-.152-.114-.171a.751.751 0 0 1 .205-1.402c.43-.083.567-.311.596-.465.03-.165-.025-.441-.374-.677a.75.75 0 0 1 .217-1.344c.18-.05.26-.127.299-.18a.366.366 0 0 0 .062-.235c-.009-.22-.162-.52-.502-.696-.126-.065-.442-.136-.967-.163a14.612 14.612 0 0 0-1.615.027 28.77 28.77 0 0 0-1.904.189l-.123.017-.04.005h-.001a.75.75 0 0 1-.736-1.154l.003-.001c0-.002.003-.006.006-.01l.03-.047a10.845 10.845 0 0 0 .463-.821c.272-.537.519-1.147.576-1.628.057-.49-.033-.775-.141-.945-.11-.173-.29-.312-.56-.408a.472.472 0 0 0-.102-.027c-.017-.002-.023 0-.024 0 0 0-.005 0-.016.006ZM3.5 19.25H6v-7.5H3.5v7.5Z"/> </svg> 
    `;
  }
}

customElements.define('jh-icon-thumbs-up', JhIconThumbsUp);