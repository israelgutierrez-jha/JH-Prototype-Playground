/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconViewfinderIdCard extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path d="M21.25 17.498a.75.75 0 0 1 .75.75v.957l.002.001v1.046a1.75 1.75 0 0 1-1.75 1.749h-1.046V22h-.954a.75.75 0 0 1 0-1.5h1.5v.001h.5a.25.25 0 0 0 .25-.25v-.503H20.5v-1.5a.75.75 0 0 1 .75-.75ZM2.751 17.5a.75.75 0 0 1 .75.75v1.5h-.002v.5c0 .138.112.25.25.25h2.003a.75.75 0 0 1 0 1.5H3.749a1.75 1.75 0 0 1-1.75-1.75v-1.046h.002v-.954a.75.75 0 0 1 .75-.75ZM17.546 7.01c1.044.104 1.956.96 1.956 2.127v5.725c0 1.245-1.038 2.136-2.167 2.137H6.665c-1.13 0-2.167-.892-2.167-2.137V9.137C4.498 7.892 5.536 7 6.665 7h10.67l.21.01ZM6.665 8.5c-.368 0-.667.286-.667.637v5.725c0 .351.299.637.667.637h10.67c.367 0 .667-.286.667-.637V9.137c0-.351-.3-.636-.667-.637H6.665Zm9.584 4.901a.497.497 0 0 1 0 .993h-2.502a.496.496 0 0 1 0-.993h2.502ZM9.567 8.977c.45 0 .933.14 1.312.468.397.344.63.853.607 1.456v.01a7.1 7.1 0 0 1-.102.884l.039.018c.328.161 1.004.582 1.004 1.403v.36a.75.75 0 0 1-1.5 0v-.308a.712.712 0 0 0-.168-.11 1.794 1.794 0 0 0-.397-.137v-.002a.75.75 0 0 1-.579-.94 5.48 5.48 0 0 0 .203-1.24c.005-.156-.045-.221-.089-.259a.511.511 0 0 0-.328-.103.528.528 0 0 0-.336.106c-.048.042-.101.111-.097.27.02.415.087.826.202 1.224a.752.752 0 0 1-.57.942l-.02.005a1.85 1.85 0 0 0-.367.133.708.708 0 0 0-.164.109v.31a.75.75 0 0 1-1.5 0v-.36c0-.812.663-1.234.987-1.398l.034-.016a6.865 6.865 0 0 1-.101-.895l-.001-.014c-.015-.604.224-1.108.62-1.449.38-.325.862-.467 1.311-.467Zm6.678 2.682a.496.496 0 0 1 0 .99h-2.5a.494.494 0 0 1 0-.99h2.5Zm0-1.743a.496.496 0 0 1 0 .99h-2.5a.495.495 0 0 1 0-.99h2.5ZM5.75 2a.75.75 0 0 1 0 1.5h-2a.25.25 0 0 0-.25.25v2.003a.75.75 0 0 1-1.5 0V3.75C2 2.784 2.784 2 3.75 2h2Zm14 .001h.503c.966 0 1.75.784 1.75 1.751v1.046L22 4.797v.954a.75.75 0 0 1-1.5 0v-1.5h.003v-.5a.25.25 0 0 0-.25-.25h-1.046V3.5h-.957a.75.75 0 0 1 0-1.5h1.5v.001Z"/> </svg> 
    `;
  }
}

customElements.define('jh-icon-viewfinder-id-card', JhIconViewfinderIdCard);