/**
* SPDX-FileCopyrightText: 2025 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/
import {LitElement, css, html} from 'lit';

export default class JhIconBoxOpen extends LitElement {
  /** @type {ElementInternals} */
  #internals;

  static get styles() {
    return css`
      :host {
        fill: var(
          --jh-icon-color-fill,
          var(--jh-color-content-secondary-enabled)
        );
        width: var(--icon-size);
        height: var(--icon-size);
        display: inline-block;
      }
      :host([size='x-small']) {
        --icon-size: var(
          --jh-icon-size-extra-small,
          var(--jh-dimension-400)
        );
      }
      :host([size='small']) {
        --icon-size: var(
          --jh-icon-size-small,
          var(--jh-dimension-500)
        );
      }
      :host([size='medium']) {
        --icon-size: var(
          --jh-icon-size-medium,
          var(--jh-dimension-600)
        );
      }
      :host([size='large']) {
        --icon-size: var(
          --jh-icon-size-large,
          var(--jh-dimension-900)
        );
      }
      :host([size='x-large']) {
        --icon-size: var(
          --jh-icon-size-extra-large,
          var(--jh-dimension-1400)
        );
      }
      svg {
        width: 100%;
        height: 100%;
      }
    `;
  }

  static get properties() {
    return {
      /**
      * The size of the icon.
      */
      size: {
        type: String, reflect: true 
      }
    }
  }

  constructor() {
    super();
    this.#internals = this.attachInternals();
    this.#internals.role = 'graphics-symbol';
    this.#internals.ariaHidden = 'true';

    /** @type {'x-small'|'small'|'medium'|'large'|'x-large'} */
    this.size = 'medium';
  }

  render() {
    return html`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path d="M11.775 3.873a.751.751 0 0 1 .52.026l6.917 2.965.009.004.034.016.033.018c.015.008.03.016.043.026l.01.007.03.022.02.016.01.007.016.015a.773.773 0 0 1 .083.088c.003.004.008.008.01.012l2.333 3.014a.75.75 0 0 1-.297 1.149l-1.878.803v4.385c0 .3-.18.571-.455.69L12.296 20.1a.749.749 0 0 1-.297.06.752.752 0 0 1-.288-.059c-.002 0-.004 0-.006-.002l-6.918-2.964a.751.751 0 0 1-.454-.69v-4.384l-1.879-.804a.75.75 0 0 1-.297-1.149L4.49 7.095l.011-.012a.75.75 0 0 1 .166-.153l.004-.002.01-.007a.73.73 0 0 1 .088-.048l.018-.009L11.704 3.9l.071-.026Zm2.853 10.349a.75.75 0 0 1-.889-.23l-.99-1.28v5.561l5.419-2.32v-3.249l-3.54 1.518Zm-8.795 1.73 5.416 2.32v-5.557l-.988 1.277a.75.75 0 0 1-.889.23l-3.539-1.517v3.247ZM3.937 10.26l5.493 2.354 1.385-1.787L5.32 8.472 3.937 10.26Zm9.249.567 1.384 1.787 5.494-2.354-1.385-1.788-5.493 2.355ZM6.984 7.553l4.873 2.087a.755.755 0 0 1 .284 0l4.872-2.087-5.014-2.149-5.015 2.149Z"/> </svg>   
    `;
  }
}

customElements.define('jh-icon-box-open', JhIconBoxOpen);