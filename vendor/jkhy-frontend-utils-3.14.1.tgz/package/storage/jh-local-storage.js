/*
 * Copyright (c) 2026. Jack Henry & Associates, Inc.
 * All rights reserved.
 */
import { StorageProvider } from './storage-provider.js';
class JhLocalStorage extends StorageProvider {
    constructor() {
        super(window.localStorage);
    }
}
export const jhLocalStorage = new JhLocalStorage();
