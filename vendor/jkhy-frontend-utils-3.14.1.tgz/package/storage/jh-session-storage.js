/*
 * Copyright (c) 2026. Jack Henry & Associates, Inc.
 * All rights reserved.
 */
import { StorageProvider } from './storage-provider.js';
class JhSessionStorage extends StorageProvider {
    constructor() {
        super(window.sessionStorage);
    }
}
export const jhSessionStorage = new JhSessionStorage();
