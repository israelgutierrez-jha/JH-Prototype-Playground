export declare abstract class StorageProvider {
    private readonly storage;
    constructor(storage: Storage);
    /**
     * Retrieves an item from storage.
     * Attempts to parse the item as JSON; returns the raw value if parsing fails.
     * @param key The key of the item to retrieve.
     * @returns The parsed value or null if not found. Note: T is a type hint and not validated at runtime.
     */
    getItem<T = unknown>(key: string): T | null;
    /**
     * Sets an item in storage.
     * Automatically stringifies values before storage.
     * @param key The key to store the value under.
     * @param value The value to store.
     */
    setItem(key: string, value: unknown): void;
    /**
     * Removes an item from storage.
     * @param key The key of the item to remove.
     */
    removeItem(key: string): void;
    /**
     * Clears all items from storage.
     */
    clear(): void;
}
