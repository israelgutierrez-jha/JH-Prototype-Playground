/*
 * Copyright (c) 2026. Jack Henry & Associates, Inc.
 * All rights reserved.
 */
export class StorageProvider {
    constructor(storage) {
        this.storage = storage;
    }
    /**
     * Retrieves an item from storage.
     * Attempts to parse the item as JSON; returns the raw value if parsing fails.
     * @param key The key of the item to retrieve.
     * @returns The parsed value or null if not found. Note: T is a type hint and not validated at runtime.
     */
    getItem(key) {
        const item = this.storage.getItem(key);
        if (item === null)
            return null;
        try {
            return JSON.parse(item);
        }
        catch {
            return item;
        }
    }
    /**
     * Sets an item in storage.
     * Automatically stringifies values before storage.
     * @param key The key to store the value under.
     * @param value The value to store.
     */
    setItem(key, value) {
        const serialized = JSON.stringify(value);
        this.storage.setItem(key, serialized);
    }
    /**
     * Removes an item from storage.
     * @param key The key of the item to remove.
     */
    removeItem(key) {
        this.storage.removeItem(key);
    }
    /**
     * Clears all items from storage.
     */
    clear() {
        this.storage.clear();
    }
}
