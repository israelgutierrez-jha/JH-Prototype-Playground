import { StorageProvider } from './storage-provider.js';
declare class JhLocalStorage extends StorageProvider {
    constructor();
}
export declare const jhLocalStorage: JhLocalStorage;
export {};
