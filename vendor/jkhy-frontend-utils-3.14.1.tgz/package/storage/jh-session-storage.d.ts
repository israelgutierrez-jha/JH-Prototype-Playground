import { StorageProvider } from './storage-provider.js';
declare class JhSessionStorage extends StorageProvider {
    constructor();
}
export declare const jhSessionStorage: JhSessionStorage;
export {};
