import { ObservableTransform, Observer, SubscriptionHandle, OBSERVER_NO_VALUE } from './observable.types.js';
import { ObservationSource } from './observation-source.js';
/**
 * Represents a stream of values that can be observed over time.
 *
 * In general, this class should not be instantiated directly.
 * Prefer {@link ObservationSource.toObservable | `ObservationSource::toObservable()`}.
 */
export declare class Observable<T> {
    get completed(): boolean;
    /**
     * An `ObservationSource` which drives the production of
     * values through this `Observable`.
     *
     * Since all `ObservationSource` instances are also an `Observable`,
     * in these cases, the `source` and the instance are one and the same.
     */
    protected source: ObservationSource<T>;
    protected _completed: boolean;
    protected observers: Map<string, (value: T) => void>;
    protected errorObservers: Map<string, (e: Error) => void>;
    protected completionObservers: Map<string, () => void>;
    protected lastValue?: T | typeof OBSERVER_NO_VALUE;
    constructor(source?: ObservationSource<T>);
    observe(observer: Partial<Observer<T>>): SubscriptionHandle;
    /**
     * @param emitLastValue If `true`, immediately re-emit the last value seen by this observable only to the subscriber.
     * @param defer If `true`, defers invoking the underlying value source until a later time.
     */
    subscribe(callback: Observer<T>['onNext'], emitLastValue?: boolean, defer?: boolean): SubscriptionHandle;
    listenForError(callback: Observer<T>['onError']): SubscriptionHandle;
    listenForCompletion(callback: Observer<T>['onComplete']): SubscriptionHandle;
    pipe<R>(transform: ObservableTransform<T, R>): Observable<R>;
    /**
     * Conditionally allow events from one event stream into another.
     *
     * @param predicate Function that receives a value of would-be value emission
     * and only allows it into the new stream if it passes the predicate test with a `true` result.
     */
    filter(predicate: (value: T) => boolean): Observable<T>;
    /**
     * Creates a a `Promise` representation of the `Observable`.
     *
     * Since `Promise` semantics are such that they can only
     * complete once, this will only be fulfilled with
     * last emission from the source `Observable`.
     *
     * @returns A `Promise` fulfilled with the most recent value of the source observable.
     */
    toPromise(emitLast?: boolean): Promise<T>;
    protected guardCompletion(): void;
    protected clearSubscriptions(): void;
    private initSource;
}
