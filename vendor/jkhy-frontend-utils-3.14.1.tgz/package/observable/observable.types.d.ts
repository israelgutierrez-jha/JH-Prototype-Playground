export interface Observer<T> {
    onNext: (value: T) => void;
    onError: (e: Error) => void;
    onComplete: () => void;
}
export interface SubscriptionHandle {
    unsubscribe: () => void;
}
export interface ValueSource<T> {
    emit: (value: T) => void;
    complete: () => void;
}
export type ValueProducer<T> = (source: ValueSource<T>) => void;
export type ObservableTransform<T, R> = (value: T) => R | Promise<R>;
/**
 * Initial value to indicate that an observer has not yet emitted.
 *
 * This is primarily used to allow for void observables that emit `undefined` as a valid payload.
 */
export declare const OBSERVER_NO_VALUE: unique symbol;
