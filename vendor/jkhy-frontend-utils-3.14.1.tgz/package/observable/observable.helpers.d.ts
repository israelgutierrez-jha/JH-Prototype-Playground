import { Observable } from './observable.js';
/**
 * Merge two `Observable` streams together to create a combined stream of values.
 */
export declare function combine<Type1, Type2>(o1: Observable<Type1>, o2: Observable<Type2>): Observable<Type1 | Type2>;
export declare function combineMulti<T>(...observables: Observable<T>[]): Observable<T>;
/**
 * Create a new observable from a source that limits
 * the number of emissions to once per `duration`.
 *
 * @param duration Minimum amount of time (in milliseconds) that must pass
 * since the last emission for an observable to emit again.
 */
export declare function throttle<T>(o: Observable<T>, duration: number): Observable<T>;
export declare function fromArray<T>(values: T[], completeObservable?: boolean): Observable<T>;
export declare function fromPromise<T>(p: Promise<T> | (() => Promise<T>), completeObservable?: boolean): Observable<T>;
export declare function fromEvent<EventType extends Event = Event>(e: EventTarget, eventName: string): Observable<EventType>;
export declare function range(start: number, end: number): Observable<number>;
/**
 * Create an `Observable` that emits at regular intervals.
 *
 * @param delay Time in milliseconds between Observable emission.
 */
export declare function interval(delay: number): Observable<number>;
/**
 * Create an `Observable` that emits once after a delay.
 *
 * @param delay Time in milliseconds until `Observable` emission.
 */
export declare function timer(delay: number, completeObservable?: boolean): Observable<void>;
/**
 * Create a stream that emits every second until it reaches zero
 * starting with the specified number of seconds.
 *
 * @param start Amount of time in seconds to begin counting down.
 */
export declare function countdown(start: number): Observable<number>;
