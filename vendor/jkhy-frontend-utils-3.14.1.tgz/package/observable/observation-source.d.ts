import { Observable } from './observable.js';
import type { ObservableTransform, ValueProducer } from './observable.types.js';
/**
 * Represents the source of an {@link Observable | `Observable`}.
 * There is a 1:1 relationship of sources to observables.
 *
 * Enforces a separation between emitting and listening capabilities.
 * Restricts consumers of a stream to only listening for values
 * while producers may do both.
 */
export declare class ObservationSource<T> extends Observable<T> {
    private valueProducer?;
    private deferred;
    private observable?;
    private initialized;
    /**
     * @param valueProducer Function to emit values internally
     * from the `ObservationSource`. Runs deferred after the first subscription.
     *
     * @param deferred If `true`, value production will not begin on subscription.
     * An explicit call to  `init()` must be made.
     */
    constructor(valueProducer?: ValueProducer<T> | undefined, deferred?: boolean);
    /**
     * Emit values as an external consumer of the `ObservationSource` and
     * derived `Observable`, if any.
     */
    emit(value: T): this;
    setError(e: Error): void;
    complete(): this;
    pipeSource<R>(transform: ObservableTransform<T, R>, defer?: boolean): ObservationSource<R>;
    filterSource(predicate: (value: T) => boolean, defer?: boolean): ObservationSource<T>;
    toObservable(): Observable<T>;
    subscribe(...args: Parameters<Observable<T>['subscribe']>): import("./observable.types.js").SubscriptionHandle;
    /**
     * @param deferred If `true`, do not begin producing values on subscription.
     */
    listenForCompletion(...args: Parameters<Observable<T>['listenForCompletion']>): import("./observable.types.js").SubscriptionHandle;
    /**
     * Initialize the observable with the provided value producer function.
     */
    init(): void;
}
