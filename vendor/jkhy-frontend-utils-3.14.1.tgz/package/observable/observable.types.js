/**
 * Initial value to indicate that an observer has not yet emitted.
 *
 * This is primarily used to allow for void observables that emit `undefined` as a valid payload.
 */
export const OBSERVER_NO_VALUE = Symbol('Observer non-value');
