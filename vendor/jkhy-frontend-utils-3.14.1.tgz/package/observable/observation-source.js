import { coerceError } from '../functions/index.js';
import { Observable } from './observable.js';
/**
 * Represents the source of an {@link Observable | `Observable`}.
 * There is a 1:1 relationship of sources to observables.
 *
 * Enforces a separation between emitting and listening capabilities.
 * Restricts consumers of a stream to only listening for values
 * while producers may do both.
 */
export class ObservationSource extends Observable {
    /**
     * @param valueProducer Function to emit values internally
     * from the `ObservationSource`. Runs deferred after the first subscription.
     *
     * @param deferred If `true`, value production will not begin on subscription.
     * An explicit call to  `init()` must be made.
     */
    constructor(valueProducer, deferred = false) {
        super();
        this.valueProducer = valueProducer;
        this.deferred = deferred;
        this.initialized = false;
    }
    /**
     * Emit values as an external consumer of the `ObservationSource` and
     * derived `Observable`, if any.
     */
    emit(value) {
        this.guardCompletion();
        this.lastValue = value;
        this.observers.forEach(callback => callback(value));
        return this;
    }
    setError(e) {
        this.errorObservers.forEach(callback => callback(e));
    }
    complete() {
        this.guardCompletion();
        this.completionObservers.forEach(callback => callback());
        this.clearSubscriptions();
        this._completed = true;
        return this;
    }
    pipeSource(transform, defer = false) {
        let nextStream = new ObservationSource(() => {
            this.init();
        }, defer);
        let sub = this.subscribe(v => {
            try {
                const transformResult = transform(v);
                if (transformResult instanceof Promise) {
                    transformResult
                        .then(result => nextStream.emit(result))
                        .catch(e => this.setError(coerceError(e)));
                }
                else {
                    nextStream.emit(transformResult);
                }
            }
            catch (e) {
                this.setError(coerceError(e));
            }
        });
        nextStream.listenForCompletion(() => {
            sub.unsubscribe();
            sub = null;
            nextStream = null;
        });
        return nextStream;
    }
    filterSource(predicate, defer = false) {
        let nextStream = new ObservationSource();
        let sub = this.subscribe(v => {
            try {
                if (predicate(v)) {
                    nextStream.emit(v);
                }
            }
            catch (e) {
                this.setError(coerceError(e));
            }
        }, defer);
        nextStream.listenForCompletion(() => {
            sub.unsubscribe();
            sub = null;
            nextStream = null;
        });
        return nextStream;
    }
    toObservable() {
        this.guardCompletion();
        if (!this.observable) {
            this.observable = new Observable(this);
        }
        return this.observable;
    }
    subscribe(...args) {
        const subscription = super.subscribe(...args);
        if (!this.deferred) {
            this.init();
        }
        return subscription;
    }
    /**
     * @param deferred If `true`, do not begin producing values on subscription.
     */
    listenForCompletion(...args) {
        const subscription = super.listenForCompletion(...args);
        if (!this.deferred) {
            this.init();
        }
        return subscription;
    }
    /**
     * Initialize the observable with the provided value producer function.
     */
    init() {
        if (this.initialized || !this.valueProducer) {
            return;
        }
        this.initialized = true;
        this.valueProducer({
            emit: (...args) => this.emit(...args),
            complete: (...args) => this.complete(...args),
        });
    }
}
