import { createUniqueId, exists } from '../functions/index.js';
import { OBSERVER_NO_VALUE, } from './observable.types.js';
/**
 * Represents a stream of values that can be observed over time.
 *
 * In general, this class should not be instantiated directly.
 * Prefer {@link ObservationSource.toObservable | `ObservationSource::toObservable()`}.
 */
export class Observable {
    get completed() {
        return this._completed;
    }
    constructor(source) {
        this._completed = false;
        this.observers = new Map();
        this.errorObservers = new Map();
        this.completionObservers = new Map();
        this.lastValue = OBSERVER_NO_VALUE;
        if (source) {
            this.source = source;
            // copy constructor
            this.observers = source.observers;
            this.errorObservers = source.errorObservers;
            this.completionObservers = source.completionObservers;
            this.lastValue = source.lastValue;
            source.subscribe(value => {
                this.lastValue = value;
            }, false);
            source.listenForCompletion(() => {
                this._completed = true;
            });
        }
        else {
            // hack since `ObservationSource` cannot provide
            // itself as a super() argument
            this.source = this;
        }
    }
    observe(observer) {
        this.guardCompletion();
        const { onNext, onError, onComplete } = observer;
        const subs = [
            onNext ? this.subscribe(onNext, false, true) : undefined,
            onError ? this.listenForError(onError) : undefined,
            onComplete ? this.listenForCompletion(onComplete) : undefined,
        ].filter(exists);
        this.initSource();
        return {
            unsubscribe: () => subs.forEach(s => s.unsubscribe()),
        };
    }
    /**
     * @param emitLastValue If `true`, immediately re-emit the last value seen by this observable only to the subscriber.
     * @param defer If `true`, defers invoking the underlying value source until a later time.
     */
    subscribe(callback, emitLastValue = false, defer = false) {
        this.guardCompletion();
        const id = createUniqueId();
        this.observers.set(id, callback);
        if (!defer) {
            this.initSource();
        }
        if (emitLastValue && this.lastValue !== OBSERVER_NO_VALUE) {
            callback(this.lastValue);
        }
        return {
            unsubscribe: () => {
                this.observers.delete(id);
            },
        };
    }
    listenForError(callback) {
        this.guardCompletion();
        const id = createUniqueId();
        this.errorObservers.set(id, callback);
        return {
            unsubscribe: () => {
                this.errorObservers.delete(id);
            },
        };
    }
    listenForCompletion(callback) {
        this.guardCompletion();
        const id = createUniqueId();
        this.completionObservers.set(id, callback);
        this.initSource();
        return {
            unsubscribe: () => {
                this.completionObservers.delete(id);
            },
        };
    }
    pipe(transform) {
        return this.source.pipeSource(transform, true).toObservable();
    }
    /**
     * Conditionally allow events from one event stream into another.
     *
     * @param predicate Function that receives a value of would-be value emission
     * and only allows it into the new stream if it passes the predicate test with a `true` result.
     */
    filter(predicate) {
        return this.source.filterSource(predicate, true).toObservable();
    }
    /**
     * Creates a a `Promise` representation of the `Observable`.
     *
     * Since `Promise` semantics are such that they can only
     * complete once, this will only be fulfilled with
     * last emission from the source `Observable`.
     *
     * @returns A `Promise` fulfilled with the most recent value of the source observable.
     */
    toPromise(emitLast = true) {
        // eslint-disable-next-line @typescript-eslint/no-this-alias
        const self = this;
        const subs = [];
        return new Promise((resolve, reject) => {
            const subscribeCallback = (value) => {
                subs.forEach(s => s.unsubscribe());
                resolve(value);
            };
            subs.push(self.subscribe(subscribeCallback, emitLast), self.listenForError(error => reject(error)));
        });
    }
    guardCompletion() {
        if (this._completed) {
            throw new Error('Cannot operate on a completed Observable.');
        }
    }
    clearSubscriptions() {
        this.observers.clear();
        this.completionObservers.clear();
        this.errorObservers.clear();
    }
    initSource() {
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        if (this.source !== this) {
            this.source.init();
        }
    }
}
