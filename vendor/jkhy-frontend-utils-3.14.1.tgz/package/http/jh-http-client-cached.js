import { JhHttpCache } from './jh-http-cache/jh-http-cache.js';
import { JhHttpClient } from './jh-http-client.js';
import { JhHttpResponseType, } from './jh-http-client.types.js';
/**
 * An HTTP client utilizing in-memory caching.
 */
export class JhHttpClientCached extends JhHttpClient {
    constructor(fetchFn, config, cache = new JhHttpCache()) {
        super(fetchFn, config);
        this.cache = cache;
    }
    async request(url, config) {
        const normalizedConfig = this.normalizeRequestConfig(config);
        const { maxAgeInSeconds, method, responseType, body } = normalizedConfig;
        const preserveResponse = responseType === JhHttpResponseType.Raw;
        const cacheParams = { url, method, body };
        const cacheEntry = this.cache.getEntry(cacheParams, maxAgeInSeconds);
        if (cacheEntry) {
            const response = await cacheEntry.responsePromise;
            return preserveResponse
                ? response.clone()
                : this.transformResponse(response, responseType);
        }
        const rawConfig = {
            ...normalizedConfig,
            responseType: JhHttpResponseType.Raw,
        };
        const responsePromise = super.request(url, rawConfig);
        const shouldCache = !(body instanceof FormData) && maxAgeInSeconds > 0;
        if (shouldCache) {
            this.cache.addEntry(cacheParams, responsePromise);
        }
        try {
            const response = await responsePromise;
            // remove bad responses or ones with no content
            if (!response.ok || response.status === 204) {
                this.cache.deleteEntry(cacheParams);
            }
            return this.transformResponse(response, responseType);
        }
        catch (e) {
            this.cache.deleteEntry(cacheParams);
            throw e;
        }
    }
    resetCachedValue(endpoint, config) {
        const { method } = config;
        const body = method === 'GET' ? undefined : config.body;
        this.cache.deleteEntry({ url: endpoint, method, body });
    }
    clearCache() {
        this.cache.clear();
    }
}
