import * as hash from 'object-hash';
export class JhHttpCache {
    get size() {
        return this.data.size;
    }
    constructor(hashFn = hash.default) {
        this.hashFn = hashFn;
        this.data = new Map();
        /**
         * Generating a hash is time-intensive.
         * Memoize them for later lookup.
         */
        this.hashedKeys = new WeakMap();
    }
    getEntry(params, maxAgeInSeconds = 0) {
        const key = this.generateCacheKey(params);
        if (!key) {
            return undefined;
        }
        const cachedEntry = this.data.get(key);
        if (!cachedEntry) {
            return undefined;
        }
        const now = new Date();
        const expiration = cachedEntry.cacheDate;
        expiration.setSeconds(expiration.getSeconds() + maxAgeInSeconds);
        if (expiration <= now) {
            this.deleteEntry(params);
            return undefined;
        }
        return cachedEntry;
    }
    addEntry(params, responsePromise) {
        const key = this.generateCacheKey(params);
        if (!key) {
            return;
        }
        const cacheEntry = {
            responsePromise,
            cacheDate: new Date(),
        };
        this.data.set(key, cacheEntry);
    }
    deleteEntry(params) {
        const key = this.generateCacheKey(params);
        if (!key) {
            return;
        }
        this.data.delete(key);
        this.hashedKeys.delete(params);
    }
    clear() {
        this.data.clear();
    }
    generateCacheKey(params) {
        if (params.body instanceof FormData) {
            // can't hash a form data object
            return undefined;
        }
        const previousKey = this.hashedKeys.get(params);
        if (previousKey) {
            return previousKey;
        }
        try {
            const key = this.hashFn(params);
            this.hashedKeys.set(params, key);
            return key;
        }
        catch (e) {
            console.error('Could not generate a cache key.', e instanceof Error ? e : undefined);
            return undefined;
        }
    }
}
