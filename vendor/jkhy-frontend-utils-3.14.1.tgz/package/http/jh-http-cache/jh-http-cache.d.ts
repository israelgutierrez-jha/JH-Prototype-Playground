import { HttpVerb } from '../../types/http.types.js';
import * as hash from 'object-hash';
export interface JhHttpCacheEntry {
    cacheDate: Date;
    responsePromise: Promise<Response>;
}
export interface CacheParams {
    url: string;
    method: HttpVerb;
    body?: object;
}
export declare class JhHttpCache {
    private hashFn;
    get size(): number;
    private readonly data;
    /**
     * Generating a hash is time-intensive.
     * Memoize them for later lookup.
     */
    private readonly hashedKeys;
    constructor(hashFn?: (obj: hash.NotUndefined) => string);
    getEntry(params: CacheParams, maxAgeInSeconds?: number): JhHttpCacheEntry | undefined;
    addEntry(params: CacheParams, responsePromise: Promise<Response>): void;
    deleteEntry(params: CacheParams): void;
    clear(): void;
    private generateCacheKey;
}
