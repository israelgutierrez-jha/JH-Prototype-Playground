import { HttpVerb } from '../types/http.types.js';
export interface JhHttpConfig {
    baseUrl: string | (() => Promise<string>);
    /**
     * The response header name used to send the auth token
     * for schemes that do not use authentication cookies.
     */
    authHeaderName?: string;
    /**
     * Provide custom headers to be used on every request.
     */
    createRequestHeaders?: () => Record<string, string> | void;
    /**
     * Hook to invoke to hydrate the auth token out-of-band (e.g., from session storage.).
     */
    getAuthToken: () => void;
    /**
     * Hook to invoke to set the auth token at a third party location (e.g., to session storage.).
     */
    setAuthToken: (token: string | undefined) => void;
}
export type JhRequestDefaultBody = object;
export declare enum JhHttpResponseType {
    /**
     * Deserializes the response JSON. Default response type.
     */
    Json = 0,
    /**
     * Deserializes the response as plaintext.
     */
    Text = 1,
    /**
     * If specified, will present the response as an `ArrayBuffer`.
     */
    ArrayBuffer = 2,
    /**
     * If specified, will present the response as a `Blob`.
     */
    Blob = 3,
    /**
     * If specified, will return the raw `Response` object.
     */
    Raw = 4
}
/**
 * Subset of relevant properties from the browser `fetch()` specification configuration shape.
 */
type RequestInitSubset = Pick<RequestInit, 'headers'>;
export type JhRequestConfigBase<Body extends object = JhRequestDefaultBody> = RequestInitSubset & {
    body?: Body;
    method?: HttpVerb;
    disableContentType?: boolean;
    maxAgeInSeconds?: number;
    responseType?: JhHttpResponseType;
    /**
     * If `true`, performs the request without the configured base URL (if any).
     */
    withoutBase?: boolean;
};
interface JhRequestConfigNoBody extends JhRequestConfigBase<never> {
    method: 'GET';
}
export interface JhRequestConfigWithBody<Body extends object = JhRequestDefaultBody> extends JhRequestConfigBase<Body> {
    method: 'POST' | 'PUT' | 'DELETE' | 'PATCH';
}
interface ConfigArrayBuffer extends JhRequestConfigNoBody {
    responseType: JhHttpResponseType.ArrayBuffer;
}
interface ConfigArrayBufferWithBody<Body extends object> extends JhRequestConfigWithBody<Body> {
    responseType: JhHttpResponseType.ArrayBuffer;
}
export type JhRequestConfigArrayBuffer<Body extends object = JhRequestDefaultBody> = ConfigArrayBuffer | ConfigArrayBufferWithBody<Body>;
interface ConfigBlob extends JhRequestConfigNoBody {
    responseType: JhHttpResponseType.Blob;
}
interface ConfigBlobWithBody<Body extends object> extends JhRequestConfigWithBody<Body> {
    responseType: JhHttpResponseType.Blob;
}
export type JhRequestConfigBlob<Body extends object = JhRequestDefaultBody> = ConfigBlob | ConfigBlobWithBody<Body>;
interface ConfigText extends JhRequestConfigNoBody {
    responseType: JhHttpResponseType.Text;
}
interface ConfigTextWithBody<Body extends object> extends JhRequestConfigWithBody<Body> {
    responseType: JhHttpResponseType.Text;
}
export type JhRequestConfigText<Body extends object = JhRequestDefaultBody> = ConfigText | ConfigTextWithBody<Body>;
interface ConfigRaw extends JhRequestConfigNoBody {
    responseType: JhHttpResponseType.Raw;
}
interface ConfigRawWithBody<Body extends object> extends JhRequestConfigWithBody<Body> {
    responseType: JhHttpResponseType.Raw;
}
export type JhRequestConfigRaw<Body extends object = JhRequestDefaultBody> = ConfigRaw | ConfigRawWithBody<Body>;
export type JhRequestConfig<Body extends object = JhRequestDefaultBody> = JhRequestConfigNoBody | JhRequestConfigWithBody<Body> | JhRequestConfigArrayBuffer<Body> | JhRequestConfigBlob<Body> | JhRequestConfigText<Body> | JhRequestConfigRaw<Body>;
export {};
