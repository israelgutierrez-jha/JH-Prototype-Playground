import { ObservationSource } from '../observable/observation-source.js';
import { JhHttpResponseType, } from './jh-http-client.types.js';
const DEFAULT_REQ_CONFIG = {
    method: 'GET',
    responseType: JhHttpResponseType.Json,
    withoutBase: false,
    disableContentType: false,
    maxAgeInSeconds: 0,
};
const DEFAULT_CONFIG = {
    baseUrl: '/',
    getAuthToken: () => { },
    setAuthToken: () => { },
};
/**
 * HTTP client that wraps a `fetch()` implementation to include
 * cross-cutting concerns such as headers, base URL, and auth token handling.
 */
export class JhHttpClient {
    get authToken() {
        if (!this._authToken && this.config.getAuthToken) {
            this._authToken = this.config.getAuthToken() ?? undefined;
        }
        return this._authToken;
    }
    set authToken(token) {
        if (token === this.authToken) {
            return;
        }
        this._authToken = token;
        if (this.config.setAuthToken) {
            this.config.setAuthToken(token);
        }
    }
    constructor(fetchFn = fetch, config = {}) {
        this.fetchFn = fetchFn;
        this.expirationStream = new ObservationSource();
        // eslint-disable-next-line @typescript-eslint/member-ordering
        this.sessionExpired$ = this.expirationStream.toObservable();
        this.errorSource = new ObservationSource();
        // eslint-disable-next-line @typescript-eslint/member-ordering
        this.error$ = this.errorSource.toObservable();
        this.config = normalizeConfig(config);
    }
    async request(url, config) {
        const { authHeaderName } = this.config;
        const normalizedConfig = this.normalizeRequestConfig(config);
        const { responseType, withoutBase } = normalizedConfig;
        const preserveResponse = responseType === JhHttpResponseType.Raw;
        const requestInit = this.createRequestInit(normalizedConfig);
        const resolvedUrl = await this.resolveUrl(url, withoutBase);
        const response = await this.fetchFn(resolvedUrl, requestInit);
        if (await this.isBadResponse(response)) {
            return this.handleBadResponse(response);
        }
        const authToken = authHeaderName ? response.headers.get(authHeaderName) : undefined;
        if (authToken) {
            this.authToken = authToken;
        }
        if (preserveResponse) {
            return response;
        }
        return this.transformResponse(response, responseType);
    }
    /**
     * Generate an error out of a response determined to be unusable.
     * Can be overridden in subclasses to enable error generation with more specific contexts.
     */
    async transformBadResponse(response) {
        try {
            const responseText = await response.clone().text();
            return new Error(responseText);
        }
        catch {
            return new Error('An unknown error occurred.');
        }
    }
    normalizeRequestConfig(config) {
        const normalizedConfig = {
            ...DEFAULT_REQ_CONFIG,
            ...config,
        };
        if (normalizedConfig.body === null) {
            normalizedConfig.body = undefined;
        }
        return normalizedConfig;
    }
    /**
     * Convert the response into the format specified by the config options.
     */
    async transformResponse(response, responseType) {
        // clone response so it can be deserialized multiple times if retrieved from cache
        const clone = response.clone();
        switch (responseType) {
            case JhHttpResponseType.Raw:
                return clone;
            case JhHttpResponseType.ArrayBuffer:
                return clone.arrayBuffer();
            case JhHttpResponseType.Blob:
                return clone.blob();
            case JhHttpResponseType.Json:
                return clone.json();
            case JhHttpResponseType.Text:
            default:
                return clone.text();
        }
    }
    /**
     * Check to determine if a response is considered in an error state
     * and should be handled or an exception thrown.
     *
     * Subclasses can override to layer additional logic or replace entirely.
     */
    isBadResponse(resp) {
        return Promise.resolve(!resp.ok);
    }
    async resolveUrl(url, ignoreBase) {
        if (ignoreBase) {
            return url;
        }
        let { baseUrl } = this.config;
        // TODO: normalize URL and baseURL to not include slashes
        if (baseUrl === '/') {
            return `/${url}`;
        }
        if (typeof baseUrl === 'function') {
            baseUrl = await baseUrl();
        }
        return `${baseUrl}/${url}`;
    }
    createRequestInit(config) {
        const { method, headers, disableContentType } = config;
        const autoHeaders = this.createHeaders(disableContentType, config.body);
        const reqConfig = {
            method,
            headers: {
                ...autoHeaders,
                ...headers,
            },
            credentials: 'include',
        };
        reqConfig.body = prepareBody(config);
        return reqConfig;
    }
    /**
     * Create the set of headers that should be included on every request to a TM API.
     */
    createHeaders(disableContentType = false, body) {
        const { authHeaderName, createRequestHeaders } = this.config;
        const autoHeaders = createRequestHeaders ? createRequestHeaders() || {} : {};
        const contentType = getContentType(body);
        if (!disableContentType && contentType) {
            autoHeaders['Content-Type'] = contentType;
        }
        if (this.authToken && authHeaderName) {
            autoHeaders[authHeaderName] = this.authToken;
        }
        return autoHeaders;
    }
    async handleBadResponse(response) {
        // unauthorized due to expired token
        if (response.status === 401) {
            this.authToken = undefined;
            this.expirationStream.emit();
        }
        const error = await this.transformBadResponse(response);
        this.errorSource.emit(error);
        throw error;
    }
}
function prepareBody(config) {
    const { disableContentType, body } = config;
    if (!body) {
        return undefined;
    }
    else if (disableContentType || body instanceof File || body instanceof FormData) {
        return body;
    }
    // assume body is a JSON post payload if it doesn't meet other criteria
    else {
        return JSON.stringify(body);
    }
}
function getContentType(body) {
    if (body instanceof FormData) {
        // forms containing binary data should use multipart/form-data;
        // however, the string boundary must be generated by the browser
        // so we cannot set the content type explicitly here and instead
        // should let it be inferred
        return formHasFile(body) ? undefined : 'application/x-www-form-urlencoded';
    }
    else if (body instanceof File) {
        return 'application/octet-stream';
    }
    else {
        return 'application/json';
    }
}
function normalizeConfig(config) {
    return {
        ...DEFAULT_CONFIG,
        ...config,
    };
}
function formHasFile(data) {
    return Array.from(data.values()).some(value => value instanceof File);
}
