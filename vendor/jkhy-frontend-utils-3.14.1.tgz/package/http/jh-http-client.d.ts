import { FetchFn } from '../types/http.types.js';
import { JhHttpConfig, JhHttpResponseType, JhRequestConfig, JhRequestConfigBase, JhRequestConfigArrayBuffer, JhRequestConfigBlob, JhRequestConfigRaw, JhRequestConfigText } from './jh-http-client.types.js';
type MinReqConfig = Required<Pick<JhRequestConfigBase, 'method' | 'responseType' | 'withoutBase' | 'disableContentType' | 'maxAgeInSeconds'>> & Pick<JhRequestConfigBase, 'body'>;
/**
 * HTTP client that wraps a `fetch()` implementation to include
 * cross-cutting concerns such as headers, base URL, and auth token handling.
 */
export declare class JhHttpClient {
    private readonly fetchFn;
    get authToken(): string | undefined;
    set authToken(token: string | undefined);
    private readonly config;
    private readonly expirationStream;
    readonly sessionExpired$: import("../observable/observable.js").Observable<void>;
    private readonly errorSource;
    readonly error$: import("../observable/observable.js").Observable<Error>;
    private _authToken?;
    constructor(fetchFn?: FetchFn, config?: Partial<JhHttpConfig>);
    request(url: string, config: JhRequestConfigText): Promise<string>;
    request(url: string, config: JhRequestConfigArrayBuffer): Promise<ArrayBuffer>;
    request(url: string, config: JhRequestConfigRaw): Promise<Response>;
    request(url: string, config: JhRequestConfigBlob): Promise<Blob>;
    request<T>(url: string, config?: JhRequestConfig): Promise<T>;
    /**
     * Generate an error out of a response determined to be unusable.
     * Can be overridden in subclasses to enable error generation with more specific contexts.
     */
    protected transformBadResponse(response: Response): Promise<Error>;
    protected normalizeRequestConfig(config?: Partial<JhRequestConfigBase>): MinReqConfig;
    /**
     * Convert the response into the format specified by the config options.
     */
    protected transformResponse<T extends object>(response: Response, responseType: JhHttpResponseType): Promise<string | Blob | ArrayBuffer | Response | T>;
    /**
     * Check to determine if a response is considered in an error state
     * and should be handled or an exception thrown.
     *
     * Subclasses can override to layer additional logic or replace entirely.
     */
    protected isBadResponse(resp: Response): Promise<boolean>;
    private resolveUrl;
    private createRequestInit;
    /**
     * Create the set of headers that should be included on every request to a TM API.
     */
    private createHeaders;
    private handleBadResponse;
}
export {};
