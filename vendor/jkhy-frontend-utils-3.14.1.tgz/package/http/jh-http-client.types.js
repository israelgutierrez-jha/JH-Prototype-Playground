export var JhHttpResponseType;
(function (JhHttpResponseType) {
    /**
     * Deserializes the response JSON. Default response type.
     */
    JhHttpResponseType[JhHttpResponseType["Json"] = 0] = "Json";
    /**
     * Deserializes the response as plaintext.
     */
    JhHttpResponseType[JhHttpResponseType["Text"] = 1] = "Text";
    /**
     * If specified, will present the response as an `ArrayBuffer`.
     */
    JhHttpResponseType[JhHttpResponseType["ArrayBuffer"] = 2] = "ArrayBuffer";
    /**
     * If specified, will present the response as a `Blob`.
     */
    JhHttpResponseType[JhHttpResponseType["Blob"] = 3] = "Blob";
    /**
     * If specified, will return the raw `Response` object.
     */
    JhHttpResponseType[JhHttpResponseType["Raw"] = 4] = "Raw";
})(JhHttpResponseType || (JhHttpResponseType = {}));
