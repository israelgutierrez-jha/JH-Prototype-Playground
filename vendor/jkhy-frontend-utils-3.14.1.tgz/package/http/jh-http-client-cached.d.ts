import { FetchFn } from '../types/http.types.js';
import { JhHttpCache } from './jh-http-cache/jh-http-cache.js';
import { JhHttpClient } from './jh-http-client.js';
import { JhHttpConfig, JhRequestConfig, JhRequestConfigArrayBuffer, JhRequestConfigBlob, JhRequestConfigRaw, JhRequestConfigText } from './jh-http-client.types.js';
/**
 * An HTTP client utilizing in-memory caching.
 */
export declare class JhHttpClientCached extends JhHttpClient {
    private cache;
    constructor(fetchFn?: FetchFn, config?: Partial<JhHttpConfig>, cache?: JhHttpCache);
    request(url: string, config: JhRequestConfigText<object>): Promise<string>;
    request(url: string, config: JhRequestConfigArrayBuffer<object>): Promise<ArrayBuffer>;
    request(url: string, config: JhRequestConfigRaw<object>): Promise<Response>;
    request(url: string, config: JhRequestConfigBlob<object>): Promise<Blob>;
    request<T>(url: string, config?: JhRequestConfig<object> | undefined): Promise<T>;
    resetCachedValue(endpoint: string, config: JhRequestConfig): void;
    clearCache(): void;
}
