import type { Constructor } from '../types/index.js';
/**
 * Like `Partial<T>`. but recursively makes nested fields optional.
 *
 * See: https://www.typescriptlang.org/docs/handbook/utility-types.html#partialtype
 */
export type DeepPartial<T> = {
    [P in keyof T]?: DeepPartial<T[P]>;
};
/**
 * Remove `null` and `undefined` as a possible value from every field in a type.
 *
 * See also {@link Nullable }.
 */
export type FullNonNullable<T> = {
    [P in keyof T]: NonNullable<T[P]>;
};
/**
 * Marks every field in a type as also accepting the `null` value.
 *
 * See also {@link FullNonNullable }.
 */
export type Nullable<T> = {
    [P in keyof T]: T[P] | null;
};
/**
 * Like `Nullable<T>`, but applied recursively to the entire object graph.
 */
export type DeepNullable<T> = {
    [P in keyof T]: DeepNullable<T[P]> | null;
};
/**
 * Create an array of constructors based on an array of types.
 */
export type CtorsOf<Source extends Array<unknown>> = {
    [Key in keyof Source]: Constructor<Source[Key]>;
};
export type Writeable<T> = {
    -readonly [P in keyof T]: T[P];
};
export type DeepWriteable<T> = {
    -readonly [P in keyof T]: DeepWriteable<T[P]>;
};
/**
 * Utility type for dealing with values whose type could be
 * a single instance or an array of that instance.
 *
 * Gets the element type of an array.
 * Otherwise, it is equivalent to the type itself.
 */
export type ExtractType<T> = T extends (infer U)[] ? U : T;
export type CapitalizeKeys<T> = {
    [K in keyof T as Capitalize<K & string>]: T[K] extends object ? CapitalizeKeys<T[K]> : T[K];
};
