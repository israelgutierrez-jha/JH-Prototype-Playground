import { Callback } from './function.types.js';
export type CustomEventCallback<Detail> = Callback<CustomEvent<Detail>>;
