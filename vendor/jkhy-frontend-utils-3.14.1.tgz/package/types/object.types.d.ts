export type Constructor<T = unknown, Params extends any[] = any[]> = new (...args: Params) => T;
export type AbstractConstructor<T = unknown, Params extends any[] = any[]> = abstract new (...args: Params) => T;
export type Primitive = string | boolean | number | bigint | symbol | null | undefined;
/**
 * Represents built-in and/or primitive constructor types.
 */
export type PrimitiveConstructor = NumberConstructor | ArrayConstructor | DateConstructor | StringConstructor | ObjectConstructor;
export type ReadonlyOrMutable<T> = T | Readonly<T>;
