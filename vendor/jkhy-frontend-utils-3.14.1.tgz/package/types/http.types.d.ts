export type HttpResponse = Blob | ArrayBuffer | Response | string;
export type HttpVerb = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
/**
 * Fetch signature as implemented by web browsers (contrasted with Node's version).
 */
export type BrowserFetch = Window['fetch'];
export type FetchFn = typeof fetch;
