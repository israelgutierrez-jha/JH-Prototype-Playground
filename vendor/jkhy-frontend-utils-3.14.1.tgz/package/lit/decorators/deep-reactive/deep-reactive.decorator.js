import { exists } from '../../../functions/index.js';
import { createProxy } from './helpers/index.js';
import { isProxy, unwrapReactive } from './helpers/index.js';
import { isReactiveElement } from '../../helpers/element.helpers.js';
/**
 * Provides Lit reactivity on an object when one of its properties is mutated
 * without the need to re-assign the entire reference.
 */
export function DeepReactive() {
    return function (target, propName) {
        if (!propName) {
            throw new Error('Directive DeepReactive must be used on a class property');
        }
        const isReactive = isReactiveElement(target);
        if (!isReactive) {
            const className = target.constructor.name;
            throw new Error(`Cannot decorate property "${propName}" with DeepReactive. The class ${className} is not a ReactiveElement.`);
        }
        const ctor = target.constructor;
        ctor.addInitializer(instance => {
            return new ReactiveObjectController(instance, propName);
        });
    };
}
class ReactiveObjectController {
    constructor(host, hostPropName) {
        this.host = host;
        this.hostPropName = hostPropName;
        this.isHostConnected = false;
        /**
         * Track created proxies to prevent re-wrapping.
         */
        this.proxies = new WeakSet();
        host.addController(this);
    }
    hostUpdated() {
        const hostTarget = this.host[this.hostPropName];
        // don't re-wrap an already proxy'd value
        if (this.proxies.has(hostTarget)) {
            return;
        }
        // create a proxy only for new values
        if (exists(hostTarget) && hostTarget !== this.lastValue) {
            const { proxy } = this.createProxy(hostTarget);
            this.proxies.add(proxy);
            this.host[this.hostPropName] = proxy;
            this.updateElement(hostTarget);
        }
        // store a reference to compare against new values
        this.lastValue = hostTarget;
    }
    hostConnected() {
        this.isHostConnected = true;
    }
    hostDisconnected() {
        this.isHostConnected = false;
    }
    async updateElement(newValue, postFix = '') {
        if (!this.isHostConnected) {
            return;
        }
        this.host.requestUpdate(this.hostPropName.toString() + postFix, newValue);
        await this.host.updateComplete;
    }
    createProxy(target) {
        // target has already been previously wrapped by another component;
        // re-use original reference and re-wrap for this component
        if (isProxy(target)) {
            target = unwrapReactive(target);
        }
        if (Array.isArray(target)) {
            return createProxy(target, element => {
                const index = target.findIndex(e => unwrapReactive(element) === unwrapReactive(e));
                const postFix = index > -1 ? `[${index}]` : undefined;
                this.updateElement(element, postFix);
            }, (_, oldTarget, newIndex, oldElement) => {
                const index = oldTarget.findIndex(element => unwrapReactive(element) === unwrapReactive(oldElement));
                const postFix = index > -1 ? `[${index}]` : undefined;
                this.updateElement(oldTarget, postFix);
            });
        }
        return createProxy(target, (_, oldTarget) => {
            this.updateElement(oldTarget);
        });
    }
}
