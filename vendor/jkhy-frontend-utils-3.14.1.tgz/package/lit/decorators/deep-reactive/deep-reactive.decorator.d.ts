import { ReactiveElement } from 'lit';
/**
 * Provides Lit reactivity on an object when one of its properties is mutated
 * without the need to re-assign the entire reference.
 */
export declare function DeepReactive<Element extends ReactiveElement = ReactiveElement, T extends object = object>(): (target: Element, propName?: string) => void;
