import { deepEquals, isIntegerString, isPrimitive } from '../../../../functions/index.js';
import { getPropValue, isProxy, unwrapReactive, } from './deep-reactive.common.js';
import { ObjectHandler } from './object-handler.js';
import { ProxyHandlerBase } from './proxy-handler-base.js';
/**
 * Represents the trap implementations used to create a proxy around
 * an array that satisfies the `ProxyHandler` interface.
 */
export class ArrayHandler extends ProxyHandlerBase {
    constructor(obj, onArrayChanged, onElementChanged) {
        super(obj);
        this.onArrayChanged = onArrayChanged;
        this.onElementChanged = onElementChanged;
    }
    set(target, propName, newValue) {
        newValue = unwrapReactive(newValue);
        const oldTarget = [...unwrapReactive(target)];
        const oldValue = oldTarget[propName];
        // don't forward identical values
        if (deepEquals(oldValue, newValue)) {
            return true;
        }
        Reflect.set(target, propName, newValue);
        if (typeof propName === 'string' && this.onArrayChanged) {
            // this is an array element and not some other prop on Array.prototype
            if (isIntegerString(propName)) {
                const index = parseInt(propName, 10);
                this.onArrayChanged(target, oldTarget, index, newValue, oldValue);
            }
            // this is the length property of the array when it is set to 0
            else if (propName === 'length') {
                this.onArrayChanged(target, oldTarget);
            }
        }
        return true;
    }
    get(target, propKey) {
        const value = getPropValue(target, propKey);
        // don't attempt to wrap symbols or primitives in proxies
        if (typeof propKey === 'symbol' || isPrimitive(value) || typeof value === 'function') {
            return value;
        }
        // we're getting an element for the first time;
        // wrap its value in a proxy if it isn't already
        if (!isProxy(value) && !isPrimitive(value)) {
            const handler = new ObjectHandler(value, (target, oldTarget, propName, oldPropVal, newPropVal) => {
                if (!this.onElementChanged) {
                    return;
                }
                this.onElementChanged(target, oldTarget, propName, oldPropVal, newPropVal);
            });
            const { proxy } = handler;
            // maintain correct this context w/ arrow function
            this.revokers.push(() => handler.revoke());
            return proxy;
        }
        return value;
    }
}
