import { isObject } from '../../../../functions/index.js';
/**
 * Property key used on proxies that allows access to original object.
 */
const PROXY_ORIGINAL = Symbol('PROXY_ORIGINAL');
/**
 * Property key used on proxies that denotes the object is a proxy.
 */
const IS_PROXY = Symbol('IS_PROXY');
/**
 * Get the property value for a given proxy target.
 *
 * Some properties are hidden to public consumers and can only be accessed
 * via symbols only available in this scope.
 */
export function getPropValue(target, propKey) {
    if (typeof propKey === 'string') {
        return Reflect.get(target, propKey);
    }
    // access hidden properties only available by symbol lookups in a proxy getter.
    switch (propKey) {
        // provide escape hatch for accessing original value
        case PROXY_ORIGINAL:
            return target;
        case IS_PROXY:
            return true;
        default:
            // @ts-expect-error: we can't know if the symbol exists on type T
            return target[propKey];
    }
}
/**
 * @returns `true` if the provided object has been wrapped by `@DeepReactive`
 */
export function isProxy(obj) {
    if (!(isObject(obj) || Array.isArray(obj))) {
        return false;
    }
    return Reflect.get(obj, IS_PROXY) || false;
}
/**
 * Converts an object on a `LitElement` that has been decorated
 * with `@DeepReactive` back to its naked reference.
 *
 * Otherwise, returns the passed object back.
 */
export function unwrapReactive(obj) {
    try {
        const unwrapped = Reflect.get(obj, PROXY_ORIGINAL);
        if (!unwrapped) {
            return obj;
        }
        if (Array.isArray(unwrapped)) {
            // maintain original array reference by using
            // forEach() instead of map()
            unwrapped.forEach((elem, i) => {
                unwrapped[i] = unwrapReactive(elem);
            });
        }
        return unwrapped;
    }
    catch {
        return obj;
    }
}
