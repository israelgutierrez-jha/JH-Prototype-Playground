import { ObjectChangeHandler, ArrayChangeHandler } from './deep-reactive.common.js';
import { ProxyHandlerBase } from './proxy-handler-base.js';
/**
 * Represents the trap implementations used to create a proxy around
 * an array that satisfies the `ProxyHandler` interface.
 */
export declare class ArrayHandler<T, A extends T[] = T[]> extends ProxyHandlerBase<A> {
    private readonly onArrayChanged?;
    private readonly onElementChanged?;
    constructor(obj: A, onArrayChanged?: ArrayChangeHandler<T> | undefined, onElementChanged?: ObjectChangeHandler<T> | undefined);
    set<K extends keyof A = keyof A>(target: A, propName: string | symbol, newValue: A[K]): boolean;
    get(target: T[], propKey: string | symbol): number | true | ProxyConstructor | T | T[] | {
        [x: number]: boolean | undefined;
        length?: boolean | undefined;
        toString?: boolean | undefined;
        toLocaleString?: boolean | undefined;
        pop?: boolean | undefined;
        push?: boolean | undefined;
        concat?: boolean | undefined;
        join?: boolean | undefined;
        reverse?: boolean | undefined;
        shift?: boolean | undefined;
        slice?: boolean | undefined;
        sort?: boolean | undefined;
        splice?: boolean | undefined;
        unshift?: boolean | undefined;
        indexOf?: boolean | undefined;
        lastIndexOf?: boolean | undefined;
        every?: boolean | undefined;
        some?: boolean | undefined;
        forEach?: boolean | undefined;
        map?: boolean | undefined;
        filter?: boolean | undefined;
        reduce?: boolean | undefined;
        reduceRight?: boolean | undefined;
        find?: boolean | undefined;
        findIndex?: boolean | undefined;
        fill?: boolean | undefined;
        copyWithin?: boolean | undefined;
        entries?: boolean | undefined;
        keys?: boolean | undefined;
        values?: boolean | undefined;
        includes?: boolean | undefined;
        flatMap?: boolean | undefined;
        flat?: boolean | undefined;
        at?: boolean | undefined;
        findLast?: boolean | undefined;
        findLastIndex?: boolean | undefined;
        toReversed?: boolean | undefined;
        toSorted?: boolean | undefined;
        toSpliced?: boolean | undefined;
        with?: boolean | undefined;
        [Symbol.iterator]?: boolean | undefined;
        readonly [Symbol.unscopables]?: boolean | undefined;
    } | {
        (...items: ConcatArray<T>[]): T[];
        (...items: (T | ConcatArray<T>)[]): T[];
    } | ((searchElement: T, fromIndex?: number) => number) | ((searchElement: T, fromIndex?: number) => boolean) | ((index: number) => T | undefined) | ((...items: T[]) => number) | ((separator?: string) => string) | ((compareFn?: ((a: T, b: T) => number) | undefined) => T[]) | ((callbackfn: (value: T, index: number, array: T[]) => void, thisArg?: any) => void) | {
        (callbackfn: (previousValue: T, currentValue: T, currentIndex: number, array: T[]) => T): T;
        (callbackfn: (previousValue: T, currentValue: T, currentIndex: number, array: T[]) => T, initialValue: T): T;
        <U>(callbackfn: (previousValue: U, currentValue: T, currentIndex: number, array: T[]) => U, initialValue: U): U;
    } | ((value: T, start?: number, end?: number) => T[]) | ((target: number, start: number, end?: number) => T[]) | (<A_1, D extends number = 1>(this: A_1, depth?: D | undefined) => FlatArray<A_1, D>[]) | ((index: number, value: T) => T[]);
}
