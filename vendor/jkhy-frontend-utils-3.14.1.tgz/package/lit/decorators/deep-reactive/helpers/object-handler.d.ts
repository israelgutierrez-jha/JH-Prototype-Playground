import { ObjectChangeHandler } from './deep-reactive.common.js';
import { ProxyHandlerBase } from './proxy-handler-base.js';
/**
 * Represents the trap implementations used to create a proxy around
 * an object that satisfies the `ProxyHandler` interface.
 */
export declare class ObjectHandler<T extends object> extends ProxyHandlerBase<T> {
    private readonly onPropChanged?;
    constructor(obj: T, onPropChanged?: ObjectChangeHandler<T> | undefined);
    set<K extends keyof T>(target: T, propName: string | symbol, newValue: T[K]): boolean;
    get(target: T, propKey: string | symbol): boolean | T | T[keyof T];
}
