export * from './deep-reactive.common.js';
import { isProxy } from './deep-reactive.common.js';
import { ArrayHandler } from './array-handler.js';
import { ObjectHandler } from './object-handler.js';
import { exists } from '../../../../functions/object.helpers.js';
export function createProxy(obj, onPropChanged, onArrayChanged) {
    if (!exists(obj)) {
        throw new Error('Could not wrap provided object. It is an empty value.');
    }
    if (isProxy(obj)) {
        throw new Error('Could not wrap provided object. It is already a proxy.');
    }
    let handler;
    if (Array.isArray(obj)) {
        handler = new ArrayHandler(obj, onArrayChanged, onPropChanged);
    }
    else if (typeof obj === 'object') {
        handler = new ObjectHandler(obj, onPropChanged);
    }
    else {
        throw new Error(`Could not create proxy for type ${typeof obj}. It is not an object or array.`);
    }
    const { proxy } = handler;
    return {
        revoke: () => handler.revoke(),
        proxy,
    };
}
