export * from './deep-reactive.common.js';
import { ObjectChangeHandler, ArrayChangeHandler } from './deep-reactive.common.js';
import { Action } from '../../../../types/function.types.js';
interface ProxyHandle {
    proxy: typeof Proxy;
    revoke: Action;
}
export declare function createProxy<T, A extends T[] = T[]>(obj: A, onElementChanged: ObjectChangeHandler<T>, onArrayChanged: ArrayChangeHandler<T>): ProxyHandle;
export declare function createProxy<T extends object>(obj: T, onPropChanged: ObjectChangeHandler<T>): ProxyHandle;
