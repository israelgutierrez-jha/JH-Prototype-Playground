import { clone, deepEquals, isPrimitive } from '../../../../functions/index.js';
import { getPropValue, unwrapReactive } from './deep-reactive.common.js';
import { ArrayHandler } from './array-handler.js';
import { ProxyHandlerBase } from './proxy-handler-base.js';
/**
 * Represents the trap implementations used to create a proxy around
 * an object that satisfies the `ProxyHandler` interface.
 */
export class ObjectHandler extends ProxyHandlerBase {
    constructor(obj, onPropChanged) {
        super(obj);
        this.onPropChanged = onPropChanged;
    }
    set(target, propName, newValue) {
        const oldValue = unwrapReactive(target[propName]);
        newValue = unwrapReactive(newValue);
        // don't forward identical values
        if (deepEquals(oldValue, newValue)) {
            return true;
        }
        const oldTarget = clone(target);
        const success = Reflect.set(target, propName, newValue);
        if (this.onPropChanged) {
            this.onPropChanged(target, oldTarget, propName, oldValue, newValue);
        }
        return success;
    }
    get(target, propKey) {
        const value = getPropValue(target, propKey);
        // don't attempt to wrap symbols or primitives in proxies
        if (typeof propKey === 'symbol' || isPrimitive(value)) {
            return value;
        }
        const childProxy = this.childProxies.get(propKey);
        // only re-use a proxy if the references are the same
        if (childProxy && value === unwrapReactive(childProxy)) {
            return childProxy;
        }
        let handler;
        if (typeof value === 'object') {
            handler = new ObjectHandler(value, this.onPropChanged);
        }
        else if (Array.isArray(value)) {
            handler = new ArrayHandler(value, (target, oldTarget, index, element, oldElement) => {
                if (!this.onPropChanged) {
                    return;
                }
                this.onPropChanged(target, oldTarget, (index ? index.toString() : 'length'), oldElement, element);
            }, this.onPropChanged);
        }
        if (handler) {
            this.childProxies.set(propKey, handler.proxy);
            // maintain correct this context w/ arrow function
            this.revokers.push(() => handler.revoke());
            return handler.proxy;
        }
        return value;
    }
}
