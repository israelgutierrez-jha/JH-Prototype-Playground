import { isProxy, unwrapReactive } from './deep-reactive.common.js';
export class ProxyHandlerBase {
    constructor(obj) {
        /**
         * A map of property names to proxied values owned by this object.
         *
         * This exists so that proxies do not need to be installed directly
         * on the source object, thereby maintaining original object references
         * and alleviating the need to recursively unwrap objects in `unwrapReactive()`.
         */
        this.childProxies = new Map();
        this.revokers = [];
        this.proxy = this.createProxy(obj);
    }
    revoke() {
        if (!this) {
            throw new Error('Cannot get reference to this');
        }
        this.revokers.forEach(revoke => revoke());
        this.revokers = [];
        this.childProxies.clear();
        this.proxy = null;
    }
    createProxy(obj) {
        if (isProxy(obj)) {
            obj = unwrapReactive(obj);
        }
        const { revoke, proxy } = Proxy.revocable(obj, this);
        this.revokers.push(revoke);
        return proxy;
    }
}
