export type ArrayChangeHandler<T> = (target: T[], oldTarget: T[], index?: number, element?: T, oldElement?: T) => void;
export type ObjectChangeHandler<T, K extends keyof T = keyof T> = (target: T, oldTarget: T, propName: K, oldPropValue: T[K], newPropValue: T[K]) => void;
/**
 * Get the property value for a given proxy target.
 *
 * Some properties are hidden to public consumers and can only be accessed
 * via symbols only available in this scope.
 */
export declare function getPropValue<T extends object>(target: T, propKey: symbol | string): true | T | T[keyof T];
/**
 * @returns `true` if the provided object has been wrapped by `@DeepReactive`
 */
export declare function isProxy(obj: unknown): obj is typeof Proxy;
/**
 * Converts an object on a `LitElement` that has been decorated
 * with `@DeepReactive` back to its naked reference.
 *
 * Otherwise, returns the passed object back.
 */
export declare function unwrapReactive<T>(obj: T): T;
