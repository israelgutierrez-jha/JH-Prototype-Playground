import { Action } from '../../../../types/function.types.js';
export declare abstract class ProxyHandlerBase<T extends object> implements ProxyHandler<T> {
    readonly proxy: typeof Proxy;
    /**
     * A map of property names to proxied values owned by this object.
     *
     * This exists so that proxies do not need to be installed directly
     * on the source object, thereby maintaining original object references
     * and alleviating the need to recursively unwrap objects in `unwrapReactive()`.
     */
    protected readonly childProxies: Map<string, ProxyConstructor>;
    protected revokers: Action[];
    constructor(obj: T);
    abstract set<K extends keyof T = keyof T>(target: T, propName: string | symbol, newValue: T[K]): boolean;
    abstract get(target: T, propName: string | symbol): unknown;
    revoke(): void;
    private createProxy;
}
