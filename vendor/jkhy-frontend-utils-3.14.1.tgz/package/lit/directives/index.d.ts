export { observe } from './observe.directive.js';
