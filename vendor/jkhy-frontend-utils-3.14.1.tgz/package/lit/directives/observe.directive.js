import { noChange } from 'lit';
import { AsyncDirective } from 'lit/async-directive.js';
import { directive } from 'lit/directive.js';
import { exists } from '../../functions/object.helpers.js';
class ObserveDirective extends AsyncDirective {
    render(observable, defaultValue) {
        if (exists(defaultValue)) {
            this.setValue(defaultValue);
        }
        this.subscription = observable.subscribe(value => {
            this.setValue(value);
        }, true);
        return noChange;
    }
    disconnected() {
        this.subscription?.unsubscribe();
        this.subscription = undefined;
    }
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const observeDirective = directive((ObserveDirective));
/**
 * Lit directive for interacting with {@link Observable | `Observable`} instances in templates.
 */
export function observe(...args) {
    return observeDirective(...args);
}
