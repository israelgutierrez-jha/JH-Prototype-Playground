import { AsyncDirective } from 'lit/async-directive.js';
import { Observable } from '../../observable/observable.js';
declare class ObserveDirective<T> extends AsyncDirective {
    private subscription?;
    render(observable: Observable<T>, defaultValue?: T): symbol;
    protected disconnected(): void;
}
/**
 * Lit directive for interacting with {@link Observable | `Observable`} instances in templates.
 */
export declare function observe<T>(...args: Parameters<ObserveDirective<T>['render']>): import("lit-html/directive.js").DirectiveResult<{
    new (_partInfo: import("lit-html/directive.js").PartInfo): ObserveDirective<any>;
}>;
export {};
