import { render } from 'lit';
import { createUniqueId } from '../../functions/id.helpers.js';
import { ObservationSource } from '../../observable/index.js';
import { disposePart, getElementForPart } from '../helpers/rendering.helpers.js';
import { DynamicComponentExitReason, } from './dynamic-component-registry.types.js';
const DEFAULT_OPTIONS = Object.freeze({
    host: window.document.body,
});
/**
 * Represents a store of homogenous components that have been
 * created and rendered dynamically outside of Lit's usual lifecycle.
 */
export class DynamicComponentRegistry {
    get hasMultiple() {
        return this.components.size > 0;
    }
    constructor(allowMultiple = false) {
        this.allowMultiple = allowMultiple;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        this.components = new Map();
        /**
         * A mapping of host element to children rendered using this registry.
         *
         * Used as a queue with the `renderBefore` option of Lit's `render()` function.
         */
        this.elementMap = new WeakMap();
    }
    create(rendererOrTemplate, options = {}) {
        if (this.hasMultiple && !this.allowMultiple) {
            throw new Error('Cannot create more than one dynamic component.  Remove the existing one before create another.');
        }
        const id = createUniqueId();
        const allOptions = normalizeOptions(options);
        const { host } = allOptions;
        const template = typeof rendererOrTemplate === 'function'
            ? rendererOrTemplate(result => this.dispose(id, result))
            : rendererOrTemplate;
        const elementQueue = host instanceof Element ? this.getQueueForHost(host) : undefined;
        const renderBefore = elementQueue ? getLast(elementQueue) : undefined;
        const part = render(template, host, {
            renderBefore,
        });
        const disposedStream = new ObservationSource();
        this.components.set(id, {
            part,
            options: allOptions,
            disposedStream,
            disposeTasks: [],
        });
        const handle = this.createHandle(id);
        // update ref to last element to support multi-element rendering
        elementQueue?.push(handle.element);
        return handle;
    }
    destroyAll() {
        Array.from(this.components.keys()).forEach(id => {
            this.dispose(id, {
                reason: DynamicComponentExitReason.ForceClose,
            });
        });
    }
    createHandle(id) {
        const { disposedStream, part, options } = this.getMetadata(id);
        const element = getElementForPart(part);
        return {
            dispose: (result, waitFor) => {
                const { host } = options;
                if (host instanceof Element) {
                    this.removeFromMap(element, host);
                }
                return this.dispose(id, result, waitFor);
            },
            listenFor: (eventName, callback) => {
                this.listenFor(id, eventName, callback);
            },
            disposed: disposedStream.toObservable().toPromise(),
            element,
        };
    }
    /**
     * @param waitFor Promise to wait on before disposing of the component.
     */
    async dispose(id, result, waitFor) {
        let meta;
        try {
            meta = this.getMetadata(id);
        }
        catch {
            // swallow error; handle was already closed
            return;
        }
        const { disposedStream, part, disposeTasks } = meta;
        const element = getElementForPart(part);
        result = result || {
            reason: DynamicComponentExitReason.ForceClose,
        };
        this.components.delete(id);
        disposePart(part);
        const promises = [awaitAnimations(element), waitFor];
        await Promise.all(promises);
        element.remove();
        disposeTasks.forEach(task => task());
        disposedStream.emit(result);
        disposedStream.complete();
    }
    getQueueForHost(host) {
        let elementQueue = this.elementMap.get(host);
        if (!elementQueue) {
            elementQueue = [];
            this.elementMap.set(host, elementQueue);
        }
        return elementQueue;
    }
    /**
     * Groom the element queue for a given host when an element is removed.
     */
    removeFromMap(target, host) {
        const queue = this.elementMap.get(host);
        if (!queue) {
            return;
        }
        const index = queue.indexOf(target);
        if (index < 0) {
            return;
        }
        queue.splice(index, 1);
    }
    listenFor(id, eventName, listener) {
        const { disposeTasks, part } = this.getMetadata(id);
        const element = getElementForPart(part);
        element.addEventListener(eventName, listener);
        disposeTasks.push(() => element.removeEventListener(eventName, listener));
    }
    getMetadata(id) {
        const meta = this.components.get(id);
        if (!meta) {
            throw new Error(`Could not get component metadata for ${id}`);
        }
        return meta;
    }
}
function normalizeOptions(options) {
    return {
        ...DEFAULT_OPTIONS,
        ...options,
    };
}
async function awaitAnimations(el) {
    const animationPromises = el.getAnimations().map(a => a.finished);
    await Promise.all(animationPromises);
}
function getLast(arr) {
    return arr.length > 0 ? arr[arr.length - 1] : undefined;
}
