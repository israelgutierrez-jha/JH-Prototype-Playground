import type { TemplateResult } from 'lit';
import { DynamicComponentHandle, DynamicComponentOptions, DynamicComponentRenderer } from './dynamic-component-registry.types.js';
/**
 * Represents a store of homogenous components that have been
 * created and rendered dynamically outside of Lit's usual lifecycle.
 */
export declare class DynamicComponentRegistry<Elem extends Element = Element> {
    private readonly allowMultiple;
    private readonly components;
    /**
     * A mapping of host element to children rendered using this registry.
     *
     * Used as a queue with the `renderBefore` option of Lit's `render()` function.
     */
    private elementMap;
    private get hasMultiple();
    constructor(allowMultiple?: boolean);
    create<T>(rendererOrTemplate: DynamicComponentRenderer | TemplateResult, options?: Partial<DynamicComponentOptions>): DynamicComponentHandle<Elem, T>;
    destroyAll(): void;
    private createHandle;
    /**
     * @param waitFor Promise to wait on before disposing of the component.
     */
    private dispose;
    private getQueueForHost;
    /**
     * Groom the element queue for a given host when an element is removed.
     */
    private removeFromMap;
    private listenFor;
    private getMetadata;
}
