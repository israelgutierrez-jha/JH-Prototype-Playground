export var DynamicComponentExitReason;
(function (DynamicComponentExitReason) {
    DynamicComponentExitReason["Confirm"] = "confirm";
    DynamicComponentExitReason["Cancel"] = "cancel";
    DynamicComponentExitReason["ForceClose"] = "force";
})(DynamicComponentExitReason || (DynamicComponentExitReason = {}));
