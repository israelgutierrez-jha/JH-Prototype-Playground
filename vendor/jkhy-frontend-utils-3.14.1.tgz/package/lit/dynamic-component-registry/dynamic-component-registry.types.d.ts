import type { ObservationSource } from '../../observable/index.js';
import type { Action } from '../../types/index.js';
import type { RootPart, TemplateResult } from 'lit';
export declare enum DynamicComponentExitReason {
    Confirm = "confirm",
    Cancel = "cancel",
    ForceClose = "force"
}
export type DynamicComponentDisposeFn<T = unknown> = (result?: DynamicComponentResult<T>, waitFor?: Promise<void>) => void;
export type DynamicComponentRenderer<T = unknown> = (close: DynamicComponentDisposeFn<T>) => TemplateResult;
export interface DynamicComponentResult<T = unknown> {
    reason: DynamicComponentExitReason;
    data?: T;
}
export interface DynamicComponentOptions {
    host: HTMLElement | DocumentFragment;
}
export interface DynamicComponentMetadata<T = unknown> {
    part: RootPart;
    disposedStream: ObservationSource<DynamicComponentResult<T>>;
    options: DynamicComponentOptions;
    disposeTasks: Action[];
}
export interface DynamicComponentHandle<Elem extends Element = Element, T = unknown> {
    dispose: DynamicComponentDisposeFn<T>;
    /**
     * Promise that completes when the element has been removed from the DOM.
     */
    disposed: Promise<DynamicComponentResult<T>>;
    element: Elem;
    /**
     * Provides a hook for events fired from the components contained within the template
     */
    listenFor: <Data>(eventName: string, listener: (e: CustomEvent<Data | undefined>) => void) => void;
}
