import { type RootPart } from 'lit';
/**
 * Low-level function to dispose of a `RootPart` created with Lit's `render()` function.
 */
export declare function disposePart(part: RootPart): void;
export declare function getElementForPart<Elem extends Element = Element>(part: RootPart): Elem;
