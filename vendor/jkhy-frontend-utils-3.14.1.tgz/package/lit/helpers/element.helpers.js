import { ReactiveElement } from 'lit';
import { getPrototypeList, isSubclassOf } from '../../functions/class.helpers.js';
export function isReactiveElement(element) {
    if (element instanceof ReactiveElement) {
        return true;
    }
    if (isSubclassOf(ReactiveElement, element.constructor)) {
        return true;
    }
    // fall back to using constructor names in case multiple versions of Lit exists
    // and there are more than one ReactiveElement class constructors present
    const protoList = getPrototypeList(element.constructor).map(p => p.name);
    if (protoList.includes('ReactiveElement')) {
        return true;
    }
    return false;
}
