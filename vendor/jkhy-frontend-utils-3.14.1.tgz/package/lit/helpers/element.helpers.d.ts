import { ReactiveElement } from 'lit';
export declare function isReactiveElement(element: Element): element is ReactiveElement;
