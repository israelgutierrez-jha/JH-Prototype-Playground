import { exists } from '../../functions/object.helpers.js';
/**
 * Low-level function to dispose of a `RootPart` created with Lit's `render()` function.
 */
export function disposePart(part) {
    part.setConnected(false);
    const { parentNode, startNode, endNode } = part;
    let node = startNode;
    while (exists(node) && node !== endNode) {
        const removedNode = node;
        // assign this before calling removeChild(), or the reference will skip the next node
        node = node.nextSibling;
        parentNode.removeChild(removedNode);
    }
    /***
     * This is either the node that was specified with `renderBefore` or
     * the original parent node if this is the first element in the host.
     *
     * These nodes acts as pointers to content and  maintain Lit element metadata
     * that must be removed when a `RootPart` is disposed.
     */
    const priorNode = endNode || parentNode;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    delete priorNode['_$litPart$'];
}
export function getElementForPart(part) {
    // the start node should be a Lit comment, so get the next one
    const nextSibling = part.startNode.nextElementSibling;
    if (!nextSibling) {
        throw new Error('Could not get element for RootPart');
    }
    return nextSibling;
}
