import { adoptStyles } from 'lit';
import { exists } from '../../functions/object.helpers.js';
import { enforceArray } from '../../functions/index.js';
/**
 * Creates a mixin that applies base styles to a LitElement component while preserving subclass styles.
 *
 * This mixin intercepts the `connectedCallback` lifecycle method to dynamically adopt styles into the
 * component's shadow root. The base styles are applied first, followed by any styles defined in the
 * subclass, ensuring proper style cascading.
 *
 * @param {T} superClass - The LitElement class to extend with style capabilities
 * @param {string} baseStyles - CSS string containing the base styles to apply to the component
 * @returns {T} An abstract class that extends the provided superClass with style adoption logic
 *
 * @example
 * ```typescript
 * const baseStyles = `
 *   :host {
 *     display: block;
 *     padding: 1rem;
 *   }
 * `;
 *
 * class MyElement extends StyleMixin(LitElement, baseStyles) {
 *   static styles = css`
 *     .custom { color: blue; }
 *   `;
 * }
 *
 * // Importing a stylesheet for use in a Vite project
 * import baseStyles from './base-styles.css?inline';
 * ```
 */
export const StyleMixin = (superClass, baseStyles) => {
    class StyleMixin extends superClass {
        connectedCallback() {
            super.connectedCallback();
            if (this.renderRoot instanceof ShadowRoot) {
                const prototype = Object.getPrototypeOf(this);
                const subclass = prototype.constructor;
                const subclassStyles = exists(subclass.styles) ? enforceArray(subclass.styles) : [];
                const baseStyleSheet = new CSSStyleSheet();
                baseStyleSheet.replaceSync(baseStyles);
                adoptStyles(this.renderRoot, [
                    baseStyleSheet,
                    ...subclassStyles,
                ]);
            }
        }
    }
    return StyleMixin;
};
