import 'reflect-metadata';
import { exists } from '../functions/index.js';
import { FACTORY_DEPS, IS_INJECTABLE_KEY, TOKEN_INJECTABLES } from './di.constants.js';
import { InjectionToken } from './di.types.js';
export function create(ctor, parameters) {
    return Reflect.construct(ctor, parameters);
}
/**
 * Determine if a constructor has been decorated so that its constructor metadata
 * is made available to reflection to be fulfilled by DI.
 *
 * @returns `true` if the constructor has been annotated with TypeScript constructor metadata.
 */
export function isInjectable(ctor) {
    return Reflect.getMetadata(IS_INJECTABLE_KEY, ctor) === true;
}
/**
 * @returns A (possibly sparse) array of metadata about the dependencies of a constructor,
 * keyed by parameter index. Only parameters that have been decorated will be included in this list.
 */
export function getTokenInjectables(ctor) {
    return Reflect.getMetadata(TOKEN_INJECTABLES, ctor);
}
/**
 * Get a list of all types associated with a method or constructor.
 *
 * @param ctor Constructor decorated as `Injectable`.
 * @returns An ordered list of DI tokens for each dependency required by the source constructor.
 */
export function getDependencies(ctor) {
    const factoryDeps = Reflect.getMetadata(FACTORY_DEPS, ctor);
    const ctorTypes = Reflect.getMetadata('design:paramtypes', ctor);
    const dependencies = factoryDeps || ctorTypes || [];
    const injectables = getTokenInjectables(ctor) || {};
    const undefinedIndex = dependencies.indexOf(undefined);
    if (undefinedIndex >= 0) {
        throw new Error(`Found an undefined dependency for class ${ctor.name} at position ${undefinedIndex}. This is likely due to circular imports.`);
    }
    const unknownIndex = dependencies.indexOf(Object);
    if (unknownIndex >= 0 && !exists(injectables[unknownIndex])) {
        throw new Error(`Found an unknown dependency for class ${ctor.name} at position ${unknownIndex}. This is likely due to circular imports.`);
    }
    return dependencies.map((d, i) => (exists(injectables[i]) ? injectables[i].token : d));
}
export function isSymbolToken(token) {
    return typeof token === 'string' || token instanceof InjectionToken;
}
export function getTokenName(token) {
    return isSymbolToken(token) ? token.toString() : token.name;
}
