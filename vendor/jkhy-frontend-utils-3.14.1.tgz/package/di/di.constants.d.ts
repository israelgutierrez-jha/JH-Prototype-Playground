export declare const IS_INJECTABLE_KEY: unique symbol;
export declare const TOKEN_INJECTABLES: unique symbol;
export declare const FACTORY_DEPS: unique symbol;
