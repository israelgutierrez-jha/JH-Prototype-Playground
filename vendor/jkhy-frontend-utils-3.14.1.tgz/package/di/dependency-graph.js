import 'reflect-metadata';
import { exists } from '../functions/index.js';
import { getDependencies, getTokenInjectables, getTokenName, isSymbolToken } from './di.helpers.js';
export class DependencyNode {
    constructor(token) {
        this.token = token;
        this.children = [];
        this.name = getTokenName(this.token);
        this.optionalDeps = this.getOptionalDeps();
    }
    /**
     * @returns `true` if a dependency is considered optional for this node.
     */
    checkOptional(token) {
        return this.optionalDeps.has(token);
    }
    getOptionalDeps() {
        if (isSymbolToken(this.token)) {
            return new Set([]);
        }
        const optional = Object.values(getTokenInjectables(this.token) || {})
            .filter(i => i.config.isOptional)
            .map(i => i.token);
        return new Set(optional);
    }
}
/**
 * Maximum number of times the dependency algorithm can loop to create
 * a valid graph. Places a hard cap to prevent stack overflow scenarios that
 * result in browser unresponsiveness and instead results in an error.
 */
const RECURSION_LIMIT = 100;
export class DependencyGraph {
    get hasCycle() {
        return !!this.cycle;
    }
    constructor(tokenOrRoot) {
        this.root =
            tokenOrRoot instanceof DependencyNode
                ? tokenOrRoot
                : createDependencyGraph(tokenOrRoot);
        this.cycle = detectCircularDependencies(this.root);
    }
    /**
     * Visit each node in the graph in a breadth-first manner starting with the root.
     *
     * @param fn Function to invoke against each node.
     * @param visitMulti If `false`, nodes are only ever visited once even if they appear in the graph at multiple points.
     */
    traverse(fn, visitMulti = false) {
        if (this.cycle) {
            throw new Error(`Cannot traverse the graph; there is a cycle: ${this.cycle}`);
        }
        const queue = [this.root];
        /**
         * Tracks which nodes have already been touched.
         */
        const explored = new Set();
        do {
            const node = queue.shift();
            if (!node) {
                return;
            }
            fn(node);
            node.children.forEach(child => {
                if (explored.has(child) && !visitMulti) {
                    return;
                }
                explored.add(child);
                queue.push(child);
            });
        } while (queue.length > 0);
    }
    /**
     * Produces a list of dependencies needed to instantiate the `root` token (inclusive)
     * as if the graph was [topologically sorted](https://en.wikipedia.org/wiki/Topological_sorting).
     */
    createDependencyStack() {
        if (this.cycle) {
            throw new Error(`Cannot create a dependency stack; there is a cycle in the graph: ${this.cycle}`);
        }
        const depStack = [];
        /**
         * Tracks the number of times a `DependencyNode` occurs in `depStack` for later pruning.
         */
        const occurrences = new Map();
        this.traverse(node => {
            const count = occurrences.get(node) || 0;
            occurrences.set(node, count + 1);
            depStack.push(node);
        }, true);
        // prune duplicates
        return (depStack
            .filter(node => {
            const count = occurrences.get(node) || 1;
            if (count === 1) {
                return true;
            }
            occurrences.set(node, count - 1);
            return false;
        })
            // ensure array is ordered from nodes with least dependencies to most
            .reverse());
    }
}
function createDependencyGraph(rootToken) {
    const rootNode = new DependencyNode(rootToken);
    const nodesList = [];
    /**
     * Nodes that have been created but possibly
     * not had their child dependencies determined.
     */
    const seenNodes = new Map([[rootNode.token, rootNode]]);
    /**
     * Nodes which have been both instantiated and had their child
     * dependencies linked.
     */
    const resolvedNodes = new Set();
    let count = 0;
    let currentNode = rootNode;
    while (exists(currentNode) && count < RECURSION_LIMIT) {
        const childNodes = getChildNodes(currentNode);
        nodesList.push(...childNodes);
        currentNode = nodesList.shift();
        count++;
        if (count >= RECURSION_LIMIT) {
            throw new Error(`Reached recursion limit of ${RECURSION_LIMIT} while trying to resolve ${rootNode.name}. Aborting.`);
        }
    }
    return rootNode;
    function getChildNodes(depNode) {
        if (resolvedNodes.has(depNode)) {
            // if this node has already been resolved,return an empty array
            // to prevent infinitely adding to the processing queue
            return [];
        }
        const { token } = depNode;
        const dependencies = isSymbolToken(token) ? [] : getDependencies(token);
        const childNodes = dependencies.map(dep => {
            if (seenNodes.has(dep)) {
                return seenNodes.get(dep);
            }
            const childNode = new DependencyNode(dep);
            seenNodes.set(dep, childNode);
            return childNode;
        });
        depNode.children = childNodes;
        resolvedNodes.add(depNode);
        return childNodes;
    }
}
/**
 * Checks the graph of dependencies for cycles starting with the provided node.
 *
 * @returns An array of strings describing the cycle if one is found.
 */
function detectCircularDependencies(node) {
    /**
     * Tracks which nodes have already been seen.
     */
    const explored = new Set();
    /**
     * Tracks which nodes are currently being evaluated as part of a dependency chain.
     */
    const evaluating = new Set();
    return visit(node);
    function visit(node) {
        const { children } = node;
        explored.add(node);
        evaluating.add(node);
        for (let i = 0; i < children.length; i++) {
            const child = children[i];
            if (!explored.has(child)) {
                const cycle = visit(child);
                if (cycle) {
                    return cycle;
                }
            }
            else if (evaluating.has(child)) {
                return [...evaluating, child].map(n => n.name);
            }
        }
        evaluating.delete(node);
        return undefined;
    }
}
/**
 * Create a stack of dependencies for the provided token,
 * ordered from fewest to most transitive dependencies.
 *
 * The last element is always the dependency for which we have created the stack.
 */
export function createDependencyStack(token) {
    const tokenName = getTokenName(token);
    const graph = new DependencyGraph(token);
    if (graph.cycle) {
        throw new Error(`Cannot create a dependency stack for ${tokenName}. It has a cyclic dependency: ${graph.cycle.join(' => ')}`);
    }
    return graph.createDependencyStack();
}
