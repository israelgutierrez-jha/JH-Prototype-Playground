export const IS_INJECTABLE_KEY = Symbol.for('IS_INJECTABLE');
export const TOKEN_INJECTABLES = Symbol.for('TOKEN_INJECTABLES');
export const FACTORY_DEPS = Symbol.for('FACTORY_DEPS');
