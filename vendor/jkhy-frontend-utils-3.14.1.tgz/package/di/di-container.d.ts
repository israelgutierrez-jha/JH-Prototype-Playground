import 'reflect-metadata';
import { AbstractConstructor, Constructor, CtorsOf } from '../types/index.js';
import { AsyncDependencyFactory, DependencyFactory, DiContainerConfig, DiToken, InjectableFnParams, InjectionToken } from './di.types.js';
/**
 * Registry of services available for injection.
 */
export declare class DiContainer {
    static get initialized(): boolean;
    private static currentInstance?;
    private static asyncInitStream;
    static asyncInit$: import("../observable/observable.js").Observable<void>;
    /**
     * Maximum time in milliseconds to wait to resolve async dependencies.
     */
    private timeoutLimit?;
    private readonly registry;
    /**
     * Represents any in-progress async instantiations.
     *
     * Used to prevent race conditions when more than one consumer is requesting an async instance.
     */
    private readonly asyncTasks;
    private static initStream;
    static initialized$: import("../observable/observable.js").Observable<DiContainer>;
    static getInstance(): Promise<DiContainer>;
    /**
     * Given a list of dependencies specified as DI tokens,
     * create a new function which will supply their instances to the provided function as arguments.
     *
     * Eagerly retrieves dependencies, allowing the resulting function to be invoked synchronously.
     *
     * @returns A function which, when invoked, will call the original function with the requested
     * dependencies as arguments.
     */
    static injectFunction<Deps extends unknown[], Args extends unknown[] | void = void, ReturnType = void>(deps: CtorsOf<Deps> | Readonly<CtorsOf<Deps>>, fn: (...params: InjectableFnParams<Deps, Args>) => ReturnType, di?: DiContainer | undefined): Promise<(...args: Args extends unknown[] ? Args : []) => ReturnType>;
    /**
     * Like `injectFunction()`, but fulfills dependencies lazily when the bound function is called.
     *
     * This allows function creation to be synchronous (unlike `injectFunction()`) at the cost
     * of forcing the created function to be async.
     *
     * This is only useful in cases where initial function generation cannot be async and should
     * probably be avoided in favor of `injectFunction()` to preserve original return value semantics
     * and its fail-fast nature.
     *
     * @returns An async function which, when invoked, will attempt to resolve dependencies and call the
     * original function with the requested dependencies as arguments.
     */
    static injectFunctionDeferred<Deps extends unknown[], Args extends unknown[] | void = void, ReturnType = void>(deps: CtorsOf<Deps> | Readonly<CtorsOf<Deps>>, fn: (...params: InjectableFnParams<Deps, Args>) => ReturnType, di?: DiContainer | undefined): (...args: Args extends unknown[] ? Args : []) => Promise<ReturnType>;
    /**
     * Initialize an application-wide, singleton DI container instance or provide your own.
     *
     * @param instance Provide a pre-configured `DiContainer` instance.
     * Useful for seeding the container with dependencies before ones marked with `@Injectable` are registered.
     *
     */
    static init(instance?: DiContainer, config?: Partial<DiContainerConfig>): Promise<void>;
    has<T>(token: DiToken<T>): boolean;
    /**
     * Provide a subclass constructor to fulfill the instance of a parent class token.
     *
     * Exists to support the
     * [Liskov substitution principle](https://en.wikipedia.org/wiki/Liskov_substitution_principle)
     * and [polymorphic code](https://en.wikipedia.org/wiki/Polymorphism_(computer_science)).
     *
     * @param ctorToken The constructor by which the dependency will be injected.
     * @param implementationCtor
     */
    provide<T, I extends T>(ctorToken: Constructor<T> | AbstractConstructor<T>, implementationCtor: Constructor<I>): this;
    /**
     * Provide an already-existing dependency that is accessible with the provided token.
     *
     * @param token An `InjectToken` reference to look up the dependency with.
     * @param instance An optional instance to associate with the token if the default value
     * should be overridden.
     */
    provide<T>(token: InjectionToken<T>, instance?: T): this;
    /**
     * Provide an already-existing dependency that is accessible with the provided key.
     *
     * @param key A string value key to look up the dependency with.
     * @param instance An instance of the dependency available with the provided string.
     */
    provide<T>(key: string, instance: T): this;
    /**
     * Provide a a dependency as a constructor with a pre-existing instance.
     *
     * @param constructor The class to be used as the injection token associated with the instance.
     * @param instance An optional instance of the class to use associated with provided type.
     * This will be used instead of the container instantiating the class itself.
     */
    provide<T>(constructor: Constructor<T> | AbstractConstructor<T>, instance: T): this;
    /**
     * Provide a dependency using a constructable token.
     * @param constructor A constructor to be used as a DI token and—optionally—as a constructor for instantiation.
     */
    provide<T>(constructor: Constructor<T> | AbstractConstructor<T>): this;
    /**
     * Provide a dependency via a factory function.
     *
     * Useful for when an instance needs to be created at run time or
     * it has constructor arguments that cannot be fulfilled entirely via DI.
     *
     * @param token The DI token to associate the instance with.
     * @param dependencies Any dependencies that the factory requires to create its instance.
     * @param factory A function to invoke once to create a singleton instance of the provided dependency.
     */
    provideFactory<T, Deps extends Array<any>>(token: DiToken<T>, dependencies: CtorsOf<Deps> | Readonly<CtorsOf<Deps>>, factory: DependencyFactory<T, Deps>): this;
    /**
     * Provide a dependency via a factory function that does asynchronous work and returns its dependency as a `Promise<T>`.
     *
     * @param defaultInstance  Instance to use by synchronous code until async instantiation has completed.
     */
    provideFactoryAsync<T, Deps extends Array<any>>(token: DiToken<T>, dependencies: CtorsOf<Deps> | Readonly<CtorsOf<Deps>>, factory: AsyncDependencyFactory<T, Deps>, defaultInstance?: T): this;
    /**
     * @deprecated Prefer `getAsync()`.
     *
     * Retrieve the instance associated with the provided DI token.
     *
     * @param warnOnAsync If true (default), logs a warning message to the console when retrieving an async dependency synchronously.
     */
    get<T>(token: DiToken<T>, warnOnAsync?: boolean): T;
    getAsync<T>(token: DiToken<T>): Promise<T>;
    /**
     * Instantiates all known dependencies provided via `provideAsyncFactory()`.
     *
     * Any dependencies registered at this time will become available
     * synchronously after the returned promise is fulfilled.
     */
    createAsyncDependencies(): Promise<void>;
    private copyFrom;
    /**
     * Instantiate a class decorated with `@Injectable`.
     */
    private instantiate;
    /**
     * Asynchronously instantiate a dependency.
     * Instantiates both static dependencies and dependencies provided as an async factory.
     */
    private instantiateAsync;
    /**
     * Starts at the bottom of a dependency graph (no dependencies) and
     * works up by instantiating and placing each into registry.
     *
     * @param depStack List of dependencies in order of fulfillment (least -> most dependencies).
     * The root is always the last dependency.
     *
     * @returns The instance of the root dependency for which the stack has been processed.
     */
    private processDependencyStack;
    /**
     * Asynchronously starts at the bottom of a dependency graph (no dependencies) and
     * works up by instantiating and placing each into registry.
     *
     * @param depStack List of dependencies in order of fulfillment (least -> most dependencies).
     * The root is always the last dependency.
     *
     * @returns The instance of the root dependency for which the stack has been processed.
     */
    private processDependencyStackAsync;
    /**
     * Instantiate a constructor-based dependency
     */
    private instantiateFromNode;
    private instantiateFromFactory;
    private instantiateFromAsyncFactory;
    private guardSubclass;
    private guardDependency;
    private guardUnknownDependencies;
}
