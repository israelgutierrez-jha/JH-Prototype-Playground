var _a;
import 'reflect-metadata';
import { exists, isConstructor, isPrimitiveCtor, isSubclassOf, waitUntil, } from '../functions/index.js';
import { ObservationSource } from '../observable/index.js';
import { createDependencyStack } from './dependency-graph.js';
import { DiRegistry } from './di-registry.js';
import { create, getTokenName, isInjectable } from './di.helpers.js';
import { FactoryType, InjectionToken, } from './di.types.js';
/**
 * Registry of services available for injection.
 */
export class DiContainer {
    constructor() {
        this.registry = new DiRegistry();
        /**
         * Represents any in-progress async instantiations.
         *
         * Used to prevent race conditions when more than one consumer is requesting an async instance.
         */
        this.asyncTasks = new Map();
    }
    static get initialized() {
        return exists(_a.currentInstance);
    }
    static getInstance() {
        return _a.initialized$.toPromise();
    }
    /**
     * Given a list of dependencies specified as DI tokens,
     * create a new function which will supply their instances to the provided function as arguments.
     *
     * Eagerly retrieves dependencies, allowing the resulting function to be invoked synchronously.
     *
     * @returns A function which, when invoked, will call the original function with the requested
     * dependencies as arguments.
     */
    static async injectFunction(deps, fn, di = _a.currentInstance) {
        if (!di) {
            throw new Error('No DI container instance provided or available to inject dependencies from.');
        }
        const instances = await Promise.all(deps.map(d => di.getAsync(d)));
        return function (...args) {
            const combined = exists(args) && args.length > 0 ? [...instances, ...args] : instances;
            return fn(...combined);
        };
    }
    /**
     * Like `injectFunction()`, but fulfills dependencies lazily when the bound function is called.
     *
     * This allows function creation to be synchronous (unlike `injectFunction()`) at the cost
     * of forcing the created function to be async.
     *
     * This is only useful in cases where initial function generation cannot be async and should
     * probably be avoided in favor of `injectFunction()` to preserve original return value semantics
     * and its fail-fast nature.
     *
     * @returns An async function which, when invoked, will attempt to resolve dependencies and call the
     * original function with the requested dependencies as arguments.
     */
    static injectFunctionDeferred(deps, fn, di = _a.currentInstance) {
        if (!di) {
            throw new Error('No DI container instance provided or available to inject dependencies from.');
        }
        /**
         * Cache of previously-resolved dependencies encapsulated by outer function closure.
         * Populated on first invocation of the returned function.
         */
        let instances;
        return async function (...args) {
            if (!instances) {
                instances = await Promise.all(deps.map(d => di.getAsync(d)));
            }
            const combined = exists(args) && args.length > 0 ? [...instances, ...args] : instances;
            return fn(...combined);
        };
    }
    /**
     * Initialize an application-wide, singleton DI container instance or provide your own.
     *
     * @param instance Provide a pre-configured `DiContainer` instance.
     * Useful for seeding the container with dependencies before ones marked with `@Injectable` are registered.
     *
     */
    static async init(instance = new _a(), config = {}) {
        const { recall, initializeAsyncDeps, asyncTimeout, broadcast } = normalizeConfig(config);
        instance.timeoutLimit = asyncTimeout;
        // carry over registrations from previous instances
        if (_a.currentInstance && recall) {
            instance.copyFrom(_a.currentInstance);
        }
        const initPromise = _a.initialized$.toPromise();
        if (broadcast) {
            _a.initStream.emit(instance);
            await initPromise;
        }
        _a.currentInstance = instance;
        if (initializeAsyncDeps) {
            // this is intentionally not awaited, since an async dependency can depend on
            // the result of another service's async method call which is itself waiting
            // for the DI container to initialize, creating a deadlock;
            // use asyncInit$ observable for this purpose or call the method directly
            instance.createAsyncDependencies();
        }
    }
    has(token) {
        return this.registry.has(token);
    }
    provide(token, instanceOrCtor) {
        this.guardDependency(token, instanceOrCtor);
        this.registry.set(token, instanceOrCtor);
        return this;
    }
    /**
     * Provide a dependency via a factory function.
     *
     * Useful for when an instance needs to be created at run time or
     * it has constructor arguments that cannot be fulfilled entirely via DI.
     *
     * @param token The DI token to associate the instance with.
     * @param dependencies Any dependencies that the factory requires to create its instance.
     * @param factory A function to invoke once to create a singleton instance of the provided dependency.
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    provideFactory(token, dependencies, factory) {
        this.guardDependency(token, factory);
        this.registry.setFactory(FactoryType.Sync, token, dependencies, factory);
        return this;
    }
    /**
     * Provide a dependency via a factory function that does asynchronous work and returns its dependency as a `Promise<T>`.
     *
     * @param defaultInstance  Instance to use by synchronous code until async instantiation has completed.
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    provideFactoryAsync(token, dependencies, factory, defaultInstance) {
        this.guardDependency(token, factory);
        this.registry.setFactory(FactoryType.Async, token, dependencies, factory, defaultInstance);
        return this;
    }
    /**
     * @deprecated Prefer `getAsync()`.
     *
     * Retrieve the instance associated with the provided DI token.
     *
     * @param warnOnAsync If true (default), logs a warning message to the console when retrieving an async dependency synchronously.
     */
    get(token, warnOnAsync = true) {
        this.guardSubclass(token);
        const instance = this.instantiate(token);
        const isAsync = this.registry.isAsync(token);
        const defaultInstance = this.registry.getDefaultInstance(token);
        if (warnOnAsync && isAsync && exists(defaultInstance) && defaultInstance === instance) {
            const tokenName = getTokenName(token);
            console.warn(`Attempted to get ${tokenName} synchronously when it is an async dependency. You are receiving the default implementation. To get the async implementation, call createAsyncDependencies() prior or retrieve with getAsync().`);
        }
        return instance;
    }
    getAsync(token) {
        this.guardSubclass(token);
        return this.instantiateAsync(token);
    }
    /**
     * Instantiates all known dependencies provided via `provideAsyncFactory()`.
     *
     * Any dependencies registered at this time will become available
     * synchronously after the returned promise is fulfilled.
     */
    async createAsyncDependencies() {
        await Promise.all(this.registry.getAsyncTokens().map(asyncToken => this.getAsync(asyncToken)));
        _a.asyncInitStream.emit();
    }
    copyFrom(other) {
        this.registry.copyFrom(other.registry);
    }
    /**
     * Instantiate a class decorated with `@Injectable`.
     */
    instantiate(token) {
        let instance = this.registry.getInstance(token);
        if (instance) {
            return instance;
        }
        const tokenName = getTokenName(token);
        /**
         * The token doesn't have an instance, isn't a constructor and doesn't have a factory.
         * It also isn't an `InjectionToken` which can produce its own value or be optional.
         *
         * There is no way for the container fulfill this token, so we should error early.
         */
        const canCanBeFulfilled = this.registry.hasFactory(token) || token instanceof InjectionToken;
        if (!canCanBeFulfilled) {
            const baseMessage = `Cannot instantiate ${tokenName}.`;
            const constructor = this.registry.getConstructor(token);
            if (!constructor) {
                throw new Error(`${baseMessage} No constructor was provided.`);
            }
            if (isPrimitiveCtor(constructor)) {
                throw new Error(`${baseMessage} It is a primitive type.`);
            }
            if (!isInjectable(constructor)) {
                throw new Error(`${baseMessage} It is not decorated.`);
            }
        }
        const depStack = createDependencyStack(token);
        instance = this.processDependencyStack(depStack);
        if (!instance) {
            throw new Error(`Failed to instantiate ${tokenName}.`);
        }
        return instance;
    }
    /**
     * Asynchronously instantiate a dependency.
     * Instantiates both static dependencies and dependencies provided as an async factory.
     */
    async instantiateAsync(token) {
        let instance = this.registry.getInstance(token);
        const defaultInstance = this.registry.getDefaultInstance(token);
        // don't return the default instance during async instantiation;
        // it exists only to provide a reasonable fallback during retrieval
        // of synchronous dependencies w/ async transitive dependencies
        if (exists(instance) && instance !== defaultInstance) {
            return instance;
        }
        const tokenName = getTokenName(token);
        /**
         * The token doesn't have an instance, isn't a constructor and doesn't have a factory.
         * It also isn't an `InjectionToken` which can produce its own value or be optional.
         *
         * There is no way for the container fulfill this token, so we should error early.
         */
        const canCanBeFulfilled = this.registry.hasFactory(token) || token instanceof InjectionToken;
        if (!canCanBeFulfilled) {
            const constructor = this.registry.getConstructor(token);
            const baseMessage = `Cannot instantiate ${tokenName}.`;
            if (!constructor) {
                throw new Error(`${baseMessage} No constructor was provided.`);
            }
            if (isPrimitiveCtor(constructor)) {
                throw new Error(`Cannot asynchronously instantiate ${tokenName}. It is a primitive type.`);
            }
            if (!isInjectable(constructor)) {
                throw new Error(`${baseMessage} It is not decorated.`);
            }
        }
        let asyncTask = this.asyncTasks.get(token);
        if (!asyncTask) {
            const depStack = createDependencyStack(token);
            asyncTask = this.processDependencyStackAsync(depStack);
            this.asyncTasks.set(token, asyncTask);
        }
        const instancePromise = exists(this.timeoutLimit)
            ? waitUntil(asyncTask, this.timeoutLimit)
            : asyncTask;
        instance = (await instancePromise);
        this.asyncTasks.delete(token);
        if (!instance) {
            throw new Error(`Could not asynchronously instantiate ${tokenName}.`);
        }
        return instance;
    }
    /**
     * Starts at the bottom of a dependency graph (no dependencies) and
     * works up by instantiating and placing each into registry.
     *
     * @param depStack List of dependencies in order of fulfillment (least -> most dependencies).
     * The root is always the last dependency.
     *
     * @returns The instance of the root dependency for which the stack has been processed.
     */
    processDependencyStack(depStack) {
        this.guardUnknownDependencies(depStack);
        /**
         * The token which we are processing dependencies for.
         * Always the last element of the dependency stack.
         */
        const rootDep = depStack[depStack.length - 1];
        for (const node of depStack) {
            const { token } = node;
            const depName = getTokenName(token);
            const hasInstance = this.registry.hasInstance(token);
            if (hasInstance) {
                continue;
            }
            let instance;
            if (this.registry.hasFactory(token)) {
                if (this.registry.isAsync(token)) {
                    const defaultInstance = this.registry.getDefaultInstance(token);
                    if (!defaultInstance) {
                        throw new Error(`Could not synchronously instantiate ${depName}. It is an async dependency which does not have a default value. Run createAsyncDependencies() first and/or provide a default value.`);
                    }
                    instance = defaultInstance;
                }
                else {
                    instance = this.instantiateFromFactory(token);
                }
            }
            else {
                instance = this.instantiateFromNode(node);
            }
            this.registry.set(token, instance);
        }
        return this.registry.getInstance(rootDep.token);
    }
    /**
     * Asynchronously starts at the bottom of a dependency graph (no dependencies) and
     * works up by instantiating and placing each into registry.
     *
     * @param depStack List of dependencies in order of fulfillment (least -> most dependencies).
     * The root is always the last dependency.
     *
     * @returns The instance of the root dependency for which the stack has been processed.
     */
    async processDependencyStackAsync(depStack) {
        this.guardUnknownDependencies(depStack);
        /**
         * The token which we are processing dependencies for.
         * Always the last element of the dependency stack.
         */
        const rootDep = depStack[depStack.length - 1];
        for (const node of depStack) {
            const { token } = node;
            const defaultInstance = this.registry.getDefaultInstance(token);
            let instance = this.registry.getInstance(token);
            if (exists(instance) && instance !== defaultInstance) {
                continue;
            }
            if (this.registry.hasFactory(token)) {
                instance = this.registry.isAsync(token)
                    ? await this.instantiateFromAsyncFactory(token)
                    : this.instantiateFromFactory(token);
            }
            else {
                instance = this.instantiateFromNode(node);
            }
            if (!instance) {
                throw new Error(`Could process dependency ${node.name} of ${rootDep.name}. No instance was created.`);
            }
            this.registry.set(token, instance);
        }
        return this.registry.getInstance(rootDep.token);
    }
    /**
     * Instantiate a constructor-based dependency
     */
    instantiateFromNode(node) {
        const { children, token } = node;
        const constructor = this.registry.getConstructor(token);
        // the dependency graph for the constructor may be
        // different than the one for the token used to look it up
        if (constructor && token !== constructor) {
            return this.instantiate(constructor);
        }
        const dependencies = children.map(child => {
            // child dependencies should have already been instantiated
            // based on order of a previously-processed dependency stack
            const instance = this.registry.getInstance(child.token);
            const isOptional = node.checkOptional(child.token);
            if (!instance && !isOptional) {
                throw new Error(`Cannot instantiate ${node.name}. Dependency ${child.name} was not provided and was not listed as optional.`);
            }
            return instance;
        });
        if (token instanceof InjectionToken) {
            return token.getValue() || undefined;
        }
        else if (!constructor) {
            throw new Error(`Could not instantiate ${node.name}. No constructor was found.`);
        }
        return create(constructor, dependencies);
    }
    instantiateFromFactory(token) {
        const { dependencies, factory } = this.registry.tryGetFactory(token);
        const depInstances = dependencies.map(d => this.instantiate(d));
        return factory(...depInstances);
    }
    async instantiateFromAsyncFactory(token) {
        const { dependencies, factory } = this.registry.tryGetFactory(token);
        const instancePromises = dependencies.map(d => this.getAsync(d));
        const instances = await Promise.all(instancePromises);
        return factory(...instances);
    }
    guardSubclass(token) {
        if (!this.registry.isKnownSubclass(token)) {
            return;
        }
        const tokenName = getTokenName(token);
        const parentClass = this.registry.getTokenForSubclass(token);
        let message = `Cannot instantiate ${tokenName}. `;
        message += exists(parentClass)
            ? `It is a subclass of ${getTokenName(parentClass)}.`
            : `It is a subclass of a known dependency.`;
        throw new Error(message);
    }
    guardDependency(token, instanceOrMaker) {
        const name = getTokenName(token);
        const baseMessage = 'Attempted to register ' + name + ' more than once.';
        const isSubClass = isConstructor(instanceOrMaker) && isConstructor(token)
            ? isSubclassOf(token, instanceOrMaker)
            : false;
        if (isSubClass) {
            // don't warn when providing a subclass implementation for a known dependency
            return;
        }
        if (typeof instanceOrMaker === 'function') {
            if (this.registry.hasFactory(token)) {
                console.warn(`${baseMessage} A factory already exists for this token.`);
            }
            return;
        }
        else if (this.registry.hasProvider(token)) {
            console.warn(`${baseMessage} A provider already exists for this token.`);
            return;
        }
    }
    guardUnknownDependencies(depStack) {
        /**
         * The token which we are processing dependencies for.
         * Always the last element of the dependency stack.
         */
        const rootDep = depStack[depStack.length - 1];
        const unknownDeps = this.registry.getUnknownDependencies(depStack.map(d => d.token));
        if (unknownDeps.length > 0) {
            const unknownList = unknownDeps.map(d => getTokenName(d)).join(', ');
            throw new Error(`Could not process dependencies for ${rootDep.name}. The following dependencies are not known to the DI container: ${unknownList}`);
        }
    }
}
_a = DiContainer;
DiContainer.asyncInitStream = new ObservationSource();
// eslint-disable-next-line @typescript-eslint/member-ordering
DiContainer.asyncInit$ = _a.asyncInitStream.toObservable();
DiContainer.initStream = new ObservationSource();
// eslint-disable-next-line @typescript-eslint/member-ordering
DiContainer.initialized$ = _a.initStream.toObservable();
const DEFAULT_CONFIG = Object.freeze({
    initializeAsyncDeps: true,
    recall: false,
    broadcast: true,
});
function normalizeConfig(config) {
    return {
        ...DEFAULT_CONFIG,
        ...config,
    };
}
