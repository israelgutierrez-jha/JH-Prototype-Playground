import type { AbstractConstructor, Constructor, CtorsOf } from '../types/index.js';
import { DiContainer } from './di-container.js';
export interface DiContainerConfig {
    /**
     * If `true`, dependencies provided with `provideAsyncFactory()` will also be initialized.
     */
    initializeAsyncDeps: boolean;
    /**
     * If `true`, calling `init()` more than once will carry over existing dependencies into
     * the new container instance.
     */
    recall: boolean;
    /**
     * If `true`, broadcasts to classes decorated with `@Injectable` that
     * a new container is available and registers them with it.
     */
    broadcast: boolean;
    /**
     * Timeout in milliseconds to wait for async dependencies to resolve.
     */
    asyncTimeout?: number;
}
interface InjectionTokenConfig<T> {
    /**
     * Provide a static value for the dependency provided by the `InjectionToken`.
     */
    value?: T;
    /**
     * Provide a computed value for the dependency provided by the `InjectionToken`.
     */
    factory?: () => T;
}
export interface InjectByTokenConfig {
    isOptional?: boolean;
}
/**
 * A non-instantiable token that can be used with a DI Container to
 * register/retrieve already-created instances or constant dependencies in a type-safe way.
 */
export declare class InjectionToken<T> {
    readonly name: string;
    private readonly config;
    get hasValue(): boolean;
    constructor(name: string, config?: InjectionTokenConfig<T>);
    toString(): string;
    getValue(): NonNullable<T> | undefined;
}
/**
 * Non-instantiable token used to retrieve a dependency from the DI container.
 */
export type SymbolToken<T> = InjectionToken<T> | string;
export type DiToken<T> = Constructor<T> | AbstractConstructor<T> | SymbolToken<T>;
export type DependencyFactory<T, Deps extends Array<any>> = (...dependencies: Deps) => T;
export type AsyncDependencyFactory<T, Deps extends Array<any>> = (...dependencies: Deps) => Promise<T>;
export interface DependencyDefinition<T> {
    /**
     * The class constructor used to fulfill a dependency.
     *
     * This may or may not be the same as the key used to retrieve it.
     * There are scenarios where a token used for lookup may be associated with some other
     * token (an injection token, a sub-class constructor, etc.) for instantiation.
     *
     * When in doubt, this value should be the considered the source of truth
     * for creating an instance of any dependency.
     */
    constructor?: Constructor<T>;
    instance?: T;
}
export declare enum FactoryType {
    Async = 0,
    Sync = 1
}
export interface FactoryDefinition<T, Deps extends any[] = any[]> {
    type: FactoryType;
    dependencies: DiToken<any>[];
    factory: DependencyFactory<T, Deps> | AsyncDependencyFactory<T, Deps>;
    /**
     * An instance to use until async instantiation has completed.
     */
    defaultInstance?: T;
}
interface DependencyProviderBase<T, Deps extends Array<any>> {
    type: FactoryType;
    provide: Constructor<T> | SymbolToken<T>;
    dependencies: CtorsOf<Deps> | Readonly<CtorsOf<Deps>>;
    factory: DependencyFactory<T, Deps> | AsyncDependencyFactory<T, Deps>;
}
interface DependencyProviderSync<T, Deps extends Array<any>> extends DependencyProviderBase<T, Deps> {
    type: FactoryType.Sync;
    factory: DependencyFactory<T, Deps>;
}
interface DependencyProviderAsync<T, Deps extends Array<any>> extends DependencyProviderBase<T, Deps> {
    type: FactoryType.Async;
    factory: AsyncDependencyFactory<T, Deps>;
    defaultInstance?: T;
}
export type DependencyProvider<T, Deps extends Array<any>> = DependencyProviderSync<T, Deps> | DependencyProviderAsync<T, Deps>;
export interface InjectConfig<T = unknown, Deps extends any[] = any[]> {
    /**
     * The DI container to register the dependency with.
     * Useful for test scenarios or segregating dependencies into packages.
     */
    container?: DiContainer;
    /**
     * Provide this dependency explicitly using a factory function.
     * Useful for when a class constructor has mixed injectable and
     * non-injectable parameters or has a run-time requirement.
     */
    provider?: DependencyProvider<T, Deps>;
}
interface TokenConfig<T> extends InjectConfig {
    token?: DiToken<T>;
    async: false | undefined;
}
interface AsyncConfig<T> extends InjectConfig {
    token: DiToken<T>;
    async: true;
}
export type InjectPropertyConfig<T> = TokenConfig<T> | AsyncConfig<T>;
/**
 * Dependency definition for a parameter of an injectable constructor
 * that is annotated with a non-constructable injection token.
 */
export interface TokenDependency {
    /**
     * Ordinal position in the constructor argument list.
     */
    index: number;
    token: SymbolToken<unknown>;
    config: InjectByTokenConfig;
}
/**
 * The parameters of an injectable function.
 * Dependencies resolved by the container are passed first,
 * followed by arguments passed at call time (if any).
 */
export type InjectableFnParams<Deps extends unknown[], Args extends unknown[] | void = void> = Args extends unknown[] ? [...Deps, ...Args] : [...Deps];
export {};
