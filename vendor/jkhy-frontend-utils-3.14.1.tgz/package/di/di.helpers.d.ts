import 'reflect-metadata';
import type { AbstractConstructor, Constructor } from '../types/index.js';
import { DiToken, SymbolToken, TokenDependency } from './di.types.js';
export declare function create<T>(ctor: Constructor<T>, parameters: ConstructorParameters<Constructor<T>>): T;
/**
 * Determine if a constructor has been decorated so that its constructor metadata
 * is made available to reflection to be fulfilled by DI.
 *
 * @returns `true` if the constructor has been annotated with TypeScript constructor metadata.
 */
export declare function isInjectable<T>(ctor: Constructor<T> | AbstractConstructor<T>): boolean;
/**
 * @returns A (possibly sparse) array of metadata about the dependencies of a constructor,
 * keyed by parameter index. Only parameters that have been decorated will be included in this list.
 */
export declare function getTokenInjectables(ctor: Constructor<unknown> | AbstractConstructor<unknown>): {
    [index: number]: TokenDependency;
} | undefined;
/**
 * Get a list of all types associated with a method or constructor.
 *
 * @param ctor Constructor decorated as `Injectable`.
 * @returns An ordered list of DI tokens for each dependency required by the source constructor.
 */
export declare function getDependencies(ctor: Constructor | AbstractConstructor): DiToken<unknown>[];
export declare function isSymbolToken<T>(token: DiToken<T>): token is SymbolToken<T>;
export declare function getTokenName<T>(token: DiToken<T>): string;
