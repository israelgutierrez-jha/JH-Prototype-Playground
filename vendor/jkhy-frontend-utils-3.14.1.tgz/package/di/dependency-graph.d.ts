import 'reflect-metadata';
import { DiToken } from './di.types.js';
export declare class DependencyNode<T = unknown> {
    readonly token: DiToken<T>;
    children: DependencyNode<unknown>[];
    readonly name: string;
    private readonly optionalDeps;
    constructor(token: DiToken<T>);
    /**
     * @returns `true` if a dependency is considered optional for this node.
     */
    checkOptional(token: DiToken<unknown>): boolean;
    private getOptionalDeps;
}
export type GraphTraversalCallback = (node: DependencyNode<unknown>) => void;
export declare class DependencyGraph<T> {
    readonly root: DependencyNode<T>;
    readonly cycle?: string[];
    get hasCycle(): boolean;
    constructor(tokenOrRoot: DiToken<T> | DependencyNode<T>);
    /**
     * Visit each node in the graph in a breadth-first manner starting with the root.
     *
     * @param fn Function to invoke against each node.
     * @param visitMulti If `false`, nodes are only ever visited once even if they appear in the graph at multiple points.
     */
    traverse(fn: GraphTraversalCallback, visitMulti?: boolean): void;
    /**
     * Produces a list of dependencies needed to instantiate the `root` token (inclusive)
     * as if the graph was [topologically sorted](https://en.wikipedia.org/wiki/Topological_sorting).
     */
    createDependencyStack(): DependencyNode<unknown>[];
}
/**
 * Create a stack of dependencies for the provided token,
 * ordered from fewest to most transitive dependencies.
 *
 * The last element is always the dependency for which we have created the stack.
 */
export declare function createDependencyStack(token: DiToken<unknown>): DependencyNode<unknown>[];
