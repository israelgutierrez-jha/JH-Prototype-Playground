/* eslint-disable @typescript-eslint/no-explicit-any */
import { exists } from '../functions/index.js';
/**
 * A non-instantiable token that can be used with a DI Container to
 * register/retrieve already-created instances or constant dependencies in a type-safe way.
 */
export class InjectionToken {
    get hasValue() {
        const { value, factory } = this.config;
        return exists(value) || exists(factory);
    }
    constructor(name, config = {}) {
        this.name = name;
        this.config = config;
    }
    toString() {
        return this.name;
    }
    getValue() {
        const { value: defaultValue, factory } = this.config;
        return defaultValue ?? factory?.() ?? undefined;
    }
}
export var FactoryType;
(function (FactoryType) {
    FactoryType[FactoryType["Async"] = 0] = "Async";
    FactoryType[FactoryType["Sync"] = 1] = "Sync";
})(FactoryType || (FactoryType = {}));
