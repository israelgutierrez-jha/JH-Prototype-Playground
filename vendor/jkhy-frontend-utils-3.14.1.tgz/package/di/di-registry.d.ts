import type { AbstractConstructor, Constructor, CtorsOf } from '../types/index.js';
import { AsyncDependencyFactory, DependencyFactory, DiToken, FactoryDefinition, FactoryType, InjectionToken } from './di.types.js';
/**
 * Encapsulates setting and retrieving dependency injection definitions and instances.
 */
export declare class DiRegistry {
    /**
     * Definitions for dependencies that have been registered using
     * a conventional constructor-based approach or with an already-existing instance.
     *
     * Instances created from factories will also be placed here.
     */
    private readonly static;
    private readonly factories;
    has<T = unknown>(token: DiToken<T>): boolean;
    /**
     * Returns `true` if the provided token is fulfilled asynchronously.
     */
    isAsync<T>(token: DiToken<T>): boolean;
    /**
     * Returns `true` if the provided token is fulfilled via a factory.
     */
    hasFactory<T>(token: DiToken<T>): boolean;
    hasProvider<T>(token: DiToken<T>): boolean;
    hasInstance<T>(token: DiToken<T>): boolean;
    /**
     * Retrieve a list of tokens for all asynchronous dependencies known to the registry.
     */
    getAsyncTokens(): (string | AbstractConstructor<unknown> | InjectionToken<unknown>)[];
    tryGetFactory<T = unknown>(token: DiToken<T>): FactoryDefinition<unknown, any[]>;
    getInstance<T = unknown>(token: DiToken<T>): T | undefined;
    getConstructor<T = unknown>(token: DiToken<T>): Constructor<T> | undefined;
    /**
     * Retrieves the default implementation for the provided token
     * if one exists and it is asynchronous dependency.
     */
    getDefaultInstance<T = unknown>(token: DiToken<T>): T | undefined;
    /**
     * Create or update a dependency definition for a DI token within the registry.
     * Optionally, alternate ways of resolving a dependency instance can be specified:
     *  * An already-created instance can be provided that is associated with the token
     *  * A subclass constructor can be provided for instantiation when the token is requested
     *
     * Omitting the second argument uses the token itself as the constructor
     * if it is a constructor function.
     */
    set<T>(token: DiToken<T>, constructor: Constructor<T>): void;
    set<T>(token: DiToken<T>, instance?: T): void;
    set<T>(constructor: Constructor<T>): void;
    set<T>(token: InjectionToken<T>): void;
    setFactory<T, Deps extends unknown[]>(type: FactoryType.Async, token: DiToken<T>, dependencies: CtorsOf<Deps> | Readonly<CtorsOf<Deps>>, factory: AsyncDependencyFactory<T, Deps>, defaultInstance?: T): void;
    setFactory<T, Deps extends unknown[]>(type: FactoryType.Sync, token: DiToken<T>, dependencies: CtorsOf<Deps> | Readonly<CtorsOf<Deps>>, factory: DependencyFactory<T, Deps>): void;
    /**
     * Returns `true` if the constructor is known to the DI registry as a subclass
     * constructor of another token.
     */
    isKnownSubclass(subclass: Constructor | AbstractConstructor): boolean;
    /**
     * Given a subclass for a known dependency, retrieve its DI token.
     */
    getTokenForSubclass<T = unknown>(subclass: Constructor<T> | AbstractConstructor<T>): Constructor<T> | undefined;
    /**
     * Given a list of tokens, return those which are not known to
     * the registry or are not subclasses of ones that are.
     */
    getUnknownDependencies(list: DiToken<unknown>[]): DiToken<unknown>[];
    /**
     * Copy the dependency contents of another `DiRegistry` into this one.
     */
    copyFrom(other: DiRegistry): void;
    private get;
    private normalizeDefinition;
}
