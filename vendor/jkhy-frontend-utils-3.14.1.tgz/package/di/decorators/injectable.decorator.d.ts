import 'reflect-metadata';
import { Constructor } from '../../types/index.js';
import { InjectConfig } from '../di.types.js';
/**
 * Decorate a class to register it as a provider with the DI container
 * and make it eligible for injection.
 */
export declare function Injectable<T = unknown, Deps extends any[] = []>(config?: Partial<InjectConfig<T, Deps>>): (ctor: Constructor<T>) => void;
