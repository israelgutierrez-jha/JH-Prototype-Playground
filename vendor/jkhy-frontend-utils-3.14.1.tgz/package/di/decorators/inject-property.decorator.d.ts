import 'reflect-metadata';
import type { InjectPropertyConfig } from '../di.types.js';
/**
 * Fulfills a class property with an instance of its type or the provided token.
 *
 * **Note:** It is not possible to assign instance properties using decorators.
 * Under the hood, this decorator places a getter with the same
 * name as the field on the class' prototype. Assigning a value to this
 * property name via the instance will make the getter inaccessible due to it
 * shadowing the getter on the [prototype chain](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Inheritance_and_the_prototype_chain#inheriting_properties).
 *
 * See: https://stackoverflow.com/a/34756469
 */
export declare function InjectProperty<T, R>(config?: InjectPropertyConfig<R>): (target: T, propName: string) => void;
