import 'reflect-metadata';
import { Constructor } from '../../types/index.js';
import { InjectByTokenConfig, SymbolToken } from '../di.types.js';
/**
 * Decorate a constructor parameter with the name or token of a constant dependency
 * known to the DI container. This value will be fulfilled on instantiation.
 *
 * This is necessary when injecting a dependency that is registered with
 * the DI container using an injection token other than a class constructor.
 *
 * Examples of things that might be injected this way include constant values like strings and numbers,
 * or already existing objects with no available constructor such as `window`.
 *
 * @param token The name of the non-constructor dependency.
 */
export declare function InjectByToken<T, Class>(token: SymbolToken<T>, config?: InjectByTokenConfig): (ctor: Constructor<Class>, paramName: string | undefined, index: number) => void;
