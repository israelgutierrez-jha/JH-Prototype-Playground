import 'reflect-metadata';
import { DiContainer } from '../di-container.js';
import { getTokenName } from '../di.helpers.js';
/**
 * Fulfills a class property with an instance of its type or the provided token.
 *
 * **Note:** It is not possible to assign instance properties using decorators.
 * Under the hood, this decorator places a getter with the same
 * name as the field on the class' prototype. Assigning a value to this
 * property name via the instance will make the getter inaccessible due to it
 * shadowing the getter on the [prototype chain](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Inheritance_and_the_prototype_chain#inheriting_properties).
 *
 * See: https://stackoverflow.com/a/34756469
 */
export function InjectProperty(config = { async: false }) {
    const { async, token } = config;
    let { container } = config;
    if (!container) {
        DiContainer.initialized$.subscribe(newContainer => {
            container = newContainer;
            return newContainer;
        }, true);
    }
    return function (target, propName) {
        const baseErrMsg = `Could not inject property '${propName}'.`;
        const paramType = Reflect.getMetadata('design:type', target, propName);
        if (async) {
            if (!token) {
                throw new Error(`${baseErrMsg} You must provide an injection token as part of the decorator config.`);
            }
            const depName = getTokenName(token);
            // throw an error if in async mode and the property is not typed as a promise
            if (paramType !== Promise) {
                throw new Error(`${baseErrMsg} It was typed as ${paramType.name} instead of as Promise<${depName}>. Correct the type or use synchronous injection.`);
            }
        }
        const diToken = token || paramType;
        if (!diToken) {
            throw new Error(`${baseErrMsg} Invalid DI token.`);
        }
        const property = {
            get() {
                if (async === true) {
                    return DiContainer.getInstance().then(container => container.getAsync(diToken));
                }
                if (!container) {
                    throw new Error(`Could not inject property: ${propName}. No DI container available.`);
                }
                // turn off warning about async providers, since this is the only way
                // to inject them into components in a way that appears synchronous
                // after createAsyncDependencies() has been called
                const dep = container.get(diToken, false);
                if (!dep) {
                    const depName = getTokenName(diToken);
                    throw new Error(`Could not inject property: ${propName}. No instance found for ${depName}.`);
                }
                return dep;
            },
        };
        Object.defineProperty(target, propName, property);
    };
}
