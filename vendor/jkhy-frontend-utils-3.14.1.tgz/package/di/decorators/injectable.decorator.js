import 'reflect-metadata';
import { DiContainer } from '../di-container.js';
import { FACTORY_DEPS, IS_INJECTABLE_KEY } from '../di.constants.js';
import { FactoryType } from '../di.types.js';
/**
 * Decorate a class to register it as a provider with the DI container
 * and make it eligible for injection.
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function Injectable(config = {}) {
    const { container, provider } = config;
    return function (ctor) {
        Reflect.defineMetadata(IS_INJECTABLE_KEY, true, ctor);
        if (provider) {
            Reflect.defineMetadata(FACTORY_DEPS, provider.dependencies, ctor);
        }
        if (container) {
            provideDependency(container, provider || ctor);
            return;
        }
        // register class with any new container instances that are emitted
        DiContainer.initialized$.subscribe(newContainer => {
            provideDependency(newContainer, provider || ctor);
        }, true);
    };
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function provideDependency(container, ctorOrProvider) {
    if (typeof ctorOrProvider !== 'function') {
        const { provide, dependencies, type, factory } = ctorOrProvider;
        if (type === FactoryType.Async) {
            const { defaultInstance } = ctorOrProvider;
            container.provideFactoryAsync(provide, dependencies, factory, defaultInstance);
        }
        else {
            container.provideFactory(provide, dependencies, factory);
        }
        return;
    }
    container.provide(ctorOrProvider);
}
