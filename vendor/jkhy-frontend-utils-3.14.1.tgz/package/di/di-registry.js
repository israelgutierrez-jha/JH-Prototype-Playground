import { exists, getBaseClass, isConstructor, isSubclassOf } from '../functions/index.js';
import { getTokenName, isInjectable } from './di.helpers.js';
import { FactoryType, } from './di.types.js';
/**
 * Encapsulates setting and retrieving dependency injection definitions and instances.
 */
export class DiRegistry {
    constructor() {
        /**
         * Definitions for dependencies that have been registered using
         * a conventional constructor-based approach or with an already-existing instance.
         *
         * Instances created from factories will also be placed here.
         */
        this.static = new Map();
        this.factories = new Map();
    }
    has(token) {
        return (this.static.has(token) || this.factories.has(token));
    }
    /**
     * Returns `true` if the provided token is fulfilled asynchronously.
     */
    isAsync(token) {
        return this.factories.get(token)?.type === FactoryType.Async;
    }
    /**
     * Returns `true` if the provided token is fulfilled via a factory.
     */
    hasFactory(token) {
        return this.factories.has(token);
    }
    hasProvider(token) {
        return this.static.has(token);
    }
    hasInstance(token) {
        const def = this.get(token);
        return exists(def?.instance);
    }
    /**
     * Retrieve a list of tokens for all asynchronous dependencies known to the registry.
     */
    getAsyncTokens() {
        return Array.from(this.factories.keys())
            .map(k => {
            const def = this.factories.get(k);
            return def?.type === FactoryType.Async ? k : undefined;
        })
            .filter(exists);
    }
    tryGetFactory(token) {
        const factoryDef = this.factories.get(token);
        if (!factoryDef) {
            const tokenName = getTokenName(token);
            throw new Error(`Could not get factory definition for ${tokenName}.`);
        }
        return factoryDef;
    }
    getInstance(token) {
        return this.static.get(token)?.instance;
    }
    getConstructor(token) {
        if (isConstructor(token) && this.isKnownSubclass(token)) {
            return token;
        }
        return this.static.get(token)?.constructor;
    }
    /**
     * Retrieves the default implementation for the provided token
     * if one exists and it is asynchronous dependency.
     */
    getDefaultInstance(token) {
        return this.factories.get(token)?.defaultInstance;
    }
    set(token, instanceOrCtor) {
        let instance;
        let constructor;
        if (isConstructor(instanceOrCtor)) {
            constructor = instanceOrCtor;
        }
        else if (exists(instanceOrCtor)) {
            instance = instanceOrCtor;
        }
        // use the token as the constructor if no mechanism to produce an instance is provided
        if (!exists(constructor) && !exists(instance) && isConstructor(token)) {
            constructor = token;
        }
        if (exists(constructor) && !isInjectable(constructor)) {
            const tokenName = getTokenName(constructor);
            throw new Error(`Cannot register ${tokenName} as a dependency. It is not decorated.`);
        }
        const parentClassToken = constructor ? this.getTokenForSubclass(constructor) : undefined;
        if (parentClassToken) {
            token = parentClassToken;
        }
        // subclasses are not directly instantiable;
        // prune subclass key from registry if it was already provided,
        // e.g.,  using @Injectable()
        if (exists(constructor) &&
            this.static.has(constructor) &&
            isConstructor(token) &&
            isSubclassOf(token, constructor)) {
            this.static.delete(constructor);
        }
        const def = this.normalizeDefinition(token, { constructor, instance });
        this.static.set(token, def);
    }
    setFactory(type, token, dependencies, factory, defaultInstance) {
        this.factories.set(token, {
            type,
            factory,
            dependencies: dependencies,
            defaultInstance,
        });
    }
    /**
     * Returns `true` if the constructor is known to the DI registry as a subclass
     * constructor of another token.
     */
    isKnownSubclass(subclass) {
        const token = this.getTokenForSubclass(subclass);
        if (!token) {
            return false;
        }
        const def = this.get(token);
        if (!def) {
            return false;
        }
        return def.constructor === subclass;
    }
    /**
     * Given a subclass for a known dependency, retrieve its DI token.
     */
    getTokenForSubclass(subclass) {
        // don't return anything if the class is already a token
        if (this.has(subclass)) {
            return;
        }
        // find the base class constructor to determine if it is known
        const baseClass = getBaseClass(subclass);
        if (!this.has(baseClass)) {
            return;
        }
        return baseClass;
    }
    /**
     * Given a list of tokens, return those which are not known to
     * the registry or are not subclasses of ones that are.
     */
    getUnknownDependencies(list) {
        const isKnownSubclass = (token) => isConstructor(token) && this.isKnownSubclass(token);
        return list.filter(token => !this.has(token) && !isKnownSubclass(token));
    }
    /**
     * Copy the dependency contents of another `DiRegistry` into this one.
     */
    copyFrom(other) {
        other.static.forEach((value, key) => {
            this.static.set(key, value);
        });
        other.factories.forEach((value, key) => {
            this.factories.set(key, value);
        });
    }
    get(token) {
        return this.static.get(token);
    }
    normalizeDefinition(token, props) {
        const { instance, constructor } = props;
        const def = this.static.get(token) || {};
        // mutate the definition if it exists rather than creating a new one
        // with spread syntax so that consumers with existing references are updated
        def.instance = instance;
        def.constructor = constructor;
        return def;
    }
}
