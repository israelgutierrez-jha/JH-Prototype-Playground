import type { NavigationGuard, NavigationGuardHandle, NavigationOptions, RouterConfig, RouterLocation } from './router.types.js';
/**
 * A zero-dependency, framework agnostic single-page application (SPA) router for
 * use with web component based applications.
 *
 * This router utilizes the native `URLPattern` API for route matching.
 *
 * This is a singleton class. Use `Router.getInstance()` to get the instance, then
 * call `init(config)` to configure and start the router.
 */
export declare class Router {
    /**
     * The current location object
     */
    get location(): RouterLocation;
    private static instance?;
    private outlet?;
    private routePatterns?;
    private basePath?;
    private basePathPattern?;
    private basePathParams;
    private currentLocation?;
    private previousLocation?;
    private isNavigating;
    private pendingNavigation?;
    private readonly namedRoutes;
    private readonly navigationGuards;
    private constructor();
    /**
     * Gets the singleton Router instance. Creates it if it doesn't exist.
     *
     * @returns The singleton Router instance
     */
    static getInstance(): Router;
    /**
     * Configures and starts the router. Sets up the outlet, route patterns, named
     * route map, and navigation listeners, then navigates to the current URL.
     *
     * @param config - Router configuration object containing outlet, routes, and optional basePath
     */
    init(config: RouterConfig): void;
    /**
     * Registers a guard that is evaluated before every navigation.
     * Return `true` to allow navigation, `false` to block it.
     *
     * The guard is automatically removed once it allows navigation to proceed.
     * If it blocks navigation it remains registered and will be evaluated again
     * on the next navigation attempt.
     *
     * The returned handle's `remove()` method can be used to unregister the guard
     * early if needed (e.g. when a form is submitted programmatically without navigating).
     *
     * Note: guards do not apply to browser tab or window close events.
     *
     * @param guard - Function evaluated before navigation proceeds
     * @returns A handle with a `remove()` method to unregister the guard early
     */
    addNavigationGuard(guard: NavigationGuard): NavigationGuardHandle;
    /**
     * Trigger navigation to a named route, with optional navigation options.
     *
     * @param name - Route name to navigate to
     * @param options - Navigation options including params for path substitution
     */
    go(name: string, options?: NavigationOptions): void;
    /**
     * Generate a path for a named route. Path parameter values will be
     * substituted into the route returned path.
     *
     * @param name - The route name
     * @param params - Optional object of route parameters
     * @returns The generated path string
     */
    pathForName(name: string, params?: Record<string, string>): string;
    private buildPathFromPattern;
    private buildRoutePatterns;
    private joinPaths;
    private buildNamedRouteMap;
    /**
     * Ensures base path params are extracted from the current URL
     */
    private ensureBasePathParams;
    /**
     * Extracts parameter names from the base path pattern
     */
    private getBasePathParamNames;
    /**
     * Extracts base path parameters from a given pathname
     */
    private extractBasePathParams;
    private setupNavigationListeners;
    private shouldIgnoreClick;
    private findAnchorElement;
    private shouldHandleAnchorClick;
    private goToPath;
    private handleNavigation;
    private findMatchingRoute;
    private createLocation;
    private createLocationFromUrl;
    private render;
    private clearContainerChildren;
    private emitLocationChanged;
    /**
     * Evaluates all registered navigation guards in order.
     * Returns `true` if all guards allow navigation, `false` if any block it.
     * Removes all guards on success. Restores the URL on popstate block.
     */
    private runNavigationGuards;
    private restoreCurrentUrl;
    /**
     * Normalize a pathname by removing a trailing slash if present.
     * @param pathname - The pathname to normalize.
     */
    private normalizePathname;
}
