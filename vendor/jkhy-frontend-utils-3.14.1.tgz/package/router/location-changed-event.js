/**
 * Event fired during navigation, after component has rendered.
 * Contains the new location and previous location (if any).
 */
export class LocationChangedEvent extends Event {
    constructor(location, previousLocation) {
        super(LocationChangedEvent.eventName, { bubbles: true, composed: true });
        this.location = location;
        this.previousLocation = previousLocation;
    }
}
LocationChangedEvent.eventName = 'jh-router-location-changed';
