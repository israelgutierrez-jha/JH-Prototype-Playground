import { LocationChangedEvent } from './location-changed-event.js';
/**
 * A zero-dependency, framework agnostic single-page application (SPA) router for
 * use with web component based applications.
 *
 * This router utilizes the native `URLPattern` API for route matching.
 *
 * This is a singleton class. Use `Router.getInstance()` to get the instance, then
 * call `init(config)` to configure and start the router.
 */
export class Router {
    /**
     * The current location object
     */
    get location() {
        this.currentLocation ?? (this.currentLocation = this.createLocationFromUrl(window.location));
        return this.currentLocation;
    }
    constructor() {
        this.basePathParams = {};
        this.isNavigating = false;
        this.namedRoutes = new Map();
        this.navigationGuards = new Set();
    }
    /**
     * Gets the singleton Router instance. Creates it if it doesn't exist.
     *
     * @returns The singleton Router instance
     */
    static getInstance() {
        if (!Router.instance) {
            Router.instance = new Router();
        }
        return Router.instance;
    }
    /**
     * Configures and starts the router. Sets up the outlet, route patterns, named
     * route map, and navigation listeners, then navigates to the current URL.
     *
     * @param config - Router configuration object containing outlet, routes, and optional basePath
     */
    init(config) {
        this.outlet = config.outlet;
        this.basePath = config.basePath ?? '';
        this.basePathPattern = undefined;
        this.basePathParams = {};
        this.currentLocation = undefined;
        this.previousLocation = undefined;
        if (this.basePath) {
            this.basePathPattern = new URLPattern({ pathname: this.basePath });
        }
        this.navigationGuards.clear();
        this.routePatterns = this.buildRoutePatterns(config.routes, this.basePath);
        this.buildNamedRouteMap();
        this.setupNavigationListeners();
        void this.handleNavigation(window.location.pathname + window.location.search);
    }
    /**
     * Registers a guard that is evaluated before every navigation.
     * Return `true` to allow navigation, `false` to block it.
     *
     * The guard is automatically removed once it allows navigation to proceed.
     * If it blocks navigation it remains registered and will be evaluated again
     * on the next navigation attempt.
     *
     * The returned handle's `remove()` method can be used to unregister the guard
     * early if needed (e.g. when a form is submitted programmatically without navigating).
     *
     * Note: guards do not apply to browser tab or window close events.
     *
     * @param guard - Function evaluated before navigation proceeds
     * @returns A handle with a `remove()` method to unregister the guard early
     */
    addNavigationGuard(guard) {
        this.navigationGuards.add(guard);
        return {
            remove: () => {
                this.navigationGuards.delete(guard);
            },
        };
    }
    /**
     * Trigger navigation to a named route, with optional navigation options.
     *
     * @param name - Route name to navigate to
     * @param options - Navigation options including params for path substitution
     */
    go(name, options) {
        const pattern = this.namedRoutes.get(name);
        if (!pattern) {
            throw new Error(`No route found with name: ${name}. Pathless routes cannot be navigated to directly.`);
        }
        this.ensureBasePathParams();
        const mergedParams = { ...this.basePathParams, ...options?.params };
        // Build the URL for browser history
        let path = this.buildPathFromPattern(pattern.path, mergedParams);
        if (options?.searchParams) {
            const searchStr = typeof options.searchParams === 'string'
                ? options.searchParams
                : options.searchParams.toString();
            path += (path.includes('?') ? '&' : '?') + searchStr;
        }
        const matchedRoute = {
            route: pattern.route,
            params: mergedParams,
            chain: pattern.chain,
        };
        // Navigate using the pre matched route to skip redundant route lookup
        void this.handleNavigation(path, matchedRoute, options?.replace ? 'replace' : 'push', options?.state);
    }
    /**
     * Generate a path for a named route. Path parameter values will be
     * substituted into the route returned path.
     *
     * @param name - The route name
     * @param params - Optional object of route parameters
     * @returns The generated path string
     */
    pathForName(name, params) {
        const pattern = this.namedRoutes.get(name);
        if (!pattern) {
            throw new Error(`No route found with name: ${name}. Pathless routes cannot be navigated to directly.`);
        }
        this.ensureBasePathParams();
        const mergedParams = { ...this.basePathParams, ...params };
        return this.buildPathFromPattern(pattern.path, mergedParams);
    }
    buildPathFromPattern(pathPattern, params) {
        let path = pathPattern;
        if (params) {
            for (const [key, value] of Object.entries(params)) {
                // Replace all occurrences of both required (:key) and optional (:key?) parameters
                // Use regex with global flag to replace all occurrences
                const optionalParamRegex = new RegExp(`:${key}\\?`, 'g');
                const requiredParamRegex = new RegExp(`:${key}`, 'g');
                path = path.replace(optionalParamRegex, value);
                path = path.replace(requiredParamRegex, value);
            }
        }
        // Remove any remaining optional parameters that weren't provided
        path = path.replace(/\/:[^/]+\?/g, '');
        // Check for any remaining required parameters that weren't substituted
        const missingParams = path.match(/:(\w+)/g);
        if (missingParams) {
            throw new Error(`Missing required parameter(s) for route: ${missingParams.join(', ')}. Cannot generate URL: ${pathPattern}`);
        }
        return path;
    }
    buildRoutePatterns(routes, parentPath = '', chain = []) {
        const patterns = [];
        for (const route of routes) {
            const fullPath = route.path ? this.joinPaths(parentPath, route.path) : parentPath;
            chain.push(route);
            // Only create a pattern if the route has a defined path
            if (route.path) {
                const pattern = new URLPattern({ pathname: fullPath });
                patterns.push({
                    path: fullPath,
                    pattern,
                    route,
                    chain: [...chain],
                });
            }
            // Recursively process children
            if (route.children) {
                patterns.push(...this.buildRoutePatterns(route.children, fullPath, chain));
            }
            chain.pop();
        }
        return patterns;
    }
    joinPaths(parent, child) {
        if (!parent)
            return child;
        if (!child)
            return parent;
        // Remove trailing slash from parent and leading slash from child
        const cleanParent = parent.endsWith('/') ? parent.slice(0, -1) : parent;
        const cleanChild = child.startsWith('/') ? child.slice(1) : child;
        return cleanChild ? `${cleanParent}/${cleanChild}` : cleanParent;
    }
    buildNamedRouteMap() {
        if (!this.routePatterns)
            return;
        this.namedRoutes.clear();
        for (const pattern of this.routePatterns) {
            if (pattern.route.name) {
                this.namedRoutes.set(pattern.route.name, pattern);
            }
        }
    }
    /**
     * Ensures base path params are extracted from the current URL
     */
    ensureBasePathParams() {
        if (Object.keys(this.basePathParams).length === 0) {
            if (this.currentLocation?.params) {
                const basePathParamNames = this.getBasePathParamNames();
                for (const paramName of basePathParamNames) {
                    if (this.currentLocation.params[paramName]) {
                        this.basePathParams[paramName] = this.currentLocation.params[paramName];
                    }
                }
            }
        }
    }
    /**
     * Extracts parameter names from the base path pattern
     */
    getBasePathParamNames() {
        if (!this.basePathPattern)
            return [];
        const testMatch = this.basePathPattern.exec({ pathname: this.basePath });
        if (testMatch?.pathname.groups) {
            return Object.keys(testMatch.pathname.groups);
        }
        return [];
    }
    /**
     * Extracts base path parameters from a given pathname
     */
    extractBasePathParams(pathname) {
        if (this.basePathPattern) {
            const basePathMatch = this.basePathPattern.exec({ pathname });
            if (basePathMatch) {
                this.basePathParams = {};
                for (const [key, value] of Object.entries(basePathMatch.pathname.groups)) {
                    if (value !== undefined) {
                        this.basePathParams[key] = value;
                    }
                }
            }
        }
    }
    setupNavigationListeners() {
        // Handle browser back/forward
        window.addEventListener('popstate', () => {
            void this.handleNavigation(window.location.pathname + window.location.search, undefined, undefined, undefined, true);
        });
        window.addEventListener('click', e => {
            if (this.shouldIgnoreClick(e))
                return;
            const anchor = this.findAnchorElement(e);
            if (!anchor || !this.shouldHandleAnchorClick(anchor))
                return;
            const path = anchor.pathname + anchor.search + anchor.hash;
            const url = new URL(path, window.location.origin);
            const matchedRoute = this.findMatchingRoute(url.pathname);
            // No matching route, let browser handle the navigation
            if (!matchedRoute)
                return;
            e.preventDefault();
            this.goToPath(path, matchedRoute);
        });
    }
    shouldIgnoreClick(e) {
        return e.defaultPrevented || e.ctrlKey || e.metaKey || e.shiftKey;
    }
    findAnchorElement(e) {
        // Check direct target first
        if (e.target instanceof HTMLAnchorElement) {
            return e.target;
        }
        // Fall back to composed path for Shadow DOM
        const composedPath = e.composedPath();
        for (const element of composedPath) {
            if (element instanceof HTMLAnchorElement) {
                return element;
            }
        }
    }
    shouldHandleAnchorClick(anchor) {
        const excludedProtocols = ['mailto:', 'tel:', 'javascript:', 'data:', 'vbscript:'];
        return (!!anchor.href &&
            anchor.origin === window.location.origin &&
            anchor.target !== '_blank' &&
            !excludedProtocols.includes(anchor.protocol) &&
            !anchor.hasAttribute('download'));
    }
    goToPath(path, matchedRoute) {
        void this.handleNavigation(path, matchedRoute, 'push');
    }
    async handleNavigation(path, preMatchedRoute, historyAction, historyState, isPopstate = false) {
        if (this.isNavigating) {
            // Navigation triggered during previous navigation, queue it up for processing after the current one finishes
            if (this.pendingNavigation?.path !== path) {
                this.pendingNavigation = { path, matchedRoute: preMatchedRoute };
            }
            return;
        }
        this.isNavigating = true;
        let pendingRedirect;
        try {
            // Parse the URL
            const url = new URL(path, window.location.origin);
            const pathname = url.pathname;
            // Find matching route (use pre matched route if provided)
            const matchedRoute = preMatchedRoute ?? this.findMatchingRoute(pathname);
            if (!matchedRoute) {
                console.error(`No route found for path: ${pathname}`);
                return;
            }
            // Run navigation guards before committing to navigation
            if (this.navigationGuards.size > 0 && !(await this.runNavigationGuards(isPopstate))) {
                return;
            }
            const context = {
                pathname,
                searchParams: url.searchParams,
                params: matchedRoute.params,
                route: matchedRoute.route,
                redirect: (name, params) => {
                    pendingRedirect = { name, params };
                },
            };
            // Handle redirect
            if (matchedRoute.route.redirectName) {
                // Allow the redirect to proceed immediately by clearing the navigation lock
                this.isNavigating = false;
                this.go(matchedRoute.route.redirectName, {
                    replace: true,
                    params: matchedRoute.params,
                });
                return;
            }
            // Execute route actions (guards and imports) for all routes in the chain
            for (const route of matchedRoute.chain) {
                if (route.beforeEnter) {
                    const result = await route.beforeEnter(context);
                    if (!result) {
                        // Navigation prevented
                        if (pendingRedirect) {
                            this.isNavigating = false;
                            this.go(pendingRedirect.name, {
                                replace: true,
                                params: pendingRedirect.params,
                            });
                        }
                        return;
                    }
                }
            }
            // Only update history after guards pass
            if (historyAction === 'replace') {
                window.history.replaceState(historyState ?? null, '', path);
            }
            else if (historyAction === 'push') {
                window.history.pushState(historyState ?? null, '', path);
            }
            // Create location object
            const location = this.createLocation(url, matchedRoute);
            // Update current location
            this.previousLocation = this.currentLocation;
            this.currentLocation = location;
            // Render the component
            this.render(matchedRoute);
            // Emit location changed event
            this.emitLocationChanged(location, this.previousLocation);
        }
        finally {
            this.isNavigating = false;
            // Process any pending navigation that was queued
            if (this.pendingNavigation) {
                const { path, matchedRoute } = this.pendingNavigation;
                this.pendingNavigation = undefined;
                void this.handleNavigation(path, matchedRoute);
            }
        }
    }
    findMatchingRoute(pathname) {
        if (!this.routePatterns)
            return undefined;
        // Extract base path parameters first
        this.extractBasePathParams(pathname);
        // Normalize pathname by removing trailing slash for matching
        const normalizedPathname = this.normalizePathname(pathname);
        // Try to match against all route patterns
        for (const routePattern of this.routePatterns) {
            // Try matching with normalized pathname first, fallback to original
            const result = routePattern.pattern.exec({
                pathname: normalizedPathname,
            }) ??
                routePattern.pattern.exec({
                    pathname,
                });
            if (result) {
                // Extract parameters from the match
                const params = {};
                for (const [key, value] of Object.entries(result.pathname.groups)) {
                    if (value !== undefined) {
                        params[key] = value;
                    }
                }
                return {
                    route: routePattern.route,
                    params,
                    chain: routePattern.chain,
                };
            }
        }
    }
    createLocation(url, match) {
        return {
            pathname: url.pathname,
            hash: url.hash,
            params: match.params,
            route: match.route,
            searchParams: url.searchParams,
        };
    }
    createLocationFromUrl(location) {
        const pathname = location.pathname;
        const match = this.findMatchingRoute(pathname);
        return {
            pathname,
            hash: location.hash,
            params: match?.params ?? {},
            route: match?.route,
            searchParams: new URLSearchParams(location.search),
        };
    }
    render(match) {
        if (!this.outlet)
            throw new Error('Router outlet element is not defined');
        if (!match.route.tagName)
            return;
        // Build the component hierarchy from the chain
        let currentContainer = this.outlet;
        // Render each component in the chain, reusing existing elements when possible
        for (let i = 0; i < match.chain.length; i++) {
            const route = match.chain[i];
            if (!route.tagName) {
                continue;
            }
            // Check if the current component already exists in the correct position
            const existingElement = currentContainer.querySelector(`:scope > ${route.tagName}`);
            if (existingElement) {
                // Component already exists, reuse it
                currentContainer = existingElement;
                // If this is the last route in the chain, remove any child route components
                // that are no longer part of the active route
                if (i === match.chain.length - 1) {
                    this.clearContainerChildren(currentContainer);
                }
            }
            else {
                // Component doesn't exist, we need to create it and remove any old child content
                this.clearContainerChildren(currentContainer);
                // Create new component and all remaining components in the chain
                const enterElements = [];
                for (let j = i; j < match.chain.length; j++) {
                    const remainingRoute = match.chain[j];
                    if (remainingRoute.tagName) {
                        const element = document.createElement(remainingRoute.tagName);
                        element.classList.add('route-enter');
                        currentContainer.appendChild(element);
                        enterElements.push(element);
                        currentContainer = element;
                    }
                }
                // Batch animate all new elements in a single requestAnimationFrame
                if (enterElements.length > 0) {
                    requestAnimationFrame(() => {
                        enterElements.forEach(element => {
                            element.classList.add('route-enter-active');
                            // Remove animation classes after transition completes
                            element.addEventListener('transitionend', (e) => {
                                if (e.target !== element)
                                    return;
                                element.classList.remove('route-enter', 'route-enter-active');
                            }, { once: true });
                            // Fallback: remove classes if no transition defined
                            setTimeout(() => {
                                element.classList.remove('route-enter', 'route-enter-active');
                            }, 500);
                        });
                    });
                }
                break;
            }
        }
    }
    clearContainerChildren(container) {
        const children = Array.from(container.children);
        children.forEach(child => {
            child.classList.add('route-exit');
            child.classList.remove('route-enter', 'route-enter-active');
        });
        container.innerHTML = '';
    }
    emitLocationChanged(location, previousLocation) {
        const event = new LocationChangedEvent(location, previousLocation);
        window.dispatchEvent(event);
    }
    /**
     * Evaluates all registered navigation guards in order.
     * Returns `true` if all guards allow navigation, `false` if any block it.
     * Removes all guards on success. Restores the URL on popstate block.
     */
    async runNavigationGuards(isPopstate) {
        if (this.navigationGuards.size === 0)
            return true;
        const guards = [...this.navigationGuards];
        for (const guard of guards) {
            const allowed = await guard();
            if (!allowed) {
                if (isPopstate)
                    this.restoreCurrentUrl();
                return false;
            }
        }
        // All guards allowed navigation — remove them
        for (const guard of guards) {
            this.navigationGuards.delete(guard);
        }
        return true;
    }
    restoreCurrentUrl() {
        if (!this.currentLocation) {
            throw new Error('Navigation guard blocked a popstate event but currentLocation is undefined.');
        }
        const search = this.currentLocation.searchParams?.toString();
        const restoredPath = this.currentLocation.pathname +
            (search ? `?${search}` : '') +
            (this.currentLocation.hash ?? '');
        window.history.replaceState(null, '', restoredPath);
    }
    /**
     * Normalize a pathname by removing a trailing slash if present.
     * @param pathname - The pathname to normalize.
     */
    normalizePathname(pathname) {
        return pathname.endsWith('/') ? pathname.slice(0, -1) : pathname;
    }
}
