import { RouterLocation } from './router.types.js';
/**
 * Event fired during navigation, after component has rendered.
 * Contains the new location and previous location (if any).
 */
export declare class LocationChangedEvent extends Event {
    static readonly eventName = "jh-router-location-changed";
    readonly location: RouterLocation;
    readonly previousLocation?: RouterLocation;
    constructor(location: RouterLocation, previousLocation?: RouterLocation);
}
