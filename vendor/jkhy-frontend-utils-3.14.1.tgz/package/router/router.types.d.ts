export interface Route {
    /**
     * Name for the route, used for named navigation
     */
    name: string;
    /**
     * The path pattern for this route (e.g., '/users/:id', '/posts/:postId?')
     * Supports path parameters with ':' prefix and optional parameters with '?' suffix
     * Optional for layout-only routes that should not be directly navigable
     */
    path?: string;
    /**
     * The component tag name to render when this route matches
     */
    tagName?: string;
    /**
     * Optional route name to redirect to.
     */
    redirectName?: string;
    /**
     * Child routes nested under this route
     */
    children?: Route[];
    /**
     * Optional function to execute during navigation, before rendering the component.
     * Can be used for imports, route guards, data loading, etc.
     * Returning false prevents navigation
     */
    beforeEnter?: (context: RouteContext) => Promise<boolean> | boolean;
}
export interface RouteContext {
    /**
     * The path that was matched (e.g., '/users/123')
     */
    pathname: string;
    /**
     * Search parameters as URLSearchParams object
     */
    searchParams: URLSearchParams;
    /**
     * Extracted path parameters (e.g., { id: '123' })
     */
    params: Record<string, string>;
    /**
     * The route configuration that matched
     */
    route: Route;
    /**
     * Navigate to a different route by name (useful for redirects in actions)
     */
    redirect: (name: string, params?: Record<string, string>) => void;
}
export interface RouterLocation {
    /**
     * The current pathname
     */
    pathname: string;
    /**
     * Hash fragment (with leading '#')
     */
    hash: string;
    /**
     * Extracted path parameters
     */
    params: Record<string, string>;
    /**
     * The matched route configuration
     */
    route?: Route;
    /**
     * Search parameters as URLSearchParams object
     */
    searchParams?: URLSearchParams;
}
export interface NavigationOptions {
    /**
     * Whether to replace the current history entry instead of pushing a new one
     */
    replace?: boolean;
    /**
     * Search parameters to append to the URL
     */
    searchParams?: URLSearchParams | string;
    /**
     * Additional state to store with the history entry
     */
    state?: unknown;
    /**
     * Route parameters for URL path substitution (e.g., { id: '123' } for path '/users/:id')
     */
    params?: Record<string, string>;
}
export interface RedirectConfig {
    /**
     * The route name to redirect to
     */
    name: string;
    /**
     * Optional parameters for the redirect route
     */
    params?: Record<string, string>;
}
export interface MatchedRoute {
    /**
     * The route configuration that matched
     */
    route: Route;
    /**
     * Extracted path parameters
     */
    params: Record<string, string>;
    /**
     * Full chain of parent routes leading to this match
     */
    chain: Route[];
}
export interface RoutePattern {
    /**
     * The original route path from config
     */
    path: string;
    /**
     * The URLPattern instance for matching
     */
    pattern: URLPattern;
    /**
     * The route configuration
     */
    route: Route;
    /**
     * Parent route chain
     */
    chain: Route[];
}
/**
 * A function that can prevent navigation from proceeding.
 * Return (or resolve) `true` to allow navigation, `false` to block it.
 */
export type NavigationGuard = () => boolean | Promise<boolean>;
/**
 * Handle returned by `addNavigationGuard`. Call `remove()` to unregister
 * the guard before it is automatically removed on successful navigation.
 */
export interface NavigationGuardHandle {
    remove: () => void;
}
export interface RouterConfig {
    /**
     * The DOM element where route components will be rendered
     */
    outlet: Element;
    /**
     * Array of route configuration objects
     */
    routes: Route[];
    /**
     * Optional base path to prepend to all routes (e.g., '/a/app-name/')
     * @default ''
     */
    basePath?: string;
}
