/**
 * Generate a pseudo-unique identifier.
 * Suitable for client-side unique identifiers like hash keys.
 *
 * Should not be used for applications where long-lived universal uniqueness is required.
 */
export function createUniqueId() {
    try {
        return crypto.randomUUID();
    }
    catch {
        // randomUUID() is only supported in secure contexts (i.e., HTTPS) and localhost;
        // fall back to generating the ID manually in insecure contexts
        const regex = /[018]/g;
        const templateString = '10000000-1000-4000-8000-100000000000';
        // https://stackoverflow.com/a/2117523/574930
        return templateString.replace(regex, c => (+c ^ (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (+c / 4)))).toString(16));
    }
}
