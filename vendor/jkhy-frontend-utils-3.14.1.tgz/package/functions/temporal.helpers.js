/**
 * Create a `Promise` that resolves after a set amount of time.
 * Useful for performing an action with a delay without manually invoking `setTimeout()`.
 *
 * To maximize readability, pair with `await`.
 *
 * @example
 * const delayedValue= async value => {
 *    await delay(500);
 *    return value;
 * };
 * @param period Delay in milliseconds.
 */
export function delay(period = 0) {
    if (period < 0) {
        throw new Error('Cannot create a delay with a negative timeout value.');
    }
    return new Promise(resolve => {
        const handle = setTimeout(() => {
            clearTimeout(handle);
            resolve();
        }, period);
    });
}
/**
 * Await a promise up to a maximum amount of time.
 *
 * If it does not resolve within this time, this results in a rejected promise.
 * If it does, the result of the original is returned.
 *
 * @param limit Maximum time to wait, in milliseconds.
 * @returns The result of the original promise if it is completed
 * within the maximum time specified.
 */
export function waitUntil(p, limit) {
    const guardPromise = delay(limit).then(() => {
        throw new Error(`Failed to resolve promise within ${limit} milliseconds.`);
    });
    return Promise.race([p, guardPromise]);
}
export const debounce = (func, wait) => {
    let timeout;
    return function (...args) {
        return new Promise(resolve => {
            if (timeout) {
                clearTimeout(timeout);
            }
            timeout = setTimeout(() => resolve(func(...args)), wait);
        });
    };
};
