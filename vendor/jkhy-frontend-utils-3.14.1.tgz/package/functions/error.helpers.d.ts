export declare function coerceError(maybeError: unknown): Error;
