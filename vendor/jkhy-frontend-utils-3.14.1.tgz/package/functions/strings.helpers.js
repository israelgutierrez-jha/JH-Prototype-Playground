import { exists } from './object.helpers.js';
export function isEmptyString(str) {
    return typeof str === 'string' && str.length === 0;
}
export function isNonEmptyString(str) {
    return typeof str === 'string' && str.length > 0;
}
/**
 * Returns `true` if the provided value is a string containing
 * only an integer number (e.g., `'10203'`).
 */
export function isIntegerString(str) {
    if (!exists(str)) {
        return false;
    }
    if (str.length < 1) {
        return false;
    }
    // do not consider decimal numbers
    if (str.includes('.')) {
        return false;
    }
    // avoiding parseInt() here, as it parses strings with postfix measurement units
    return !Number.isNaN(+str);
}
/**
 * Removes all non-alphanumeric characters in a string.
 */
export function removeSpecialChars(str) {
    // https://regex101.com/r/DJTaqH/1
    return (str || '').replace(/[^a-zA-Z0-9]/g, '');
}
/**
 * Type guard that checks if a value is null or undefined or an empty string.
 * @param value - The value to check.
 * @param considerWhitespace - Optional flag to trim whitespace during the evaluation
 * @returns True if the value is null, undefined, or an empty string; otherwise, false.
 */
export function isNullOrEmpty(value, considerWhitespace = false) {
    if (!exists(value)) {
        return true;
    }
    if (typeof value !== 'string') {
        return false;
    }
    // Now we know `value` is a string, so we can safely call .trim()
    return (considerWhitespace ? value.trim() : value) === '';
}
/**
 * Gets the value or the default value if the value is null or undefined.
 * @param value
 * @param defaultValue
 * @returns value or default value
 */
export function getValueOrDefault(value, defaultValue = '—') {
    return isNullOrEmpty(value) ? defaultValue : value;
}
/**
 * Removes the trailing period off a string value
 * @param value
 * @returns value without trailing period
 */
export function removeTrailingPeriod(value) {
    // Use regular expressions to match a trailing period
    const pattern = /^(?<stringValue>.*)\.$/u;
    // Check if the string matches the pattern
    if (pattern.test(value)) {
        // Extract the content without the trailing period
        return value.replace(pattern, '$1');
    }
    // If the string doesn't have a trailing period, return it as is
    return value;
}
/**
 * Type guard that checks if a value is not an empty string.
 * @param value - The value to check.
 * @returns false if the value is null, undefined, or an empty string; otherwise, true.
 */
export function hasValue(value) {
    return value !== null && value !== void 0 && value.length > 0;
}
/**
 * Formats a string with sentence case.
 * @param value
 * @returns reformatted string
 */
export function toSentenceCase(value) {
    if (isNullOrEmpty(value)) {
        return '';
    }
    return value[0].toUpperCase() + value.substring(1).toLowerCase();
}
/**
 * Masks a string based on a specified mode.
 * @param text The raw string to mask.
 * @param options The configuration object for masking.
 * @returns The masked string.
 */
export function maskText(text, options) {
    const MASK_CHAR = '*';
    switch (options.maskingMode) {
        case 'last-four': {
            if (text.length <= 4) {
                return text.replace(/./g, MASK_CHAR);
            }
            const lastFour = text.slice(-4);
            let prefix;
            if (options.asteriskCount !== undefined && options.asteriskCount > 0) {
                prefix = MASK_CHAR.repeat(options.asteriskCount);
            }
            else {
                const hiddenLength = text.length - 4;
                prefix = MASK_CHAR.repeat(hiddenLength);
            }
            return `${prefix}${lastFour}`;
        }
        case 'full':
        default:
            // If text is available, mask it fully. Otherwise, use a fixed length.
            return text ? text.replace(/./g, MASK_CHAR) : MASK_CHAR.repeat(options.maskLength ?? 8);
    }
}
