/**
 * Type guard to determine if a reference is valid.
 *
 * Serves both a runtime purpose as well a type-narrowing one.
 * See: https://www.typescriptlang.org/docs/handbook/2/narrowing.html#using-type-predicates
 *
 * @param ref Reference whose value may be `null` or `undefined`.
 * @returns A boolean value indicating the validity of the object reference.
 * Returns `true` if the reference t is valid; `false` if the value is  `undefined` or `null`.
 */
export function exists(ref) {
    return ref !== null && typeof ref !== 'undefined';
}
/**
 * Verifies that a given list of property names all exist on the provided object.
 */
export function verifyPropNames(obj, ...propNames) {
    return propNames.every(propName => propName in obj);
}
/**
 *
 * @returns `true` if argument is a non-null, non-primitive, non-array object
 */
export function isObject(ref) {
    return exists(ref) && typeof ref === 'object' && !Array.isArray(ref);
}
export function isPrimitive(ref) {
    const type = typeof ref;
    switch (type) {
        case 'number':
        case 'bigint':
        case 'string':
        case 'boolean':
        case 'symbol':
        case 'undefined':
            return true;
        case 'object':
            return ref === null;
        default:
            return false;
    }
}
/**
 * Coerces a possibly `undefined` value to the `null` value.
 */
export function coerceToNull(ref) {
    return typeof ref === 'undefined' ? null : ref;
}
export function arrayToDict(arr, transform) {
    return arr.reduce((dict, val, i) => {
        const { key, value } = transform(val, i);
        dict[key] = value;
        return dict;
    }, {});
}
/**
 * Coerces an object with possibly `undefined` values to `null` values.
 */
export function coerceMembersToNull(object) {
    const keys = Object.keys(object);
    return keys.reduce((copy, key) => {
        copy[key] = coerceToNull(object[key]);
        return copy;
    }, {});
}
/**
 * Coerces a possibly empty string to the `null` value.
 */
export function coerceEmptyStringToNull(str) {
    return str.length === 0 ? null : str;
}
/**
 * Coerces an object with possibly empty string values to `null` values.
 */
export function coerceEmptyStringsToNull(object) {
    const keys = Object.keys(object);
    return keys.reduce((copy, key) => {
        const val = object[key];
        // can't reuse coerceEmptyStringToNull() here; TS doesn't like the lack of type narrowing
        copy[key] = typeof val === 'string' && val.length === 0 ? null : val;
        return copy;
    }, {});
}
/**
 * Coerces a possibly synchronous or deferred value into an asynchronous one.
 */
export async function coerceToAsyncValue(value) {
    return typeof value === 'function' ? value() : value;
}
/**
 * Deeply copies an object, maintaining the prototype chain for class instances.
 *
 * Supports circular references by maintaining cloned object references.
 */
export function clone(obj) {
    function _clone(current, seenRefs) {
        if (current === null || typeof current === 'undefined') {
            return current;
        }
        const type = typeof current;
        const noCloneTypes = ['string', 'boolean', 'number', 'function'];
        if (noCloneTypes.includes(type)) {
            return current;
        }
        if (current instanceof Node) {
            return current.cloneNode(true);
        }
        if (current instanceof Date) {
            return new Date(current.getTime());
        }
        if (Array.isArray(current)) {
            return current.map(val => _clone(val, seenRefs));
        }
        // prevent infinite recursion by returning the clone for a previously seen ref
        if (seenRefs.has(current)) {
            return seenRefs.get(current);
        }
        const proto = Object.getPrototypeOf(current);
        const clonedObj = Object.create(proto);
        const keys = Object.keys(current);
        // associate the original reference and the clone for
        // linking circular references in future recursive calls
        seenRefs.set(current, clonedObj);
        // copy instance properties not on prototype
        keys.forEach(k => {
            clonedObj[k] = _clone(current[k], seenRefs);
        });
        return clonedObj;
    }
    const seenRefs = new Map();
    const clone = _clone(obj, seenRefs);
    seenRefs.clear();
    return clone;
}
/**
 * Compare two objects for deep equality.
 *
 * Adapted from `fast-deep-equal`.
 */
export function deepEquals(a, b) {
    if (a === b) {
        return true;
    }
    if (Number.isNaN(a) && Number.isNaN(b)) {
        return true;
    }
    if (Array.isArray(a) && Array.isArray(b)) {
        if (a.length !== b.length) {
            return false;
        }
        for (let i = 0; i < a.length; i++) {
            if (!deepEquals(a[i], b[i])) {
                return false;
            }
        }
        return true;
    }
    if (isObject(a) && isObject(b)) {
        if (a.constructor !== b.constructor)
            return false;
        if (a instanceof RegExp && b instanceof RegExp) {
            return a.source === b.source && a.flags === b.flags;
        }
        if (a instanceof Date && b instanceof Date) {
            return a.getTime() === b.getTime();
        }
        if (a.valueOf !== Object.prototype.valueOf)
            return a.valueOf() === b.valueOf();
        if (a.toString !== Object.prototype.toString)
            return a.toString() === b.toString();
        const keys = Object.keys(a);
        const { length } = keys;
        if (length !== Object.keys(b).length)
            return false;
        for (let i = 0; i < length; i++)
            if (!Object.prototype.hasOwnProperty.call(b, keys[i]))
                return false;
        for (let i = 0; i < length; i++) {
            const key = keys[i];
            const val1 = a[key];
            const val2 = b[key];
            if (!deepEquals(val1, val2)) {
                return false;
            }
        }
        return true;
    }
    return false;
}
/**
 * Strongly-typed alternative to `Object.keys()`.
 * Returns only keys for an object's [own properties](https://www.javascripttutorial.net/javascript-own-properties/).
 */
export function getKeys(obj) {
    return Object.keys(obj);
}
/**
 * Returns the keys owned directly by an object as well as those on its prototype.
 * This includes both enumerable and non-enumerable keys.
 */
export function getKeysInstance(obj) {
    const forbiddenKeys = ['constructor', '__defineGetter__', 'toString', '__proto__'];
    let proto = Object.getPrototypeOf(obj);
    const keys = getKeys(obj);
    // don't consider keys from the top of the prototype hierarchy
    while (exists(proto) && proto !== Object.prototype) {
        const protoKeys = Object.getOwnPropertyNames(proto).filter(k => !forbiddenKeys.includes(k));
        keys.push(...protoKeys);
        proto = Object.getPrototypeOf(proto);
    }
    return keys;
}
/**
 * Recursively merges two objects.
 *
 * @param target – The base object that will receive properties.
 * @param source – The object whose properties will overwrite / extend the target.
 * @returns A new object containing the merged result. Neither input is mutated.
 */
export function deepMerge(target, source) {
    // Helper: is value a plain object (not an array, Date, etc.)?
    const isPlainObject = (value) => !!value && Object.prototype.toString.call(value) === '[object Object]';
    // Make a shallow copy of target so we never mutate the original
    const output = { ...target };
    // Iterate keys in the source object
    for (const [key, sourceValue] of Object.entries(source)) {
        if (sourceValue === undefined) {
            continue;
        }
        const targetValue = output[key];
        if (isPlainObject(sourceValue) && isPlainObject(targetValue)) {
            // If both values are plain objects, merge them recursively
            output[key] = deepMerge(targetValue, sourceValue);
        }
        else {
            // Otherwise, source wins (arrays & scalars are replaced, not concatenated)
            output[key] = sourceValue;
        }
    }
    return output;
}
/** return an object that excludes the specified properties */
export function exceptProps(item, ...props) {
    if (!item)
        return {};
    return Object.entries(item).reduce((acc, [key, val]) => {
        return props.includes(key) ? acc : { ...acc, ...{ [key]: val } };
    }, {});
}
/** return an object with only the specified properties */
export function onlyProps(item, ...props) {
    if (!item)
        return {};
    return Object.entries(item).reduce((acc, [key, val]) => {
        return props.includes(key) ? { ...acc, ...{ [key]: val } } : acc;
    }, {});
}
export function removeBlankValues(item) {
    if (!item)
        return {};
    return Object.entries(item).reduce((acc, [key, val]) => {
        let processedValue = val;
        if (typeof val === 'object' && val !== null) {
            if (Array.isArray(val)) {
                processedValue = val.map(v => typeof v === 'object' && v !== null
                    ? removeBlankValues(v)
                    : v);
            }
            else {
                processedValue = removeBlankValues(val);
            }
        }
        if (processedValue !== undefined &&
            processedValue !== null &&
            processedValue !== '' &&
            !(Array.isArray(processedValue) && processedValue.length === 0) &&
            !(typeof processedValue === 'object' &&
                !Array.isArray(processedValue) &&
                processedValue !== null && // Ensure it's not null before checking keys
                Object.keys(processedValue).length === 0)) {
            // Only add the key if the processed value is not blank.
            acc[key] = processedValue;
        }
        return acc;
    }, {});
}
