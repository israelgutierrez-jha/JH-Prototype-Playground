export function coerceError(maybeError) {
    if (maybeError instanceof Error) {
        return maybeError;
    }
    const msg = typeof maybeError === 'string' ? maybeError : JSON.stringify(maybeError);
    return new Error(msg);
}
