/**
 * Generate a pseudo-unique identifier.
 * Suitable for client-side unique identifiers like hash keys.
 *
 * Should not be used for applications where long-lived universal uniqueness is required.
 */
export declare function createUniqueId(): string;
