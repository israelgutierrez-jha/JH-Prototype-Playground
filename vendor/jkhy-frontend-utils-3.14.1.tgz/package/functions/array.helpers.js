export function enforceArray(arrayOrItem) {
    return Array.isArray(arrayOrItem) ? arrayOrItem : [arrayOrItem];
}
/**
 * Helper function to ensure an array contains all values from a string union type.
 * TypeScript will error with a helpful message showing which values are missing.
 *
 * @example
 * type Status = 'active' | 'inactive' | 'pending';
 * const statuses = exhaustiveArray<Status>()(['active', 'inactive']);
 * // Error: Argument of type 'string[]' is not assignable to parameter of type '"⛔ Missing: pending"'.
 */
export function exhaustiveStringArray() {
    return (array) => array;
}
