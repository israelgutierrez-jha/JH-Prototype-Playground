import { exists } from './object.helpers.js';
export function isConstructor(maybeCtor) {
    if (typeof maybeCtor !== 'function') {
        return false;
    }
    const descriptor = Object.getOwnPropertyDescriptor(maybeCtor, 'prototype');
    // class constructors have a non-writable prototype property, while regular functions do
    if (descriptor && descriptor.writable) {
        return false;
    }
    // https://stackoverflow.com/a/48036194/574930
    try {
        const testInstance = {};
        const handler = {
            construct() {
                return testInstance;
            },
        };
        const proxy = new Proxy(maybeCtor, handler);
        // to verify the function is newable
        const instance = new proxy();
        return exists(instance) && instance === testInstance;
    }
    catch {
        return false;
    }
}
export function isPrimitiveCtor(ctor) {
    const { name } = ctor;
    switch (name) {
        case 'Number':
        case 'String':
        case 'Array':
        case 'Date':
        case 'Object':
            return true;
        default:
            return false;
    }
}
/**
 * Produces a list of constructors found in an object's
 * [prototype chain](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Inheritance_and_the_prototype_chain),
 * starting with (and including) the provided constructor.
 */
export function getPrototypeList(ctor) {
    const list = [ctor];
    let { prototype } = ctor;
    let nextProto = Object.getPrototypeOf(prototype);
    // Object is the root of all types and is not useful
    // in determining a base class
    while (exists(nextProto) && nextProto.constructor !== Object) {
        prototype = nextProto;
        nextProto = Object.getPrototypeOf(prototype);
        list.push(prototype.constructor);
    }
    return list;
}
/**
 * Traverses the prototype chain of a constructor until it
 * finds the first, non-`Object` constructor.
 */
export function getBaseClass(ctor) {
    const protoList = getPrototypeList(ctor);
    return protoList[protoList.length - 1];
}
/**
 * Returns `true` if `child` is a subclass of `parent`.
 *
 * Supports deep class hierarchies.
 *
 * @param parent The parent class to check against.
 * @param child The subclass to verify.
 */
export function isSubclassOf(parent, child) {
    if (parent === child) {
        return false;
    }
    const childProtoList = getPrototypeList(child);
    // any constructor that appears somewhere in the prototype list
    // of the tested class is considered a parent of it
    return childProtoList.includes(parent);
}
