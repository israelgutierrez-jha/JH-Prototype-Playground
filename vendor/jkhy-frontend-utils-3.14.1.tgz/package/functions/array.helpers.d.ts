export declare function enforceArray<T>(arrayOrItem: T[] | T): T[];
/**
 * Helper function to ensure an array contains all values from a string union type.
 * TypeScript will error with a helpful message showing which values are missing.
 *
 * @example
 * type Status = 'active' | 'inactive' | 'pending';
 * const statuses = exhaustiveArray<Status>()(['active', 'inactive']);
 * // Error: Argument of type 'string[]' is not assignable to parameter of type '"⛔ Missing: pending"'.
 */
export declare function exhaustiveStringArray<T extends string>(): <const U extends readonly T[]>(array: [T] extends [U[number]] ? U : `⛔ Missing: ${Exclude<T, U[number]>}`) => [T] extends [U[number]] ? U : `\u26D4 Missing: ${Exclude<T, U[number]>}`;
