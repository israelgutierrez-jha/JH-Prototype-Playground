import type { AbstractConstructor, Constructor, PrimitiveConstructor } from '../types/index.js';
export declare function isConstructor<T>(maybeCtor: unknown): maybeCtor is Constructor<T>;
export declare function isPrimitiveCtor<T>(ctor: Constructor<T> | AbstractConstructor<T> | PrimitiveConstructor): ctor is PrimitiveConstructor;
/**
 * Produces a list of constructors found in an object's
 * [prototype chain](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Inheritance_and_the_prototype_chain),
 * starting with (and including) the provided constructor.
 */
export declare function getPrototypeList<T>(ctor: Constructor<T> | AbstractConstructor<T>): (Constructor<T> | AbstractConstructor<T>)[];
/**
 * Traverses the prototype chain of a constructor until it
 * finds the first, non-`Object` constructor.
 */
export declare function getBaseClass<T, S extends T>(ctor: Constructor<S> | AbstractConstructor<S>): Constructor<T>;
/**
 * Returns `true` if `child` is a subclass of `parent`.
 *
 * Supports deep class hierarchies.
 *
 * @param parent The parent class to check against.
 * @param child The subclass to verify.
 */
export declare function isSubclassOf<T>(parent: Constructor<T> | AbstractConstructor<T>, child: Constructor<unknown>): child is Constructor<T>;
