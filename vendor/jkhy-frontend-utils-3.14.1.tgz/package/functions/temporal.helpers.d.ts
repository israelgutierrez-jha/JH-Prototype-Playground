/**
 * Create a `Promise` that resolves after a set amount of time.
 * Useful for performing an action with a delay without manually invoking `setTimeout()`.
 *
 * To maximize readability, pair with `await`.
 *
 * @example
 * const delayedValue= async value => {
 *    await delay(500);
 *    return value;
 * };
 * @param period Delay in milliseconds.
 */
export declare function delay(period?: number): Promise<void>;
/**
 * Await a promise up to a maximum amount of time.
 *
 * If it does not resolve within this time, this results in a rejected promise.
 * If it does, the result of the original is returned.
 *
 * @param limit Maximum time to wait, in milliseconds.
 * @returns The result of the original promise if it is completed
 * within the maximum time specified.
 */
export declare function waitUntil<T>(p: Promise<T>, limit: number): Promise<T>;
export declare const debounce: <Params extends unknown[], F extends (...args: Params) => unknown>(func: F, wait: number) => (...args: Params) => ReturnType<F> extends unknown ? ReturnType<F> : Promise<ReturnType<F>>;
