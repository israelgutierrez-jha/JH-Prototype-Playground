import type { Nullable, SyncAsyncDeferred } from '../types/index.js';
/**
 * Type guard to determine if a reference is valid.
 *
 * Serves both a runtime purpose as well a type-narrowing one.
 * See: https://www.typescriptlang.org/docs/handbook/2/narrowing.html#using-type-predicates
 *
 * @param ref Reference whose value may be `null` or `undefined`.
 * @returns A boolean value indicating the validity of the object reference.
 * Returns `true` if the reference t is valid; `false` if the value is  `undefined` or `null`.
 */
export declare function exists<T>(ref: T | null | undefined): ref is T;
/**
 * Verifies that a given list of property names all exist on the provided object.
 */
export declare function verifyPropNames<T extends object>(obj: T, ...propNames: (keyof T)[]): boolean;
/**
 *
 * @returns `true` if argument is a non-null, non-primitive, non-array object
 */
export declare function isObject(ref: unknown): ref is object;
export declare function isPrimitive(ref: unknown): ref is number | string | boolean | symbol | bigint | undefined | null;
/**
 * Coerces a possibly `undefined` value to the `null` value.
 */
export declare function coerceToNull<T>(ref: T | undefined): (T & {}) | null;
type ArrayDictTransform<T, V> = (elem: T, index: number) => {
    key: string;
    value: V;
};
export declare function arrayToDict<T, V>(arr: T[], transform: ArrayDictTransform<T, V>): Record<string, V>;
/**
 * Coerces an object with possibly `undefined` values to `null` values.
 */
export declare function coerceMembersToNull<T>(object: Partial<T>): Nullable<T>;
/**
 * Coerces a possibly empty string to the `null` value.
 */
export declare function coerceEmptyStringToNull(str: string): string | null;
/**
 * Coerces an object with possibly empty string values to `null` values.
 */
export declare function coerceEmptyStringsToNull<T extends object>(object: T): Nullable<T>;
/**
 * Coerces a possibly synchronous or deferred value into an asynchronous one.
 */
export declare function coerceToAsyncValue<T>(value: SyncAsyncDeferred<T>): Promise<T>;
/**
 * Deeply copies an object, maintaining the prototype chain for class instances.
 *
 * Supports circular references by maintaining cloned object references.
 */
export declare function clone<T>(obj: T): T;
/**
 * Compare two objects for deep equality.
 *
 * Adapted from `fast-deep-equal`.
 */
export declare function deepEquals<T extends object | number | string, R = T | T[]>(a: R, b: R): boolean;
/**
 * Strongly-typed alternative to `Object.keys()`.
 * Returns only keys for an object's [own properties](https://www.javascripttutorial.net/javascript-own-properties/).
 */
export declare function getKeys<T extends object>(obj: T): (keyof T)[];
/**
 * Returns the keys owned directly by an object as well as those on its prototype.
 * This includes both enumerable and non-enumerable keys.
 */
export declare function getKeysInstance<T extends object>(obj: T): (keyof T)[];
/**
 * Recursively merges two objects.
 *
 * @param target – The base object that will receive properties.
 * @param source – The object whose properties will overwrite / extend the target.
 * @returns A new object containing the merged result. Neither input is mutated.
 */
export declare function deepMerge<T extends Record<string, unknown>, U extends Record<string, unknown>>(target: T, source: U): T & U;
/** return an object that excludes the specified properties */
export declare function exceptProps<T extends Record<string, unknown>>(item: T, ...props: (keyof T)[]): Partial<T>;
/** return an object with only the specified properties */
export declare function onlyProps<T extends Record<string, unknown>>(item: T | undefined, ...props: (keyof T)[]): Partial<T>;
export declare function removeBlankValues<T extends Record<string, unknown> | undefined>(item: T): Partial<T>;
export {};
