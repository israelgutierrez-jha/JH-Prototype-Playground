export declare function isEmptyString(str: unknown): str is string;
export declare function isNonEmptyString(str: unknown): str is string;
/**
 * Returns `true` if the provided value is a string containing
 * only an integer number (e.g., `'10203'`).
 */
export declare function isIntegerString(str: string | undefined | null): boolean;
/**
 * Removes all non-alphanumeric characters in a string.
 */
export declare function removeSpecialChars(str: string): string;
/**
 * Type guard that checks if a value is null or undefined or an empty string.
 * @param value - The value to check.
 * @param considerWhitespace - Optional flag to trim whitespace during the evaluation
 * @returns True if the value is null, undefined, or an empty string; otherwise, false.
 */
export declare function isNullOrEmpty(value: unknown, considerWhitespace?: boolean): value is null | undefined | '';
/**
 * Gets the value or the default value if the value is null or undefined.
 * @param value
 * @param defaultValue
 * @returns value or default value
 */
export declare function getValueOrDefault(value: string | null | undefined, defaultValue?: string): string;
/**
 * Removes the trailing period off a string value
 * @param value
 * @returns value without trailing period
 */
export declare function removeTrailingPeriod(value: string): string;
/**
 * Type guard that checks if a value is not an empty string.
 * @param value - The value to check.
 * @returns false if the value is null, undefined, or an empty string; otherwise, true.
 */
export declare function hasValue(value: string | null | undefined): value is string;
/**
 * Formats a string with sentence case.
 * @param value
 * @returns reformatted string
 */
export declare function toSentenceCase(value: string): string;
export interface MaskTextOptions {
    /**
     * The masking strategy to apply.
     * 'full': Masks the entire string.
     * 'last-four': Reveals the last four characters.
     */
    maskingMode: 'full' | 'last-four';
    /**
     * Optional. For 'last-four' mode, specifies a fixed number of asterisks
     * for the masked portion. If omitted, the number of asterisks will match
     * the number of masked characters.
     */
    asteriskCount?: number;
    /**
     * Optional. For 'full' mode, specifies the number of asterisks to show
     * when the input string is empty.
     * @default 8
     */
    maskLength?: number;
}
/**
 * Masks a string based on a specified mode.
 * @param text The raw string to mask.
 * @param options The configuration object for masking.
 * @returns The masked string.
 */
export declare function maskText(text: string, options: MaskTextOptions): string;
