import JhaThumbnail from './JhaThumbnail.js';
customElements.define('jha-thumbnail', JhaThumbnail);
/** @customElement jha-thumbnail */
export default JhaThumbnail;
