import JhaErrorMessage from './JhaErrorMessage.js';
customElements.define('jha-error-message', JhaErrorMessage);
/** @customElement jha-error-message */
export default JhaErrorMessage;
