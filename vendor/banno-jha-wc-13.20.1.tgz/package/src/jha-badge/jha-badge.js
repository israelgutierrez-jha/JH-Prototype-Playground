import JhaBadgeElement from './JhaBadge.js';
customElements.define('jha-badge', JhaBadgeElement);
/** @customElement jha-badge */
export default JhaBadgeElement;
