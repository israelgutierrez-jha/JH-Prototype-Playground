import { css } from 'lit';
import JhaStyleElement from '../style-element/JhaStyleElement.js';
import { jhaStyles } from '../styles/jha-styles.js';
const styles = css `
  :host {
    display: inline-block;
    height: 20px;
    background-color: var(--jha-badge-background, var(--jha-text-muted, #b3bfc9));
    color: var(--jha-badge-text, #fff);
    font-size: var(--jha-badge-text-size, 12px);
    line-height: 20px;
    text-align: center;
    vertical-align: middle;
    white-space: nowrap;
    padding: 0 8px;
    border-radius: var(--jha-badge-border-radius, 10px);
  }
  :host([primary]) {
    --jha-badge-background: var(--jha-color-primary, #3aaeda);
    --jha-badge-text: var(--jha-text-white, #ffffff);
  }
  :host([success]) {
    --jha-badge-background: var(--jha-color-success, #4caf50);
    --jha-badge-text: #ffffff;
  }
  :host([danger]) {
    --jha-badge-background: var(--jha-color-danger, #f44336);
    --jha-badge-text: #ffffff;
  }
  :host([warning]) {
    --jha-badge-background: var(--jha-color-warning, #fca902);
    --jha-badge-text: #ffffff;
  }
  :host([light]) {
    --jha-badge-background: var(--jha-color-light, #8c989f);
  }
  :host([medium]) {
    --jha-badge-text-size: 12px;
    height: 16px;
    line-height: 16px;
    padding: 0 5px;
  }
  :host([small]) {
    --jha-badge-text-size: 9px;
    height: 15px;
    line-height: 15px;
    padding: 0 5px;
  }
  :host([dot]) {
    width: 7px;
    height: 7px;
    line-height: 7px;
    padding: 0;
  }

  /** BADGES */
  :host([appearance]) {
    --jha-badge-border-radius: 4px;
    padding: 0 4px;
    font-weight: 700;
  }
  :host([appearance='primary']) {
    --jha-badge-background: var(--jh-color-content-brand-enabled);
    --jha-badge-text: var(--jh-color-content-on-brand-enabled);
  }
  :host([appearance='secondary']) {
    --jha-badge-background: var(--jh-color-container-secondary-enabled);
    --jha-badge-text: var(--jh-color-content-primary-enabled);
  }
  :host([appearance='neutral']) {
    --jha-badge-background: var(--jh-color-content-primary-enabled);
    --jha-badge-text: var(--jh-color-container-secondary-enabled);
  }
  :host([appearance='positive']) {
    --jha-badge-background: var(--jh-color-content-positive-enabled);
    --jha-badge-text: var(--jh-color-content-on-positive-enabled);
  }
  :host([appearance='negative']) {
    --jha-badge-background: var(--jh-color-content-negative-enabled);
    --jha-badge-text: var(--jh-color-content-on-negative-enabled);
  }
`;
/**@element jha-badge */
export default class JhaBadgeElement extends JhaStyleElement {
    static get styles() {
        return [jhaStyles, styles];
    }
}
export { styles as JhaBadgeStyles };
