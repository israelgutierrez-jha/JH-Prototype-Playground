import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
const JhaCollapsibleSectionOpenEvent = 'collapsible-section-opened';
const JhaCollapsibleSectionCloseEvent = 'collapsible-section-closed';
const styles = css `
  :host {
    display: block;
    position: relative;
  }
  .toggle {
    background: var(--jha-background-color, #edeeef);
    margin: var(--jha-collapsible-section-header-margin, 0);
    border-radius: var(--jha-collapsible-section-header-border-radius, 0);
  }
  button.section-toggle {
    display: flex;
    display: flex;
    width: 100%;
    justify-content: space-between;
    align-items: center;
    padding: var(--jha-collapsible-section-header-padding, 8px);
  }
  button[disabled] {
    opacity: var(--jha-button-disabled-opacity, 0.3);
    pointer-events: none;
    cursor: default;
  }
  jha-icon-chevron-down {
    fill: var(--jha-text-dark, #455564);
    transition: all 0.3s cubic-bezier(0.1, 0.5, 0.1, 1);
    padding: var(--jha-collapsible-section-icon-padding, 4px);
    width: var(--jha-collapsible-section-icon-size, 24px);
    height: var(--jha-collapsible-section-icon-size, 24px);
  }
  :host([is-open]) jha-icon-chevron-down {
    transform: rotate(180deg);
  }
  /* jhaAccordianBody */
  article {
    height: 0;
    overflow: hidden;
    will-change: transform, opacity;
    opacity: var(--jha-accordion-body-opacity, 0.3);
    transition: all 0.3s cubic-bezier(0.1, 0.5, 0.1, 1);
    padding: 0;
    visibility: hidden;
  }
  :host([is-open]) article {
    height: auto;
    opacity: var(--jha-accordion-opacity, 1);
    padding: var(--jha-accordion-body-padding, 0);
    padding-top: var(--jha-accordion-open-body-padding-top, 16px);
    visibility: visible;
    overflow: visible;
  }
`;
/**@element jha-collapsible-section */
export default class JhaCollapsibleSection extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            isOpen: {
                type: Boolean,
                attribute: 'is-open',
                reflect: true,
            },
            grouped: {
                type: Boolean,
            },
            headless: {
                type: Boolean,
            },
            disabled: {
                type: Boolean,
            },
        };
    }
    constructor() {
        super();
        import('../../icons/jha-icon-chevron-down.js');
        this.isOpen = false;
        this.grouped = false;
        this.headless = false;
        this.disabled = false;
    }
    toggleContent() {
        if (this.disabled)
            return;
        this.isOpen = !this.isOpen;
        const eventName = this.isOpen ? JhaCollapsibleSectionOpenEvent : JhaCollapsibleSectionCloseEvent;
        this.dispatchEvent(new CustomEvent(eventName, {
            bubbles: true,
            composed: true,
        }));
    }
    render() {
        return html `
      ${this.headless
            ? ''
            : html `
            <div class="toggle">
              <button
                class="section-toggle"
                button-reset
                @click="${this.toggleContent}"
                ?disabled=${this.disabled}>
                <slot name="header"></slot>
                <jha-icon-chevron-down></jha-icon-chevron-down>
              </button>
            </div>
          `}
      <article>
        <slot name="body"></slot>
      </article>
    `;
    }
}
export { styles as JhaCollapsibleSectionStyles, JhaCollapsibleSectionOpenEvent, JhaCollapsibleSectionCloseEvent };
