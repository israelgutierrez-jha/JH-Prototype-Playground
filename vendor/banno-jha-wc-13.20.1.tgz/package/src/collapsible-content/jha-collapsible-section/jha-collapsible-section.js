import JhaCollapsibleSection from './JhaCollapsibleSection.js';
customElements.define('jha-collapsible-section', JhaCollapsibleSection);
/** @customElement jha-collapsible-section */
export default JhaCollapsibleSection;
