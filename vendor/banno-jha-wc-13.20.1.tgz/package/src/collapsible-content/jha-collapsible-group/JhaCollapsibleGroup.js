import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
import { JhaCollapsibleSectionOpenEvent } from '../jha-collapsible-section/JhaCollapsibleSection.js';
/** @typedef {import('../jha-collapsible-section/JhaCollapsibleSection.js').default} JhaCollapsibleSection */
const styles = css `
  :host {
    display: block;
  }
  :host ::slotted(jha-collapsible-section) {
    margin-bottom: var(--jha-collapsible-section-margin-bottom, 16px);
  }
`;
/**@element jha-collapsible-group */
export default class JhaCollapsibleGroup extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {};
    }
    constructor() {
        super();
        this.boundOnSectionOpened_ = this.onSectionOpened.bind(this);
    }
    onSlotUpdate_() {
        this.removeListeners();
        this.sections.forEach((item) => {
            item.grouped = true;
            item.addEventListener(JhaCollapsibleSectionOpenEvent, this.boundOnSectionOpened_);
        });
    }
    removeListeners() {
        this.sections.forEach((item) => {
            item.removeEventListener(JhaCollapsibleSectionOpenEvent, this.boundOnSectionOpened_);
        });
    }
    onSectionOpened(evt) {
        const openedSection = evt.target;
        this.sections
            .filter((item) => item !== openedSection)
            .map((item) => {
            return { ...item, ...{ isOpen: false } };
        });
    }
    /** @return {Array<JhaCollapsibleSection>} */
    get sections() {
        const slot = this.shadowRoot.querySelector('slot');
        return /** @type {Array<JhaCollapsibleSection>} */ (slot
            .assignedNodes({ flatten: true })
            .filter((item) => /** @type {JhaCollapsibleSection} */ (item).tagName === 'JHA-COLLAPSIBLE-SECTION'));
    }
    render() {
        return html ` <slot @slotchange=${this.onSlotUpdate_}></slot> `;
    }
}
export { styles as JhaCollapsibleGroupStyles };
