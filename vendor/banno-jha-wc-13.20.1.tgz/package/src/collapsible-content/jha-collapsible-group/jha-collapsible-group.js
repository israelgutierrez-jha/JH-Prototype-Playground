import JhaCollapsibleGroup from './JhaCollapsibleGroup.js';
customElements.define('jha-collapsible-group', JhaCollapsibleGroup);
/** @customElement jha-collapsible-group */
export default JhaCollapsibleGroup;
