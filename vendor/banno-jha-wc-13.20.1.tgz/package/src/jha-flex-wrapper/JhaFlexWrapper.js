import { css } from 'lit';
import { jhaStyles } from '../styles/jha-styles.js';
import JhaStyleElement from '../style-element/JhaStyleElement.js';
const styles = css `
  :host {
    display: flex;
    align-items: var(--jha-flex-wrapper-align-items, center);
    gap: var(--jha-flex-wrapper-gap, 0);
    justify-content: var(--jha-flex-wrapper-justify-content, inherit);
  }
  :host([space-between]) {
    --jha-flex-wrapper-justify-content: space-between;
  }
  :host([flex-start]) {
    --jha-flex-wrapper-justify-content: flex-start;
  }
`;
/**@element jha-flex-wrapper */
export default class JhaFlexWrapper extends JhaStyleElement {
    static get styles() {
        return [jhaStyles, styles];
    }
}
export { styles as JhaFlexWrapperStyles };
