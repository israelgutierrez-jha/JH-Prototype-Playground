import JhaFlexWrapper from './JhaFlexWrapper.js';
customElements.define('jha-flex-wrapper', JhaFlexWrapper);
/** @customElement jha-flex-wrapper */
export default JhaFlexWrapper;
