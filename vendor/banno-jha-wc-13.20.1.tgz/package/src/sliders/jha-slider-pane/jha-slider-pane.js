import JhaSliderPane from './JhaSliderPane.js';
customElements.define('jha-slider-pane', JhaSliderPane);
/** @customElement jha-slider-pane */
export default JhaSliderPane;
