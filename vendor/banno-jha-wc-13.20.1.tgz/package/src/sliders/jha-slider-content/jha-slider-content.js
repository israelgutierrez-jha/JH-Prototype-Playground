import JhaSliderContent from './JhaSliderContent.js';
customElements.define('jha-slider-content', JhaSliderContent);
/** @customElement jha-slider-content */
export default JhaSliderContent;
