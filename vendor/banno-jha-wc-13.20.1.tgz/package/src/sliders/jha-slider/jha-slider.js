import JhaSlider from './JhaSlider.js';
customElements.define('jha-slider', JhaSlider);
/** @customElement jha-slider */
export default JhaSlider;
