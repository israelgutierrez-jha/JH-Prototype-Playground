import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../styles/jha-styles.js';
import '../buttons/jha-button/jha-button.js';
const days = Array.from(Array(31), (x, index) => index + 1);
const styles = css `
  :host {
    display: block;
    box-sizing: border-box;
  }
  :host([small]) {
    --jha-day-picker-day-size: 24px;
    --jha-day-picker-font-size: 14px;
  }
  .calendar {
    height: 100%;
    padding-bottom: 24px;
  }
  .month-container {
    display: flex;
    flex-wrap: wrap;
    max-width: 450px;
    margin: 0 auto;
  }
  @supports (display: grid) {
    .month-container {
      display: grid;
      grid-template-columns: repeat(7, 1fr);
    }
  }
  .day {
    text-align: center;
    padding: 2px 0;
    flex-basis: 14%;
  }
  jha-icon-date {
    margin-right: 8px;
  }
  button {
    -webkit-appearance: none;
    position: relative;
    margin-bottom: 0;
    text-align: center;
    vertical-align: middle;
    cursor: pointer;
    border: none;
    white-space: nowrap;
    text-transform: none;
    border-radius: 500px;
    box-shadow: none;
    box-sizing: border-box;
    background-color: transparent;
    touch-action: manipulation;
    color: var(--jha-date-picker-text-color, var(--jha-text-base, var(--body-text-primary-color)));
  }
  *[data-day] {
    transition: background-color ease 0.2s;
    min-height: var(--jha-day-picker-day-size, 42px);
    min-width: var(--jha-day-picker-day-size, 42px);
    padding: 0;
  }
  button + span {
    vertical-align: center;
    margin: 0 10px 5px;
  }
  .day button:hover {
    font-size: 16px;
    color: var(--jha-date-picker-hover-text-color, inherit);
    background: var(--jha-date-picker-hover-background-color, inherit);
    border-radius: var(--jha-date-picker-in-range-border-radius, 30px);
  }
  .day button[selected='true'] {
    background: var(--jha-date-picker-in-range-selected, var(--jha-color-primary, #3aaeda));
    border-radius: var(--jha-date-picker-in-range-border-radius, 30px);
    color: var(--jha-date-picker-selected-text-color, var(--jha-text-white, #ffffff));
    opacity: 1;
  }
  .day button {
    font-size: var(--jha-day-picker-font-size, 16px);
  }
  slot[name='message'] div,
  slot[name='confirmation'] div,
  :host ::slotted(div[slot='message']),
  :host ::slotted(div[slot='confirmation']) {
    display: flex;
    align-items: center;
    color: var(--jha-text-theme, var(--body-text-theme-color));
    padding: 16px 0;
    justify-content: center;
  }
  slot[name='message'] div,
  :host ::slotted(div[slot='message']) {
    justify-content: center;
  }
  #confirmation-drawer {
    bottom: 0px;
    @apply --flex-space-between;
    height: 80px;
    padding: 0 26px;
    background: var(--jha-component-background-color, var(--primary-content-background-color));
    border-top: 1px solid var(--jha-border-color);
    text-align: center;
  }
  #confirmation-drawer[show] {
    visibility: visible;
  }
`;
/**@element jha-day-picker */
export default class JhaDayPicker extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            minDays: {
                type: Number,
            },
            maxDays: {
                type: Number,
            },
            selectedDays: {
                type: Array,
                value: () => [],
            },
            calendarOnly: {
                type: Boolean,
            },
        };
    }
    constructor() {
        super();
        import('../icons/jha-icon-date.js');
        this.minDays = 2;
        this.maxDays = 2;
        this.selectedDays = [];
        this.calendarOnly = false;
    }
    /**
     * @private
     * @return {!Array<!number>}
     */
    getDays() {
        return days;
    }
    /**
     * @private
     * @description Determine if the provided day number is selected
     * @param {!number} num
     * @param {Array<!number>} selectedDays
     */
    isSelected(num, selectedDays) {
        return selectedDays.some((n) => n === num);
    }
    /**
     * @private
     * @description `click` event handler for *Confirm* button
     */
    dispatchChange() {
        /** @type {import('../js/utils/types.js').InputDaysSelectedEvent} */
        const changeEvent = new CustomEvent('days-selected', {
            bubbles: true,
            composed: true,
            detail: {
                selectedDays: this.selectedDays.slice(),
            },
        });
        this.dispatchEvent(changeEvent);
    }
    /**
     * @private
     * @description Determine whether to show the confirmation drawer
     * @param {Array<!number>} selectedDays
     * @param {!number} minDays
     * @param {boolean=} calendarOnly
     */
    showConfirmation(selectedDays, minDays, calendarOnly) {
        return !calendarOnly && selectedDays.length >= minDays;
    }
    /**
     * @private
     * @description `click` event handler for each day button
     * @param {!Event} event */
    selectDay(event) {
        const button = /** @type {HTMLButtonElement} */ (event.currentTarget);
        if (!button)
            return;
        button.blur();
        const day = button.dataset.day && Number.parseInt(button.dataset.day, 10);
        if (this.selectedDays.some((n) => n === day))
            return;
        if (this.selectedDays.length >= this.maxDays) {
            this.selectedDays = [];
        }
        this.selectedDays = this.selectedDays.concat(day);
        if (this.calendarOnly) {
            this.dispatchChange();
        }
    }
    get selectedDaysText() {
        const daysLength = this.selectedDays.length;
        if (!daysLength)
            return '';
        const label = daysLength > 1 ? 'Selected days:' : 'Selected day:';
        const daysString = this.selectedDays.reduce((acc, day, index) => {
            if (index === 0) {
                return `${day}`;
            }
            return `${acc}${index === daysLength - 1 ? ' and' : ','} ${day}`;
        }, '');
        return `${label} ${daysString}`;
    }
    render() {
        return html `
      ${this.calendarOnly
            ? ''
            : html `
            <div class="message">
              <slot name="message">
                <div>
                  <jha-icon-date></jha-icon-date>
                  <span>Select ${this.maxDays}</span>
                </div>
              </slot>
            </div>
          `}
      <div
        id="calendar"
        class="calendar">
        <div class="month-container">
          ${this.getDays().map((day) => html `
              <div class="day">
                <button
                  @click=${this.selectDay}
                  data-day=${day}
                  selected=${this.isSelected(day, this.selectedDays)}
                  type="button">
                  <span>${day}</span>
                </button>
              </div>
            `)}
        </div>
        ${this.showConfirmation(this.selectedDays, this.minDays, this.calendarOnly)
            ? html `
              <div id="confirmation-drawer">
                <slot name="confirmation">
                  <div>
                    <jha-icon-date></jha-icon-date>
                    ${this.selectedDays.length ? html ` <span>${this.selectedDaysText}</span> ` : ``}
                  </div>
                </slot>
                <jha-button
                  sync=""
                  wide=""
                  id="btnConfirm"
                  @click=${this.dispatchChange}
                  type="button">
                  Confirm
                </jha-button>
              </div>
            `
            : html ``}
      </div>
    `;
    }
}
export { styles as JhaDayPickerStyles };
