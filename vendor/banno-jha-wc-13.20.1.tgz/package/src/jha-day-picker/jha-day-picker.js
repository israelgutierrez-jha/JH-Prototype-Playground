import JhaDayPicker from './JhaDayPicker.js';
customElements.define('jha-day-picker', JhaDayPicker);
/** @customElement jha-day-picker */
export default JhaDayPicker;
