import JhaTab from './JhaTab.js';
customElements.define('jha-tab', JhaTab);
/** @customElement jha-tab */
export default JhaTab;
