import { css } from 'lit';
import JhaStyleElement from '../style-element/JhaStyleElement.js';
import { jhaStyles } from '../styles/jha-styles.js';
const styles = css `
  :host {
    display: inline-block;
    text-align: center;
    vertical-align: middle;
    white-space: nowrap;
    background-color: var(--jha-chip-background, transparent);
    border: 1px solid var(--jha-chip-border, var(--jha-text-light, #8c989f));
    color: var(--jha-chip-color, var(--jha-text-light, #8c989f));
    font-size: var(--jha-chip-size, calc(var(--jha-text-size-base, 14px) - 2));
    text-transform: uppercase;
    padding: var(--jha-chip-padding-vertical, 4px) var(--jha-chip-padding-horizontal, 8px);
    font-weight: 600;
    border-radius: 3px;
    line-height: 1.2;
  }
  :host([primary]) {
    border-color: var(--jha-chip-border, var(--jha-color-primary, #3aaeda));
    color: var(--jha-chip-color, var(--jha-color-primary, #3aaeda));
  }
  :host([success]) {
    border-color: var(--jha-chip-border, var(--jha-color-success, #4caf50));
    color: var(--jha-chip-color, var(--jha-color-success, #4caf50));
  }
  :host([danger]) {
    border-color: var(--jha-chip-border, var(--jha-color-danger, #f44336));
    color: var(--jha-chip-color, var(--jha-color-danger, #f44336));
  }
  :host([warning]) {
    border-color: var(--jha-chip-border, var(--jha-color-warning, #fca902));
    color: var(--jha-chip-color, var(--jha-color-warning, #fca902));
  }
  :host([outline-success]) {
    border-color: var(--jha-chip-border, var(--jha-color-success, #4caf50));
    color: var(--jha-chip-color, var(--jha-color-success, #4caf50));
  }
  :host([small]) {
    --jha-chip-size: 9px;
    --jha-chip-padding-vertical: 2px;
    --jha-chip-padding-horizontal: 5px;
  }
  :host([medium]) {
    text-transform: inherit;
    --jha-chip-size: 10px;
  }
`;
/** @element jha-chip */
export default class JhaChip extends JhaStyleElement {
    static get styles() {
        return [jhaStyles, styles];
    }
}
export { styles as JhaChipStyles };
