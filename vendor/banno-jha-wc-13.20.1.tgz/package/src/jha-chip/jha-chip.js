import JhaChip from './JhaChip.js';
customElements.define('jha-chip', JhaChip);
/** @customElement jha-chip */
export default JhaChip;
