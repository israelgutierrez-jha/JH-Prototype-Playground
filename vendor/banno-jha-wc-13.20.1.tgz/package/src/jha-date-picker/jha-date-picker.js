import JhaDatePicker from './JhaDatePicker.js';
customElements.define('jha-date-picker', JhaDatePicker);
/** @customElement jha-date-picker */
export default JhaDatePicker;
