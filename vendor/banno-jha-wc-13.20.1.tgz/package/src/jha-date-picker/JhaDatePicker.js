// JR: temp ignore tsc
// @ts-nocheck
import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../styles/jha-styles.js';
import '../jha-tooltip/jha-tooltip.js';
/**
 * @typedef {Object} DateTip
 * @property {string} tooltip
 * @property {Date} date
 */
const DEFAULT_MONTH_NAMES = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
];
const DEFAULT_DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
/** @enum {number} */
const Direction = {
    NEXT: 1,
    PREVIOUS: -1,
};
const MONTH_HEIGHT = 324; // number of pixels a month's calendar/header takes up (with padding)
/**
 * @description returns boolean of if two dates are the same
 * @param {Date} date1
 * @param {Date} date2
 * @return {boolean}
 * @const
 */
function sameDate(date1, date2) {
    if (!date1 || !date2) {
        return false;
    }
    return (date1.getFullYear() === date2.getFullYear() &&
        date1.getMonth() === date2.getMonth() &&
        date1.getDate() === date2.getDate());
}
/**
 * @param {!Date} date
 * @param {!Direction=} direction
 * @return {!Date}
 */
function addDay(date, direction = Direction.NEXT) {
    const newDate = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 12, 0, 0, 0);
    newDate.setDate(newDate.getDate() + (direction !== Direction.NEXT ? -1 : 1));
    newDate.setHours(12);
    return newDate;
}
/**
 * Add or subtract one month from the given date. Return a the first
 * date of the new month.
 *
 * @param {!Date} date
 * @param {!Direction=} direction - positive for forward, negative for backwards
 * @return {!Date}
 */
function addMonth(date, direction = Direction.NEXT) {
    const newDate = new Date(date.getFullYear(), date.getMonth(), 1, 12, 0, 0, 0);
    if (newDate.getMonth() === 0 && direction < 0) {
        newDate.setMonth(11);
        newDate.setFullYear(newDate.getFullYear() - 1);
    }
    else if (newDate.getMonth() === 11 && direction > 0) {
        newDate.setMonth(0);
        newDate.setFullYear(newDate.getFullYear() + 1);
    }
    else {
        newDate.setMonth(newDate.getMonth() + (direction > 0 ? 1 : -1));
    }
    return newDate;
}
/**
 * @description Get the first day of the month prior to the specified date
 * @param {!Date} date
 * @return {!Date}
 */
function getPreviousMonthDate(date) {
    const prevMonth = (date.getMonth() - 1) % 12;
    const year = prevMonth === 11 ? date.getFullYear() - 1 : date.getFullYear();
    return new Date(year, prevMonth, 1, 12, 0, 0, 0);
}
/**
 * @description Get the first day of the month after the specified date
 * @param {!Date} date
 * @return {!Date}
 */
function getNextMonthDate(date) {
    const nextMonth = (date.getMonth() + 1) % 12;
    const year = nextMonth === 0 ? date.getFullYear() + 1 : date.getFullYear();
    return new Date(year, nextMonth, 1, 0, 0, 0, 0);
}
/**
 * @description returns an array of null values with a length = date.getDay. Used for padding the start of each month.
 * @param {!Date} date
 * @return {Array<null>}
 */
function getInitialPadding(date) {
    return new Array(date.getDay()).fill(null);
}
/**
 * @param {!Date} date
 * @return {!Array<!Date>}
 */
function getMonthDays(date) {
    const firstDateInCalendar = new Date(date.getFullYear(), date.getMonth(), 1, 12, 0, 0, 0);
    const lastDateInCalendar = addDay(addMonth(date, Direction.NEXT), Direction.PREVIOUS);
    const days = [];
    for (let currentDate = new Date(firstDateInCalendar); currentDate <= lastDateInCalendar; currentDate = addDay(currentDate)) {
        days.push(new Date(currentDate));
    }
    return days;
}
/**
 * @param {!Date} date
 * @param {Array<string>} monthNames
 * @return {string}
 */
function getMonthName(date, monthNames = DEFAULT_MONTH_NAMES) {
    return monthNames[date.getMonth()];
}
/**
 * @param {!Date} date
 * @return {boolean}
 */
function isLastOfMonth(date) {
    const tempDate = new Date(date.getTime());
    const month = tempDate.getMonth();
    tempDate.setDate(tempDate.getDate() + 1);
    return tempDate.getMonth() !== month;
}
/**
 * @param {boolean} showToday
 * @param {!Date} date
 * @return {boolean}
 */
function isToday(showToday, date) {
    if (!showToday)
        return false;
    return sameDate(date, new Date());
}
/**
 * @param {!Date} date
 * @return {boolean}
 */
function isTopRight(date) {
    return date.getDay() === 0;
}
/**
 * @param {!Date} date
 * @return {boolean}
 */
function isTopLeft(date) {
    return date.getDay() === 6;
}
/**
 * @description whether or not the tooltip should be shown above or below the day
 * @param {!Date} date
 * @return {boolean}
 */
function tooltipTop(date) {
    return !isTopRight(date) && !isTopLeft(date);
}
/**
 * @description Default function for isDateActive property
 * @param {Date} date
 * @param {Date=} minDate
 * @param {?Date=} maxDate
 * @return {boolean}
 */
function isInRange(date, minDate = new Date(), maxDate = null) {
    if (!maxDate)
        return false;
    if (!date)
        return false;
    const normalizeMaxDate = new Date(maxDate.getFullYear(), maxDate.getMonth(), maxDate.getDate(), 12, 0, 0, 0);
    const normalizeMinDate = new Date(minDate.getFullYear(), minDate.getMonth(), minDate.getDate(), 12, 0, 0, 0);
    return date >= normalizeMinDate && date <= normalizeMaxDate;
}
/**
 *
 * @param {Date} date
 * @param {Date} minDate
 * @param {Date} maxDate
 * @param {Array<Date|DateTip>} activeDates
 * @param {?Function} activeDateFilter
 * @return {boolean}
 */
function isDateDisabled(date, minDate, maxDate, activeDates, activeDateFilter) {
    if (typeof activeDateFilter === 'function') {
        return !activeDateFilter(date, minDate, maxDate);
    }
    if (activeDates && activeDates.length > 0) {
        // return true if date does not exist in activeDates
        return !activeDates.some((d) => (d.date instanceof Date ? sameDate(d.date, date) : sameDate(d, date)));
    }
    // JR: disabling this check since activeDates or activeDateFilter is preferred.
    // disabling this also allows selecting dates in the past.
    return false; // !isInRange(date, minDate || MIN_DATE, maxDate || MAX_DATE);
}
/**
 * @param {Date} date
 * @param {Date} selectedDate
 * @return {boolean}
 */
function isSelectedDate(date, selectedDate) {
    if (!date || !selectedDate) {
        return false;
    }
    return sameDate(date, selectedDate);
}
/**
 * @param {Date} date
 * @param {Date} selectedDate
 * @return {boolean}
 */
function isSelectedSecondaryDate(date, secondaryDate) {
    if (!date || !secondaryDate) {
        return false;
    }
    return date.toDateString() === secondaryDate.toDateString();
}
/**
 *
 * @param {Date} date
 * @param {Array<Date|DateTip>=} activeDates
 * @return {string}
 */
function getTooltipText(date, activeDates = []) {
    const active = activeDates.find((d) => sameDate(d.date, date));
    return active ? active.tooltip : '';
}
const styles = css `
  :host {
    display: block;
    box-sizing: border-box;
    position: relative;
    height: 100%;
  }
  :host([sticky-header]) .day-headers-container {
    position: sticky;
    position: -webkit-sticky;
    top: 0;
    z-index: 9;
  }
  :host([max-months='1']) .day-headers {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr 1fr 1fr 1fr 1fr;
    z-index: 0;
  }
  :host([max-months='1']) .day-headers-container {
    border-bottom: transparent;
    text-transform: uppercase;
  }
  .calendar {
    position: var(--jha-date-picker-calendar-position, absolute);
    top: var(--jha-date-picker-calendar-top, 33px);
    left: 0;
    right: 0;
    height: calc(100% - 33px);
    overflow-x: var(--jha-date-picker-overflow-x, hidden);
    overflow-y: var(--jha-date-picker-overflow-y, auto);
    background-color: var(--jha-component-background-color, #ffffff);
  }

  @supports (-webkit-touch-callout: none) {
    /** JR: this kills momentum scrolling on ios,
   * so we don't get a long loop of scroll events in infinite scroll mode.
   * https://banno-jha.atlassian.net/browse/WEB-1166
   */
    .scroll-stop {
      overflow-y: hidden;
    }
  }

  .month-header {
    font-size: 18px;
    padding: 20px 0;
    justify-content: center;
    text-align: center;
    color: var(--jha-date-picker-month-header-text-color, var(--jha-text-dark, #455564));
  }
  .month-container {
    display: flex;
    flex-wrap: wrap;
    max-width: 450px;
    margin: 0 auto;
  }
  @supports (display: grid) {
    .month-container {
      display: grid;
      grid-template-columns: repeat(7, 1fr);
    }
  }
  .day,
  .day-header {
    position: relative;
    text-align: center;
    padding: var(--jha-date-picker-day-padding, 2px 0);
    flex-basis: 14%;
  }
  .day-header {
    padding: var(--jha-date-picker-header-padding, 0);
    background-color: var(--jha-date-picker-header-background-color, var(--jha-component-background-color, #ffffff));
    border-bottom: 1px solid var(--jha-date-picker-header-border-bottom-color, transparent);
  }
  button {
    -webkit-appearance: none;
    position: relative;
    margin-bottom: 0;
    text-align: center;
    vertical-align: middle;
    cursor: pointer;
    border: none;
    white-space: nowrap;
    text-transform: none;
    border-radius: 500px;
    box-shadow: none;
    box-sizing: border-box;
    background-color: transparent;
    overflow: visible;
  }
  button[disabled] {
    cursor: text;
    color: var(--jha-date-picker-disabled-color, var(--jha-text-neutral, #8d99a0));
    opacity: 0.7;
  }
  *[data-day] {
    transition: background-color ease 0.2s;
    min-height: var(--jha-date-picker-data-day-min-height, 42px);
    min-width: var(--jha-date-picker-data-day-min-width, 42px);
    padding: 0;
  }
  button + span {
    vertical-align: center;
    margin: 0 10px 5px;
  }
  .day button[isToday],
  .day button[selected],
  .day button[range-end] {
    background: var(--jha-date-picker-in-range-selected, var(--jha-color-primary, #3aaeda));
    border-radius: var(--jha-date-picker-in-range-border-radius, 30px);
    color: var(--jha-date-picker-selected-text-color, var(--jha-text-white, #ffffff));
    opacity: 1;
  }
  :host([show-today]) button {
    border: 2px solid transparent;
  }
  :host([show-today]) button[selected] {
    background: transparent;
    border: 2px solid var(--jha-border-color, #e4e7ea);
    color: var(--jha-date-picker-selected-text-color, var(--jha-color-primary, #3aaeda));
  }
  .day button {
    font-size: 16px;
    color: var(--jha-date-picker-text-color, var(--jha-text-base, #6b757b));
  }
  dom-repeat {
    display: none;
  }
  div[in-range] {
    z-index: 1;
  }
  div[in-range] button {
    background: var(--jha-date-picker-in-range, #e8f3f9);
  }
  div[in-range] button[disabled] {
    opacity: 1;
  }
  div button[secondary] {
    border-radius: var(--jha-date-picker-in-range-border-radius, 30px);
    border-width: 1px;
    border-color: var(--jha-border-color, #e4e7ea);
    border-style: solid;
    background: white;
    padding: 0;
  }
  *[secondary]::after {
    display: none;
  }
  div[in-range] button[selected],
  div[in-range] button[range-end] {
    background: var(--jha-date-picker-in-range-selected, var(--jha-color-primary, #3aaeda));
    border-radius: var(--jha-date-picker-in-range-border-radius, 30px);
    color: var(--jha-text-white, #ffffff);
  }
  div[in-range] button::before {
    transition: background-color ease 0.2s;
    position: absolute;
    content: ' ';
    top: 0px;
    left: -50%;
    width: 100%;
    height: 100%;
    z-index: -1;
    background: var(--jha-date-picker-in-range, #e8f3f9);
  }
  div[in-range] button[data-weekday='0']::before,
  div[in-range] button[isFirstOfMonth]::before,
  div[in-range] button[selected]::before {
    display: none;
  }
  div[in-range] button::after {
    transition: background-color ease 0.2s;
    position: absolute;
    content: ' ';
    top: 0px;
    left: 50%;
    width: 150%;
    height: 100%;
    z-index: -1;
    background: var(--jha-date-picker-in-range-after, #e8f3f9);
  }
  div[in-range] button[data-weekday='6']::after,
  div[in-range] button[isLastOfMonth]::after,
  div[in-range] button[range-end]::after {
    display: none;
  }
  @media (max-width: 512px) {
    div[in-range] button::after {
      left: 50%;
    }
    div[in-range] button::before {
      left: 0%;
      width: 50%;
    }
  }
  .calendar > div:last-of-type {
    padding-bottom: 32px;
  }
  .day-headers-container {
    display: flex;
    justify-content: center;
    position: absolute;
    top: 0px;
    left: 0;
    right: 0;
  }
  .day-headers {
    color: var(--jha-date-picker-header-text-color, var(--jha-text-neutral, #8d99a0));
    display: flex;
    z-index: 10;
    padding: 12px 0;
    width: 100%;
    max-width: 450px;
  }
  :host([dialog]) {
    margin-top: 0;
  }
  :host([dialog]) .month-header {
    font-size: 16px;
    font-weight: 500;
  }
  :host([dialog]) .day-headers-container {
    position: sticky;
    position: -webkit-sticky;
    top: 60px;
    z-index: 1;
  }
  /* IE 11-specific styles */
  @media (max-width: 739px) and (-ms-high-contrast: none) {
    :host([dialog]) .day-headers-container {
      top: 5px;
    }
  }
  /* Safari-specific styles */
  @media not all and (min-resolution: 0.001docm) {
    :host([dialog]) .day-headers-container {
      top: 0;
    }
  }
  span.badge {
    height: 5px;
    width: 5px;
    background-color: var(--jha-color-warning, #fca902);
    border-radius: 50%;
    position: absolute;
    right: 50%;
    bottom: 2px;
    border: 2px solid var(--jha-component-background-color, #ffffff);
  }
  :host([show-today]) button:focus {
    outline: none;
  }
  :host([show-today]) button:focus:before {
    content: '';
    position: absolute;
    top: -4px;
    left: -4px;
    right: -4px;
    bottom: -4px;
    background: var(--jha-focus-highlight-color, rgba(153, 153, 153, 0.12));
    border-radius: 2px;
  }
  .active-date-badge {
    transition: transform 0.1s ease-in-out;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    pointer-events: none;
  }
  jha-tooltip[inactive]:before,
  jha-tooltip[inactive]:after,
  jha-tooltip[disabled]:before,
  jha-tooltip[disabled]:after {
    display: none;
  }
  .active-date-badge .badge {
    transform: translateY(-2px) translateX(50%);
    transition: transform 0.1s ease;
  }
  button[selected] ~ .active-date-badge .badge,
  button[isToday] ~ .active-date-badge .badge {
    transform: translateY(6px) translateX(50%);
  }
  @media (max-width: 480px) {
    :host {
      --jha-date-picker-data-day-min-height: 36px;
      --jha-date-picker-data-day-min-width: 36px;
    }
  }
`;
/**@element jha-date-picker */
export default class JhaDatePicker extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            minDate: {
                type: Date,
            },
            maxDate: {
                type: Date,
            },
            initialDate: {
                type: Date,
            },
            /** @description Custom filter function to pass to jha-date-picker to determine selectable dates. Although
             * a class function could be overridden, this needs to remain a property in order for the view to update
             * when the function is changed.
             */
            activeDateFilter: {
                type: Function,
            },
            selectedDate: {
                type: Date,
            },
            secondaryDate: {
                type: Date,
            },
            maxMonths: {
                type: Number,
                reflect: true,
                attribute: 'max-months',
            },
            showToday: {
                type: Boolean,
                reflect: true,
                attribute: 'show-today',
            },
            _activeDates: {
                type: Array,
            },
            allowRangeSelection: {
                type: Boolean,
                reflect: true,
                attribute: 'allow-range-selection',
            },
            showActiveDateBadge: {
                type: Boolean,
                attribute: 'show-active-date-badge',
            },
            infiniteScroll: {
                type: Boolean,
                reflect: true,
                attribute: 'infinite-scroll',
            },
            /** @description Custom array of month names to use (must have 12 elements) */
            monthNames: {
                type: Array,
            },
            /** @description Custom array of day-of-week names to use (must have 7 elements, starting with Sunday) */
            dayNames: {
                type: Array,
            },
        };
    }
    constructor() {
        super();
        const currentDate = new Date();
        // default to today
        this.minDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate(), 12, 0, 0, 0);
        // default to one year from today
        this.maxDate = new Date(currentDate.getFullYear() + 1, currentDate.getMonth(), currentDate.getDate(), 12, 0, 0, 0);
        this.initialDate = undefined;
        this.showToday = false;
        this.showActiveDateBadge = false;
        /** @type {Array<Date|DateTip} */
        this._activeDates = [];
        this._lastScrollPosition = 0;
        // default to not using infinite scroll
        this.infiniteScroll = false;
        // default month and day names
        this.monthNames = DEFAULT_MONTH_NAMES;
        this.dayNames = DEFAULT_DAY_NAMES;
    }
    connectedCallback() {
        super.connectedCallback();
        this.setInitialScrollPosition();
    }
    async setInitialScrollPosition() {
        await this.updateComplete;
        const scrollElement = this.shadowRoot.querySelector('div#calendar');
        if (!scrollElement)
            return;
        if (this.initialDate) {
            const initialMonthId = `${getMonthName(this.initialDate, this.monthNames)}-${this.initialDate.getFullYear()}`;
            const initialMonth = this.shadowRoot.querySelector(`#${initialMonthId}`);
            if (initialMonth) {
                initialMonth.scrollIntoView();
                return;
            }
        }
        // Allows for scrolling up
        scrollElement.scroll(0, 2);
    }
    /**@param {Array<Date|DateTip>} dates */
    set activeDates(dates = []) {
        this._activeDates = dates;
        if (dates.length > 0) {
            const first = dates[0];
            const last = dates[dates.length - 1];
            this.minDate = first.date ? first.date : first;
            this.maxDate = last.date ? last.date : last;
            // if active dates is set, we should not use infinite scroll
            this.infiniteScroll = false;
        }
    }
    get activeDates() {
        return this._activeDates;
    }
    get showBadge() {
        return this.activeDates.length ? this.showActiveDateBadge : false;
    }
    /**
     * @description the list of displayed month dates
     * @param {Date} minDate
     * @param {Date} maxDate
     * @return {Array<Date>}
     */
    displayMonths(minDate, maxDate) {
        const months = [];
        let i = new Date(minDate.getFullYear(), minDate.getMonth(), 1, 12, 0, 0, 0);
        while (i <= maxDate) {
            months.push(i);
            i = getNextMonthDate(i);
        }
        return months;
    }
    /**
     * @param {Event} event
     * @param {string} monthDate
     */
    selectDate(event, monthDate) {
        event.preventDefault();
        const selectedDate = new Date(monthDate);
        // if range selection is allowed
        if (this.allowRangeSelection && this.selectedDate) {
            // if a date is already selected, and the new selection is greater, assign secondary.
            if (selectedDate > this.selectedDate) {
                this.secondaryDate = selectedDate;
            }
            else if (selectedDate < this.selectedDate) {
                // if the new selection is less, clear secondary and assign selected.
                this.selectedDate = selectedDate;
                this.secondaryDate = undefined;
            }
            else if (sameDate(selectedDate, this.selectedDate)) {
                // clicking the already selected date should clear selection
                this.selectedDate = undefined;
                this.secondaryDate = undefined;
            }
        }
        else {
            this.selectedDate = selectedDate;
        }
        /** @type {import('../../js/utils/types.js').InputDatesSelectedEvent} */
        const changeEvent = new CustomEvent('selected-dates', {
            bubbles: true,
            composed: true,
            detail: {
                selectedDate: this.selectedDate,
                secondaryDate: this.secondaryDate,
            },
        });
        this.dispatchEvent(changeEvent);
        // prevent button from being focused
        event.currentTarget.blur();
    }
    /**
     *
     * @param {Event} event
     * @param {Date} monthDate
     */
    onPointerOverBadge(event, monthDate) {
        // if active dates contains objects instead of dates,
        // look there and set the tooltip's text. otherwise let
        // the event handler handle it?
        const text = getTooltipText(monthDate, this.activeDates);
        event.currentTarget.setAttribute('text', text);
        this.dispatchEvent(new CustomEvent('badge-mouseover', {
            detail: {
                target: event.currentTarget,
                date: monthDate,
            },
        }));
    }
    /**
     * @description `scroll` event handler for calendar view. Appends/prepends and removes months from the calendar while scrolling
     * @param {Event} event
     */
    onScroll(event) {
        if (!this.infiniteScroll) {
            return;
        }
        const calendar = event.currentTarget;
        requestAnimationFrame(() => {
            const { clientHeight, scrollHeight, scrollTop } = calendar;
            const scrollDirection = scrollTop > this._lastScrollPosition ? 'down' : 'up';
            this._lastScrollPosition = scrollTop;
            const nearBottom = scrollHeight - scrollTop < clientHeight * 2 && scrollDirection === 'down';
            const nearTop = scrollTop < clientHeight && scrollDirection === 'up';
            const months = this.displayMonths(this.minDate, this.maxDate);
            const firstMonth = months[0];
            const lastMonth = months[months.length - 1];
            if (nearTop) {
                const prevMonthDate = getPreviousMonthDate(firstMonth);
                const firstMonthTime = new Date(this.minDate).setDate(1);
                if (prevMonthDate.getTime() <= firstMonthTime) {
                    // add a new month and pop the last date
                    this.minDate = prevMonthDate;
                    this.maxDate = getPreviousMonthDate(lastMonth);
                    // this stops ios safari from using momentum scrolling,
                    calendar.classList.add('scroll-stop');
                    calendar.scrollTop = scrollTop + MONTH_HEIGHT;
                    Promise.resolve().then(() => {
                        calendar.classList.remove('scroll-stop');
                    });
                }
            }
            else if (nearBottom) {
                const nextMonthDate = getNextMonthDate(lastMonth);
                const lastMonthTime = new Date(this.maxDate).setDate(1);
                if (nextMonthDate.getTime() >= lastMonthTime) {
                    this.minDate = getNextMonthDate(firstMonth);
                    this.maxDate = nextMonthDate;
                    calendar.classList.add('scroll-stop');
                    calendar.scrollTop = scrollTop - MONTH_HEIGHT;
                    Promise.resolve().then(() => {
                        calendar.classList.remove('scroll-stop');
                    });
                }
            }
        });
    }
    renderDayButton(monthDay, showBadge = false) {
        const disabled = isDateDisabled(monthDay, this.minDate, this.maxDate, this._activeDates, this.activeDateFilter);
        const secondarySelected = isSelectedSecondaryDate(monthDay, this.secondaryDate);
        return html `
      <div
        class="day"
        ?in-range=${isInRange(monthDay, this.selectedDate, this.secondaryDate)}>
        <jha-tooltip
          ?disabled=${!showBadge}
          ?inactive=${disabled}
          ?top=${tooltipTop(monthDay)}
          ?top-right=${isTopRight(monthDay)}
          ?top-left=${isTopLeft(monthDay)}
          @pointerover=${(event) => this.onPointerOverBadge(event, monthDay)}>
          <button
            type="button"
            ?selected=${isSelectedDate(monthDay, this.selectedDate)}
            ?range-end=${secondarySelected}
            ?secondary=${secondarySelected}
            @click=${(event) => this.selectDate(event, monthDay)}
            data-day=${monthDay.toDateString()}
            data-weekday=${monthDay.getDay()}
            ?isFirstOfMonth=${monthDay.getDate() === 1}
            ?isLastOfMonth=${isLastOfMonth(monthDay)}
            ?isToday=${isToday(this.showToday, monthDay)}
            ?disabled=${disabled}>
            <div>${monthDay.getDate()}</div>
          </button>
          ${showBadge && !disabled
            ? html `
                <div class="active-date-badge">
                  <span
                    class="badge"
                    @click=${(event) => this.selectDate(event, monthDay)}></span>
                </div>
              `
            : ''}
        </jha-tooltip>
      </div>
    `;
    }
    renderMonthDays(monthDays = []) {
        return monthDays.map((md) => html ` ${this.renderDayButton(md, this.showBadge)} `);
    }
    renderMonths(months = []) {
        return months.map((monthDate) => html `
        <slot name="month-header">
          <div
            class="month-header"
            id="${getMonthName(monthDate, this.monthNames)}-${monthDate.getFullYear()}">
            <span>${getMonthName(monthDate, this.monthNames)} ${monthDate.getFullYear()}</span>
          </div>
        </slot>
        <div class="month-container">
          ${getInitialPadding(monthDate).map(() => html ` <div class="day"></div> `)}
          ${this.renderMonthDays(getMonthDays(monthDate))}
        </div>
      `);
    }
    render() {
        const scrollListener = {
            handleEvent: (event) => this.onScroll(event),
            passive: true,
        };
        return html `
      <div class="day-headers-container">
        <div class="day-headers">${this.dayNames.map((dayName) => html `<div class="day-header">${dayName}</div>`)}</div>
      </div>
      ${this.infiniteScroll
            ? html `
            <div
              id="calendar"
              class="calendar"
              @scroll=${scrollListener}>
              ${this.renderMonths(this.displayMonths(this.minDate, this.maxDate))}
            </div>
          `
            : html `
            <div
              id="calendar"
              class="calendar">
              ${this.renderMonths(this.displayMonths(this.minDate, this.maxDate))}
            </div>
          `}
    `;
    }
}
export { styles as JhaDatePickerStyles };
