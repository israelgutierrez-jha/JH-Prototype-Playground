import JhaDropdownMenuItem from './JhaDropdownMenuItem.js';
customElements.define('jha-dropdown-menu-item', JhaDropdownMenuItem);
export default JhaDropdownMenuItem;
