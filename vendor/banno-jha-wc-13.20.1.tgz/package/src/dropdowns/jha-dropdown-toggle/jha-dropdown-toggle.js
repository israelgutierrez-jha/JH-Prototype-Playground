import JhaDropdownToggle from './JhaDropdownToggle.js';
customElements.define('jha-dropdown-toggle', JhaDropdownToggle);
/** @customElement jha-dropdown-toggle */
export default JhaDropdownToggle;
