import JhaDropdown from './JhaDropdown.js';
customElements.define('jha-dropdown', JhaDropdown);
/** @customElement jha-dropdown */
export default JhaDropdown;
