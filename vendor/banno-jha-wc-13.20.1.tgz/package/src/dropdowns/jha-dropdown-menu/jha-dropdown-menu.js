import JhaDropdownMenu from './JhaDropdownMenu.js';
customElements.define('jha-dropdown-menu', JhaDropdownMenu);
/** @customElement jha-dropdown-menu */
export default JhaDropdownMenu;
