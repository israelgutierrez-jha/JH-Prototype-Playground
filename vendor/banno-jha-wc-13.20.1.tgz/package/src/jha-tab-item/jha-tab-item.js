import JhaTabItem from './JhaTabItem.js';
customElements.define('jha-tab-item', JhaTabItem);
/** @customElement jha-tab-item */
export default JhaTabItem;
