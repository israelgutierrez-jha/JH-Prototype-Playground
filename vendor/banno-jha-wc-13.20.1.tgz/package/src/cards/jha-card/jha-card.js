import JhaCard from './JhaCard.js';
customElements.define('jha-card', JhaCard);
/** @customElement jha-card */
export default JhaCard;
