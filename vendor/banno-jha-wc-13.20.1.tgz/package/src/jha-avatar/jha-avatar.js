import JhaAvatar from './JhaAvatar';
customElements.define('jha-avatar', JhaAvatar);
/** @customElement jha-avatar */
export default JhaAvatar;
