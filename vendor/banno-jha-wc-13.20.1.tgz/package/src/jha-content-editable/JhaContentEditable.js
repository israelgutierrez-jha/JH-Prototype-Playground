import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../styles/jha-styles.js';
const styles = css `
  :host {
    display: block;
    --jha-content-editable-background-color-hover: var(--jh-color-container-primary-hover, rgb(235, 235, 235));
    --jha-content-editable-background-color-active: var(--jh-color-container-primary-active, rgb(215, 215, 215));
    --jha-content-editable-padding-vertical: 6px;
    --jha-content-editable-padding-horizontal: 12px;
    --jha-content-editable-border-radius: 4px;
    position: relative;
    left: calc(-1 * var(--jha-content-editable-padding-horizontal, 0));
    top: calc(-1 * var(--jha-content-editable-padding-vertical, 0));
  }
  :host ::slotted(*[contenteditable]) {
    outline: none;
    padding: var(--jha-content-editable-padding-vertical, 6px) var(--jha-content-editable-padding-horizontal, 12px);
    border-radius: var(--jha-content-editable-border-radius, 4px);
  }
  :host ::slotted(*[contenteditable]:not([contenteditable='false'])) * {
    display: inline;
    white-space: nowrap;
  }
  :host ::slotted(*[contenteditable]:not([contenteditable='false']):hover) {
    background: var(--jha-content-editable-background-color-hover);
  }
  :host ::slotted(*[contenteditable]:not([contenteditable='false']):focus) {
    background: var(--jha-content-editable-background-color-active);
  }
`;
export var JhaContentEditableEvent;
(function (JhaContentEditableEvent) {
    JhaContentEditableEvent["CANCEL"] = "cancel";
    JhaContentEditableEvent["CHANGE"] = "change";
})(JhaContentEditableEvent || (JhaContentEditableEvent = {}));
export default class JhaContentEditable extends LitElement {
    constructor() {
        super(...arguments);
        this._canceled = false;
        this._editableElement = null;
        this._savedValue = null;
        this._onBlur = (evt) => {
            if (!(evt.currentTarget instanceof HTMLElement)) {
                return;
            }
            const newValue = evt.currentTarget.innerText.trim();
            if (this._savedValue === newValue) {
                return;
            }
            if (!this._canceled) {
                this.dispatchEvent(new CustomEvent(JhaContentEditableEvent.CHANGE, {
                    bubbles: true,
                    composed: true,
                    detail: {
                        value: newValue,
                    },
                }));
            }
        };
        this._onFocus = (evt) => {
            if (!(document.activeElement instanceof HTMLElement)) {
                return;
            }
            this._canceled = false;
            this._savedValue = evt.currentTarget.innerText.trim();
        };
        this._onKeydown = (evt) => {
            const element = evt.currentTarget;
            if (!(element instanceof HTMLElement)) {
                return;
            }
            switch (evt.key) {
                case 'Enter':
                    evt.preventDefault();
                    element.blur();
                    break;
                case 'Escape':
                    this.dispatchEvent(new CustomEvent(JhaContentEditableEvent.CANCEL, {
                        bubbles: false,
                        detail: {
                            oldValue: this._savedValue,
                        },
                    }));
                    this._canceled = true;
                    element.blur();
                    break;
                default:
                    break;
            }
        };
    }
    static { this.Event = JhaContentEditableEvent; }
    static get styles() {
        return [jhaStyles, styles];
    }
    disconnectedCallback() {
        this._removeListeners();
        super.disconnectedCallback();
    }
    _onSlotChange() {
        this._removeListeners();
        this._editableElement = this.querySelector('[contenteditable]:not([contenteditable="false"])');
        if (!this._editableElement) {
            return;
        }
        this._editableElement.setAttribute('contenteditable', 'plaintext-only');
        this._editableElement.setAttribute('enterkeyhint', 'done');
        this._editableElement.addEventListener('blur', this._onBlur);
        this._editableElement.addEventListener('focus', this._onFocus);
        this._editableElement.addEventListener('keydown', this._onKeydown);
    }
    _removeListeners() {
        if (this._editableElement) {
            this._editableElement.removeEventListener('blur', this._onBlur);
            this._editableElement.removeEventListener('focus', this._onFocus);
            this._editableElement.removeEventListener('keydown', this._onKeydown);
        }
    }
    render() {
        return html ` <slot @slotchange=${this._onSlotChange}></slot> `;
    }
}
