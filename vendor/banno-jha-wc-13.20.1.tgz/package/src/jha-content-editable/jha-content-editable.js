import JhaContentEditable from './JhaContentEditable';
customElements.define('jha-content-editable', JhaContentEditable);
/** @customElement jha-content-editable */
export default JhaContentEditable;
