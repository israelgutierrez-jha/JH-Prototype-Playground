import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../styles/jha-styles.js';
const styles = css `
  :host {
    display: flex;
    color: var(--jha-toast-text-color, #ffffff);
    background-color: var(--jha-message-background, var(--jha-color-dark, #455564));
    border-radius: 3px;
    padding: 16px 20px;
    text-align: left;
  }
  :host([danger]) {
    background-color: var(--jha-message-background-danger, var(--jha-color-warning, #f44336));
    color: var(--jha-error-message-text-color, var(--error-text-color, #fff));
  }
  :host([success]) {
    background-color: var(--jha-message-background-success, var(--jha-color-success, #4caf50));
    color: var(--jha-component-background-color, var(--primary-content-background-color, #fff));
  }
  :host ::slotted(.icon) {
    fill: #fff;
    margin-right: 10px;
    vertical-align: middle;
  }
  div {
    flex-grow: 1;
  }
  @media (max-width: 480px) {
    :host {
      padding: 10px;
    }
  }
`;
/**
 * A JHA Design component for a general error message.
 *
 * @element jha-message
 * @slot unnamed slot used for content.
 *
 * @cssprop --jha-color-warning - Sets the background color to the theme's warning color.
 */
export default class JhaMessage extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            role: {
                type: String,
                reflect: true,
            },
            danger: {
                type: Boolean,
                reflect: true,
            },
            success: {
                type: Boolean,
                reflect: true,
            },
        };
    }
    constructor() {
        super();
        this.role = '';
        this.danger = false;
        this.success = false;
    }
    willUpdate(changedProperties) {
        if (changedProperties.has('danger') && this.danger) {
            this.role = 'alert';
        }
        else if (changedProperties.has('success') && this.success) {
            this.role = 'status';
        }
        else {
            this.role = '';
        }
    }
    render() {
        return html ` <div><slot></slot></div> `;
    }
}
export { styles as jhaErrorMessageStyles };
