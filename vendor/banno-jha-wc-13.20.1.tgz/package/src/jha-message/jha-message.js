import JhaMessage from './JhaMessage.js';
customElements.define('jha-message', JhaMessage);
/** @customElement jha-message */
export default JhaMessage;
