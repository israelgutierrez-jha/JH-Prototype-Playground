import JhaList from './JhaList.js';
customElements.define('jha-list', JhaList);
/** @customElement jha-list */
export default JhaList;
