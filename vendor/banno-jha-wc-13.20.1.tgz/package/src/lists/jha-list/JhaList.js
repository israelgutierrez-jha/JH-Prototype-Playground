import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
/*
 * `<jha-list>` A JHA Design list component.
 *
 * Typical usage:
 *
 *    <body>
 *      <jha-list>
 *        <jha-list-item>...</jha-list-item>
 *      </jha-list>
 *
 *      The following attribute is also available for styling:
 *
 *      Attribute | Description
 *      ----------------|-------------|----------
 *      `([borderless])` | Removed the bottom border from the jha-list-item component
 *      `([collapse])` | Removes the right margin from the jha-list-item component
 *
 * @element jha-list
 */
const styles = css `
  :host {
    --jha-list-item-border-display: solid;
    display: block;
    margin-bottom: var(--jha-list-margin-bottom, 6px);
    margin-top: var(--jha-list-margin-top, 0);
  }
  :host ::slotted(jha-list-item:last-of-type) {
    background-image: none;
    border-bottom: var(--last-item-border-display, none);
  }
  :host([borderless]) ::slotted(jha-list-item) {
    --jha-list-item-border-display: none;
    padding: 7px 0px;
  }
  :host([collapse]) ::slotted(jha-list-item) {
    margin-left: 0;
    padding-left: 0;
  }
`;
export default class JhaList extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            role: {
                type: String,
                reflect: true,
            },
        };
    }
    constructor() {
        super();
        this.role = 'list';
    }
    render() {
        return html ` <slot></slot> `;
    }
}
export { styles as JhaListStyles };
