import JhaCheckboxListItem from './JhaCheckboxListItem.js';
customElements.define('jha-checkbox-list-item', JhaCheckboxListItem);
/** @customElement jha-checkbox-list-item */
export default JhaCheckboxListItem;
