import { LitElement, css, html } from 'lit';
import { jhaListItemStyles } from '../jha-list-item/JhaListItem.js';
import '../../forms/jha-form-checkbox/jha-form-checkbox.js';
/**@element jha-checkbox-list-item */
export default class JhaCheckboxListItem extends LitElement {
    static get styles() {
        return [
            jhaListItemStyles,
            css `
        :host {
          --jha-form-checkbox-label-align-items: flex-start;
        }
        #clickable {
          margin-left: 33px;
        }
        jha-form-checkbox > div,
        jha-form-checkbox {
          width: 100%;
        }
      `,
        ];
    }
    static get properties() {
        return {
            title: {
                type: String,
            },
            subTitle: {
                type: String,
            },
            description: {
                type: String,
            },
            accountId: {
                type: String,
            },
            checked: {
                type: Boolean,
            },
        };
    }
    constructor() {
        super();
        // eslint-disable-next-line wc/no-constructor-attributes
        this.title = '';
        this.subTitle = '';
        this.description = '';
        this.accountId = '';
        this.checked = false;
    }
    render() {
        return html `
      <div class="info">
        <jha-form-checkbox
          label=${this.title}
          .checked=${this.checked}>
          <div>
            ${this.title ? html ` <div class="title">${this.title}</div> ` : ''}
            ${this.subTitle ? html ` <div class="small">${this.subTitle}</div> ` : ''}
            ${this.description ? html ` <div class="sub-title">${this.description}</div> ` : ''}
            <slot></slot>
          </div>
        </jha-form-checkbox>
        <div
          class="sub-title"
          id="clickable">
          <slot name="clickable"></slot>
        </div>
      </div>
    `;
    }
}
