import JhaReorderListItem from './JhaReorderListItem.js';
customElements.define('jha-reorder-list-item', JhaReorderListItem);
export default JhaReorderListItem;
