import JhaReorderList from './JhaReorderList.js';
customElements.define('jha-reorder-list', JhaReorderList);
export default JhaReorderList;
