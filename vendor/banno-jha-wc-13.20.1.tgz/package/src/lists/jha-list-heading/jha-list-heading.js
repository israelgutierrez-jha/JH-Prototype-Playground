import JhaListHeading from './JhaListHeading.js';
customElements.define('jha-list-heading', JhaListHeading);
/** @customElement jha-list-heading */
export default JhaListHeading;
