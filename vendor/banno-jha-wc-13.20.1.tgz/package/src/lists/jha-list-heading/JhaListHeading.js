import { css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
import JhaStyleElement from '../../style-element/JhaStyleElement.js';
/*
 * `<jha-list-heading>` A heading title used in a JHA Design list component.
 *
 * Typical usage:
 *
 *   <body>
 *     <jha-list>
 *       <jha-list-item>...</jha-list-item>
 *     </jha-list>
 *
 * The following attribute is also available for styling:
 *
 * Attribute | Description
 * ----------------|-------------|----------
 * `([inset])` | Sub-title heading for a list of items `([inset])` | Sets left inset on the hairline border
 *
 * @element jha-list-heading
 */
const styles = css `
  :host {
    display: block;
    position: relative;
    color: var(--jha-text-light, #8c989f);
    text-transform: uppercase;
    padding-top: 32px;
    padding-bottom: 6px;
    font-size: calc(var(--jha-text-size-base, 14px) - 2px);
    font-weight: 600;
    margin-bottom: 4px;
  }
  :host::after {
    clear: both;
    content: '';
    display: block;
    position: absolute;
    top: auto;
    bottom: 0;
    left: 0;
    right: 0;
    border-bottom: 1px solid var(--jha-border-color, #e4e7ea);
  }
  :host([inset]) {
    margin-left: var(--jha-list-item-inset, 16px);
  }
`;
export default class JhaListHeading extends JhaStyleElement {
    static get styles() {
        return [jhaStyles, styles];
    }
}
export { styles as JhaListHeadingStyles };
