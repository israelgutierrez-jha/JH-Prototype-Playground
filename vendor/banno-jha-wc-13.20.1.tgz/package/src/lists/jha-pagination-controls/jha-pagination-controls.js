import JhaPaginationControls from './JhaPaginationControls.js';
customElements.define('jha-pagination-controls', JhaPaginationControls);
/** @customElement jha-pagination-controls */
export default JhaPaginationControls;
