import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
import '../../buttons/jha-button/jha-button.js';
const styles = css `
  :host {
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--jha-text-theme, #3aaeda);
  }
  jha-button {
    line-height: var(--jha-button-line-height, 12px);
  }
  jha-icon-chevron-left,
  jha-icon-chevron-right {
    fill: var(--jha-pagination-controls-button-color, var(--jha-text-theme, #3aaeda));
  }
  span.dot-icon {
    display: inline-block;
    background-color: var(--jha-pagination-dot-color);
    width: 6px;
    height: 6px;
    border-radius: 50%;
    position: relative;
    top: -3.5px;
    margin: 5px 4px 0 4px;
  }
  span.dot-icon[selected] {
    background-color: var(--jha-pagination-dot-color-selected);
  }
`;
/**@element jha-pagination-controls */
export default class JhaPaginationControls extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            items: {
                type: Array,
            },
            itemsPerPage: {
                type: Number,
            },
            pageIndex: {
                type: Number,
            },
        };
    }
    constructor() {
        super();
        import('../../icons/jha-icon-chevron-left.js');
        import('../../icons/jha-icon-chevron-right.js');
        this.items = [];
        this.itemsPerPage = 4;
        this.pageIndex = 0;
    }
    // convert flat array into array of arrays
    get pages() {
        const items = this.items || [];
        this._pages = items.reduce((acc, item) => {
            if (acc[acc.length - 1] === undefined || acc[acc.length - 1].length === this.itemsPerPage) {
                acc.push([item]);
            }
            else {
                acc[acc.length - 1].push(item);
            }
            return acc;
        }, []);
        return this._pages;
    }
    updated() {
        if (this.showControls(this.itemsPerPage, this.items)) {
            this.dispatchEvent(new CustomEvent('change', {
                composed: true,
                bubbles: true,
                detail: {
                    pages: this._pages,
                    pageIndex: this.pageIndex,
                    currentPage: this._pages[this.pageIndex],
                },
            }));
        }
    }
    showControls(itemsPerPage, items = []) {
        return items.length > itemsPerPage;
    }
    isPreviousDisabled(pageIndex) {
        return pageIndex === 0;
    }
    isNextDisabled(itemsPerPage, pageIndex, itemCount) {
        return pageIndex + 1 >= itemCount / itemsPerPage;
    }
    isSelectedPage(index, pageIndex) {
        return index === pageIndex;
    }
    pageNumbersLabel(pageIndex, numPages) {
        return `${pageIndex + 1} of ${numPages}`;
    }
    showCarouselPagination(pages) {
        return pages.length < 5;
    }
    nextPage() {
        this.pageIndex += 1;
    }
    previousPage() {
        this.pageIndex -= 1;
    }
    render() {
        return html `
      ${this.showControls(this.itemsPerPage, this.items)
            ? html `
            <jha-button
              type="button"
              @click=${this.previousPage}
              icon
              ?disabled=${this.isPreviousDisabled(this.pageIndex)}
              sync>
              <jha-icon-chevron-left title="Accounts list previous page"></jha-icon-chevron-left>
            </jha-button>
            ${this.showCarouselPagination(this.pages)
                ? html `
                  ${this.pages.map((t, i) => html `
                      <span
                        class="dot-icon"
                        ?selected=${this.isSelectedPage(i, this.pageIndex)}></span>
                    `)}
                `
                : html ` ${this.pageNumbersLabel(this.pageIndex, this.pages.length)} `}
            <jha-button
              type="button"
              @click=${this.nextPage}
              icon
              ?disabled=${this.isNextDisabled(this.itemsPerPage, this.pageIndex, this.items.length)}
              sync>
              <jha-icon-chevron-right title="Accounts list next page"></jha-icon-chevron-right>
            </jha-button>
          `
            : ``}
    `;
    }
}
export { styles as JhaPaginationControlStyles };
