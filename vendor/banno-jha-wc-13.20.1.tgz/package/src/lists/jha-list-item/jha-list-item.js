import JhaListItem from './JhaListItem.js';
customElements.define('jha-list-item', JhaListItem);
/** @customElement jha-list-item */
export default JhaListItem;
