import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
const styles = css `
  :host {
    display: flex;
    padding-top: var(--jha-list-item-vertical-spacing, 18px);
    padding-bottom: var(--jha-list-item-vertical-spacing, 18px);
    padding-right: var(--jha-list-item-horizontal-spacing, 16px);
    padding-left: 0;
    margin-left: var(--jha-list-item-margin-left, 16px);
    border-bottom: 1px var(--jha-list-item-border-display, solid) var(--jha-border-color);
    align-items: var(--jha-list-item-align-items, center);
  }
  :host([no-padding]) {
    padding: 0;
  }
  :host([inset]) {
    border-bottom: none;
    position: relative;
  }
  :host([inset])::after {
    clear: both;
    content: '';
    display: var(--jha-list-item-border-display, block);
    position: absolute;
    top: auto;
    bottom: 0;
    left: var(--jha-list-item-inset, 52px);
    right: 0;
    border-bottom: 1px var(--jha-list-item-border-display, solid) var(--jha-border-color);
  }
  ::slotted(*) {
    color: var(--jha-text-base);
  }
  .title {
    font-size: 17px;
    color: var(--jha-text-base);
  }
  .sub-title {
    font-size: 15px;
    color: var(--jha-text-neutral);
  }
  .small {
    font-size: 13px;
  }
  .info {
    flex: 1 0 0px;
  }
  .right {
    margin-left: auto;
  }
  slot[name='control']::slotted(label) {
    width: 38px;
    position: relative;
  }
`;
/**
 * A JHA Design list item element
 *
 * @element jha-list-item
 *
 * @slot control - left side content for things like checkboxes and icons
 * @slot title - title content
 * @slot sm-sub-title - small sub-title content
 * @slot sub-title - sub-title content
 * @slot unnamed slot for custom content
 *
 * @cssprop --jha-list-item-vertical-spacing
 * @cssprop --jha-list-item-horizontal-spacing
 * @cssprop --jha-text-base - default text color
 * @cssprop --jha-text-neutral - sub-title text color
 * @cssprop --jha-border-color - bottom border color
 */
export default class JhaListItem extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    render() {
        return html `
      <slot name="control"></slot>
      <div class="info">
        <div class="title">
          <slot name="title"></slot>
        </div>
        <div class="sub-title small">
          <slot name="sm-sub-title"></slot>
        </div>
        <div class="sub-title">
          <slot name="sub-title"></slot>
        </div>
        <slot></slot>
      </div>
      <div class="right">
        <slot name="right"></slot>
      </div>
    `;
    }
}
export { styles as jhaListItemStyles };
