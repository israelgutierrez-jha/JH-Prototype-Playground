import JhaInstitutionSelector from './JhaInstitutionSelector.js';
customElements.define('jha-institution-selector', JhaInstitutionSelector);
/** @customElement jha-institution-selector */
export default JhaInstitutionSelector;
