import DialogUtil from '../js/utils/dialog-util.js';
import JhaInstitutionSelector from './jha-institution-selector.js';
/**
 * @typedef {Object} JhInstitution
 * @property {string} name
 * @property {string} url
 * @property {string} institutionId
 */
/**
 * @param {!Array<JhInstitution>} institutions
 * @param {string=} currentInstitution
 * @returns {Promise<!JhInstitution|undefined>}
 */
const awaitInstitutionSelection = async (institutions, currentInstitution = '') => {
    if (institutions.length === 1) {
        return institutions[0];
    }
    const dialog = new JhaInstitutionSelector();
    dialog.institutions = institutions;
    dialog.currentInstitution = currentInstitution;
    let institution;
    try {
        institution = await DialogUtil.awaitDialog({ dialog });
    }
    catch (error) {
        // Do nothing
    }
    return institution;
};
export default awaitInstitutionSelection;
