import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../styles/jha-styles.js';
import JhaDialog from '../jha-dialog/jha-dialog.js';
import '../forms/jha-form-search-input/jha-form-search-input.js';
import '../lists/jha-list/jha-list.js';
import '../lists/jha-list-item/jha-list-item.js';
import '../jha-flex-wrapper/jha-flex-wrapper.js';
const styles = css `
  :host {
    display: block;
    --jha-card-header-padding-bottom: 0;
    --jha-list-item-inset: 48px;
  }
  jha-dialog {
    --jha-dialog-min-height: calc(100vh - 90px);
    --jha-card-article-margin-left: 0px;
    --jha-card-article-padding-right: 0px;
    --jha-dialog-header-font-size: 24px;
    --jha-form-floating-group-outline-border-color: #5f6468;
    --jha-card-header-margin-left: 16px;
    --jha-card-header-padding-right: 16px;
  }
  jha-list {
    --jha-list-item-margin-left: 0;
    border-top: 1px var(--jha-list-item-border-display, solid) var(--jha-border-color);
  }
  jha-flex-wrapper {
    gap: 16px;
    padding: 16px 24px 16px 0;
    width: 100%;
    box-sizing: border-box;
  }
  jha-icon-fi {
    width: var(--jha-institution-icon-size, 36px);
    height: var(--jha-institution-icon-size, 36px);
    fill: var(--jha-institution-icon-fill, var(--jha-text-base));
  }
  jha-icon-circle-checkmark-filled {
    fill: #a6c19f;
    margin-top: 26px;
    margin-right: 24px;
  }
  h5 {
    color: var(--jha-institution-name-color, var(--jha-text-dark));
    font-size: var(--jha-institution-name-size, 16px);
    font-weight: var(--jha-institution-weight, 700);
    line-height: var(--jha-institution-line-height, 24px);
    margin: 0;
    width: 100%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  span {
    color: var(--jha-institution-url-color, var(--jha-text-light));
    font-size: var(--jha-institution-url-size, 14px);
    font-weight: var(--jha-institution-url-weight, 400);
    line-height: var(--jha-institution-url-line-height, 20px);
    width: 100%;
  }
  button.institution {
    padding-left: 16px;
    display: flex;
  }
  button.institution:hover {
    background-color: var(--jh-institution-hover-background, var(--jha-color-light, #f0f5f9));
  }
  button.institution:hover h5,
  button.institution:hover span {
    color: var(--jh-institution-hover-text-color, var(--jha-color-primary, #006ee4));
  }
  .fi-description {
    width: 0px;
    flex: 1;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  jha-form-search-input {
    --jha-border-color: #e4e7ea;
  }
  .no-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 36px;
  }
  .no-content p {
    margin: 0;
  }
  @media (max-width: 739px) {
    jha-dialog {
      --jha-card-header-margin-left: 16px;
      --jha-list-item-margin-left: 0;
    }
  }
`;
/**@element jha-institution-selector */
export default class JhaInstitutionSelector extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            title: {
                type: String,
            },
            institutions: {
                type: Array,
            },
            searchValue: {
                type: String,
            },
            hideCancel: {
                type: Boolean,
            },
            currentInstitution: {
                type: String,
            },
        };
    }
    constructor() {
        super();
        import('../icons/jha-icon-circle-checkmark-filled.js');
        import('../icons/jha-icon-fi.js');
        // eslint-disable-next-line wc/no-constructor-attributes
        this.title = 'Switch institutions';
        /** @type {!Array<import('./institutionSelectorUtil.js').JhInstitution>} */
        this.institutions = [];
        this.searchValue = '';
        this.currentInstitution = '';
        this.hideCancel = true;
    }
    saveSearchValue(evt) {
        this.searchValue = (evt.detail || '').toLowerCase();
    }
    get institutionList() {
        return this.searchValue ? this.institutions.filter(this.itemMatchesSearch.bind(this)) : [...this.institutions];
    }
    itemMatchesSearch(item) {
        const name = item.name.toLowerCase();
        const url = item.url.toLowerCase();
        return name.includes(this.searchValue) || url.includes(this.searchValue);
    }
    sortInstitutions(a, b) {
        return a.name.localeCompare(b.name);
    }
    selectInstitution(detail) {
        this.dispatchEvent(new CustomEvent(JhaDialog.events.CONFIRM, {
            bubbles: true,
            composed: true,
            detail,
        }));
    }
    renderNoInstitutionsMessage() {
        if (this.institutionList.length)
            return '';
        return html `
      <div class="no-content">
        <jha-icon-fi></jha-icon-fi>
        <p>No matches for ${this.searchValue}</p>
        <p>Try a different keyword</p>
      </div>
    `;
    }
    renderSearchBar() {
        if (this.institutions.length < 10)
            return '';
        return html `
      <jha-form-search-input
        slot="header-bottom"
        outline
        placeholder="Search"
        @search=${this.saveSearchValue}></jha-form-search-input>
    `;
    }
    render() {
        return html `
      <jha-dialog
        .title=${this.title}
        hide-confirm>
        ${this.renderSearchBar()}
        <article slot="dialog-content">
          ${this.renderNoInstitutionsMessage()}
          <jha-list>
            ${this.institutionList.sort(this.sortInstitutions).map((item) => html `
                <jha-list-item no-padding>
                  <button
                    type="button"
                    button-reset
                    class="institution"
                    @click=${() => this.selectInstitution(item)}>
                    <jha-flex-wrapper>
                      <div class="fi-description">
                        <h5 aria-label=${item.name}>${item.name}</h5>
                        <span aria-label=${item.url}>${item.url}</span>
                      </div>
                    </jha-flex-wrapper>

                    ${this.currentInstitution === item.institutionId
            ? html `
                          <div class="icon-container">
                            <jha-icon-circle-checkmark-filled></jha-icon-circle-checkmark-filled>
                          </div>
                        `
            : ''}
                  </button>
                </jha-list-item>
              `)}
          </jha-list>
        </article>
      </jha-dialog>
    `;
    }
}
export { styles as JhaInstitutionSelectorStyles };
