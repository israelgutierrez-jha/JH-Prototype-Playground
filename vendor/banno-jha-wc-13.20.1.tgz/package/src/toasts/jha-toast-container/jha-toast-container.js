import JhaToastContainer from './JhaToastContainer.js';
customElements.define('jha-toast-container', JhaToastContainer);
/** @customElement jha-toast-container */
export default JhaToastContainer;
