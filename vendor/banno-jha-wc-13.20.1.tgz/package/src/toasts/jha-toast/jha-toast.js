import JhaToast from './JhaToast.js';
customElements.define('jha-toast', JhaToast);
/** @customElement jha-toast */
export default JhaToast;
