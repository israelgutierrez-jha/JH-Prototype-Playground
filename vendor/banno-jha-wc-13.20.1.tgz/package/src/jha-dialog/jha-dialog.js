import JhaDialog from './JhaDialog.js';
customElements.define('jha-dialog', JhaDialog);
/** @customElement jha-dialog */
export default JhaDialog;
