import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../styles/jha-styles.js';
import '../buttons/jha-button/jha-button.js';
const styles = css `
  :host {
    display: block;
    position: relative;
    margin-bottom: 24px;
    padding: 16px;
    background-color: var(--jha-component-background-color, #ffffff);
    box-shadow:
      0 1px 1px 0 rgba(0, 0, 0, 0.24),
      0 1px 4px rgba(0, 0, 0, 0.12);
  }
  /* jhaAccordianToggle */
  .toggle {
    display: block;
    width: 24px;
    height: 24px;
    position: absolute;
    z-index: 1;
    bottom: -12px;
    left: 50%;
    margin-left: -12px;
    border: 0;
    background-image: none;
    background-color: var(--jha-accordion-background-color, var(--jha-color-primary, #3aaeda));
    padding: 0;
    color: var(--jha-text-white, #ffffff);
    text-align: center;
    border-radius: 50%;
    transform-origin: center;
    transition: transform 0.3 ease;
    cursor: pointer;
  }
  jha-icon-chevron-down {
    fill: var(--jha-accordion-toggle-icon-fill, #ffffff);
    transition: all 0.3s cubic-bezier(0.1, 0.5, 0.1, 1);
  }
  :host([is-open]) jha-icon-chevron-down {
    transform: rotate(180deg);
  }
  /* jhaAccordianBody */
  article {
    height: 0;
    overflow: hidden;
    will-change: transform, opacity;
    opacity: var(--jha-accordion-body-opacity, 0.3);
    transition: all 0.3s cubic-bezier(0.1, 0.5, 0.1, 1);
  }
  :host([is-open]) article {
    height: auto;
    opacity: var(--jha-accordion-opacity, 1);
    padding: var(--jha-accordion-body-padding, 0);
    padding-top: 16px;
  }
  @media (min-width: 740px) {
    :host([full]) {
      display: block;
      box-shadow: none;
      border-bottom: 1px solid var(--jha-accordion-bottom-border-color, var(--jha-border-color, #e4e7ea));
    }
  }
`;
/**
 * A JHA Design Accordion
 *
 * @element jha-accordion
 *
 * @cssprop --jha-accordion-bottom-border-color - Bottom border color
 */
export default class JhaAccordion extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            isOpen: {
                type: Boolean,
                attribute: 'is-open',
                reflect: true,
            },
        };
    }
    constructor() {
        super();
        import('../icons/jha-icon-chevron-down.js');
        this.isOpen = false;
    }
    _toggleAccordion() {
        this.isOpen = !this.isOpen;
    }
    render() {
        return html `
      <div class="toggle">
        <jha-button
          sync
          icon
          @click="${this._toggleAccordion}">
          <slot name="toggle">
            <jha-icon-chevron-down></jha-icon-chevron-down>
          </slot>
        </jha-button>
      </div>
      <header>
        <slot name="header"></slot>
      </header>
      <article>
        <slot name="body"></slot>
      </article>
    `;
    }
}
export { styles as JhaAccordionStyles };
