import JhaAccordion from './JhaAccordion.js';
customElements.define('jha-accordion', JhaAccordion);
/** @customElement jha-accordion */
export default JhaAccordion;
