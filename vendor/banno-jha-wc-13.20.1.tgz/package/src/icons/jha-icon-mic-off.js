import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-mic-off
 * @customElement jha-icon-mic-off
 */
export default class JhaIconMicOff extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="m20.678 20.678.707-.707-3.952-3.952c.802-1.182 1.317-2.813 1.317-5.019v-1a.75.75 0 0 0-1.5 0v1c0 1.777-.37 3.036-.903 3.932l-.9-.9c.351-.595.553-1.29.553-2.032V6a4 4 0 0 0-8 0v.586L4.414 3l-.707.707 16.97 16.97ZM14.5 6v6c0 .322-.061.63-.172.914L9.5 8.086V6a2.5 2.5 0 0 1 5 0Z"/>   <path d="M9.5 10.914 8 9.414V12a4 4 0 0 0 6.032 3.446l-1.118-1.118A2.5 2.5 0 0 1 9.5 12v-1.086Z"/>   <path d="M14.975 16.389c-1.008.674-2.161.861-2.975.861-.898 0-2.21-.228-3.281-1.086C7.679 15.333 6.75 13.817 6.75 11v-1a.75.75 0 0 0-1.5 0v1c0 3.183 1.071 5.167 2.532 6.336 1.133.906 2.43 1.265 3.468 1.374v1.79h-2.5a.75.75 0 0 0 0 1.5h6.5a.75.75 0 0 0 0-1.5h-2.5v-1.79c.987-.104 2.209-.433 3.3-1.245l-1.075-1.076Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-mic-off', JhaIconMicOff);
