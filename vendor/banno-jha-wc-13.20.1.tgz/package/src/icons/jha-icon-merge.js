import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-merge
 * @customElement jha-icon-merge
 */
export default class JhaIconMerge extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M13.336 11.01a.75.75 0 0 0 1.046.176l.041-.03c.588-.418 1.31-.933 1.867-1.714.588-.825.96-1.894.96-3.382V5.001a.75.75 0 0 0-1.5 0V6.06c0 1.216-.297 1.971-.681 2.511-.403.565-.936.95-1.558 1.394a.75.75 0 0 0-.175 1.046Zm-.586 5.68 1.22-1.22a.75.75 0 1 1 1.06 1.06l-2.5 2.5a.75.75 0 0 1-1.06 0l-2.5-2.5a.75.75 0 1 1 1.06-1.06l1.22 1.22v-3.13c0-.684-.21-1.106-.516-1.456-.287-.325-.646-.582-1.102-.908l-.323-.232c-.579-.42-1.238-.943-1.738-1.729-.51-.799-.821-1.813-.821-3.175v-.919a.75.75 0 1 1 1.5 0v.919c0 1.119.251 1.844.586 2.37.343.537.809.924 1.355 1.32.084.062.173.125.264.19.462.328.993.706 1.405 1.174.537.61.89 1.38.89 2.446v3.13Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-merge', JhaIconMerge);
