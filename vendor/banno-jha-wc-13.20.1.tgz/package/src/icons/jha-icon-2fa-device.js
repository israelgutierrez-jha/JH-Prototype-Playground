import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-2fa-device
 * @customElement jha-icon-2fa-device
 */
export default class JhaIcon2faDevice extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M11.004 3h-1.25a1.75 1.75 0 0 0-1.75 1.75v9.517a7.266 7.266 0 0 1 1.5 1.007V4.75a.25.25 0 0 1 .25-.25h1.25V3Zm6.75 18.5h-5.883a2.26 2.26 0 0 0 .129-.753c0-.252-.013-.501-.038-.747h5.792a.25.25 0 0 0 .25-.25V18.5h-6.359a7.208 7.208 0 0 0-.687-1.5h7.046V4.75a.25.25 0 0 0-.25-.25h-1.25V3h1.25c.966 0 1.75.784 1.75 1.75v15a1.75 1.75 0 0 1-1.75 1.75ZM4.75 17.997a.75.75 0 0 0 0 1.5c.69 0 1.25.56 1.25 1.25a.75.75 0 0 0 1.5 0 2.75 2.75 0 0 0-2.75-2.75ZM4 15.747a.75.75 0 0 1 .75-.75 5.75 5.75 0 0 1 5.75 5.75.75.75 0 0 1-1.5 0 4.25 4.25 0 0 0-4.25-4.25.75.75 0 0 1-.75-.75ZM14.254 7.25a.5.5 0 0 0-1 0v1.377l-1.187-.697a.5.5 0 0 0-.506.863l1.2.704-1.205.695a.5.5 0 0 0 .5.866l1.198-.692v1.384a.5.5 0 1 0 1 0v-1.377l1.188.697a.5.5 0 1 0 .506-.863l-1.2-.704 1.205-.695a.5.5 0 1 0-.5-.866l-1.199.692V7.25Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-2fa-device', JhaIcon2faDevice);
