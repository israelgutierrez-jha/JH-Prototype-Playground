import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-xperience
 * @customElement jha-icon-xperience
 */
export default class JhaIconXperience extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M19 4.001 3 7.891l9.37 2.74L15.11 20 19 4Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-xperience', JhaIconXperience);
