import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-lightbulb
 * @customElement jha-icon-lightbulb
 */
export default class JhaIconLightbulb extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12 3.75A5.25 5.25 0 0 0 6.75 9c0 2.333 1.504 4.588 3.5 5.293.3.106.5.39.5.707v1.24h2.5V15c0-.318.201-.6.5-.707 1.996-.705 3.5-2.96 3.5-5.293 0-2.9-2.35-5.25-5.25-5.25ZM5.25 9a6.75 6.75 0 1 1 13.5 0c0 2.707-1.608 5.398-4 6.504v1.487a.75.75 0 0 1-.75.75h-4a.75.75 0 0 1-.75-.75v-1.487c-2.391-1.105-4-3.796-4-6.504Zm4 10a.75.75 0 0 1 .75-.75h4a.75.75 0 0 1 0 1.5h-4a.75.75 0 0 1-.75-.75ZM11 20.25a.75.75 0 0 0 0 1.5h2a.75.75 0 0 0 0-1.5h-2Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-lightbulb', JhaIconLightbulb);
