import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-filter
 * @customElement jha-icon-filter
 */
export default class JhaIconFilter extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M6 7a2 2 0 1 1 4 0 2 2 0 0 1-4 0Zm-1.42.75H2.75a.75.75 0 1 1 0-1.5h1.83a3.501 3.501 0 0 1 6.84 0h9.83a.75.75 0 0 1 0 1.5h-9.83a3.501 3.501 0 0 1-6.84 0Zm16.67 10h-1.83a3.501 3.501 0 0 1-6.84 0H2.75a.75.75 0 1 1 0-1.5h9.83a3.501 3.501 0 0 1 6.84 0h1.83a.75.75 0 0 1 0 1.5ZM16 15a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-filter', JhaIconFilter);
