import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-location-off
 * @customElement jha-icon-location-off
 */
export default class JhaIconLocationOff extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3.323 3.323a.749.749 0 0 0 .147.208l16 16a.748.748 0 0 0 .207.146.75.75 0 0 1-1.207.854l-2.93-2.93a46.869 46.869 0 0 1-2.9 3.805l-.055.065-.015.017-.004.004-.001.002L12 21l-.565.494-.001-.002-.004-.004-.015-.017-.055-.065a42.936 42.936 0 0 1-.932-1.136 45.87 45.87 0 0 1-2.202-3.016c-.8-1.2-1.612-2.56-2.225-3.918C5.393 11.989 4.95 10.58 4.95 9.3c0-.683.105-1.352.3-1.989l-2.78-2.78a.75.75 0 0 1 .853-1.208Zm3.41 1.35 1.063 1.063C8.816 4.539 10.326 3.75 12 3.75c3.049 0 5.55 2.615 5.55 5.55 0 .97-.345 2.149-.918 3.418-.186.412-.393.827-.615 1.24l1.105 1.104a22.22 22.22 0 0 0 .877-1.726c.608-1.347 1.051-2.755 1.051-4.036 0-3.743-3.152-7.05-7.05-7.05-2.096 0-3.976.957-5.267 2.423Zm7.223 7.222A3.247 3.247 0 0 0 15.25 9.3 3.253 3.253 0 0 0 12 6.05c-1.06 0-2.001.509-2.595 1.295l1.08 1.08A1.752 1.752 0 0 1 12 7.55a1.75 1.75 0 0 1 .875 3.265l1.08 1.08ZM12 21l-.564.494.564.645.564-.645L12 21ZM6.45 9.3c0-.248.018-.494.053-.737l7.957 7.958A44.97 44.97 0 0 1 12 19.832a45.404 45.404 0 0 1-2.526-3.41c-.774-1.162-1.538-2.447-2.106-3.704-.573-1.27-.918-2.449-.918-3.418Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-location-off', JhaIconLocationOff);
