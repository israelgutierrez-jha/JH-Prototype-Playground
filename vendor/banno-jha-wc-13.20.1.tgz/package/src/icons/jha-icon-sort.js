import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-sort
 * @customElement jha-icon-sort
 */
export default class JhaIconSort extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M8.53 3.72 8 3.19l-.53.53-4 4a.75.75 0 0 0 1.06 1.061l2.72-2.72v9.19a.75.75 0 0 0 1.5 0V6.06l2.72 2.72a.75.75 0 1 0 1.06-1.06l-4-4Zm8.22 5.03a.75.75 0 0 0-1.5 0v9.19l-2.72-2.72a.75.75 0 1 0-1.06 1.061l4 4 .53.53.53-.53 4-4a.75.75 0 1 0-1.06-1.06l-2.72 2.72V8.75Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-sort', JhaIconSort);
