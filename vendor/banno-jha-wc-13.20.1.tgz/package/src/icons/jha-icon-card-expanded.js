import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-card-expanded
 * @customElement jha-icon-card-expanded
 */
export default class JhaIconCardExpanded extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3.25 4A.75.75 0 0 1 4 3.25h16a.75.75 0 0 1 .75.75v16a.75.75 0 0 1-.75.75H4a.75.75 0 0 1-.75-.75V4Zm1.5.75v14.5h14.5V4.75H4.75ZM6.25 7A.75.75 0 0 1 7 6.25h7a.75.75 0 0 1 0 1.5H7A.75.75 0 0 1 6.25 7ZM17 6.25a.75.75 0 0 0 0 1.5h.01a.75.75 0 0 0 0-1.5H17Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-card-expanded', JhaIconCardExpanded);
