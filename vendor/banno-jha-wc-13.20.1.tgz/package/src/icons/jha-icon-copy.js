import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-copy
 * @customElement jha-icon-copy
 */
export default class JhaIconCopy extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M4.5 4.25a.75.75 0 0 1 .75-.75h10a.75.75 0 0 1 .75.75V7h2.75a.75.75 0 0 1 .75.75v12a.75.75 0 0 1-.75.75h-10a.75.75 0 0 1-.75-.75V17H5.25a.75.75 0 0 1-.75-.75v-12ZM8 15.5V7.75A.75.75 0 0 1 8.75 7h5.75V5H6v10.5h2ZM9.5 19V8.5H18V19H9.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-copy', JhaIconCopy);
