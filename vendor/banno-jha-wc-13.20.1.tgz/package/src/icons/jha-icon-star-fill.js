import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-star-fill
 * @customElement jha-icon-star-fill
 */
export default class JhaIconStarFill extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"> <path d="M20.22,10.17a.75.75,0,0,0-.61-.53l-4.95-.72-2-4.24a.78.78,0,0,0-1.36,0l-2,4.24-4.95.72A.75.75,0,0,0,4,10.95l3.71,3.28L7,18.88a.75.75,0,0,0,1.11.77L12,17.47l3.92,2.19A.75.75,0,0,0,17,18.88l-.74-4.66L20,10.95A.75.75,0,0,0,20.22,10.17Z"/> </svg>
    `;
    }
}
customElements.define('jha-icon-star-fill', JhaIconStarFill);
