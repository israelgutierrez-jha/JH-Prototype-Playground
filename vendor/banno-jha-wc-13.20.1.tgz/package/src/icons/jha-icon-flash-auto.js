import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-flash-auto
 * @customElement jha-icon-flash-auto
 */
export default class JhaIconFlashAuto extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M11.582 2.287A.75.75 0 0 1 12.1 3v7.35h3.75a.75.75 0 0 1 .607 1.191l-7.2 9.9a.75.75 0 0 1-1.357-.44v-7.35H4.15a.75.75 0 0 1-.607-1.192l7.2-9.9a.75.75 0 0 1 .839-.272Zm-5.96 9.863H8.65a.75.75 0 0 1 .75.75v5.794l4.977-6.844H11.35a.75.75 0 0 1-.75-.75V5.307L5.623 12.15Zm11.228 1.1c.3 0 .571.179.69.455l3 7a.75.75 0 0 1-1.38.59l-.662-1.545h-3.296l-.663 1.546a.75.75 0 0 1-1.378-.591l3-7a.75.75 0 0 1 .689-.455Zm-1.005 5h2.01l-1.005-2.346-1.005 2.346Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-flash-auto', JhaIconFlashAuto);
