import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-square-checkmark
 * @customElement jha-icon-square-checkmark
 */
export default class JhaIconSquareCheckmark extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Zm0 1.5a.5.5 0 0 0-.5.5v14a.5.5 0 0 0 .5.5h14a.5.5 0 0 0 .5-.5V5a.5.5 0 0 0-.5-.5H5Zm11.268 4.483a.75.75 0 0 1 0 1.06l-4.95 4.95a.534.534 0 0 1-.025.026.75.75 0 0 1-1.06 0l-2.5-2.5a.75.75 0 1 1 1.06-1.061l1.97 1.97 4.444-4.445a.75.75 0 0 1 1.06 0Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-square-checkmark', JhaIconSquareCheckmark);
