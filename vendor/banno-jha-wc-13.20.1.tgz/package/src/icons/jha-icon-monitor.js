import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-monitor
 * @customElement jha-icon-monitor
 */
export default class JhaIconMonitor extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="m12 2.14.368.207 8 4.5.382.215V7.5c0 6.425-2.064 10.016-4.246 11.994a9.607 9.607 0 0 1-2.984 1.855c-.41.158-.756.255-1.004.314a5.345 5.345 0 0 1-.382.076l-.026.004h-.009l-.003.001h-.002L12 21c-.093.745-.094.744-.094.744H11.9l-.009-.001-.026-.004a5.345 5.345 0 0 1-.382-.076 7.826 7.826 0 0 1-1.004-.314 9.608 9.608 0 0 1-2.984-1.855C5.314 17.516 3.25 13.925 3.25 7.5v-.438l.382-.215 8-4.5L12 2.14ZM12 21l.093.745-.093.011-.093-.011L12 21Zm0-.76a6.332 6.332 0 0 0 .98-.291 8.108 8.108 0 0 0 2.516-1.567c1.774-1.607 3.66-4.654 3.75-10.445L12 3.861 4.753 7.937c.09 5.79 1.977 8.838 3.75 10.445a8.107 8.107 0 0 0 2.517 1.567 6.332 6.332 0 0 0 .98.291Zm-.096.017ZM12 18.7V12H6.72C7.89 17.17 11 18.43 12 18.7Zm5.28-6.7H12V5.58l5.71 3.22a18.64 18.64 0 0 1-.43 3.2Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-monitor', JhaIconMonitor);
