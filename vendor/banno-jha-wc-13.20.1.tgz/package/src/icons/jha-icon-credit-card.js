import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-credit-card
 * @customElement jha-icon-credit-card
 */
export default class JhaIconCreditCard extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3.875 7.25a.25.25 0 0 0-.25.25v1.75h16.5V7.5a.25.25 0 0 0-.25-.25h-16Zm-.25 9.25v-4.25h16.5v4.25a.25.25 0 0 1-.25.25h-16a.25.25 0 0 1-.25-.25Zm-1.5-9c0-.966.784-1.75 1.75-1.75h16c.966 0 1.75.784 1.75 1.75v9a1.75 1.75 0 0 1-1.75 1.75h-16a1.75 1.75 0 0 1-1.75-1.75v-9Zm3.5 6.75h-.5v1h8v-1h-7.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-credit-card', JhaIconCreditCard);
