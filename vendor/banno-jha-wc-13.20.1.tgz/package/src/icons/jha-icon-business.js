import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-business
 * @customElement jha-icon-business
 */
export default class JhaIconBusiness extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M5.25 3.875a.75.75 0 0 1 .75-.75h12a.75.75 0 0 1 .75.75v15.25H20a.75.75 0 0 1 0 1.5H4a.75.75 0 0 1 0-1.5h1.25V3.875Zm1.5 15.25h1.5v-4h7.5v4h1.5v-14.5H6.75v14.5Zm7.5 0v-2.5h-4.5v2.5h4.5ZM9 10.875h2v-2H9v2Zm6 0h-2v-2h2v2Zm-6-3h2v-2H9v2Zm6 0h-2v-2h2v2Zm-6 6h2v-2H9v2Zm6 0h-2v-2h2v2Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-business', JhaIconBusiness);
