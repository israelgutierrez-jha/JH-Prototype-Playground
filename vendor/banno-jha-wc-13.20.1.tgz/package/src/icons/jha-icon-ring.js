import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-ring
 * @customElement jha-icon-ring
 */
export default class JhaIconRing extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M19.5 14.5a7.503 7.503 0 0 0-5.024-7.081l1.853-2.256.302-.367-.202-.429-.912-1.936-.203-.43H8.685l-.203.43-.91 1.936-.202.43.3.366 1.854 2.256A7.5 7.5 0 1 0 19.5 14.5ZM9.13 4.578l2.03 2.47a7.581 7.581 0 0 1 1.68 0l2.03-2.47-.507-1.076H9.637L9.13 4.577ZM12 8.5a6 6 0 1 0 0 12 6 6 0 0 0 0-12Zm-3.25 6a3.25 3.25 0 1 1 6.5 0 3.25 3.25 0 0 1-6.5 0ZM12 9.75a4.75 4.75 0 1 0 0 9.5 4.75 4.75 0 0 0 0-9.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-ring', JhaIconRing);
