import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-saved-reply
 * @customElement jha-icon-saved-reply
 */
export default class JhaIconSavedReply extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M6 2.25a.75.75 0 0 0-.75.75v18a.75.75 0 0 0 1.28.53L12 16.062l5.47 5.47a.75.75 0 0 0 1.28-.53V3a.75.75 0 0 0-.75-.75H6Zm.75 5v-3.5h10.5v3.5H6.75Zm0 1.5v10.44l4.72-4.72a.75.75 0 0 1 1.06 0l4.72 4.72V8.75H6.75Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-saved-reply', JhaIconSavedReply);
