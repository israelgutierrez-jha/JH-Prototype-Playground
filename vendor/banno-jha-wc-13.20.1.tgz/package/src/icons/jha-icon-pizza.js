import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-pizza
 * @customElement jha-icon-pizza
 */
export default class JhaIconPizza extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M10.53 2.392a1.5 1.5 0 0 0-2.226.23 2.24 2.24 0 0 0-.107 2.461l-5.86 15.624a.75.75 0 0 0 1.004.95l15.615-6.831c.71.409 1.6.415 2.327-.014a1.5 1.5 0 0 0 .247-2.4l-11-10.02Zm7.15 11.355L9.357 6.26l-.651 1.737a2 2 0 1 1-1.214 3.238l-3.127 8.336 2.408-1.053a2 2 0 1 1 3.263-1.427l7.644-3.345ZM9.625 4.484A.74.74 0 0 1 9.52 3.5l.544.495L19.949 13l.57.52a.81.81 0 0 1-.953-.095L9.625 4.484Zm3.415 6.487a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-pizza', JhaIconPizza);
