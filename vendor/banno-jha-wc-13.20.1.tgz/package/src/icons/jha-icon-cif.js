import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-cif
 * @customElement jha-icon-cif
 */
export default class JhaIconCif extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M4 7.25a.75.75 0 0 0-.75.75v8c0 .414.336.75.75.75h4.75v-1.5h-4v-6.5h4v-1.5H4Zm8.75.75v-.75h-1.5v9.5h1.5V8Zm2.5 0a.75.75 0 0 1 .75-.75h4.75v1.5h-4v2.5h3v1.5h-3v4h-1.5V8Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-cif', JhaIconCif);
