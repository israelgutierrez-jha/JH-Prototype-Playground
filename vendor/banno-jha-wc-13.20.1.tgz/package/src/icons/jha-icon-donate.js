import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-donate
 * @customElement jha-icon-donate
 */
export default class JhaIconDonate extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3 6.25a.75.75 0 0 0-.75.75v10c0 .414.336.75.75.75h18a.75.75 0 0 0 .75-.75V7a.75.75 0 0 0-.75-.75H3Zm.75 8.271V9.48a1.504 1.504 0 0 0 1.729-1.73h13.042a1.504 1.504 0 0 0 1.729 1.73v5.042a1.504 1.504 0 0 0-1.729 1.729H5.479a1.504 1.504 0 0 0-1.729-1.729Zm11.85-3.764C15.6 12.715 12 15 12 15s-3.6-2.285-3.6-4.243c0-2.285 3.6-2.285 3.6-.326 0-1.959 3.6-1.959 3.6.326Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-donate', JhaIconDonate);
