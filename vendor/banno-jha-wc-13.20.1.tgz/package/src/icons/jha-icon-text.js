import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-text
 * @customElement jha-icon-text
 */
export default class JhaIconText extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M14.25 5.626H9v-1.5h12v1.5h-5.25v14.25h-1.5V5.626Zm-6.5 6H11v-1.5H3v1.5h3.25v8.25h1.5v-8.25Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-text', JhaIconText);
