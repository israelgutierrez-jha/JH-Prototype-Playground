import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-card-normal
 * @customElement jha-icon-card-normal
 */
export default class JhaIconCardNormal extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3.25 6.5A.75.75 0 0 1 4 5.75h16a.75.75 0 0 1 .75.75v11a.75.75 0 0 1-.75.75H4a.75.75 0 0 1-.75-.75v-11Zm1.5.75v9.5h14.5v-9.5H4.75Zm1.5 2.25A.75.75 0 0 1 7 8.75h7a.75.75 0 0 1 0 1.5H7a.75.75 0 0 1-.75-.75ZM17 8.75a.75.75 0 0 0 0 1.5h.01a.75.75 0 0 0 0-1.5H17Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-card-normal', JhaIconCardNormal);
