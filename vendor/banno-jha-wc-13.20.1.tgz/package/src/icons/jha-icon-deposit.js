import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-deposit
 * @customElement jha-icon-deposit
 */
export default class JhaIconDeposit extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M9 3.25a.75.75 0 0 0-.007 1.5H9l.058.005a2.317 2.317 0 0 1 1.026.37C10.6 5.467 11.25 6.218 11.25 8v6.19l-2.72-2.72a.75.75 0 1 0-1.06 1.06l4 4 .53.53.53-.53 4-4a.75.75 0 0 0-1.06-1.06l-2.72 2.72V8c0-2.218-.85-3.468-1.834-4.124A3.817 3.817 0 0 0 9.2 3.261a2.652 2.652 0 0 0-.175-.01H9V4v-.75Zm-6 11a.75.75 0 0 1 .75.75v3.045c0 .403.117.736.268.949.152.215.292.256.367.256h15.23c.075 0 .215-.041.367-.256.151-.213.268-.546.268-.95V15a.75.75 0 0 1 1.5 0v3.045c0 .676-.193 1.321-.544 1.816-.348.493-.9.89-1.59.89H4.384c-.69 0-1.242-.397-1.59-.89-.35-.495-.544-1.14-.544-1.816V15a.75.75 0 0 1 .75-.75Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-deposit', JhaIconDeposit);
