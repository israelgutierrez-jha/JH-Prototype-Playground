import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-cap
 * @customElement jha-icon-cap
 */
export default class JhaIconCap extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M11.593 4.327a.75.75 0 0 1 .656-.003l9.327 4.495a.75.75 0 0 1 .001 1.35l-.327.159v4.922a.75.75 0 0 1-1.5 0v-4.195l-1.5.728v4.967c0 .611-.326 1.101-.72 1.457-.393.355-.913.637-1.478.855-1.133.44-2.602.688-4.052.688-1.45 0-2.92-.248-4.052-.688-.565-.218-1.086-.5-1.478-.855-.394-.356-.72-.846-.72-1.457V11.8l-3.33-1.626a.75.75 0 0 1 0-1.347l9.173-4.5Zm.694 10.348 4.463-2.165v4.24c0 .04-.017.156-.226.345-.208.188-.547.388-1.014.569-.93.36-2.21.586-3.51.586-1.3 0-2.58-.226-3.51-.586-.467-.181-.806-.38-1.014-.57-.208-.188-.226-.304-.226-.344v-4.216l4.38 2.14a.75.75 0 0 0 .657 0Zm-.36-8.841L4.455 9.499l7.505 3.667 7.566-3.67-7.6-3.662Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-cap', JhaIconCap);
