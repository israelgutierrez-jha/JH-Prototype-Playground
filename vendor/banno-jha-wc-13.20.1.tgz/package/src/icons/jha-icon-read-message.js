import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-read-message
 * @customElement jha-icon-read-message
 */
export default class JhaIconReadMessage extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M6.75 2.938a.75.75 0 0 0-.75.75v4.1L2.649 9.65a.752.752 0 0 0-.399.663v10c0 .414.336.75.75.75h18a.75.75 0 0 0 .75-.75v-10a.747.747 0 0 0-.399-.663L18 7.788v-4.1a.75.75 0 0 0-.75-.75H6.75ZM18 9.504v1.618l1.456-.809L18 9.504Zm-1.5 2.451V4.438h-9v7.517l4.5 2.5 4.5-2.5ZM6 11.122V9.504l-1.456.81L6 11.121Zm14.25.466-7.886 4.38a.75.75 0 0 1-.728 0l-7.886-4.38v7.975h16.5v-7.975Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-read-message', JhaIconReadMessage);
