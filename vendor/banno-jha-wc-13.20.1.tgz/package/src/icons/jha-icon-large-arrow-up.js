import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-large-arrow-up
 * @customElement jha-icon-large-arrow-up
 */
export default class JhaIconLargeArrowUp extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12.53 6.47 12 5.94l-.53.53-4 4a.75.75 0 1 0 1.06 1.06l2.72-2.719v9.19a.75.75 0 0 0 1.5 0V8.81l2.72 2.72a.75.75 0 1 0 1.06-1.061l-4-4Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-large-arrow-up', JhaIconLargeArrowUp);
