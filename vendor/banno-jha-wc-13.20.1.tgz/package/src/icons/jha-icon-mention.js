import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-mention
 * @customElement jha-icon-mention
 */
export default class JhaIconMention extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12 2.25c-5.385 0-9.75 4.366-9.75 9.75A9.75 9.75 0 0 0 12 21.75V21v.75h.043c.024 0 .06 0 .105-.002a13.802 13.802 0 0 0 1.583-.13c.463-.066.98-.168 1.46-.328.466-.156.97-.39 1.34-.76a.75.75 0 1 0-1.061-1.06c-.13.13-.377.271-.754.397a7.03 7.03 0 0 1-1.197.266 12.29 12.29 0 0 1-1.493.117H12A8.25 8.25 0 1 1 20.25 12c0 1.093-.325 1.852-.757 2.356a2.709 2.709 0 0 1-1.616.905c-.601.1-1.163-.009-1.548-.244-.363-.222-.579-.554-.579-1.017V8a.75.75 0 0 0-1.5 0v.375c-.729-.696-1.679-1.125-2.75-1.125-2.438 0-4.25 2.224-4.25 4.75s1.812 4.75 4.25 4.75c1.235 0 2.31-.57 3.07-1.463.23.421.57.762.976 1.01.74.452 1.678.593 2.577.443a4.208 4.208 0 0 0 2.509-1.408c.693-.808 1.118-1.925 1.118-3.332 0-5.384-4.365-9.75-9.75-9.75ZM14.25 12c0-1.892-1.322-3.25-2.75-3.25S8.75 10.108 8.75 12s1.322 3.25 2.75 3.25 2.75-1.358 2.75-3.25Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-mention', JhaIconMention);
