import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-code
 * @customElement jha-icon-code
 */
export default class JhaIconCode extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M8.03 8.53a.75.75 0 0 0-1.06-1.06l-4 4a.75.75 0 0 0 0 1.06l4 4a.75.75 0 0 0 1.06-1.06L4.56 12l3.47-3.47Zm9-1.06a.75.75 0 1 0-1.06 1.06L19.44 12l-3.47 3.47a.75.75 0 0 0 1.06 1.06l4-4a.75.75 0 0 0 0-1.06l-4-4Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-code', JhaIconCode);
