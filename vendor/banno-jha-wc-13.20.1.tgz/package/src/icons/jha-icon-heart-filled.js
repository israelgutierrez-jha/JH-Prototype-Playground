import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-heart-filled
 * @customElement jha-icon-heart-filled
 */
export default class JhaIconHeartFilled extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M7.737 3.248a5.323 5.323 0 0 0-5.323 5.323c0 4.742 2.354 8.036 4.666 10.12a17.99 17.99 0 0 0 3.17 2.274 15.717 15.717 0 0 0 1.355.68l.084.036.024.01.007.003h.002l.001.001.277-.697-.276.697a.75.75 0 0 0 .552 0L12 20.998l.277.697.003-.001.007-.003.024-.01.084-.035a15.32 15.32 0 0 0 1.354-.681 17.99 17.99 0 0 0 3.171-2.275c2.312-2.083 4.666-5.378 4.666-10.119a5.323 5.323 0 0 0-5.323-5.323A5.305 5.305 0 0 0 12 5.39a5.306 5.306 0 0 0-4.263-2.142Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-heart-filled', JhaIconHeartFilled);
