import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-usb-drive
 * @customElement jha-icon-usb-drive
 */
export default class JhaIconUsbDrive extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <g fill-rule="evenodd">     <path d="M8.363 7.608A.75.75 0 0 1 8.75 7.5h6.5a.75.75 0 0 1 .387.108l1.25.752a.75.75 0 0 1 .363.643v8.338C17.25 20.01 14.797 22 12 22s-5.25-1.99-5.25-4.659V9.003a.75.75 0 0 1 .363-.643l1.25-.752ZM8.958 9l-.708.427v7.914C8.25 18.99 9.826 20.5 12 20.5s3.75-1.51 3.75-3.159V9.427L15.042 9H8.958Z"/>     <path d="M12 16.25a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5ZM9.75 17a2.25 2.25 0 1 1 4.5 0 2.25 2.25 0 0 1-4.5 0ZM8 2.75A.75.75 0 0 1 8.75 2h6.5a.75.75 0 0 1 .75.75v5.5a.75.75 0 0 1-.75.75h-6.5A.75.75 0 0 1 8 8.25v-5.5Zm1.5.75v4h5v-4h-5Z"/>     <path d="M13.985 6h-1.5V4.5h1.5V6Zm-2.482 0h-1.5V4.5h1.5V6Z"/>   </g> </svg> 
    `;
    }
}
customElements.define('jha-icon-usb-drive', JhaIconUsbDrive);
