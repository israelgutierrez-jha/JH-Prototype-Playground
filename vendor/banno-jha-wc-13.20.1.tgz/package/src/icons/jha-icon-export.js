import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-export
 * @customElement jha-icon-export
 */
export default class JhaIconExport extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12.53 4.47 12 3.94l-.53.53-4 4a.75.75 0 0 0 1.06 1.06l2.72-2.72V16a.75.75 0 0 0 1.5 0V6.81l2.72 2.72a.75.75 0 1 0 1.06-1.06l-4-4ZM3.25 20a.75.75 0 0 1 .75-.75h16a.75.75 0 0 1 0 1.5H4a.75.75 0 0 1-.75-.75Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-export', JhaIconExport);
