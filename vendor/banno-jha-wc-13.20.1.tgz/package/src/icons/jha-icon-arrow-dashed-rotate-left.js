import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-arrow-dashed-rotate-left
 * @customElement jha-icon-arrow-dashed-rotate-left
 */
export default class JhaIconArrowDashedRotateLeft extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path d="M20.75 12a8.75 8.75 0 0 0-15-6.123V4a.75.75 0 0 0-1.5 0v4.75H9a.75.75 0 0 0 0-1.5H6.522A7.25 7.25 0 0 1 19.25 12a.75.75 0 0 0 1.5 0Zm-1.54 3.549a.75.75 0 0 0-1.031.246 7.273 7.273 0 0 1-.807 1.074.75.75 0 1 0 1.111 1.007c.363-.4.689-.833.973-1.295a.75.75 0 0 0-.245-1.032ZM5.15 16.2A.75.75 0 0 0 5 17.252c.296.394.624.761.98 1.1a.75.75 0 1 0 1.032-1.09 7.291 7.291 0 0 1-.813-.91.75.75 0 0 0-1.05-.15Zm9.063 3.527a.75.75 0 0 0-.875-.6 7.293 7.293 0 0 1-2.556.021.75.75 0 1 0-.25 1.48 8.807 8.807 0 0 0 3.081-.026.75.75 0 0 0 .6-.875Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-arrow-dashed-rotate-left', JhaIconArrowDashedRotateLeft);
