import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-login
 * @customElement jha-icon-login
 */
export default class JhaIconLogin extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M9.334 4.75a.583.583 0 0 0-.584.584V7a.75.75 0 0 1-1.5 0V5.334c0-1.15.933-2.084 2.084-2.084h8.332c1.151 0 2.084.933 2.084 2.084v13.333c0 1.15-.933 2.083-2.084 2.083H9.334a2.083 2.083 0 0 1-2.084-2.083V17a.75.75 0 0 1 1.5 0v1.667c0 .322.261.583.584.583h8.332a.583.583 0 0 0 .584-.583V5.334a.583.583 0 0 0-.584-.584H9.334Zm1.136 2.72a.75.75 0 0 1 1.06 0l4 4 .53.53-.53.53-4 4a.75.75 0 1 1-1.06-1.06l2.72-2.72H3a.75.75 0 0 1 0-1.5h10.19l-2.72-2.72a.75.75 0 0 1 0-1.06Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-login', JhaIconLogin);
