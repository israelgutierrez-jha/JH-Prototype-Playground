import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-home
 * @customElement jha-icon-home
 */
export default class JhaIconHome extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M11.506 4.436a.75.75 0 0 1 .988 0l3.256 2.849V6h2v3h-.04l2.784 2.436a.75.75 0 1 1-.988 1.129l-.756-.662v7.347H20a.75.75 0 0 1 0 1.5H4a.75.75 0 0 1 0-1.5h1.25v-7.347l-.756.662a.75.75 0 1 1-.988-1.13l8-7ZM6.75 19.25h2.5V13a.75.75 0 0 1 .75-.75h4a.75.75 0 0 1 .75.75v6.25h2.5v-8.66L12 5.998 6.75 10.59v8.66Zm6.5 0v-5.5h-2.5v5.5h2.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-home', JhaIconHome);
