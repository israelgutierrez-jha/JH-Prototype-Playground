import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-transactions
 * @customElement jha-icon-transactions
 */
export default class JhaIconTransactions extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M19.5 8.501a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM15 6.251a.75.75 0 0 1 0 1.5H4a.75.75 0 0 1 0-1.5h11Zm.75 5.75a.75.75 0 0 0-.75-.75H4a.75.75 0 0 0 0 1.5h11a.75.75 0 0 0 .75-.75Zm3.75 1.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Zm-3.75 3.5a.75.75 0 0 0-.75-.75H4a.75.75 0 0 0 0 1.5h11a.75.75 0 0 0 .75-.75Zm3.75 1.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-transactions', JhaIconTransactions);
