import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-warning
 * @customElement jha-icon-warning
 */
export default class JhaIconWarning extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12.598 5.067c-.26-.422-.937-.422-1.197 0L7.61 11.226l-3.773 6.127c-.211.343.006.897.599.897h15.13c.593 0 .81-.554.6-.897l-3.774-6.128L12.6 5.067Zm1.278-.786c-.845-1.374-2.906-1.374-3.752 0l-3.792 6.158-3.773 6.128c-.903 1.465.257 3.183 1.876 3.183h15.13c1.619 0 2.78-1.718 1.876-3.183l-3.773-6.128-3.792-6.158ZM12 7.25a.75.75 0 0 1 .75.75v4a.75.75 0 0 1-1.5 0V8a.75.75 0 0 1 .75-.75Zm0 7.25a1 1 0 1 0 0 2 1 1 0 0 0 0-2Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-warning', JhaIconWarning);
