import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-marketing
 * @customElement jha-icon-marketing
 */
export default class JhaIconMarketing extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12 2.25a.75.75 0 0 1 .75.75v1.286a7.752 7.752 0 0 1 6.964 6.964H21a.75.75 0 0 1 0 1.5h-1.286a7.752 7.752 0 0 1-6.964 6.965V21a.75.75 0 0 1-1.5 0v-1.285a7.752 7.752 0 0 1-6.964-6.965H3a.75.75 0 0 1 0-1.5h1.286a7.752 7.752 0 0 1 6.964-6.964V3a.75.75 0 0 1 .75-.75Zm.75 15.956V18a.75.75 0 0 0-1.5 0v.206a6.253 6.253 0 0 1-5.455-5.456H6a.75.75 0 0 0 0-1.5h-.205a6.253 6.253 0 0 1 5.455-5.455V6a.75.75 0 0 0 1.5 0v-.205a6.253 6.253 0 0 1 5.456 5.455H18a.75.75 0 0 0 0 1.5h.206a6.253 6.253 0 0 1-5.456 5.456ZM12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-marketing', JhaIconMarketing);
