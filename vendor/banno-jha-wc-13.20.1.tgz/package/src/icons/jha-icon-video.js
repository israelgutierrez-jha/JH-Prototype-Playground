import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-video
 * @customElement jha-icon-video
 */
export default class JhaIconVideo extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M15 6.5H4a.5.5 0 0 0-.5.5v10a.5.5 0 0 0 .5.5h11a.5.5 0 0 0 .5-.5V7a.5.5 0 0 0-.5-.5ZM17 17v-1.615l1.643 1.517c1.282 1.182 3.357.273 3.357-1.47V8.568c0-1.744-2.075-2.652-3.357-1.47L17 8.615V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2Zm.16-3.508a.5.5 0 0 1-.16-.368v-2.248a.5.5 0 0 1 .16-.368l2.5-2.307a.5.5 0 0 1 .84.367v6.864a.5.5 0 0 1-.84.367l-2.5-2.307ZM13.25 10.5a.75.75 0 0 0 0-1.5h-4.5a.75.75 0 0 0 0 1.5h4.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-video', JhaIconVideo);
