import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-transfer-filled
 * @customElement jha-icon-transfer-filled
 */
export default class JhaIconTransferFilled extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="m19.53 7.531.53-.53-.53-.53-4-4a.75.75 0 0 0-1.28.53v3.25H9c-2.218 0-3.468.85-4.124 1.834a3.817 3.817 0 0 0-.615 1.716 2.655 2.655 0 0 0-.01.175v.015l-.001.006V10l.75.001h-.75a.75.75 0 0 0 1.5.007v-.007l.004-.058a2.317 2.317 0 0 1 .37-1.026C6.468 8.401 7.218 7.751 9 7.751h5.25v3.25a.75.75 0 0 0 1.28.53l4-4Zm-.53 5.72a.75.75 0 0 1 .75.75H19l.75.001v.024a1.9 1.9 0 0 1-.011.175 3.815 3.815 0 0 1-.615 1.716c-.656.984-1.906 1.834-4.124 1.834H9.75v3.25a.75.75 0 0 1-1.28.53l-4-4-.53-.53.53-.53 4-4a.75.75 0 0 1 1.28.53v3.25H15c1.782 0 2.532-.65 2.876-1.166a2.319 2.319 0 0 0 .374-1.084v-.007a.75.75 0 0 1 .75-.743Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-transfer-filled', JhaIconTransferFilled);
