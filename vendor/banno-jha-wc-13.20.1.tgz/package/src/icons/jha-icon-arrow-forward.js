import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-arrow-forward
 * @customElement jha-icon-arrow-forward
 */
export default class JhaIconArrowForward extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12.53 4.47a.75.75 0 1 0-1.06 1.06l5.72 5.72H5a.75.75 0 0 0 0 1.5h12.19l-5.72 5.72a.75.75 0 1 0 1.06 1.06l7-7a.75.75 0 0 0 0-1.06l-7-7Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-arrow-forward', JhaIconArrowForward);
