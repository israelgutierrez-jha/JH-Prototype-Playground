import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-fi
 * @customElement jha-icon-fi
 */
export default class JhaIconFi extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M11.584 3.376a.75.75 0 0 1 .832 0l7.5 5A.75.75 0 0 1 19.5 9.75h-2.25v5.5h1.25a.75.75 0 0 1 0 1.5h-13a.75.75 0 1 1 0-1.5h1.25v-5.5H4.5a.75.75 0 0 1-.416-1.374l7.5-5ZM15.75 9.75v5.5h-1.5v-5.5h1.5Zm-3 0v5.5h-1.5v-5.5h1.5Zm-3 0v5.5h-1.5v-5.5h1.5Zm6.75-1.5h.523L12 4.902 6.977 8.25H16.5Zm-12 9.5a.75.75 0 0 0 0 1.5h15a.75.75 0 1 0 0-1.5h-15Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-fi', JhaIconFi);
