import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-assets
 * @customElement jha-icon-assets
 */
export default class JhaIconAssets extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M4.75 5A.25.25 0 0 1 5 4.75h14a.25.25 0 0 1 .25.25v9.19l-2.72-2.72-.53-.53-.53.53-1.97 1.97-3.97-3.97L9 8.94l-.53.53-3.72 3.72V5Zm0 10.31L9 11.06l3.44 3.44-4.75 4.75H5a.25.25 0 0 1-.25-.25v-3.69Zm5.06 3.94L16 13.06l3.25 3.25V19a.25.25 0 0 1-.25.25H9.81ZM8 20.75H5A1.75 1.75 0 0 1 3.25 19V5c0-.966.784-1.75 1.75-1.75h14c.966 0 1.75.784 1.75 1.75v14A1.75 1.75 0 0 1 19 20.75H8Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-assets', JhaIconAssets);
