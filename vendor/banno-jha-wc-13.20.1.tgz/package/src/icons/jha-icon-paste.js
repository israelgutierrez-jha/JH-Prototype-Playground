import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-paste
 * @customElement jha-icon-paste
 */
export default class JhaIconPaste extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M10.25 2c-.74 0-1.387.402-1.732 1H7.25a.75.75 0 0 0-.707.5H5.75A1.75 1.75 0 0 0 4 5.25v11c0 .966.784 1.75 1.75 1.75H9v3.25c0 .414.336.75.75.75h10a.75.75 0 0 0 .75-.75v-12a.75.75 0 0 0-.75-.75H16.5V5.25a1.75 1.75 0 0 0-1.75-1.75h-.793a.75.75 0 0 0-.707-.5h-1.268c-.345-.598-.991-1-1.732-1ZM15 8.5V5.25a.25.25 0 0 0-.25-.25H14v1.75a.75.75 0 0 1-.75.75h-6a.75.75 0 0 1-.75-.75V5h-.75a.25.25 0 0 0-.25.25v11c0 .138.112.25.25.25H9V9.25a.75.75 0 0 1 .75-.75H15ZM9.76 3.9a.5.5 0 0 1 .98 0c.07.349.378.6.735.6H12.5V6H8V4.5h1.025a.75.75 0 0 0 .735-.6Zm.74 16.6V10H19v10.5h-8.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-paste', JhaIconPaste);
