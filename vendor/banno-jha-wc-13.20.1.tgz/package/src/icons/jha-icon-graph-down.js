import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-graph-down
 * @customElement jha-icon-graph-down
 */
export default class JhaIconGraphDown extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3.905 5.845a.75.75 0 1 0-1.06 1.06l6 6a.75.75 0 0 0 1.06 0l2.47-2.469 6.44 6.44h-4.19a.75.75 0 0 0 0 1.5h6.75v-6.75a.75.75 0 0 0-1.5 0v4.189l-6.97-6.97a.75.75 0 0 0-1.06 0l-2.47 2.47-5.47-5.47Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-graph-down', JhaIconGraphDown);
