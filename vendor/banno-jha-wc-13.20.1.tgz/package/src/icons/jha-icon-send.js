import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-send
 * @customElement jha-icon-send
 */
export default class JhaIconSend extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="m4.534 4.609 14.773 7.39-14.773 7.39 2.723-6.12 10.993-1.268-10.992-1.269L4.534 4.61Zm1.646 7.39-3.87 8.7a.76.76 0 0 0 .17.84.73.73 0 0 0 .85.13l17.99-9a.744.744 0 0 0 .43-.67.744.744 0 0 0-.43-.67l-17.99-9a.75.75 0 0 0-1.02.97L6.18 12Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-send', JhaIconSend);
