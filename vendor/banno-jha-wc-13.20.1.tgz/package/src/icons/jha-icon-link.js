import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-link
 * @customElement jha-icon-link
 */
export default class JhaIconLink extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M15.359 5.46a2.259 2.259 0 0 1 3.182 0 2.259 2.259 0 0 1 0 3.182l-4.243 4.242a2.259 2.259 0 0 1-3.182 0 .75.75 0 0 0-1.06 1.06 3.759 3.759 0 0 0 5.303 0L19.6 9.703a3.759 3.759 0 0 0 0-5.303 3.76 3.76 0 0 0-5.303 0l-2.12 2.12a.75.75 0 1 0 1.06 1.06l2.122-2.12Zm-5.657 5.656a2.259 2.259 0 0 1 3.182 0 .75.75 0 0 0 1.06-1.06 3.759 3.759 0 0 0-5.303 0L4.4 14.298a3.759 3.759 0 0 0 0 5.304 3.759 3.759 0 0 0 5.303 0l2.121-2.122a.75.75 0 0 0-1.06-1.06L8.64 18.54a2.259 2.259 0 0 1-3.182 0 2.259 2.259 0 0 1 0-3.182l4.243-4.243Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-link', JhaIconLink);
