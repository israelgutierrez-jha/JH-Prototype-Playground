import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-checkmark
 * @customElement jha-icon-checkmark
 */
export default class JhaIconCheckmark extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M19.959 7.53a.75.75 0 0 0-1.06-1.06l-9.47 9.47-3.47-3.47a.75.75 0 0 0-1.06 1.06l4 4a.751.751 0 0 0 1.06 0"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-checkmark', JhaIconCheckmark);
