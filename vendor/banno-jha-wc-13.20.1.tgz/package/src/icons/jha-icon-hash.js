import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-hash
 * @customElement jha-icon-hash
 */
export default class JhaIconHash extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="m11.895 4.5-.04.196-.735 3.68h3.21l.775-3.876h2.04l-.04.196-.735 3.68h2.355l-.4 2H15.97l-.65 3.25h2.355l-.4 2H14.92l-.775 3.874h-2.04l.04-.196.735-3.679H9.67L8.895 19.5h-2.04l.04-.196.735-3.679H5.275l.4-2H8.03l.65-3.25H6.325l.4-2H9.08L9.855 4.5h2.04Zm-1.825 9.125.65-3.25h3.21l-.65 3.25h-3.21Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-hash', JhaIconHash);
