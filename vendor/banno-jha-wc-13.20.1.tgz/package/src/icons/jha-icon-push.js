import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-push
 * @customElement jha-icon-push
 */
export default class JhaIconPush extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M9 4.75a.25.25 0 0 0-.25.25v10.524a7.261 7.261 0 0 0-1.5-1.006V5c0-.967.784-1.75 1.75-1.75h8c.966 0 1.75.783 1.75 1.75v15A1.75 1.75 0 0 1 17 21.75h-5.883c.083-.236.129-.49.129-.753 0-.253-.013-.502-.038-.747H17a.25.25 0 0 0 .25-.25v-1.25h-6.36a7.213 7.213 0 0 0-.687-1.5h7.047V5a.25.25 0 0 0-.25-.25H9ZM3.246 18.999a.75.75 0 0 1 .75-.75 2.75 2.75 0 0 1 2.75 2.75.75.75 0 1 1-1.5 0c0-.69-.56-1.25-1.25-1.25a.75.75 0 0 1-.75-.75Zm.75-3.75a.75.75 0 0 0 0 1.5 4.25 4.25 0 0 1 4.25 4.25.75.75 0 1 0 1.5 0 5.75 5.75 0 0 0-5.75-5.75Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-push', JhaIconPush);
