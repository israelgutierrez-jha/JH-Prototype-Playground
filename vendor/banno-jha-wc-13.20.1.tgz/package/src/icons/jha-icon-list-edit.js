import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-list-edit
 * @customElement jha-icon-list-edit
 */
export default class JhaIconListEdit extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M17.487 5.32a.75.75 0 0 0-.997.363l-4.17 8.942a.75.75 0 0 0-.061.43l.467 3.059a.75.75 0 0 0 1.131.527l2.643-1.607a.749.749 0 0 0 .29-.324l4.17-8.942a.75.75 0 0 0-.363-.997l-3.11-1.45Zm-3.711 9.734 3.756-8.057 1.751.816-3.757 8.057-1.487.905-.263-1.721ZM10 6h4.963l-.933 2H10a1 1 0 1 1 0-2Zm0 5h2.632l-.933 2H10a1 1 0 1 1 0-2Zm0 5h1.139l.305 2H10a1 1 0 1 1 0-2ZM5 8.5h1a1 1 0 0 0 1-1v-1a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1Zm1 5H5a1 1 0 0 1-1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1Zm-1 5h1a1 1 0 0 0 1-1v-1a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-list-edit', JhaIconListEdit);
