import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-pie-chart
 * @customElement jha-icon-pie-chart
 */
export default class JhaIconPieChart extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M13.875 2.25a.75.75 0 0 0-.75.75v7a.75.75 0 0 0 .75.75h7a.75.75 0 0 0 .75-.75 7.75 7.75 0 0 0-7.75-7.75Zm.75 7V3.797A6.25 6.25 0 0 1 20.08 9.25h-5.455ZM7.097 6.973a7.25 7.25 0 0 1 3.278-1.183v7.212a.75.75 0 0 0 .75.75h7.211a7.25 7.25 0 1 1-11.239-6.78Zm4.028-2.721a8.75 8.75 0 1 0 8.75 8.75.75.75 0 0 0-.75-.75h-7.25V5a.75.75 0 0 0-.75-.75Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-pie-chart', JhaIconPieChart);
