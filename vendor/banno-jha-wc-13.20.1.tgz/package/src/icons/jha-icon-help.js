import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-help
 * @customElement jha-icon-help
 */
export default class JhaIconHelp extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12 3.75a8.25 8.25 0 1 0 0 16.5 8.25 8.25 0 0 0 0-16.5ZM2.25 12c0-5.384 4.365-9.75 9.75-9.75s9.75 4.366 9.75 9.75c0 5.385-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12Zm8.51-3.84c-.296.247-.51.618-.51 1.174a.75.75 0 0 1-1.5 0c0-1 .411-1.795 1.052-2.327.624-.518 1.427-.757 2.198-.757.753 0 1.545.21 2.168.674A2.644 2.644 0 0 1 15.25 9.1c0 1.39-.844 2.281-1.495 2.874-.138.125-.258.23-.367.324a6.707 6.707 0 0 0-.454.42c-.15.157-.18.23-.184.243v1.04a.75.75 0 0 1-1.5 0v-1.05c0-.569.337-.993.598-1.267.177-.186.413-.393.628-.58v-.001c.096-.084.188-.165.27-.239.598-.545 1.004-1.053 1.004-1.764 0-.446-.187-.755-.48-.974-.315-.235-.773-.376-1.27-.376-.479 0-.926.15-1.24.41ZM12 17.5a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-help', JhaIconHelp);
