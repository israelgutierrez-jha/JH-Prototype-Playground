import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-vault
 * @customElement jha-icon-vault
 */
export default class JhaIconVault extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3.25 4.001a.75.75 0 0 1 .75-.75h16a.75.75 0 0 1 .75.75v3H22v3h-1.25v4H22v3h-1.25v3a.75.75 0 0 1-.75.75h-1v1.25h-3v-1.25H8v1.25H5v-1.25H4a.75.75 0 0 1-.75-.75v-16Zm1.5.75v14.5h14.5v-14.5H4.75Zm9.25 5.5a1.75 1.75 0 1 0 0 3.5 1.75 1.75 0 0 0 0-3.5Zm-3.25 1.75a3.25 3.25 0 1 1 6.5 0 3.25 3.25 0 0 1-6.5 0Zm-2-2.5a.75.75 0 1 0-1.5 0v5a.75.75 0 0 0 1.5 0v-5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-vault', JhaIconVault);
