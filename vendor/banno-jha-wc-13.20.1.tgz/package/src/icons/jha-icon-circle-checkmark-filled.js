import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-circle-checkmark-filled
 * @customElement jha-icon-circle-checkmark-filled
 */
export default class JhaIconCircleCheckmarkFilled extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12Zm13.755-3.005a.75.75 0 0 1 0 1.06l-4.95 4.95-.015.015-.01.01a.75.75 0 0 1-1.06 0l-2.5-2.5a.75.75 0 0 1 1.06-1.06l1.97 1.97 4.444-4.445a.75.75 0 0 1 1.061 0Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-circle-checkmark-filled', JhaIconCircleCheckmarkFilled);
