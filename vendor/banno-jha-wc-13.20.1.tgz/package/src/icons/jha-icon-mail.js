import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-mail
 * @customElement jha-icon-mail
 */
export default class JhaIconMail extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3 5.25a.75.75 0 0 0-.75.75v12c0 .415.336.75.75.75h18a.75.75 0 0 0 .75-.75V6a.75.75 0 0 0-.75-.75H3Zm17.25 2.31v-.81H3.75v.809L12 12.142l8.25-4.583ZM3.75 9.275v7.975h16.5V9.275l-7.886 4.38a.75.75 0 0 1-.728 0L3.75 9.276Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-mail', JhaIconMail);
