import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-star-empty
 * @customElement jha-icon-star-empty
 */
export default class JhaIconStarEmpty extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12 4.25a.75.75 0 0 1 .68.433l1.98 4.242 4.948.718a.75.75 0 0 1 .389 1.304l-3.71 3.278.74 4.658a.75.75 0 0 1-1.107.773L12 17.468l-3.92 2.188a.75.75 0 0 1-1.106-.773l.739-4.658-3.71-3.278a.75.75 0 0 1 .39-1.304l4.947-.718 1.98-4.242a.75.75 0 0 1 .68-.432Zm0 2.523-1.472 3.154a.75.75 0 0 1-.572.425l-3.746.543 2.805 2.479a.75.75 0 0 1 .244.68l-.562 3.54 2.938-1.64a.75.75 0 0 1 .73 0l2.938 1.64-.562-3.54a.75.75 0 0 1 .244-.68l2.806-2.479-3.747-.543a.75.75 0 0 1-.572-.425L12 6.773Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-star-empty', JhaIconStarEmpty);
