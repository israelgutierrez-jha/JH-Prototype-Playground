import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-large-arrow-left
 * @customElement jha-icon-large-arrow-left
 */
export default class JhaIconLargeArrowLeft extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M11.53 8.53a.75.75 0 0 0-1.06-1.06l-4 4-.53.53.53.53 4 4a.75.75 0 1 0 1.06-1.06l-2.72-2.72H18a.75.75 0 0 0 0-1.5H8.81l2.72-2.72Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-large-arrow-left', JhaIconLargeArrowLeft);
