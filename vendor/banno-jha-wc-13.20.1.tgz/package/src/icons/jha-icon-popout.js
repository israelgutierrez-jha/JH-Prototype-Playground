import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-popout
 * @customElement jha-icon-popout
 */
export default class JhaIconPopout extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M13.658 3.922a.75.75 0 0 0 0 1.5h3.846l-6.548 6.548a.75.75 0 1 0 1.06 1.06l6.548-6.547v3.846a.75.75 0 0 0 1.5 0V3.922h-6.406ZM3.236 7a.75.75 0 0 1 .75-.75h6a.75.75 0 1 1 0 1.5h-5.25v11.5h11.5V15a.75.75 0 1 1 1.5 0v5a.75.75 0 0 1-.75.75h-13a.75.75 0 0 1-.75-.75V7Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-popout', JhaIconPopout);
