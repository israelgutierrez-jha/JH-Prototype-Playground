import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-expand
 * @customElement jha-icon-expand
 */
export default class JhaIconExpand extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12.53 3.47a.75.75 0 0 0-1.06 0l-4 4a.75.75 0 0 0 1.06 1.06L12 5.06l3.47 3.47a.75.75 0 1 0 1.06-1.06l-4-4Zm-4 12a.75.75 0 0 0-1.06 1.06l4 4a.75.75 0 0 0 1.06 0l4-4a.75.75 0 1 0-1.06-1.06L12 18.94l-3.47-3.47Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-expand', JhaIconExpand);
