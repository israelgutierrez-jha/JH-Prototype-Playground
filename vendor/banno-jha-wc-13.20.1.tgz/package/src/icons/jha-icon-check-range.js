import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-check-range
 * @customElement jha-icon-check-range
 */
export default class JhaIconCheckRange extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M1.5 6a.75.75 0 0 1 .75-.75h16.5a.75.75 0 0 1 .75.75v2.25h2.25a.75.75 0 0 1 .75.75v9a.75.75 0 0 1-.75.75H5.25A.75.75 0 0 1 4.5 18v-2.25H2.25A.75.75 0 0 1 1.5 15V6Zm3 8.25V9a.75.75 0 0 1 .75-.75H18v-1.5H3v7.5h1.5Zm1.5 3v-7.5h15v7.5H6Zm1.5-5.5h12v1h-12v-1Zm6 2.5H13v1h6.5v-1h-6Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-check-range', JhaIconCheckRange);
