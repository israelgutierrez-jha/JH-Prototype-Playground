import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-receipt
 * @customElement jha-icon-receipt
 */
export default class JhaIconReceipt extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M6 2.25a.75.75 0 0 0-.75.75v18a.75.75 0 0 0 1.166.625L9 19.902l2.584 1.723a.75.75 0 0 0 .832 0L15 19.902l2.584 1.723A.75.75 0 0 0 18.75 21V3a.75.75 0 0 0-.75-.75H6Zm.75 17.35V3.75h10.5V19.6l-1.834-1.223a.75.75 0 0 0-.832 0L12 20.099l-2.584-1.722a.75.75 0 0 0-.832 0L6.75 19.599ZM8.5 6.25a.75.75 0 0 0 0 1.5h7a.75.75 0 0 0 0-1.5h-7ZM7.75 11a.75.75 0 0 1 .75-.75h7a.75.75 0 0 1 0 1.5h-7a.75.75 0 0 1-.75-.75Zm.75 3.25a.75.75 0 0 0 0 1.5h7a.75.75 0 0 0 0-1.5h-7Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-receipt', JhaIconReceipt);
