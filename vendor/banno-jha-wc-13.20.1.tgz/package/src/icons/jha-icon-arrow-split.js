import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-arrow-split
 * @customElement jha-icon-arrow-split
 */
export default class JhaIconArrowSplit extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12 4.5a.75.75 0 0 1 .75.75h-1.5A.75.75 0 0 1 12 4.5Zm5.245 12.445c-.043-1.218-.344-2.183-.793-2.989-.48-.86-1.112-1.503-1.686-2.047-.09-.087-.18-.17-.265-.251l-.001-.001c-1.055-.993-1.75-1.647-1.75-2.907v-3.5h-1.5v3.5c0 1.26-.695 1.914-1.75 2.907a85.34 85.34 0 0 0-.266.252c-.574.544-1.206 1.188-1.686 2.047-.45.806-.75 1.771-.793 2.989L5.53 15.72a.75.75 0 0 0-1.06 1.06l2.5 2.5a.75.75 0 0 0 1.06 0l2.5-2.5a.75.75 0 1 0-1.06-1.06l-1.213 1.212c.043-.954.279-1.667.601-2.245.364-.652.857-1.167 1.408-1.69.097-.092.196-.184.298-.278.488-.454 1.02-.947 1.436-1.557.417.61.948 1.103 1.436 1.556l.298.279c.55.523 1.044 1.038 1.408 1.69.322.578.558 1.29.601 2.245L14.53 15.72a.75.75 0 1 0-1.06 1.06l2.5 2.5a.75.75 0 0 0 1.06 0l2.5-2.5a.75.75 0 1 0-1.06-1.06l-1.225 1.225Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-arrow-split', JhaIconArrowSplit);
