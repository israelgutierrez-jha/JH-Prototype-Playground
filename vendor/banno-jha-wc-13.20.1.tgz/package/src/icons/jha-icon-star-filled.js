import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-star-filled
 * @customElement jha-icon-star-filled
 */
export default class JhaIconStarFilled extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12.68 4.684a.75.75 0 0 0-1.36 0L9.34 8.925l-4.948.718a.75.75 0 0 0-.389 1.304l3.71 3.278-.74 4.659a.75.75 0 0 0 1.107.772L12 17.468l3.92 2.188a.75.75 0 0 0 1.106-.772l-.739-4.659 3.71-3.277a.75.75 0 0 0-.39-1.305l-4.947-.718-1.98-4.241Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-star-filled', JhaIconStarFilled);
