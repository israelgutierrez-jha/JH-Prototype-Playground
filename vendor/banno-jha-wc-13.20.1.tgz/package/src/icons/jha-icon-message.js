import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-message
 * @customElement jha-icon-message
 */
export default class JhaIconMessage extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M4 3.25A1.75 1.75 0 0 0 2.25 5v16.56l1.219-.974 4.794-3.836H20A1.75 1.75 0 0 0 21.75 15V5A1.75 1.75 0 0 0 20 3.25H4ZM3.75 5A.25.25 0 0 1 4 4.75h16a.25.25 0 0 1 .25.25v10a.25.25 0 0 1-.25.25H7.737l-.206.165L3.75 18.44V5ZM8 11a1 1 0 1 0 0-2 1 1 0 0 0 0 2Zm5-1a1 1 0 1 1-2 0 1 1 0 0 1 2 0Zm3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-message', JhaIconMessage);
