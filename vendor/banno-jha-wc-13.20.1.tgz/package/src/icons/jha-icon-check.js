import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-check
 * @customElement jha-icon-check
 */
export default class JhaIconCheck extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M2.25 7.5A.75.75 0 0 1 3 6.75h18a.75.75 0 0 1 .75.75v9a.75.75 0 0 1-.75.75H3a.75.75 0 0 1-.75-.75v-9Zm1.5.75v7.5h16.5v-7.5H3.75ZM5 10h14v1H5v-1Zm6 3h-.5v1H19v-1h-8Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-check', JhaIconCheck);
