import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-tutorial
 * @customElement jha-icon-tutorial
 */
export default class JhaIconTutorial extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M14.794 3.81a.746.746 0 0 0-.29-.059h-.012a.746.746 0 0 0-.388.113l-4.67 2.802-4.655-1.861A.75.75 0 0 0 3.75 5.5v12a.75.75 0 0 0 .471.696l4.985 1.994a.747.747 0 0 0 .294.06h.01a.747.747 0 0 0 .386-.113l4.67-2.803 4.655 1.862a.75.75 0 0 0 1.029-.696v-12a.75.75 0 0 0-.471-.696L14.794 3.81ZM13.75 5.827l-3.5 2.1v10.25l3.5-2.1V5.826Zm1.5 10.167V5.61l3.5 1.4v10.384l-3.5-1.4Zm-10-9.384 3.5 1.4v10.384l-3.5-1.4V6.61Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-tutorial', JhaIconTutorial);
