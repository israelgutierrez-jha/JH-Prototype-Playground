import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-briefcase
 * @customElement jha-icon-briefcase
 */
export default class JhaIconBriefcase extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M9 6.5h6V5H9v1.5Zm7.5 0V4.25a.75.75 0 0 0-.75-.75h-7.5a.75.75 0 0 0-.75.75V6.5H3.75a.75.75 0 0 0-.75.75v12c0 .414.336.75.75.75h16.5a.75.75 0 0 0 .75-.75v-12a.75.75 0 0 0-.75-.75H16.5Zm-6.75 5.453L4.5 10.7v7.8h15v-7.793L14.25 12v1.25a.75.75 0 0 1-.75.75h-3a.75.75 0 0 1-.75-.75v-1.297Zm0-1.542L4.5 9.158V8h15v1.162l-5.25 1.293v-.205a.75.75 0 0 0-.75-.75h-3a.75.75 0 0 0-.75.75v.16Zm1.5 2.089V11h1.5v1.5h-1.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-briefcase', JhaIconBriefcase);
