import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-transfer
 * @customElement jha-icon-transfer
 */
export default class JhaIconTransfer extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="m20.06 7.001-.53.53-4 4a.75.75 0 1 1-1.06-1.06l2.72-2.72H9c-1.782 0-2.532.65-2.876 1.166a2.317 2.317 0 0 0-.374 1.084v.007a.75.75 0 0 1-1.5-.007H5L4.25 10v-.024a1.91 1.91 0 0 1 .011-.175 3.817 3.817 0 0 1 .615-1.716C5.532 7.1 6.782 6.25 9 6.25h8.19l-2.72-2.72a.75.75 0 0 1 1.06-1.06l4 4 .53.53Zm-.31 7a.75.75 0 0 0-1.5-.007v.007l-.004.058a2.32 2.32 0 0 1-.37 1.026c-.344.516-1.095 1.166-2.876 1.166H6.81l2.72-2.72a.75.75 0 0 0-1.06-1.06l-4 4-.53.53.53.53 4 4a.75.75 0 1 0 1.06-1.06l-2.72-2.72H15c2.218 0 3.468-.85 4.124-1.834a3.815 3.815 0 0 0 .624-1.849 1.9 1.9 0 0 0 .002-.042v-.024l-.75-.001h.75Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-transfer', JhaIconTransfer);
