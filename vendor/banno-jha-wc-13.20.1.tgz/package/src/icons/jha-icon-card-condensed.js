import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-card-condensed
 * @customElement jha-icon-card-condensed
 */
export default class JhaIconCardCondensed extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3.25 8.5A.75.75 0 0 1 4 7.75h16a.75.75 0 0 1 .75.75v7a.75.75 0 0 1-.75.75H4a.75.75 0 0 1-.75-.75v-7Zm1.5.75v5.5h14.5v-5.5H4.75Zm1.5 2.25a.75.75 0 0 1 .75-.75h7a.75.75 0 0 1 0 1.5H7a.75.75 0 0 1-.75-.75ZM17 10.75a.75.75 0 0 0 0 1.5h.01a.75.75 0 0 0 0-1.5H17Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-card-condensed', JhaIconCardCondensed);
