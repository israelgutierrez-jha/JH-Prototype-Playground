import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-action
 * @customElement jha-icon-action
 */
export default class JhaIconAction extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="m12 2.107.507.465 3 2.753a.75.75 0 0 1-1.014 1.106l-1.743-1.6v9.044a.75.75 0 0 1-1.5 0V4.831l-1.743 1.6a.75.75 0 0 1-1.014-1.106l3-2.753.507-.465ZM7 9.625a.25.25 0 0 0-.25.25v10c0 .138.112.25.25.25h10a.25.25 0 0 0 .25-.25v-10a.25.25 0 0 0-.25-.25h-2.008a.75.75 0 0 1 0-1.5H17c.966 0 1.75.784 1.75 1.75v10a1.75 1.75 0 0 1-1.75 1.75H7a1.75 1.75 0 0 1-1.75-1.75v-10c0-.966.784-1.75 1.75-1.75h2.012a.75.75 0 0 1 0 1.5H7Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-action', JhaIconAction);
