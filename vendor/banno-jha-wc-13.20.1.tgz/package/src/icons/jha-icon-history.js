import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-history
 * @customElement jha-icon-history
 */
export default class JhaIconHistory extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M5.748 8.25a7.275 7.275 0 0 1 6.228-3.5c4.02 0 7.274 3.25 7.274 7.25A7.241 7.241 0 0 1 12 19.25c-3.582 0-6.366-2.72-7.288-5.487a.75.75 0 0 0-1.423.475C4.366 17.47 7.63 20.75 12 20.75A8.741 8.741 0 0 0 20.75 12c0-4.834-3.93-8.75-8.774-8.75A8.772 8.772 0 0 0 4.75 7.035V5a.75.75 0 1 0-1.5 0v4.75H8a.75.75 0 1 0 0-1.5H5.748Zm6.252-1a.75.75 0 0 1 .75.75v3.6l2.666 1.777a.75.75 0 1 1-.832 1.248l-3-2-.334-.222V8a.75.75 0 0 1 .75-.75Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-history', JhaIconHistory);
