import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-delete
 * @customElement jha-icon-delete
 */
export default class JhaIconDelete extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M9 3.25a.75.75 0 0 0-.75.75v2.25H5a.75.75 0 0 0 0 1.5h.75V19c0 1.032.897 1.75 1.85 1.75h8.8c.953 0 1.85-.718 1.85-1.75V7.75H19a.75.75 0 0 0 0-1.5h-3.25V4a.75.75 0 0 0-.75-.75H9Zm5.25 3v-1.5h-4.5v1.5h4.5ZM9 7.75H7.25V19c0 .044.018.099.077.152.06.054.154.098.273.098h8.8a.405.405 0 0 0 .273-.098c.059-.053.077-.108.077-.152V7.75H9ZM10.75 10a.75.75 0 0 0-1.5 0v7a.75.75 0 0 0 1.5 0v-7ZM14 9.25a.75.75 0 0 1 .75.75v7a.75.75 0 0 1-1.5 0v-7a.75.75 0 0 1 .75-.75Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-delete', JhaIconDelete);
