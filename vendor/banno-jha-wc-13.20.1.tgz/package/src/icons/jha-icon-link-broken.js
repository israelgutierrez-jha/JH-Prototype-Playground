import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-link-broken
 * @customElement jha-icon-link-broken
 */
export default class JhaIconLinkBroken extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path d="M19.85 4.149c-.87-.87-2.319-.865-3.199.014l-2.744 2.74a2.311 2.311 0 0 0-.654 1.723l-1.249 1.248a3.8 3.8 0 0 1 .83-4.02l.01-.008 2.747-2.744c1.456-1.455 3.854-1.48 5.32-.014 1.465 1.465 1.443 3.862-.014 5.318l-.934.935-1.811 1.812a3.762 3.762 0 0 1-4.024.84l1.247-1.246a2.252 2.252 0 0 0 1.716-.655l1.81-1.81.935-.936c.88-.88.885-2.327.014-3.197Zm-9.973 7.853a3.795 3.795 0 0 0-4.036.85l-2.748 2.744-.008.008c-1.43 1.474-1.466 3.826.008 5.299a3.76 3.76 0 0 0 5.309 0l1.81-1.812.935-.935a3.79 3.79 0 0 0 .851-4.033l-1.25 1.251c.03.62-.191 1.252-.661 1.722h-.001l-.934.935-1.81 1.81a2.26 2.26 0 0 1-3.189 0c-.871-.87-.872-2.28.004-3.188l2.744-2.74a2.28 2.28 0 0 1 1.725-.66l1.25-1.251Zm.373-7.752a.75.75 0 1 0-1.5 0v1.5a.75.75 0 1 0 1.5 0v-1.5Zm-4.97-.03a.75.75 0 1 0-1.06 1.06l1.5 1.5a.75.75 0 0 0 1.06-1.06l-1.5-1.5Zm14.47 9.53h-1.5a.75.75 0 0 0 0 1.5h1.5a.75.75 0 0 0 0-1.5Zm-1.03 6.03a.75.75 0 1 0 1.06-1.06l-1.5-1.5a.75.75 0 1 0-1.06 1.06l1.5 1.5Zm-4.22.72a.75.75 0 0 1-.75-.75v-1.5a.75.75 0 0 1 1.5 0v1.5a.75.75 0 0 1-.75.75ZM5.75 10.25h-1.5a.75.75 0 1 1 0-1.5h1.5a.75.75 0 1 1 0 1.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-link-broken', JhaIconLinkBroken);
