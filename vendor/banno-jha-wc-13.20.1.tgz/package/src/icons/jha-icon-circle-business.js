import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-circle-business
 * @customElement jha-icon-circle-business
 */
export default class JhaIconCircleBusiness extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3.75 12a8.25 8.25 0 1 1 14.614 5.25H17.5V6.5h-11v10.75h-.864A8.216 8.216 0 0 1 3.75 12Zm3.505 6.75A8.212 8.212 0 0 0 12 20.25a8.212 8.212 0 0 0 4.745-1.5h-9.49ZM8 17.25h1.25v-3h5.5v3H16V8H8v9.25Zm5.25 0v-1.5h-2.5v1.5h2.5ZM12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25ZM11 9H9.5v1.455H11V9Zm-1.5 2.5H11V13H9.5v-1.5Zm5-2.5H13v1.455h1.5V9ZM13 11.5h1.5V13H13v-1.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-circle-business', JhaIconCircleBusiness);
