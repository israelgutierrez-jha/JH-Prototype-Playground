import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-remove-tag
 * @customElement jha-icon-remove-tag
 */
export default class JhaIconRemoveTag extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M7.512 6.931 3.93 11.573l-.016.02-.017.02a.584.584 0 0 0 0 .775l.017.02.016.02 3.582 4.642c.11.115.263.18.422.18H20a.25.25 0 0 0 .25-.25V7a.25.25 0 0 0-.25-.25H7.934a.583.583 0 0 0-.422.181ZM6.377 5.95c.396-.445.962-.7 1.557-.7H20c.966 0 1.75.784 1.75 1.75v10A1.75 1.75 0 0 1 20 18.75H7.934a2.084 2.084 0 0 1-1.557-.698l-.017-.02-.016-.02-3.587-4.65a2.084 2.084 0 0 1 0-2.723l3.587-4.65.016-.02.017-.02ZM9.47 8.47a.75.75 0 0 1 1.06 0L13 10.94l2.47-2.47a.75.75 0 0 1 1.06 1.06L14.06 12l2.47 2.47a.75.75 0 1 1-1.06 1.06L13 13.062l-2.47 2.47a.75.75 0 0 1-1.06-1.06L11.94 12 9.47 9.53a.75.75 0 0 1 0-1.06Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-remove-tag', JhaIconRemoveTag);
