import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-2fa
 * @customElement jha-icon-2fa
 */
export default class JhaIcon2fa extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12.368 2.346 12 2.14l-.368.207-8 4.5-.382.215V7.5c0 6.425 2.064 10.016 4.246 11.993a9.608 9.608 0 0 0 2.984 1.855 7.9 7.9 0 0 0 1.004.315 5.345 5.345 0 0 0 .382.075l.026.004.009.001h.003l.002.001L12 21l-.093.744.093.012.093-.012L12 21l.094.744h.005l.009-.002.026-.004a5.345 5.345 0 0 0 .382-.076 7.826 7.826 0 0 0 1.004-.314 9.607 9.607 0 0 0 2.984-1.855c2.182-1.977 4.246-5.568 4.246-11.993v-.439l-.382-.215-8-4.5Zm-.197 17.857L12 20.24a6.332 6.332 0 0 1-.98-.291 8.107 8.107 0 0 1-2.516-1.567c-1.774-1.608-3.66-4.655-3.75-10.445L12 3.86l7.247 4.076c-.09 5.79-1.977 8.837-3.75 10.445a8.108 8.108 0 0 1-2.517 1.567c-.34.13-.62.209-.809.254Zm-.267.053Zm4.1-11.261a.75.75 0 0 1 .001 1.06l-4.95 4.95-.015.015-.01.01a.75.75 0 0 1-1.06 0l-2.5-2.5a.75.75 0 1 1 1.06-1.06l1.97 1.97 4.444-4.445a.75.75 0 0 1 1.06 0Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-2fa', JhaIcon2fa);
