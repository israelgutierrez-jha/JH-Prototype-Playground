import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-clock
 * @customElement jha-icon-clock
 */
export default class JhaIconClock extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3.75 12a8.25 8.25 0 1 1 16.5 0 8.25 8.25 0 0 1-16.5 0ZM12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25ZM12.75 8a.75.75 0 0 0-1.5 0v4c0 .25.125.485.334.624l3 2a.75.75 0 0 0 .832-1.248L12.75 11.6V8Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-clock', JhaIconClock);
