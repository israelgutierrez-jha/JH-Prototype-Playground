import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-nt
 * @customElement jha-icon-nt
 */
export default class JhaIconNt extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3.763 7.414a.75.75 0 0 1 .837.261l4.65 6.2v-6.5h1.5v8.75a.75.75 0 0 1-1.35.45l-4.65-6.2v6.5h-1.5v-8.75a.75.75 0 0 1 .513-.711ZM16.25 8.875v8h1.5v-8h3v-1.5h-7.5v1.5h3Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-nt', JhaIconNt);
