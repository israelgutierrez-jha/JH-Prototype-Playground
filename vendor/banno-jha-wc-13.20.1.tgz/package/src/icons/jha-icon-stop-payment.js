import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-stop-payment
 * @customElement jha-icon-stop-payment
 */
export default class JhaIconStopPayment extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3.25 7.001a.75.75 0 0 1 .75-.75h16a.75.75 0 0 1 .75.75v2.316a5.997 5.997 0 0 0-1.5-.88v-.686H4.75v7.5h6.38c.113.53.294 1.032.536 1.5H4a.75.75 0 0 1-.75-.75v-9Zm3.25 2.5h6.531a6.028 6.028 0 0 0-.905 1H6v-1h.5Zm2 2.5h2.841a5.95 5.95 0 0 0-.258 1H8v-1h.5Zm5.25 2a3.25 3.25 0 1 1 6.5 0 3.25 3.25 0 0 1-6.5 0ZM17 9.251a4.75 4.75 0 1 0 0 9.5 4.75 4.75 0 0 0 0-9.5Zm-1.643 3.107a.555.555 0 0 1 .786 0l.857.857.857-.857a.555.555 0 1 1 .786.786l-.857.857.857.857a.556.556 0 0 1-.786.786L17 14.787l-.857.857a.556.556 0 0 1-.786-.786l.857-.857-.857-.857a.556.556 0 0 1 0-.786Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-stop-payment', JhaIconStopPayment);
