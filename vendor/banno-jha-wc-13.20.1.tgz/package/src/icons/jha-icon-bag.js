import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-bag
 * @customElement jha-icon-bag
 */
export default class JhaIconBag extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M16.495 6.413a4.5 4.5 0 0 0-8.995.212v.75H4.286a.75.75 0 0 0-.746.676l-1.123 11.35a2.252 2.252 0 0 0 2.241 2.474h14.688a2.248 2.248 0 0 0 2.237-2.47L20.46 8.051a.75.75 0 0 0-.746-.676H16.5v-.75l-.005-.212ZM15 8.875v1.75l.007.102a.75.75 0 0 0 1.493-.102v-1.75h2.535l1.056 10.678a.748.748 0 0 1-.745.822H4.658l-.1-.007a.753.753 0 0 1-.649-.82L4.965 8.876H7.5v1.75l.007.102A.75.75 0 0 0 9 10.625v-1.75h6Zm0-1.5v-.75a3 3 0 0 0-5.995-.176L9 6.625v.75h6Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-bag', JhaIconBag);
