import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-inbox
 * @customElement jha-icon-inbox
 */
export default class JhaIconInbox extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M6.7 5.25h-.408l-.222.343-3.7 5.728-.12.186V16.5A2.756 2.756 0 0 0 5 19.25h14a2.756 2.756 0 0 0 2.75-2.75v-4.993l-.12-.186-3.7-5.728-.222-.343H6.7Zm13.099 6-2.907-4.5H7.108l-2.907 4.5H9a.75.75 0 0 1 .75.75A2.259 2.259 0 0 0 12 14.25 2.259 2.259 0 0 0 14.25 12a.75.75 0 0 1 .75-.75h4.799ZM3.75 12.75h4.576c.35 1.708 1.867 3 3.674 3a3.762 3.762 0 0 0 3.674-3h4.576v3.75c0 .686-.564 1.25-1.25 1.25H5c-.686 0-1.25-.564-1.25-1.25v-3.75Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-inbox', JhaIconInbox);
