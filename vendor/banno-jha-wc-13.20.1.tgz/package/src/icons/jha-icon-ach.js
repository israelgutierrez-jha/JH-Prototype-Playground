import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-ach
 * @customElement jha-icon-ach
 */
export default class JhaIconAch extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M8.5 2.25a.75.75 0 0 1 .687.45l3.5 8a.75.75 0 1 1-1.374.6l-.679-1.55H6.366l-.679 1.55a.75.75 0 0 1-1.374-.6l3.5-8a.75.75 0 0 1 .687-.45Zm-1.478 6h2.956L8.5 4.871 7.022 8.25Zm7.508 4.22a.75.75 0 1 0-1.06 1.06l2.72 2.72H9.5c-1.11 0-1.808-.254-2.252-.548a2.193 2.193 0 0 1-.825-.993.75.75 0 1 0-1.383.58 3.693 3.693 0 0 0 1.379 1.663c.735.488 1.737.798 3.081.798h6.69l-2.72 2.72a.75.75 0 1 0 1.06 1.06l4-4 .53-.53-.53-.53-4-4Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-ach', JhaIconAch);
