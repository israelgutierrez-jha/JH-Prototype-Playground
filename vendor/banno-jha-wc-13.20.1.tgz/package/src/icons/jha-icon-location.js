import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-location
 * @customElement jha-icon-location
 */
export default class JhaIconLocation extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12 2.25c-3.898 0-7.05 3.307-7.05 7.05 0 1.281.443 2.69 1.05 4.036.614 1.358 1.425 2.717 2.226 3.918a46.234 46.234 0 0 0 3.134 4.152l.055.065.015.017.004.004v.002h.001L12 21l-.565.494.565.645.564-.645L12 21l.565.494.001-.002.004-.004.015-.017.055-.065a42.61 42.61 0 0 0 .932-1.136c.6-.756 1.4-1.813 2.202-3.016.8-1.2 1.612-2.56 2.225-3.918.608-1.347 1.051-2.755 1.051-4.036 0-3.743-3.152-7.05-7.05-7.05Zm.396 17.09c-.145.183-.278.348-.396.492a44.762 44.762 0 0 1-2.526-3.41c-.775-1.162-1.538-2.447-2.106-3.704-.573-1.27-.918-2.449-.918-3.418 0-2.935 2.501-5.55 5.55-5.55s5.55 2.615 5.55 5.55c0 .97-.345 2.149-.918 3.418-.568 1.257-1.332 2.542-2.106 3.704a44.759 44.759 0 0 1-2.13 2.917ZM10.25 9.3c0-.964.786-1.75 1.75-1.75s1.75.786 1.75 1.75c0 .965-.786 1.75-1.75 1.75s-1.75-.785-1.75-1.75ZM12 6.05A3.253 3.253 0 0 0 8.75 9.3 3.253 3.253 0 0 0 12 12.55a3.253 3.253 0 0 0 3.25-3.25A3.253 3.253 0 0 0 12 6.05Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-location', JhaIconLocation);
