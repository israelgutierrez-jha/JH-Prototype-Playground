import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-square-checkmark-filled
 * @customElement jha-icon-square-checkmark-filled
 */
export default class JhaIconSquareCheckmarkFilled extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Zm11.005 5.996a.75.75 0 0 1 0 1.06l-4.95 4.95-.015.016-.01.01a.75.75 0 0 1-1.06 0l-2.5-2.5a.75.75 0 0 1 1.06-1.062l1.97 1.97 4.444-4.444a.75.75 0 0 1 1.06 0Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-square-checkmark-filled', JhaIconSquareCheckmarkFilled);
