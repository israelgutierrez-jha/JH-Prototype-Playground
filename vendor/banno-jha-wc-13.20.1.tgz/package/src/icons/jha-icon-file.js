import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-file
 * @customElement jha-icon-file
 */
export default class JhaIconFile extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M6 3.25a.75.75 0 0 0-.75.75v16c0 .415.336.75.75.75h12a.75.75 0 0 0 .75-.75v-9a.75.75 0 0 0-.22-.53l-7-7a.75.75 0 0 0-.53-.22H6Zm.75 16V4.75h3.5V11c0 .415.336.75.75.75h6.25v7.5H6.75Zm9.439-9L11.75 5.811v4.44h4.439Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-file', JhaIconFile);
