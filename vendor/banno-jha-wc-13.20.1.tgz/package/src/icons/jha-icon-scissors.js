import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-scissors
 * @customElement jha-icon-scissors
 */
export default class JhaIconScissors extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M9.404 9.045a3 3 0 1 0-1.855 1.293l1.606 1.043 1.836-1.193-1.64-1.065.053-.078Zm-1.7-2.892A1.5 1.5 0 1 1 6.072 8.67a1.5 1.5 0 0 1 1.634-2.517Zm1.7 8.801a3 3 0 1 1-1.908-1.303l9.887-6.42 2.313-.246c.523-.056.766.63.325.916L9.33 14.845c.026.036.05.072.075.11Zm-1.7 2.892a1.5 1.5 0 1 0-1.633-2.516 1.5 1.5 0 0 0 1.634 2.516Z"/>   <path d="m17.383 16.724-4.556-2.958 1.836-1.193 5.359 3.48c.44.286.197.972-.325.916l-2.314-.245Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-scissors', JhaIconScissors);
