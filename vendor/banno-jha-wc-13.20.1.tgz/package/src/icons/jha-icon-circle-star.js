import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-circle-star
 * @customElement jha-icon-circle-star
 */
export default class JhaIconCircleStar extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3.75 12a8.25 8.25 0 1 1 16.5 0 8.25 8.25 0 0 1-16.5 0ZM12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25Zm.679 4.289a.75.75 0 0 0-1.358 0l-1.263 2.69-3.165.458a.75.75 0 0 0-.388 1.305l2.368 2.082-.47 2.95a.75.75 0 0 0 1.104.775L12 15.415l2.493 1.384a.75.75 0 0 0 1.105-.774l-.47-2.951 2.367-2.082a.75.75 0 0 0-.388-1.305l-3.165-.458-1.263-2.69Zm-1.435 3.694L12 8.623l.756 1.61a.75.75 0 0 0 .572.423l1.956.283-1.458 1.281a.75.75 0 0 0-.245.681l.293 1.838-1.51-.838a.75.75 0 0 0-.728 0l-1.51.838.293-1.838a.75.75 0 0 0-.245-.681l-1.458-1.281 1.956-.283a.75.75 0 0 0 .572-.423Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-circle-star', JhaIconCircleStar);
