import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-cards
 * @customElement jha-icon-cards
 */
export default class JhaIconCards extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3.5 4.25a.75.75 0 0 0-.75.75v8c0 .414.336.75.75.75h2.25V16c0 .414.336.75.75.75h2.25V19c0 .414.336.75.75.75h11a.75.75 0 0 0 .75-.75v-8a.75.75 0 0 0-.75-.75h-2.25V8a.75.75 0 0 0-.75-.75h-2.25V5a.75.75 0 0 0-.75-.75h-11Zm13.25 6v-1.5h-9.5v6.5h1.5V11a.75.75 0 0 1 .75-.75h7.25ZM5.75 8v4.25h-1.5v-6.5h9.5v1.5H6.5a.75.75 0 0 0-.75.75Zm4.5 10.25v-6.5h9.5v6.5h-9.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-cards', JhaIconCards);
