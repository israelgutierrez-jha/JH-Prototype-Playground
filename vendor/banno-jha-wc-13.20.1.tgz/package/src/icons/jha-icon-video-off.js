import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-video-off
 * @customElement jha-icon-video-off
 */
export default class JhaIconVideoOff extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="m3.575 2.661-.707.707 5.664 5.664 8.417 8.417 2.183 2.183.707-.707L17 16.085v-.7l1.643 1.517c1.282 1.182 3.357.273 3.357-1.47V8.568c0-1.744-2.075-2.652-3.357-1.47L17 8.615V7a2 2 0 0 0-2-2H5.914L3.575 2.661ZM7.415 6.5l2.5 2.5h3.335a.75.75 0 0 1 0 1.5h-1.836l4.086 4.086V7a.5.5 0 0 0-.5-.5H7.414Zm9.746 6.992a.5.5 0 0 1-.161-.368v-2.248a.5.5 0 0 1 .16-.368l2.5-2.307a.5.5 0 0 1 .84.367v6.864a.5.5 0 0 1-.84.367l-2.5-2.307Z"/>   <path d="M2 7a2 2 0 0 1 1.237-1.85L4.586 6.5H4a.5.5 0 0 0-.5.5v10a.5.5 0 0 0 .5.5h11a.5.5 0 0 0 .394-.192l1.062 1.063A1.994 1.994 0 0 1 15 19H4a2 2 0 0 1-2-2V7Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-video-off', JhaIconVideoOff);
