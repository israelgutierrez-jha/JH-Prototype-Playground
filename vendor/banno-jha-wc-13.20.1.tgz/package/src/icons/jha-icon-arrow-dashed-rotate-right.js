import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-arrow-dashed-rotate-right
 * @customElement jha-icon-arrow-dashed-rotate-right
 */
export default class JhaIconArrowDashedRotateRight extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path d="M3.25 12a8.75 8.75 0 0 1 15-6.123V4a.75.75 0 0 1 1.5 0v4.75H15a.75.75 0 0 1 0-1.5h2.477A7.25 7.25 0 0 0 4.75 12a.75.75 0 0 1-1.5 0Zm1.54 3.549a.75.75 0 0 1 1.031.246c.216.35.461.682.732.99a.75.75 0 0 1-1.126.99 8.779 8.779 0 0 1-.883-1.194.75.75 0 0 1 .245-1.032Zm14.06.651a.75.75 0 0 1 .15 1.051 8.8 8.8 0 0 1-.892 1.014.75.75 0 0 1-1.047-1.074c.267-.26.515-.542.74-.84a.75.75 0 0 1 1.05-.15Zm-8.943 3.56a.75.75 0 0 1 .865-.613 7.306 7.306 0 0 0 2.345.018.75.75 0 1 1 .23 1.482 8.82 8.82 0 0 1-2.827-.022.75.75 0 0 1-.613-.865Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-arrow-dashed-rotate-right', JhaIconArrowDashedRotateRight);
