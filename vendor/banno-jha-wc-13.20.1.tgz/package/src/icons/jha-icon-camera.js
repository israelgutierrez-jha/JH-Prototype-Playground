import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-camera
 * @customElement jha-icon-camera
 */
export default class JhaIconCamera extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M8 4.25h-.464l-.207.415-.793 1.585H4A1.75 1.75 0 0 0 2.25 8v9c0 .966.784 1.75 1.75 1.75h16A1.75 1.75 0 0 0 21.75 17V8A1.75 1.75 0 0 0 20 6.25h-2.537l-.792-1.585-.207-.415H8Zm-.33 3.085.794-1.585h7.072l.793 1.585.207.415H20a.25.25 0 0 1 .25.25v9a.25.25 0 0 1-.25.25H4a.25.25 0 0 1-.25-.25V8A.25.25 0 0 1 4 7.75h3.464l.207-.415ZM9.75 12a2.25 2.25 0 1 1 4.5 0 2.25 2.25 0 0 1-4.5 0ZM12 8.25a3.75 3.75 0 1 0 0 7.5 3.75 3.75 0 0 0 0-7.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-camera', JhaIconCamera);
