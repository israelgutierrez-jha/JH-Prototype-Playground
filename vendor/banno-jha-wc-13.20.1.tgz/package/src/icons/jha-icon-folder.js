import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-folder
 * @customElement jha-icon-folder
 */
export default class JhaIconFolder extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M8.75 4.75 10.5 7h8.75a1 1 0 0 1 1 1v10.25a1 1 0 0 1-1 1H4.75a1 1 0 0 1-1-1V5.75a1 1 0 0 1 1-1h4Zm2.484.75-1.3-1.67a1.5 1.5 0 0 0-1.184-.58h-4a2.5 2.5 0 0 0-2.5 2.5v12.5a2.5 2.5 0 0 0 2.5 2.5h14.5a2.5 2.5 0 0 0 2.5-2.5V8a2.5 2.5 0 0 0-2.5-2.5h-8.016Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-folder', JhaIconFolder);
