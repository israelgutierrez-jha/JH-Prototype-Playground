import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-automatic-payment
 * @customElement jha-icon-automatic-payment
 */
export default class JhaIconAutomaticPayment extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12.024 3.25C7.18 3.25 3.25 7.166 3.25 12A8.741 8.741 0 0 0 12 20.75c4.37 0 7.634-3.28 8.711-6.513a.75.75 0 0 0-1.423-.474C18.366 16.53 15.582 19.25 12 19.25A7.241 7.241 0 0 1 4.75 12c0-4.002 3.254-7.25 7.274-7.25a7.272 7.272 0 0 1 5.895 3H16.5a.75.75 0 0 0 0 1.5h3.75V5.5a.75.75 0 0 0-1.5 0v.88a8.766 8.766 0 0 0-6.726-3.13Zm.726 3.938V8.1c.292.08.574.212.822.4.48.366.803.93.803 1.642v.75h-1.5v-.75a.518.518 0 0 0-.212-.448c-.15-.115-.388-.195-.663-.195s-.512.08-.663.195a.518.518 0 0 0-.212.448c0 .425.126.6.256.716.183.163.45.274.886.44l.046.018c.374.142.893.34 1.303.703.479.426.759 1.024.759 1.837 0 .712-.323 1.276-.803 1.641a2.4 2.4 0 0 1-.822.401v.914h-1.5v-.914a2.414 2.414 0 0 1-.822-.4 2.015 2.015 0 0 1-.803-1.642v-.75h1.5v.75c0 .217.083.35.212.448.15.115.388.195.663.195s.512-.08.663-.195a.518.518 0 0 0 .212-.448c0-.425-.126-.6-.256-.716-.183-.163-.45-.274-.886-.44l-.046-.018c-.374-.142-.893-.339-1.303-.703-.479-.426-.759-1.024-.759-1.837 0-.712.323-1.276.803-1.641a2.4 2.4 0 0 1 .822-.401v-.914h1.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-automatic-payment', JhaIconAutomaticPayment);
