import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-file-filled
 * @customElement jha-icon-file-filled
 */
export default class JhaIconFileFilled extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M5.25 4A.75.75 0 0 1 6 3.25h4.25V11c0 .415.336.75.75.75h7.75V20a.75.75 0 0 1-.75.75H6a.75.75 0 0 1-.75-.75V4Zm13.06 6.25-6.56-6.56v6.56h6.56Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-file-filled', JhaIconFileFilled);
