import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-edit
 * @customElement jha-icon-edit
 */
export default class JhaIconEdit extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M16.78 3.22a.75.75 0 0 0-1.06 0l-1.97 1.97-.53.53-8 8-.53.53-.47.47a.75.75 0 0 0-.205.383l-1 5a.75.75 0 0 0 .882.883l5-1a.75.75 0 0 0 .383-.206l.47-.47.53-.53 8-8 .53-.53 1.97-1.97a.75.75 0 0 0 0-1.06l-4-4Zm.97 5.97 1.44-1.44-2.94-2.94-1.44 1.44 2.94 2.94Zm-4-1.88-6.94 6.94 2.94 2.94 6.94-6.94-2.94-2.94ZM8.69 18.25l-2.94-2.94-.31.31-.734 3.674 3.674-.735.31-.309Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-edit', JhaIconEdit);
