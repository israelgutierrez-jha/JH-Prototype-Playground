import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-tablet
 * @customElement jha-icon-tablet
 */
export default class JhaIconTablet extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M4 6.751a.25.25 0 0 0-.25.25v10c0 .138.112.25.25.25h1.25v-10.5H4Zm2.75 0v10.5h10.5v-10.5H6.75ZM18 5.251H4a1.75 1.75 0 0 0-1.75 1.75v10c0 .966.784 1.75 1.75 1.75h16a1.75 1.75 0 0 0 1.75-1.75v-10A1.75 1.75 0 0 0 20 5.251h-2Zm.75 1.5v10.5H20a.25.25 0 0 0 .25-.25v-10a.25.25 0 0 0-.25-.25h-1.25Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-tablet', JhaIconTablet);
