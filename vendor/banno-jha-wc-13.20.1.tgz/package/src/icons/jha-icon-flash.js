import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-flash
 * @customElement jha-icon-flash
 */
export default class JhaIconFlash extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M13.582 2.287A.75.75 0 0 1 14.1 3v7.35h3.75a.75.75 0 0 1 .607 1.191l-7.2 9.9a.75.75 0 0 1-1.357-.44v-7.35H6.15a.75.75 0 0 1-.607-1.192l7.2-9.9a.75.75 0 0 1 .839-.272Zm-5.96 9.863h3.028a.75.75 0 0 1 .75.75v5.794l4.977-6.844H13.35a.75.75 0 0 1-.75-.75V5.307L7.623 12.15Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-flash', JhaIconFlash);
