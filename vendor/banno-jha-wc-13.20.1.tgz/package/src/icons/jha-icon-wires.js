import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-wires
 * @customElement jha-icon-wires
 */
export default class JhaIconWires extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M4.728 2.82a.75.75 0 1 0-1.456.363l2 8a.75.75 0 0 0 1.424.097L8 8.02l1.304 3.26a.75.75 0 0 0 1.423-.097l2-8a.75.75 0 1 0-1.455-.364L9.835 8.57 8.696 5.722a.75.75 0 0 0-1.392 0L6.165 8.57 4.728 2.82Zm8.742 9.65a.75.75 0 0 1 1.06 0l4 4 .53.531-.53.53-4 4a.75.75 0 0 1-1.06-1.06l2.72-2.72H9.5c-1.344 0-2.346-.31-3.081-.798A3.692 3.692 0 0 1 5.04 15.29a.75.75 0 1 1 1.383-.581c.137.327.381.698.825.993.444.294 1.143.548 2.252.548h6.69l-2.72-2.72a.75.75 0 0 1 0-1.06Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-wires', JhaIconWires);
