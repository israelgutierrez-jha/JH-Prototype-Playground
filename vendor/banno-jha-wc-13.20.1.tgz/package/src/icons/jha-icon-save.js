import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-save
 * @customElement jha-icon-save
 */
export default class JhaIconSave extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3.25 4A.75.75 0 0 1 4 3.25h13a.75.75 0 0 1 .53.22l3 3c.141.14.22.332.22.53v13a.75.75 0 0 1-.75.75H4a.75.75 0 0 1-.75-.75V4Zm1.5.75h2.5V9c0 .415.336.75.75.75h8a.75.75 0 0 0 .75-.75V4.812l2.5 2.5v11.94H4.75V4.75Zm10.5 3.5v-3.5h-6.5v3.5h6.5Zm-8.25 4a.75.75 0 0 0-.75.75v4c0 .415.336.75.75.75h10a.75.75 0 0 0 .75-.75v-4a.75.75 0 0 0-.75-.75H7Zm.75 4v-2.5h8.5v2.5h-8.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-save', JhaIconSave);
