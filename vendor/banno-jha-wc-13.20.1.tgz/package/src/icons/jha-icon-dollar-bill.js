import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-dollar-bill
 * @customElement jha-icon-dollar-bill
 */
export default class JhaIconDollarBill extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3 6.25a.75.75 0 0 0-.75.75v10c0 .414.336.75.75.75h18a.75.75 0 0 0 .75-.75V7a.75.75 0 0 0-.75-.75H3Zm.75 3.23v5.041a1.504 1.504 0 0 1 1.729 1.729h13.042a1.504 1.504 0 0 1 1.729-1.729V9.48a1.504 1.504 0 0 1-1.729-1.729H5.479A1.504 1.504 0 0 1 3.75 9.48Zm6.5 2.52a1.75 1.75 0 1 1 3.5 0 1.75 1.75 0 0 1-3.5 0ZM12 8.75a3.25 3.25 0 1 0 0 6.5 3.25 3.25 0 0 0 0-6.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-dollar-bill', JhaIconDollarBill);
