import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-lock
 * @customElement jha-icon-lock
 */
export default class JhaIconLock extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12 4.25c-1.912 0-3.25 1.68-3.25 3.25v2.25h6.5V7.5c0-1.568-1.35-3.25-3.25-3.25ZM7.25 7.5v2.25H5a.75.75 0 0 0-.75.75v10c0 .415.336.75.75.75h14a.75.75 0 0 0 .75-.75v-10a.75.75 0 0 0-.75-.75h-2.25V7.5c0-2.289-1.917-4.75-4.75-4.75-2.848 0-4.75 2.463-4.75 4.75Zm11 3.75H5.75v8.5h12.5v-8.5ZM13 16.233a2 2 0 1 0-2 0V18.5h2v-2.267Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-lock', JhaIconLock);
