import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-bulk-select
 * @customElement jha-icon-bulk-select
 */
export default class JhaIconBulkSelect extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M5 7h10.5a2 2 0 0 1 2 2v10.5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2Zm0 1.5a.5.5 0 0 0-.5.5v10.5a.5.5 0 0 0 .5.5h10.5a.5.5 0 0 0 .5-.5V9a.5.5 0 0 0-.5-.5H5Z"/>   <path d="M14.535 11.464a.75.75 0 0 1 0 1.061l-4.95 4.95-.014.015-.01.01a.75.75 0 0 1-1.061 0L6 15a.75.75 0 0 1 1.06-1.06l1.97 1.97 4.445-4.446a.75.75 0 0 1 1.06 0ZM8.75 3H19.5a2 2 0 0 1 2 2v10.75a.75.75 0 0 1-1.5 0V5a.5.5 0 0 0-.5-.5H8.75a.75.75 0 0 1 0-1.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-bulk-select', JhaIconBulkSelect);
