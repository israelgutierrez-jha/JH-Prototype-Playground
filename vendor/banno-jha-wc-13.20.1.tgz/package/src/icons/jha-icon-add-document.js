import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-add-document
 * @customElement jha-icon-add-document
 */
export default class JhaIconAddDocument extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M5.25 4A.75.75 0 0 1 6 3.25h6a.75.75 0 0 1 .53.22l6 6c.141.14.22.332.22.53v10a.75.75 0 0 1-.75.75H6a.75.75 0 0 1-.75-.75V4Zm1.5.75v14.5h10.5v-8.5H12a.75.75 0 0 1-.75-.75V4.75h-4.5Zm6 1.06v3.44h3.439L12.75 5.81Zm0 6.69a.75.75 0 0 0-1.5 0v1.75H9.5a.75.75 0 0 0 0 1.5h1.75v1.75a.75.75 0 0 0 1.5 0v-1.75h1.75a.75.75 0 0 0 0-1.5h-1.75V12.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-add-document', JhaIconAddDocument);
