import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-collapse
 * @customElement jha-icon-collapse
 */
export default class JhaIconCollapse extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M8.53 4.47a.75.75 0 0 0-1.06 1.06l4 4a.75.75 0 0 0 1.06 0l4-4a.75.75 0 0 0-1.06-1.06L12 7.94 8.53 4.47Zm8 14-4-4a.75.75 0 0 0-1.06 0l-4 4a.75.75 0 0 0 1.06 1.06L12 16.06l3.47 3.47a.75.75 0 0 0 1.06-1.06Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-collapse', JhaIconCollapse);
