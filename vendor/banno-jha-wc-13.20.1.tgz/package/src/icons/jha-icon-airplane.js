import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-airplane
 * @customElement jha-icon-airplane
 */
export default class JhaIconAirplane extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M17.242 3.645a2.2 2.2 0 0 1 3.113 0 2.2 2.2 0 0 1 0 3.113l-3.468 3.468 1.958 8.487a.75.75 0 0 1-.2.7l-1.368 1.367a.75.75 0 0 1-1.195-.182l-3.289-6.278-2.775 2.775.288 2.023a.75.75 0 0 1-.212.636L9.068 20.78a.75.75 0 0 1-1.186-.166l-1.606-2.89-2.89-1.607a.75.75 0 0 1-.166-1.185l1.025-1.026a.75.75 0 0 1 .637-.212l2.023.289 2.776-2.776-6.279-3.289a.75.75 0 0 1-.182-1.194l1.368-1.369a.75.75 0 0 1 .699-.2l8.487 1.959 3.468-3.468Zm2.052 1.06a.699.699 0 0 0-.991 0v.001L14.54 8.468a.75.75 0 0 1-.699.2L5.355 6.71l-.353.353 6.278 3.289a.75.75 0 0 1 .183 1.194L7.7 15.308a.75.75 0 0 1-.636.213l-2.023-.29-.058.058 2.209 1.227a.75.75 0 0 1 .291.292l1.228 2.209.058-.058-.29-2.023a.75.75 0 0 1 .213-.636l3.762-3.762a.75.75 0 0 1 1.195.182l3.288 6.278.353-.352-1.958-8.488a.75.75 0 0 1 .2-.699l3.762-3.761a.7.7 0 0 0 0-.992Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-airplane', JhaIconAirplane);
