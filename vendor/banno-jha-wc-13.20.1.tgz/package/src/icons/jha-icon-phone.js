import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-phone
 * @customElement jha-icon-phone
 */
export default class JhaIconPhone extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M5.312 2.47a.75.75 0 0 1 1.06 0l4.737 4.737a.75.75 0 0 1 0 1.06L8.937 10.44a.198.198 0 0 0 0 .28l4.345 4.344a.198.198 0 0 0 .279 0l2.172-2.173a.75.75 0 0 1 1.06 0l4.737 4.737a.75.75 0 0 1 0 1.06l-2.842 2.843a.75.75 0 0 1-.53.22c-3.6 0-7.57-2.285-10.596-5.312C4.535 13.412 2.25 9.442 2.25 5.843a.75.75 0 0 1 .22-.53L5.312 2.47ZM3.757 6.147c.125 2.967 2.067 6.433 4.866 9.231 2.798 2.798 6.264 4.74 9.23 4.866l2.086-2.085-3.676-3.677-1.642 1.642a1.698 1.698 0 0 1-2.4 0L7.877 11.78a1.698 1.698 0 0 1 0-2.4l1.641-1.642L5.842 4.06 3.757 6.147Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-phone', JhaIconPhone);
