import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-ellipsis-vertical
 * @customElement jha-icon-ellipsis-vertical
 */
export default class JhaIconEllipsisVertical extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12 16a2 2 0 1 1 0 4 2 2 0 0 1 0-4Zm0-6a2 2 0 1 1 0 4 2 2 0 0 1 0-4Zm2-4a2 2 0 1 0-4 0 2 2 0 0 0 4 0Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-ellipsis-vertical', JhaIconEllipsisVertical);
