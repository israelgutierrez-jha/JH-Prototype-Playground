import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-arrow-drop-down
 * @customElement jha-icon-arrow-drop-down
 */
export default class JhaIconArrowDropDown extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="m12 15-5-5h10l-5 5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-arrow-drop-down', JhaIconArrowDropDown);
