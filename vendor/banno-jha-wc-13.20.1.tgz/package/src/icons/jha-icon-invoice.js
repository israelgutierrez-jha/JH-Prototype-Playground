import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-invoice
 * @customElement jha-icon-invoice
 */
export default class JhaIconInvoice extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M4.25 5c0-.966.784-1.75 1.75-1.75h12c.966 0 1.75.784 1.75 1.75v14A1.75 1.75 0 0 1 18 20.75H6A1.75 1.75 0 0 1 4.25 19V5ZM6 4.75a.25.25 0 0 0-.25.25v14c0 .138.112.25.25.25h12a.25.25 0 0 0 .25-.25V5a.25.25 0 0 0-.25-.25H6ZM7.25 8A.75.75 0 0 1 8 7.25h3a.75.75 0 0 1 0 1.5H8A.75.75 0 0 1 7.25 8ZM8 10.25a.75.75 0 0 0-.75.75v6c0 .415.336.75.75.75h8a.75.75 0 0 0 .75-.75v-6a.75.75 0 0 0-.75-.75H8Zm4.25 1.5h-3.5v1.5h3.5v-1.5Zm1.5 1.5v-1.5h1.5v1.5h-1.5Zm-1.5 1.5h-3.5v1.5h3.5v-1.5Zm1.5 1.5v-1.5h1.5v1.5h-1.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-invoice', JhaIconInvoice);
