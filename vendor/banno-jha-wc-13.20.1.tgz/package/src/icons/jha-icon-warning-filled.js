import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-warning-filled
 * @customElement jha-icon-warning-filled
 */
export default class JhaIconWarningFilled extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M13.876 4.281c-.845-1.373-2.906-1.374-3.752 0L2.56 16.567c-.903 1.466.257 3.184 1.876 3.184h15.13c1.618 0 2.78-1.718 1.876-3.184L13.876 4.281Zm-1.126 3.72a.75.75 0 0 0-1.5 0v4a.75.75 0 1 0 1.5 0v-4Zm-1.75 7.5a1 1 0 1 1 2 0 1 1 0 0 1-2 0Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-warning-filled', JhaIconWarningFilled);
