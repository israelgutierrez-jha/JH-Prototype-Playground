import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-dollar
 * @customElement jha-icon-dollar
 */
export default class JhaIconDollar extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M13 4v1.51a3.935 3.935 0 0 1 1.531.695C15.29 6.783 15.8 7.67 15.8 8.8v1h-2v-1c0-.47-.19-.782-.481-1.004-.32-.243-.794-.396-1.32-.396-.524 0-.999.152-1.318.396-.291.221-.481.534-.481 1.004 0 .808.247 1.193.54 1.453.362.322.877.531 1.616.813l.068.025c.652.249 1.501.572 2.165 1.162.758.674 1.211 1.622 1.211 2.947 0 1.13-.51 2.018-1.269 2.596A3.934 3.934 0 0 1 13 18.49V20h-2v-1.51a3.935 3.935 0 0 1-1.531-.695C8.71 17.218 8.2 16.33 8.2 15.2v-1h2v1c0 .47.19.783.481 1.005.32.243.794.395 1.319.395.525 0 1-.152 1.319-.395.291-.222.481-.535.481-1.005 0-.808-.247-1.193-.54-1.452-.362-.323-.877-.531-1.616-.813l-.068-.026c-.652-.248-1.501-.571-2.165-1.161C8.653 11.074 8.2 10.125 8.2 8.8c0-1.13.51-2.017 1.269-2.595A3.934 3.934 0 0 1 11 5.509V4h2Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-dollar', JhaIconDollar);
