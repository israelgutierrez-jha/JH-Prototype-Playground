import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-date-remove
 * @customElement jha-icon-date-remove
 */
export default class JhaIconDateRemove extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M7.75 4a.75.75 0 0 0-1.5 0v2.25H4a.75.75 0 0 0-.75.75v13c0 .414.336.75.75.75h16a.75.75 0 0 0 .75-.75V7a.75.75 0 0 0-.75-.75h-2.25V4a.75.75 0 0 0-1.5 0v2.25h-8.5V4ZM17 7.75H4.75v2.5h14.5v-2.5H17ZM4.75 19.25v-7.5h14.5v7.5H4.75Zm6.28-5.78a.75.75 0 1 0-1.06 1.06l.97.97-.97.97a.75.75 0 0 0 1.06 1.06l.97-.97.97.97a.75.75 0 0 0 1.06-1.06l-.97-.97.97-.97a.75.75 0 0 0-1.06-1.06l-.97.97-.97-.97Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-date-remove', JhaIconDateRemove);
