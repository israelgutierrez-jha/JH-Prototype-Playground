import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-hide
 * @customElement jha-icon-hide
 */
export default class JhaIconHide extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="m4.672 4.672.708-.707 2.956 2.957c1.06-.42 2.261-.672 3.664-.672 4.354 0 6.76 2.427 9.066 4.753l.464.467a.75.75 0 0 1 0 1.06l-.464.467c-1.094 1.104-2.21 2.23-3.546 3.109l2.515 2.515-.707.707L4.672 4.672ZM6.48 7.895c-1.336.879-2.452 2.005-3.546 3.108l-.464.467a.75.75 0 0 0 0 1.06l.464.467C5.24 15.324 7.646 17.75 12 17.75c1.403 0 2.604-.252 3.664-.671l-1.176-1.176A8.57 8.57 0 0 1 12 16.25c-3.65 0-5.635-1.933-7.941-4.25 1.166-1.171 2.25-2.244 3.507-3.02L6.48 7.896Zm2.812 2.812a3 3 0 0 0 4 4l-4-4Zm.22-2.61 1.195 1.196a3 3 0 0 1 4 4l1.727 1.727c1.258-.775 2.341-1.848 3.507-3.02-2.306-2.317-4.29-4.25-7.941-4.25a8.57 8.57 0 0 0-2.488.348Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-hide', JhaIconHide);
