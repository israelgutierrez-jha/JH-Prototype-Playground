import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-life-preserver
 * @customElement jha-icon-life-preserver
 */
export default class JhaIconLifePreserver extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M21.033 10A9.263 9.263 0 0 0 14 2.968 1 1 0 0 0 13 2h-2a1 1 0 0 0-1 .967 9.263 9.263 0 0 0-7.033 7.034A1 1 0 0 0 2 11v2a1 1 0 0 0 .967.999A9.263 9.263 0 0 0 10 21.034 1 1 0 0 0 11 22h2a1 1 0 0 0 1-.966A9.263 9.263 0 0 0 21.032 14 1 1 0 0 0 22 13v-2a1 1 0 0 0-.967-1ZM10.861 4.334a7.812 7.812 0 0 1 2.278 0l-.61 2.444a5.31 5.31 0 0 0-1.058 0l-.61-2.444Zm-1.455.362a7.772 7.772 0 0 0-4.711 4.711l2.443.61a5.268 5.268 0 0 1 2.877-2.877l-.61-2.444Zm-5.073 6.167a7.814 7.814 0 0 0 0 2.277l2.443-.61a5.313 5.313 0 0 1 0-1.058l-2.443-.61Zm.362 3.733a7.772 7.772 0 0 0 4.71 4.71l.61-2.443a5.267 5.267 0 0 1-2.877-2.877l-2.443.61Zm6.166 5.072a7.815 7.815 0 0 0 2.278 0l-.61-2.443a5.292 5.292 0 0 1-1.058 0l-.61 2.443Zm3.733-.362a7.772 7.772 0 0 0 4.711-4.71l-2.443-.61a5.267 5.267 0 0 1-2.877 2.877l.61 2.443Zm5.073-6.166a7.801 7.801 0 0 0 0-2.277l-2.443.609a5.292 5.292 0 0 1 0 1.059l2.443.609Zm-.362-3.733a7.772 7.772 0 0 0-4.71-4.71l-.61 2.443a5.267 5.267 0 0 1 2.877 2.876l2.443-.609ZM12 8.25a3.75 3.75 0 1 0 0 7.5 3.75 3.75 0 0 0 0-7.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-life-preserver', JhaIconLifePreserver);
