import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-circle-plus
 * @customElement jha-icon-circle-plus
 */
export default class JhaIconCirclePlus extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12 3.75a8.25 8.25 0 1 0 0 16.5 8.25 8.25 0 0 0 0-16.5ZM2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12Zm5.5 0a.75.75 0 0 1 .75-.75h2.75V8.5a.75.75 0 0 1 1.5 0v2.75h2.75a.75.75 0 1 1 0 1.5h-2.75v2.75a.75.75 0 0 1-1.5 0v-2.75H8.5a.75.75 0 0 1-.75-.75Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-circle-plus', JhaIconCirclePlus);
