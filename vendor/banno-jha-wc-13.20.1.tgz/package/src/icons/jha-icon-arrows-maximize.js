import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-arrows-maximize
 * @customElement jha-icon-arrows-maximize
 */
export default class JhaIconArrowsMaximize extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3.498 3.499H8.49a.75.75 0 1 1 0 1.5H6.058l3.908 3.908a.75.75 0 0 1-1.06 1.06L4.998 6.06v2.432a.75.75 0 1 1-1.5 0V3.499Zm11.261.75a.75.75 0 0 1 .75-.75h4.993V8.49a.75.75 0 0 1-1.5 0V6.059l-3.908 3.908a.75.75 0 1 1-1.06-1.06l3.908-3.908h-2.433a.75.75 0 0 1-.75-.75Zm-4.793 9.845a.75.75 0 0 1 0 1.06l-3.908 3.909h2.433a.75.75 0 0 1 0 1.5H3.498V15.57a.75.75 0 0 1 1.5 0v2.431l3.908-3.908a.75.75 0 0 1 1.06 0Zm4.068 0a.75.75 0 0 1 1.06 0l3.908 3.908v-2.431a.75.75 0 0 1 1.5 0v4.992H15.51a.75.75 0 0 1 0-1.5h2.433l-3.909-3.908a.75.75 0 0 1 0-1.06Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-arrows-maximize', JhaIconArrowsMaximize);
