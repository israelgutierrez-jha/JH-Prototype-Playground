import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-flash-off
 * @customElement jha-icon-flash-off
 */
export default class JhaIconFlashOff extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M13.082 2.287A.75.75 0 0 1 13.6 3v7.35h3.75a.75.75 0 0 1 .606 1.191l-2.105 2.896 4.184 4.184-.707.707L4.672 4.672l.708-.707 3.38 3.382 3.482-4.788a.75.75 0 0 1 .839-.272ZM9.835 8.421l2.265 2.265v-5.38L9.835 8.422Zm3.43 3.43 1.512 1.512 1.1-1.513h-2.613Zm.321 3.15 1.074 1.074-3.903 5.366a.75.75 0 0 1-1.357-.44v-7.35H5.65a.75.75 0 0 1-.607-1.192L7.57 8.985l1.074 1.074-1.521 2.091h3.027a.75.75 0 0 1 .75.75v5.794L13.586 15Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-flash-off', JhaIconFlashOff);
