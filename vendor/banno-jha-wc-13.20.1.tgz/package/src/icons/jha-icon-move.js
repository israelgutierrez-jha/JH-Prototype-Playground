import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-move
 * @customElement jha-icon-move
 */
export default class JhaIconMove extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="m12 1.94.53.53 3 3a.75.75 0 0 1-1.06 1.06l-1.72-1.719v6.44h6.44l-1.72-1.72a.75.75 0 0 1 1.06-1.06l3 3 .53.53-.53.53-3 3a.75.75 0 1 1-1.06-1.06l1.72-1.72h-6.44v6.439l1.72-1.72a.75.75 0 1 1 1.06 1.06l-3 3-.53.531-.53-.53-3-3a.75.75 0 1 1 1.06-1.06l1.72 1.719v-6.44H4.81l1.72 1.72a.75.75 0 1 1-1.06 1.06l-3-3-.53-.53.53-.53 3-3a.75.75 0 0 1 1.06 1.06l-1.72 1.72h6.44V4.811l-1.72 1.72a.75.75 0 0 1-1.06-1.06l3-3L12 1.94Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-move', JhaIconMove);
