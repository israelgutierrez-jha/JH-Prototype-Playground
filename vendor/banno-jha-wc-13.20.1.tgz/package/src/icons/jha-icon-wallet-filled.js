import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-wallet-filled
 * @customElement jha-icon-wallet-filled
 */
export default class JhaIconWalletFilled extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M2.25 5.501c0-.967.784-1.75 1.75-1.75h15c.966 0 1.75.783 1.75 1.75v2.75h-6.5a2 2 0 0 0-2 2v3.5a2 2 0 0 0 2 2h6.5v2.75a1.75 1.75 0 0 1-1.75 1.75H4a1.75 1.75 0 0 1-1.75-1.75v-13Zm12 4.25a.5.5 0 0 0-.5.5v3.5a.5.5 0 0 0 .5.5h7.5v-4.5h-7.5Zm1.75 3.25a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-wallet-filled', JhaIconWalletFilled);
