import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-group
 * @customElement jha-icon-group
 */
export default class JhaIconGroup extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12 3.75a8.25 8.25 0 1 0 0 16.5 8.25 8.25 0 0 0 0-16.5ZM2.25 12c0-5.384 4.365-9.75 9.75-9.75s9.75 4.366 9.75 9.75c0 5.385-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12Zm11.75.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0ZM10.5 6a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5ZM7 15.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-group', JhaIconGroup);
