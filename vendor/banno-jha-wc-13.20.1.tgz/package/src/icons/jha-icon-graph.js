import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-graph
 * @customElement jha-icon-graph
 */
export default class JhaIconGraph extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M14.625 5.625a.75.75 0 0 0 0 1.5h4.19l-6.44 6.44-2.47-2.47a.75.75 0 0 0-1.06 0l-6 6a.75.75 0 1 0 1.06 1.06l5.47-5.47 2.47 2.47a.75.75 0 0 0 1.06 0l6.97-6.97v4.19a.75.75 0 0 0 1.5 0v-6.75h-6.75Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-graph', JhaIconGraph);
