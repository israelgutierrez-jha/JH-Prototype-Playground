import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-tag-filled
 * @customElement jha-icon-tag-filled
 */
export default class JhaIconTagFilled extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M7.934 5.251c-.595 0-1.161.255-1.557.7l-.017.019-.016.02-3.587 4.649a2.084 2.084 0 0 0 0 2.724l3.587 4.649.016.02.017.02c.396.444.962.699 1.557.699H20a1.75 1.75 0 0 0 1.75-1.75v-10A1.75 1.75 0 0 0 20 5.251H7.934Zm-.184 6.75a1.25 1.25 0 1 1 2.5 0 1.25 1.25 0 0 1-2.5 0Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-tag-filled', JhaIconTagFilled);
