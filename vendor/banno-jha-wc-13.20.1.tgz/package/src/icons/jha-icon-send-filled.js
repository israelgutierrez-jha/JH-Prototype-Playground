import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-send-filled
 * @customElement jha-icon-send-filled
 */
export default class JhaIconSendFilled extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="m3.33 2.33 17.99 9c.26.121.43.382.43.67 0 .286-.17.547-.43.67l-17.99 9a.73.73 0 0 1-.85-.13.76.76 0 0 1-.17-.84l3.216-7.231L18.25 12 5.527 10.533 2.31 3.299a.75.75 0 0 1 1.02-.97Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-send-filled', JhaIconSendFilled);
