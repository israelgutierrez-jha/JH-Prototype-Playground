import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-dashboard
 * @customElement jha-icon-dashboard
 */
export default class JhaIconDashboard extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3 3.75h8v16.5H3V3.75Zm1.5 1.5v13.5h5V5.25h-5Zm8.5-1.5h8v8.5h-8v-8.5Zm1.5 1.5v5.5h5v-5.5h-5Zm-.75 8.5H13v6.5h8v-6.5h-7.25Zm.75 5v-3.5h5v3.5h-5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-dashboard', JhaIconDashboard);
