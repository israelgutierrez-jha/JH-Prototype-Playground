import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-paginate
 * @customElement jha-icon-paginate
 */
export default class JhaIconPaginate extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path d="M16 12a4 4 0 1 0-8 0 4 4 0 0 0 8 0Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-paginate', JhaIconPaginate);
