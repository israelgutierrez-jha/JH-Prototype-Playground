import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-document
 * @customElement jha-icon-document
 */
export default class JhaIconDocument extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M6.5 3.25A1.75 1.75 0 0 0 4.75 5v14c0 .967.784 1.75 1.75 1.75h11A1.75 1.75 0 0 0 19.25 19V5a1.75 1.75 0 0 0-1.75-1.75h-11ZM6.25 5a.25.25 0 0 1 .25-.25h11a.25.25 0 0 1 .25.25v14a.25.25 0 0 1-.25.25h-11a.25.25 0 0 1-.25-.25V5ZM9 7.25a.75.75 0 0 0 0 1.5h6a.75.75 0 0 0 0-1.5H9ZM8.25 12a.75.75 0 0 1 .75-.75h6a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75ZM9 15.25a.75.75 0 0 0 0 1.5h6a.75.75 0 0 0 0-1.5H9Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-document', JhaIconDocument);
