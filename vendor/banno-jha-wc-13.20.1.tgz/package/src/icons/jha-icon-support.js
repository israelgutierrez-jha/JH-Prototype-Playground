import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-support
 * @customElement jha-icon-support
 */
export default class JhaIconSupport extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3.75 2.376A1.75 1.75 0 0 0 2 4.126v14.59l1.227-1.011 4.042-3.329h8.981a1.75 1.75 0 0 0 1.75-1.75v-8.5a1.75 1.75 0 0 0-1.75-1.75H3.75Zm-.25 1.75a.25.25 0 0 1 .25-.25h12.5a.25.25 0 0 1 .25.25v8.5a.25.25 0 0 1-.25.25H6.73l-.207.171-3.023 2.49V4.126Zm4.5 12.5v-.75h1.5v.75c0 .138.112.25.25.25h7.504l.202.154 3.044 2.328V8.126a.25.25 0 0 0-.25-.25h-.75v-1.5h.75c.966 0 1.75.783 1.75 1.75v14.268l-1.206-.922-4.048-3.096H9.75A1.75 1.75 0 0 1 8 16.626Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-support', JhaIconSupport);
