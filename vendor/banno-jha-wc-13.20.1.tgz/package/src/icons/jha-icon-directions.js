import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-directions
 * @customElement jha-icon-directions
 */
export default class JhaIconDirections extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M11.47 2.47a.75.75 0 0 1 1.06 0l9 9a.75.75 0 0 1 0 1.06l-9 9a.75.75 0 0 1-1.06 0l-9-9a.75.75 0 0 1 0-1.06l9-9ZM4.06 12 12 19.94 19.94 12 12 4.06 4.06 12Zm5.19-1a.75.75 0 0 1 .75-.75h4.19l-1.22-1.22a.75.75 0 0 1 1.06-1.06l2.5 2.5.53.53-.53.53-2.5 2.5a.75.75 0 0 1-1.06-1.06l1.22-1.22h-3.44V16a.75.75 0 0 1-1.5 0v-5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-directions', JhaIconDirections);
