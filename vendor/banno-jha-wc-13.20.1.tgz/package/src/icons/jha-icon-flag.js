import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-flag
 * @customElement jha-icon-flag
 */
export default class JhaIconFlag extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M4.75 3a.75.75 0 0 0-1.5 0v18a.75.75 0 1 0 1.5 0v-6.882a5.323 5.323 0 0 1 1.576-.71c1.144-.304 2.787-.326 4.726.96 2.348 1.556 4.703 1.553 6.443 1.168a9.948 9.948 0 0 0 2.093-.717 8.526 8.526 0 0 0 .805-.437l.014-.009.004-.003h.002v-.001L20 13.743l.414.625a.75.75 0 0 0 .336-.625V5.257a.75.75 0 0 0-1.202-.598l-.002.002-.023.016a5.795 5.795 0 0 1-.522.319 6.669 6.669 0 0 1-1.518.595c-1.236.312-2.854.314-4.497-.931-2.107-1.597-4.495-1.575-6.275-1.197-.77.163-1.443.396-1.961.607V3Zm0 2.711v6.685a6.9 6.9 0 0 1 1.191-.439c1.522-.403 3.613-.382 5.94 1.161 1.92 1.272 3.83 1.276 5.29.954a8.45 8.45 0 0 0 2.079-.761V6.548c-.39.18-.863.362-1.4.497-1.564.395-3.68.394-5.77-1.19-1.626-1.232-3.505-1.254-5.058-.925a10.161 10.161 0 0 0-2.272.781Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-flag', JhaIconFlag);
