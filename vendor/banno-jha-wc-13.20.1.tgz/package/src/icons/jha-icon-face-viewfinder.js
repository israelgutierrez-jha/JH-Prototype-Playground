import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-face-viewfinder
 * @customElement jha-icon-face-viewfinder
 */
export default class JhaIconFaceViewfinder extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <g fill-rule="evenodd">     <path d="M12 6.75a5.25 5.25 0 1 0 0 10.5 5.25 5.25 0 0 0 0-10.5ZM5.25 12a6.75 6.75 0 1 1 13.5 0 6.75 6.75 0 0 1-13.5 0Z"/>     <path d="M10.667 10.5a.834.834 0 1 1-1.668 0 .834.834 0 0 1 1.668 0Zm4.333 0a.834.834 0 1 1-1.667 0 .834.834 0 0 1 1.667 0Zm-6.083 2.21a.75.75 0 0 1 1.04.207c1.037 1.555 3.05 1.555 4.086 0a.75.75 0 1 1 1.248.832c-1.63 2.446-4.952 2.446-6.582 0a.75.75 0 0 1 .208-1.04ZM2.75 16.75a.75.75 0 0 1 .75.75v2.75c0 .138.112.25.25.25H6.5a.75.75 0 0 1 0 1.5H3.75A1.75 1.75 0 0 1 2 20.25V17.5a.75.75 0 0 1 .75-.75Zm18.5 0a.75.75 0 0 0-.75.75v2.75a.25.25 0 0 1-.25.25H17.5a.75.75 0 0 0 0 1.5h2.75A1.75 1.75 0 0 0 22 20.25V17.5a.75.75 0 0 0-.75-.75Zm-1-13.25a.25.25 0 0 1 .25.25V6.5a.75.75 0 0 0 1.5 0V3.75A1.75 1.75 0 0 0 20.25 2H17.5a.75.75 0 0 0 0 1.5h2.75Zm-16.5 0a.25.25 0 0 0-.25.25V6.5a.75.75 0 0 1-1.5 0V3.75C2 2.784 2.784 2 3.75 2H6.5a.75.75 0 0 1 0 1.5H3.75Z"/>   </g> </svg> 
    `;
    }
}
customElements.define('jha-icon-face-viewfinder', JhaIconFaceViewfinder);
