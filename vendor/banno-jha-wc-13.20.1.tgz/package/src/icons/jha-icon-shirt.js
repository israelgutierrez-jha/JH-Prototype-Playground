import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-shirt
 * @customElement jha-icon-shirt
 */
export default class JhaIconShirt extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M7.487 4.574a.25.25 0 0 1 .177-.073h1.399a2.975 2.975 0 0 0 5.924 0h1.349a.25.25 0 0 1 .177.073l3.68 3.681-1.414 1.414L17.28 8.17A.75.75 0 0 0 16 8.7v10.8H8V8.7a.75.75 0 0 0-1.28-.53l-1.5 1.5-1.414-1.415 3.681-3.681Zm5.987-.073h-2.898a1.475 1.475 0 0 0 2.898 0ZM7.664 3a1.75 1.75 0 0 0-1.237.512L2.215 7.725a.75.75 0 0 0 0 1.06L4.69 11.26a.75.75 0 0 0 1.061 0l.749-.749v9.74c0 .414.336.75.75.75h9.5a.75.75 0 0 0 .75-.75v-9.74l.75.75a.75.75 0 0 0 1.06 0l2.475-2.476a.75.75 0 0 0 0-1.06l-4.212-4.212a1.75 1.75 0 0 0-1.237-.512H7.664Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-shirt', JhaIconShirt);
