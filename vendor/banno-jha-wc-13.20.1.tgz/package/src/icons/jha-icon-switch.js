import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-switch
 * @customElement jha-icon-switch
 */
export default class JhaIconSwitch extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="m7 3.94.53.53 4 4a.75.75 0 0 1-1.06 1.061l-2.72-2.72v8.19c0 1.781.65 2.532 1.166 2.876A2.314 2.314 0 0 0 10 18.25h.007a.75.75 0 0 1-.007 1.5V19l-.001.75h-.024a2.782 2.782 0 0 1-.175-.011 3.815 3.815 0 0 1-1.716-.615C7.1 18.468 6.25 17.218 6.25 15V6.81L3.53 9.53a.75.75 0 0 1-1.06-1.06l4-4L7 3.94Zm7 .311a.75.75 0 0 0-.007 1.5H14l.058.004a2.317 2.317 0 0 1 1.026.37c.516.344 1.166 1.094 1.166 2.876v8.19l-2.72-2.72a.75.75 0 1 0-1.06 1.06l4 4 .53.53.53-.53 4-4a.75.75 0 0 0-1.06-1.06l-2.72 2.72V9c0-2.219-.85-3.468-1.834-4.124a3.817 3.817 0 0 0-1.716-.615 2.658 2.658 0 0 0-.175-.01l-.015-.001h-.009L14 5v-.75Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-switch', JhaIconSwitch);
