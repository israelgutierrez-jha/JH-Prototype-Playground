import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-support-filled
 * @customElement jha-icon-support-filled
 */
export default class JhaIconSupportFilled extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M2 4.126c0-.967.784-1.75 1.75-1.75h12.5c.966 0 1.75.783 1.75 1.75v8.5a1.75 1.75 0 0 1-1.75 1.75H7.27l-4.043 3.329L2 18.715V4.126Zm6 11.75h8.25a3.25 3.25 0 0 0 3.25-3.25v-6.25h.75c.966 0 1.75.783 1.75 1.75v14.268l-1.206-.922-4.048-3.096H9.75A1.75 1.75 0 0 1 8 16.626v-.75Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-support-filled', JhaIconSupportFilled);
