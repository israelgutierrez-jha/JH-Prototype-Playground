import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-download
 * @customElement jha-icon-download
 */
export default class JhaIconDownload extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12 4.25a.75.75 0 0 1 .75.75v9.19l2.72-2.72a.75.75 0 1 1 1.06 1.06l-4 4-.53.53-.53-.53-4-4a.75.75 0 0 1 1.06-1.06l2.72 2.72V5a.75.75 0 0 1 .75-.75Zm-9 10a.75.75 0 0 1 .75.75v3.045c0 .403.117.736.268.949.152.215.292.256.367.256h15.23c.075 0 .215-.041.367-.256.151-.213.268-.546.268-.95V15a.75.75 0 0 1 1.5 0v3.045c0 .676-.193 1.321-.544 1.816-.348.493-.9.89-1.59.89H4.384c-.69 0-1.242-.397-1.59-.89-.35-.495-.544-1.14-.544-1.816V15a.75.75 0 0 1 .75-.75Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-download', JhaIconDownload);
