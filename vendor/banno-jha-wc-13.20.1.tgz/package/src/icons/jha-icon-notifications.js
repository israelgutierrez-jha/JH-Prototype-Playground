import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-notifications
 * @customElement jha-icon-notifications
 */
export default class JhaIconNotifications extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12 2a1.5 1.5 0 0 0-1.5 1.5v.66c-3.075.67-5 3.368-5 6.09v5.69l-1.78 1.78A.75.75 0 0 0 4.25 19h15.5a.75.75 0 0 0 .53-1.28l-1.78-1.78v-5.69c0-2.722-1.925-5.42-5-6.09V3.5A1.5 1.5 0 0 0 12 2Zm-5 8.25C7 7.893 8.936 5.5 12 5.5s5 2.393 5 4.75v6.311l.22.22.72.72H6.06l.72-.72.22-.22V10.25ZM12 22a2 2 0 0 1-2-2h4a2 2 0 0 1-2 2Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-notifications', JhaIconNotifications);
