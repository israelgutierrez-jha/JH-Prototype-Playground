import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-mic
 * @customElement jha-icon-mic
 */
export default class JhaIconMic extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M8 6a4 4 0 1 1 8 0v6a4 4 0 0 1-8 0V6Zm6.5 0v6a2.5 2.5 0 0 1-5 0V6a2.5 2.5 0 0 1 5 0Z"/>   <path d="M6.75 10a.75.75 0 0 0-1.5 0v1c0 3.183 1.071 5.167 2.532 6.336 1.133.906 2.43 1.265 3.468 1.374v1.79h-2.5a.75.75 0 0 0 0 1.5h6.5a.75.75 0 0 0 0-1.5h-2.5v-1.79c1.038-.11 2.335-.468 3.468-1.374 1.46-1.169 2.532-3.153 2.532-6.336v-1a.75.75 0 0 0-1.5 0v1c0 2.817-.929 4.333-1.969 5.164-1.072.858-2.383 1.086-3.281 1.086-.898 0-2.21-.228-3.281-1.086C7.679 15.333 6.75 13.817 6.75 11v-1Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-mic', JhaIconMic);
