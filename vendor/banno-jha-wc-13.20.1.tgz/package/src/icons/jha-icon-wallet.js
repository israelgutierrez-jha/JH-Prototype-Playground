import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-wallet
 * @customElement jha-icon-wallet
 */
export default class JhaIconWallet extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M4 3.751a1.75 1.75 0 0 0-1.75 1.75v13c0 .966.784 1.75 1.75 1.75h15a1.75 1.75 0 0 0 1.75-1.75v-2.75H21a.75.75 0 0 0 .75-.75v-6a.75.75 0 0 0-.75-.75h-.25v-2.75A1.75 1.75 0 0 0 19 3.751H4Zm10.25 12h5v2.75a.25.25 0 0 1-.25.25H4a.25.25 0 0 1-.25-.25v-13a.25.25 0 0 1 .25-.25h15a.25.25 0 0 1 .25.25v2.75h-5a2 2 0 0 0-2 2v3.5a2 2 0 0 0 2 2Zm0-6a.5.5 0 0 0-.5.5v3.5a.5.5 0 0 0 .5.5h6v-4.5h-6Zm1.75 3.25a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-wallet', JhaIconWallet);
