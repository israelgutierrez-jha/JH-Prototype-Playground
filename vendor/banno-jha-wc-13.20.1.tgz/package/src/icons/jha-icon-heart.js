import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-heart
 * @customElement jha-icon-heart
 */
export default class JhaIconHeart extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M2.414 8.571a5.323 5.323 0 0 1 5.323-5.323c1.748 0 3.294.843 4.263 2.142a5.305 5.305 0 0 1 4.263-2.142 5.323 5.323 0 0 1 5.323 5.323c0 4.742-2.354 8.036-4.666 10.12a17.99 17.99 0 0 1-3.17 2.274 15.719 15.719 0 0 1-1.355.68 6.25 6.25 0 0 1-.084.036l-.024.01-.007.003h-.002l-.001.001-.277-.697-.277.697-.003-.001-.007-.003-.024-.01a7.605 7.605 0 0 1-.386-.171c-.257-.12-.62-.3-1.052-.545a17.99 17.99 0 0 1-3.17-2.275c-2.313-2.083-4.667-5.378-4.667-10.119ZM12 20.998l-.276.697a.75.75 0 0 0 .552 0L12 20.998Zm0-.818.062-.029c.226-.106.554-.269.95-.492a16.49 16.49 0 0 0 2.904-2.083c2.106-1.898 4.17-4.817 4.17-9.005A3.82 3.82 0 0 0 12.7 7.196a.75.75 0 0 1-1.4 0 3.82 3.82 0 0 0-7.386 1.375c0 4.188 2.064 7.107 4.17 9.005a16.506 16.506 0 0 0 2.904 2.083 14.133 14.133 0 0 0 1.012.52Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-heart', JhaIconHeart);
