import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-zelle
 * @customElement jha-icon-zelle
 */
export default class JhaIconZelle extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12.887 20.001H11.27c-.151 0-.275-.144-.275-.322v-1.843H8.38c-.209 0-.379-.2-.379-.445v-1.489c0-.099.029-.196.08-.274l4.633-6.922H8.587c-.21 0-.38-.2-.38-.444V6.61c0-.246.17-.445.38-.445h2.407V4.323c0-.178.123-.322.275-.322h1.617c.151 0 .274.144.274.322v1.843h2.46c.21 0 .38.2.38.445v1.424a.497.497 0 0 1-.08.274l-4.662 6.987h4.363c.209 0 .379.199.379.444v1.65c0 .246-.17.445-.38.445h-2.458v1.844c0 .178-.123.322-.275.322Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-zelle', JhaIconZelle);
