import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-share
 * @customElement jha-icon-share
 */
export default class JhaIconShare extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M14.75 6a2.25 2.25 0 1 1 4.5 0 2.25 2.25 0 0 1-4.5 0ZM17 2.25a3.75 3.75 0 0 0-3.572 4.897L9.165 9.989a3.75 3.75 0 1 0 0 4.023l4.263 2.842a3.75 3.75 0 1 0 .738-1.31L9.708 12.57a3.778 3.778 0 0 0 0-1.14l4.46-2.973A3.75 3.75 0 1 0 17 2.25Zm0 13.5a2.25 2.25 0 1 0 0 4.5 2.25 2.25 0 0 0 0-4.5ZM3.75 12a2.25 2.25 0 1 1 4.5 0 2.25 2.25 0 0 1-4.5 0Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-share', JhaIconShare);
