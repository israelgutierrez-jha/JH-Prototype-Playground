import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-notifications-off
 * @customElement jha-icon-notifications-off
 */
export default class JhaIconNotificationsOff extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M6.544 6.855 3.97 4.28a.75.75 0 0 1 1.06-1.06l15.247 15.247a.75.75 0 0 0 .18.032.734.734 0 0 1-.044.103l.617.618a.75.75 0 0 1-1.06 1.06L18.69 19H4.25a.75.75 0 0 1-.53-1.28l1.78-1.78v-5.69a6.17 6.17 0 0 1 1.044-3.395ZM17.189 17.5H6.061l.72-.72.219-.219V10.25c0-.796.22-1.597.632-2.307l9.557 9.557ZM17 13.184v.006l1.5 1.5v-4.44c0-2.722-1.925-5.42-5-6.09V3.5a1.5 1.5 0 0 0-3 0v.66a6.428 6.428 0 0 0-1.829.7l1.113 1.114c.646-.3 1.39-.474 2.216-.474 3.064 0 5 2.393 5 4.75v2.934ZM12 22a2 2 0 0 1-2-2h4a2 2 0 0 1-2 2Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-notifications-off', JhaIconNotificationsOff);
