import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-date-add
 * @customElement jha-icon-date-add
 */
export default class JhaIconDateAdd extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M7.75 4a.75.75 0 0 0-1.5 0v2.25H4a.75.75 0 0 0-.75.75v13c0 .414.336.75.75.75h16a.75.75 0 0 0 .75-.75V7a.75.75 0 0 0-.75-.75h-2.25V4a.75.75 0 0 0-1.5 0v2.25h-8.5V4ZM17 7.75H4.75v2.5h14.5v-2.5H17ZM4.75 19.25v-7.5h14.5v7.5H4.75Zm8-5.75a.75.75 0 0 0-1.5 0v1.25H10a.75.75 0 0 0 0 1.5h1.25v1.25a.75.75 0 0 0 1.5 0v-1.25H14a.75.75 0 0 0 0-1.5h-1.25V13.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-date-add', JhaIconDateAdd);
