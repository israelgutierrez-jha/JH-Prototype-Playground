import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-windows
 * @customElement jha-icon-windows
 */
export default class JhaIconWindows extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M22 11.501v-9.5l-10.854 1.6v8l10.854-.1Zm-20-6.6 8.14-1.2v7.9H2v-6.7Zm0 14.3v-6.7h8.14v7.9L2 19.201Zm20 2.8-10.854-1.5v-8H22v9.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-windows', JhaIconWindows);
