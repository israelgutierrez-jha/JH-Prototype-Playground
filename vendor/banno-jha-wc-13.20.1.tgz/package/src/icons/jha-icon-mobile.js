import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-mobile
 * @customElement jha-icon-mobile
 */
export default class JhaIconMobile extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M7.75 4.5A.25.25 0 0 1 8 4.25h8a.25.25 0 0 1 .25.25v12.293a.75.75 0 0 0-.25-.043H8a.75.75 0 0 0-.25.043V4.5Zm0 13.708V19.5c0 .138.112.25.25.25h8a.25.25 0 0 0 .25-.25v-1.292a.75.75 0 0 1-.25.042H8a.75.75 0 0 1-.25-.042ZM8 2.75A1.75 1.75 0 0 0 6.25 4.5v15c0 .967.784 1.75 1.75 1.75h8a1.75 1.75 0 0 0 1.75-1.75v-15A1.75 1.75 0 0 0 16 2.75H8Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-mobile', JhaIconMobile);
