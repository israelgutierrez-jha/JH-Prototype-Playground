import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-conversation
 * @customElement jha-icon-conversation
 */
export default class JhaIconConversation extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M2.25 5c0-.966.784-1.75 1.75-1.75h16c.966 0 1.75.784 1.75 1.75v10A1.75 1.75 0 0 1 20 16.75H8.263L3.47 20.586l-1.219.975V5ZM4 4.75a.25.25 0 0 0-.25.25v13.44l3.781-3.026.206-.164H20a.25.25 0 0 0 .25-.25V5a.25.25 0 0 0-.25-.25H4ZM7.25 8A.75.75 0 0 1 8 7.25h8a.75.75 0 0 1 0 1.5H8A.75.75 0 0 1 7.25 8ZM8 11.25a.75.75 0 0 0 0 1.5h8a.75.75 0 0 0 0-1.5H8Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-conversation', JhaIconConversation);
