import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-template
 * @customElement jha-icon-template
 */
export default class JhaIconTemplate extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M4.375 4.001a.75.75 0 0 1 .75-.75h13.75a.75.75 0 0 1 .75.75v3.79l.82-.82a.75.75 0 0 1 1.06 1.06l-2.125 2.125a.75.75 0 0 1-1.06 0l-2.125-2.125a.75.75 0 1 1 1.06-1.06l.87.87V4.75H5.875V10a.75.75 0 0 1-1.5 0V4Zm14.5 9.283a.75.75 0 0 1 .75.75v5.967a.75.75 0 0 1-.75.75H5.125a.75.75 0 0 1-.75-.75v-4.214l-.82.82a.75.75 0 0 1-1.06-1.061L4.62 13.42a.75.75 0 0 1 1.06 0l2.125 2.125a.75.75 0 1 1-1.06 1.06l-.87-.87v3.515h12.25v-5.217a.75.75 0 0 1 .75-.75Zm-8.45.967a.75.75 0 0 0 0 1.5h3.15a.75.75 0 0 0 0-1.5h-3.15Zm-.75-2.55a.75.75 0 0 1 .75-.75h3.15a.75.75 0 0 1 0 1.5h-3.15a.75.75 0 0 1-.75-.75Zm.75-3.95a.75.75 0 0 0 0 1.5h3.15a.75.75 0 0 0 0-1.5h-3.15Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-template', JhaIconTemplate);
