import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-tag
 * @customElement jha-icon-tag
 */
export default class JhaIconTag extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="m3.93 11.574 3.582-4.642a.583.583 0 0 1 .422-.181H20a.25.25 0 0 1 .25.25v10a.25.25 0 0 1-.25.25H7.934a.583.583 0 0 1-.422-.18L3.93 12.427l-.016-.02-.017-.02a.584.584 0 0 1 0-.774l.017-.02.016-.02ZM7.934 5.25c-.595 0-1.161.255-1.557.7l-.017.019-.016.02-3.587 4.649a2.084 2.084 0 0 0 0 2.724l3.587 4.649.016.02.017.02c.396.444.962.699 1.557.699H20A1.75 1.75 0 0 0 21.75 17V7A1.75 1.75 0 0 0 20 5.251H7.934ZM7.75 12a1.25 1.25 0 1 1 2.5 0 1.25 1.25 0 0 1-2.5 0ZM9 9.251a2.75 2.75 0 1 0 0 5.5 2.75 2.75 0 0 0 0-5.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-tag', JhaIconTag);
