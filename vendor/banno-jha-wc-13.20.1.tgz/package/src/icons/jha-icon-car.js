import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-car
 * @customElement jha-icon-car
 */
export default class JhaIconCar extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M6.446 5a.25.25 0 0 0-.234.163L4.605 9.5h14.79l-1.607-4.337A.25.25 0 0 0 17.554 5H6.446Zm13.504 6H4.05l-.05.134V17h16v-5.866L19.95 11ZM2.5 17.75v1.75a1 1 0 0 0 1 1h1a1 1 0 0 0 1-1v-1h13v1a1 1 0 0 0 1 1h1a1 1 0 0 0 1-1v-8.634l-.047-.127-2.258-6.097A1.75 1.75 0 0 0 17.554 3.5H6.446a1.75 1.75 0 0 0-1.641 1.142L2.547 10.74l-.047.127v6.884Zm5.75-4.125a1.625 1.625 0 1 1-3.25 0 1.625 1.625 0 0 1 3.25 0Zm9.125 1.625a1.625 1.625 0 1 0 0-3.25 1.625 1.625 0 0 0 0 3.25Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-car', JhaIconCar);
