import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-face-id
 * @customElement jha-icon-face-id
 */
export default class JhaIconFaceId extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M4.159 4.159A2.25 2.25 0 0 1 5.75 3.5h2a.75.75 0 0 0 0-1.5h-2A3.75 3.75 0 0 0 2 5.75v2a.75.75 0 0 0 1.5 0v-2c0-.597.237-1.169.659-1.591Zm4.048 3.634A1 1 0 0 0 6.5 8.5v.75a1 1 0 0 0 2 0V8.5a1 1 0 0 0-.293-.707Zm9 0A1 1 0 0 0 15.5 8.5v.75a1 1 0 0 0 2 0V8.5a1 1 0 0 0-.293-.707Zm-8.891 7.69a.75.75 0 0 1 1.06-.027 3.82 3.82 0 0 0 5.258 0 .75.75 0 1 1 1.032 1.088 5.32 5.32 0 0 1-7.322 0 .75.75 0 0 1-.028-1.06ZM2.75 15.5a.75.75 0 0 1 .75.75v2a2.25 2.25 0 0 0 2.25 2.25h2a.75.75 0 0 1 0 1.5h-2A3.75 3.75 0 0 1 2 18.25v-2a.75.75 0 0 1 .75-.75Zm19.25.75a.75.75 0 0 0-1.5 0v2a2.25 2.25 0 0 1-2.25 2.25h-2a.75.75 0 0 0 0 1.5h2A3.75 3.75 0 0 0 22 18.25v-2Zm-6.5-13.5a.75.75 0 0 1 .75-.75h1.86a3.75 3.75 0 0 1 3.75 3.75v1.86a.75.75 0 0 1-1.5 0V5.75a2.25 2.25 0 0 0-2.25-2.25h-1.86a.75.75 0 0 1-.75-.75ZM13.25 8.5a.75.75 0 0 0-1.5 0v3.25c0 .261-.052.486-.124.617a.23.23 0 0 1-.065.082c-.002.002-.015.011-.061.011a.75.75 0 0 0 0 1.5c.701 0 1.177-.396 1.437-.865.24-.431.313-.936.313-1.345V8.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-face-id', JhaIconFaceId);
