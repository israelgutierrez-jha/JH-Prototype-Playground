import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-dining
 * @customElement jha-icon-dining
 */
export default class JhaIconDining extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M15.968 4.405c-.505.505-.843 1.196-.843 1.97v3.865l.52 1.386h1.23V3.788c-.312.13-.627.337-.907.617Zm-2.295 6.234.702 1.872v7.364a2 2 0 1 0 4 0v-17a.75.75 0 0 0-.75-.75c-.987 0-1.982.484-2.718 1.22-.745.745-1.282 1.804-1.282 3.03v4h.75-.75c0 .09.016.18.048.264Zm2.202 9.236v-6.75h1v6.75a.5.5 0 1 1-1 0ZM7.625 8.898a.5.5 0 0 1-.5-.5V5.375a.75.75 0 0 0-1.5 0v4.5c0 1.04.49 1.967 1.25 2.562v7.688c0 .967.784 1.75 1.75 1.75h.5a1.75 1.75 0 0 0 1.75-1.75v-7.688a3.244 3.244 0 0 0 1.25-2.562v-4.5a.75.75 0 0 0-1.5 0v3.023a.5.5 0 0 1-1 0V5.375a.75.75 0 0 0-1.5 0v3.023a.5.5 0 0 1-.5.5Zm0 1.5c.473 0 .908-.164 1.25-.439a1.991 1.991 0 0 0 1.685.392 1.75 1.75 0 0 1-3.37 0c.14.03.286.047.435.047Zm1.75 2.727h-1v7c0 .138.112.25.25.25h.5a.25.25 0 0 0 .25-.25v-7Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-dining', JhaIconDining);
