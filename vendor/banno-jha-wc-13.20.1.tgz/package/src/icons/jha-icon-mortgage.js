import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-mortgage
 * @customElement jha-icon-mortgage
 */
export default class JhaIconMortgage extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M11.506 2.936a.75.75 0 0 1 .988 0l3.256 2.849V4.5h2v3h-.04l2.784 2.436a.75.75 0 1 1-.988 1.129l-.756-.662v7.347H20a.75.75 0 0 1 0 1.5H4a.75.75 0 0 1 0-1.5h1.25v-7.347l-.756.662a.75.75 0 1 1-.988-1.13l8-7ZM17.25 9.09v8.66H6.75V9.09L12 4.497l5.25 4.594Zm-4.75-.34v-.5h-1v.754a1.954 1.954 0 0 0-.765.348 1.59 1.59 0 0 0-.635 1.297c0 .663.226 1.137.605 1.474.332.295.757.457 1.083.58l.034.014c.37.14.627.245.808.406.146.13.27.322.27.726a.591.591 0 0 1-.24.503c-.16.121-.398.197-.66.197s-.5-.076-.66-.197a.591.591 0 0 1-.24-.502v-.5h-1v.5c0 .564.255 1.008.635 1.297.227.173.492.287.765.348v.754h1v-.754c.273-.061.538-.175.765-.348a1.59 1.59 0 0 0 .635-1.297c0-.663-.226-1.137-.605-1.474-.332-.295-.757-.457-1.083-.581l-.034-.013c-.37-.14-.627-.245-.808-.406-.146-.13-.27-.322-.27-.727 0-.235.095-.391.24-.502.16-.121.398-.198.66-.198s.5.077.66.198c.145.111.24.267.24.502v.5h1v-.5a1.59 1.59 0 0 0-.635-1.297 1.967 1.967 0 0 0-.765-.348V8.75Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-mortgage', JhaIconMortgage);
