import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-baby
 * @customElement jha-icon-baby
 */
export default class JhaIconBaby extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M5.5 12a6.5 6.5 0 0 1 6.732-6.496c-.037.489-.128.766-.214.931-.1.192-.224.292-.446.438a.77.77 0 0 1-.221.088 1.25 1.25 0 0 1-.292.039.75.75 0 0 0-1.309.5c0 .533.41.791.62.88.227.094.475.12.68.12.41 0 .935-.105 1.344-.372.286-.188.672-.46.953-.997.193-.37.317-.825.371-1.401A6.5 6.5 0 1 1 5.5 12ZM12 4a8.002 8.002 0 0 0-7.335 4.803 3.251 3.251 0 0 0 0 6.394 8.002 8.002 0 0 0 14.67 0 3.251 3.251 0 0 0 0-6.394A8.002 8.002 0 0 0 12 4Zm7.89 6.672a8.056 8.056 0 0 1 0 2.655 1.746 1.746 0 0 0 0-2.655ZM3.5 12c0-.53.236-1.007.61-1.328a8.055 8.055 0 0 0 0 2.655A1.746 1.746 0 0 1 3.5 12Zm4-.5a2 2 0 1 1 4 0 .75.75 0 0 1-1.5 0 .5.5 0 0 0-1 0 .75.75 0 0 1-1.5 0Zm7-2a2 2 0 0 0-2 2 .75.75 0 0 0 1.5 0 .5.5 0 0 1 1 0 .75.75 0 0 0 1.5 0 2 2 0 0 0-2-2Zm-4.75 4a.75.75 0 0 1 .75.751c.004.016.046.186.343.396.283.2.694.353 1.157.353a2.03 2.03 0 0 0 1.157-.353c.297-.21.339-.38.343-.396v-.001a.75.75 0 0 1 1.5 0c0 .694-.476 1.267-.975 1.62A3.531 3.531 0 0 1 12 16.5a3.53 3.53 0 0 1-2.025-.63c-.5-.353-.975-.926-.975-1.62a.75.75 0 0 1 .75-.75Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-baby', JhaIconBaby);
