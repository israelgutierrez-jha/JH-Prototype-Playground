import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-question-mark
 * @customElement jha-icon-question-mark
 */
export default class JhaIconQuestionMark extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M10.5 8c0-.643.213-.976.431-1.163.245-.209.618-.337 1.067-.336.466 0 .857.127 1.107.321.216.168.395.434.395.929 0 .133-.055.334-.234.614a5.23 5.23 0 0 1-.721.853c-.19.188-.345.332-.502.476-.111.103-.222.205-.345.323a4.179 4.179 0 0 0-.373.398 1.728 1.728 0 0 0-.187.283 1.21 1.21 0 0 0-.138.553v.028c.009.292.009.837.007 1.325l-.005.624-.001.191v.053l-.001.013v.004l1 .012 1 .01v-.073l.002-.194.005-.631c.001-.353.002-.757-.002-1.078l.079-.077c.06-.058.148-.14.25-.234.19-.175.425-.394.62-.589.334-.33.706-.737.998-1.195.29-.455.548-1.032.548-1.69 0-1.09-.446-1.947-1.168-2.508-.687-.534-1.546-.741-2.33-.742-.802-.002-1.678.224-2.371.817-.72.616-1.13 1.534-1.13 2.683v.75h2V8Zm2.386 3.664.002-.002-.002.002Zm.614 5.338a1.5 1.5 0 1 0-2.999.001 1.5 1.5 0 0 0 2.999-.001Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-question-mark', JhaIconQuestionMark);
