import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-authy
 * @customElement jha-icon-authy
 */
export default class JhaIconAuthy extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M17.834 6.166A8.25 8.25 0 1 0 6.166 17.834 8.25 8.25 0 0 0 17.834 6.166ZM5.106 5.106c3.807-3.808 9.98-3.808 13.788 0 3.808 3.807 3.808 9.98 0 13.788-3.807 3.808-9.98 3.808-13.788 0-3.808-3.807-3.808-9.98 0-13.788Zm6.275 5.038a2.5 2.5 0 0 0-3.535 3.535l1.944 1.945a.75.75 0 0 1-1.06 1.06L6.785 14.74a4 4 0 1 1 5.657-5.657l1.944 1.945a.75.75 0 0 1-1.06 1.06l-1.945-1.944Zm4.773.177a2.5 2.5 0 1 1-3.535 3.535l-1.945-1.944a.75.75 0 1 0-1.06 1.06l1.944 1.945a4 4 0 1 0 5.657-5.657L15.27 7.315a.75.75 0 0 0-1.06 1.061l1.944 1.945Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-authy', JhaIconAuthy);
