import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-attach
 * @customElement jha-icon-attach
 */
export default class JhaIconAttach extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M16.034 4.693c-.527-.03-1.116.147-1.68.71L6.93 12.827c-.917.917-1.227 1.904-1.174 2.807.054.92.491 1.814 1.174 2.497.682.682 1.576 1.12 2.497 1.173.902.054 1.89-.256 2.806-1.173l6.01-6.01a.75.75 0 1 1 1.061 1.06l-6.01 6.01c-1.205 1.205-2.604 1.69-3.955 1.61-1.333-.078-2.561-.701-3.47-1.61-.908-.908-1.532-2.136-1.61-3.469-.08-1.351.406-2.75 1.61-3.955l7.425-7.425c.85-.85 1.852-1.204 2.828-1.146.957.056 1.832.503 2.475 1.146.643.643 1.09 1.518 1.147 2.475.057.976-.296 1.977-1.147 2.828l-7.425 7.425c-.497.497-1.1.718-1.7.682a2.302 2.302 0 0 1-1.481-.682 2.302 2.302 0 0 1-.683-1.48c-.035-.6.185-1.204.683-1.702L14 7.878a.75.75 0 1 1 1.06 1.06l-6.01 6.01c-.21.21-.254.402-.245.553.01.17.093.356.245.508a.805.805 0 0 0 .508.246c.152.009.343-.036.553-.246l7.424-7.424c.564-.564.741-1.153.71-1.68-.032-.545-.292-1.085-.71-1.502-.417-.417-.957-.678-1.502-.71Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-attach', JhaIconAttach);
