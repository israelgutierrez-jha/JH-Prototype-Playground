import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-refresh
 * @customElement jha-icon-refresh
 */
export default class JhaIconRefresh extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12.024 3.25C7.18 3.25 3.25 7.167 3.25 12A8.741 8.741 0 0 0 12 20.75c4.37 0 7.634-3.28 8.711-6.512a.75.75 0 0 0-1.423-.475c-.922 2.767-3.706 5.488-7.288 5.488A7.241 7.241 0 0 1 4.75 12c0-4.002 3.254-7.25 7.274-7.25a7.275 7.275 0 0 1 6.228 3.5H16a.75.75 0 0 0 0 1.5h4.75V5a.75.75 0 0 0-1.5 0v2.034a8.772 8.772 0 0 0-7.226-3.784Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-refresh', JhaIconRefresh);
