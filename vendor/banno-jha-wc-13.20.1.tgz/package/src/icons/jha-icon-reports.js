import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-reports
 * @customElement jha-icon-reports
 */
export default class JhaIconReports extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M11.5 4.496a1 1 0 0 0-1 1v13.5h-2v-4.5a1 1 0 0 0-1-1h-1a1 1 0 0 0-1 1v4.5H3.25a.75.75 0 0 0 0 1.5h13.157a.95.95 0 0 0 .093.004h1a.964.964 0 0 0 .093-.004h3.157a.75.75 0 0 0 0-1.5H18.5v-9.5a1 1 0 0 0-1-1h-1a1 1 0 0 0-1 1v9.5h-2v-13.5a1 1 0 0 0-1-1h-1Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-reports', JhaIconReports);
