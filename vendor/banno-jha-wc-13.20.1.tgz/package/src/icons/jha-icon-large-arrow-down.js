import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-large-arrow-down
 * @customElement jha-icon-large-arrow-down
 */
export default class JhaIconLargeArrowDown extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12.75 6a.75.75 0 0 0-1.5 0v9.19l-2.72-2.72a.75.75 0 0 0-1.06 1.06l4 4 .53.531.53-.53 4-4a.75.75 0 1 0-1.06-1.061l-2.72 2.72V6Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-large-arrow-down', JhaIconLargeArrowDown);
