import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-desktop
 * @customElement jha-icon-desktop
 */
export default class JhaIconDesktop extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M3.25 4.5A.75.75 0 0 1 4 3.75h16a.75.75 0 0 1 .75.75v12a.75.75 0 0 1-.75.75h-4.96l.671 2.013a.75.75 0 0 1-.711.987H9a.75.75 0 0 1-.712-.987l.671-2.013H4a.75.75 0 0 1-.75-.75v-12Zm1.5 9.75v1.5h14.5v-1.5H4.75Zm14.5-1.5H4.75v-7.5h14.5v7.5Zm-8.71 4.5h2.92l.5 1.5h-3.92l.5-1.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-desktop', JhaIconDesktop);
