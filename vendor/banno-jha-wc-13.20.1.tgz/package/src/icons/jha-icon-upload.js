import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-upload
 * @customElement jha-icon-upload
 */
export default class JhaIconUpload extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12.53 4.47 12 3.94l-.53.53-4 4a.75.75 0 0 0 1.06 1.061l2.72-2.72v9.19a.75.75 0 0 0 1.5 0v-9.19l2.72 2.72a.75.75 0 1 0 1.06-1.06l-4-4ZM3 14.252a.75.75 0 0 1 .75.75v3.045c0 .403.117.736.268.949.152.215.292.256.367.256h15.23c.075 0 .215-.041.367-.256.151-.213.268-.546.268-.95v-3.044a.75.75 0 0 1 1.5 0v3.045c0 .676-.193 1.32-.544 1.816-.348.493-.9.889-1.59.889H4.384c-.69 0-1.242-.396-1.59-.89-.35-.494-.544-1.139-.544-1.816v-3.044a.75.75 0 0 1 .75-.75Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-upload', JhaIconUpload);
