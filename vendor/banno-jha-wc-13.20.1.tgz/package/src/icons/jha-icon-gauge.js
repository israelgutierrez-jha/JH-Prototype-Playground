import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-gauge
 * @customElement jha-icon-gauge
 */
export default class JhaIconGauge extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M11.25 6.928a8.213 8.213 0 0 0-4.53 1.877l.86.86-1.06 1.06-.86-.86a8.213 8.213 0 0 0-1.876 4.53H5v1.5H3a.75.75 0 0 1-.75-.75c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75a.75.75 0 0 1-.75.75h-2v-1.5h1.216a8.213 8.213 0 0 0-1.876-4.53l-.86.86-1.06-1.06.86-.86a8.213 8.213 0 0 0-4.53-1.877v1.217h-1.5V6.928Zm3.016 2.84-.75-.01-.668-.342a.75.75 0 0 1 1.418.353Zm-.75-.01-.668-.342-.002.004-.006.011-.023.045-.087.171a305.087 305.087 0 0 0-1.275 2.537c-.355.716-.718 1.46-1.006 2.077-.272.582-.518 1.133-.592 1.407-.289 1.078.355 2.263 1.48 2.565 1.127.301 2.277-.403 2.566-1.481.085-.32.14-.945.181-1.6.044-.692.079-1.522.106-2.317a182.214 182.214 0 0 0 .071-2.81l.004-.189V9.77l-.75-.011Zm-.836 3.334a94.631 94.631 0 0 0-.872 1.805c-.298.635-.47 1.043-.502 1.16a.615.615 0 0 0 .42.727.615.615 0 0 0 .728-.42c.038-.144.088-.601.133-1.307a75.77 75.77 0 0 0 .093-1.965Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-gauge', JhaIconGauge);
