import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-form
 * @customElement jha-icon-form
 */
export default class JhaIconForm extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M5 3.25A1.75 1.75 0 0 0 3.25 5v14c0 .967.784 1.75 1.75 1.75h11A1.75 1.75 0 0 0 17.75 19v-3.582l-1.5 1.5V19a.25.25 0 0 1-.25.25H5a.25.25 0 0 1-.25-.25V5A.25.25 0 0 1 5 4.75h11a.25.25 0 0 1 .25.25v.877l.967-.968c.145-.144.304-.265.474-.362A1.75 1.75 0 0 0 16 3.25H5ZM6.25 8A.75.75 0 0 1 7 7.25h6a.75.75 0 0 1 0 1.5H7A.75.75 0 0 1 6.25 8ZM7 11.25a.75.75 0 0 0 0 1.5h2a.75.75 0 0 0 0-1.5H7Zm11.278-5.28a.75.75 0 0 1 1.06 0l2.34 2.339a.75.75 0 0 1 0 1.06l-6.724 6.724a.75.75 0 0 1-.384.205l-2.923.585a.75.75 0 0 1-.882-.883l.584-2.923a.75.75 0 0 1 .205-.383l6.724-6.724Zm-5.502 7.624-.32 1.597 1.598-.32 6.032-6.032-1.278-1.278-6.032 6.033ZM7 15.25a.75.75 0 0 0 0 1.5h2a.75.75 0 0 0 0-1.5H7Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-form', JhaIconForm);
