import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-birthday
 * @customElement jha-icon-birthday
 */
export default class JhaIconBirthday extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M12 2s-1.5 1.333-1.5 2.667C10.5 5.409 11.171 6 12 6c.826 0 1.5-.591 1.5-1.333C13.5 3.333 12 2 12 2Zm.75 7.25V7h-1.5v2.25H6A1.75 1.75 0 0 0 4.25 11v9.75h15.5v-5.203a.773.773 0 0 0 0-.094V11A1.75 1.75 0 0 0 18 9.25h-5.25Zm5.5 5.912V11a.25.25 0 0 0-.25-.25H6a.25.25 0 0 0-.25.25v4.114c.335.3.764.459 1.134.396.36-.06.951-.389 1.404-1.747a.75.75 0 0 1 1.423 0c.772 2.316 3.805 2.316 4.577 0a.75.75 0 0 1 1.423 0c.452 1.357 1.041 1.685 1.412 1.747.354.06.77-.077 1.126-.348Zm-12.5 1.68v2.408h12.5v-2.397a2.71 2.71 0 0 1-1.374.137c-.756-.126-1.414-.58-1.931-1.36-1.529 1.827-4.363 1.827-5.891 0-.516.779-1.171 1.233-1.92 1.36a2.635 2.635 0 0 1-1.385-.148Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-birthday', JhaIconBirthday);
