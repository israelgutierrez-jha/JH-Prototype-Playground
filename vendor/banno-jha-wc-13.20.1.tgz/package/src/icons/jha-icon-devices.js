import { LitElement, html } from 'lit';
import { jhaIconStyles } from '../styles/jha-icon-styles.js';
/**
 * @element jha-icon-devices
 * @customElement jha-icon-devices
 */
export default class JhaIconDevices extends LitElement {
    static get styles() {
        return [jhaIconStyles];
    }
    render() {
        // icon svg's contain ? in the tag which is invalid according to the linter
        return html `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">   <path fill-rule="evenodd" d="M4 4.75a.25.25 0 0 0-.25.25v10c0 .138.112.25.25.25h1.25V4.75H4Zm2-1.5H4A1.75 1.75 0 0 0 2.25 5v10c0 .966.784 1.75 1.75 1.75h8v-1.5H6.75V4.75h9.5V6h1.5V4.75H19a.25.25 0 0 1 .25.25v1h1.5V5A1.75 1.75 0 0 0 19 3.25H6ZM13.25 8a.75.75 0 0 1 .75-.75h7a.75.75 0 0 1 .75.75v12a.75.75 0 0 1-.75.75h-7a.75.75 0 0 1-.75-.75V8Zm7 .75v7.5h-5.5v-7.5h5.5Zm0 9h-5.5v1.5h5.5v-1.5Z"/> </svg> 
    `;
    }
}
customElements.define('jha-icon-devices', JhaIconDevices);
