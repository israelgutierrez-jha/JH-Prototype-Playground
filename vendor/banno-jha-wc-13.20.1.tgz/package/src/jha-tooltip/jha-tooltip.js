import JhaTooltip from './JhaTooltip.js';
customElements.define('jha-tooltip', JhaTooltip);
/** @customElement jha-tooltip */
export default JhaTooltip;
