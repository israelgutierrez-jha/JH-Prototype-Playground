import JhaProgressLinear from './JhaProgressLinear.js';
customElements.define('jha-progress-linear', JhaProgressLinear);
export default JhaProgressLinear;
