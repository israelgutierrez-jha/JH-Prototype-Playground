import JhaProgress from './JhaProgress.js';
customElements.define(JhaProgress.is, JhaProgress);
/** @customElement jha-progress */
export default JhaProgress;
