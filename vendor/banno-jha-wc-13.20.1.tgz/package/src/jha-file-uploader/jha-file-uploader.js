import JhaFileUploader from './JhaFileUploader.js';
customElements.define('jha-file-uploader', JhaFileUploader);
/** @customElement jha-file-uploader */
export default JhaFileUploader;
