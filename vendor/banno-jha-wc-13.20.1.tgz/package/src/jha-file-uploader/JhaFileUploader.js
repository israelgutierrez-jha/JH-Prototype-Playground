import { LitElement, html, css } from 'lit';
import { classMap } from 'lit/directives/class-map.js';
import { jhaStyles } from '../styles/jha-styles.js';
import '../progress/jha-progress/jha-progress.js';
import bytesToFormattedFilesize from '../js/utils/format-filesize.js';
import randomGuid from '../js/utils/random-guid.js';
/** @type {import('../js/utils/types.js').UploadFile} */
class UploadFile {
    /**
     * @param {!File} file
     * @param {string=} parameterName
     */
    constructor(file, parameterName = 'file') {
        this.id = randomGuid();
        this.file = file;
        this.parameterName = parameterName;
        this._loaded = false;
    }
    get loaded() {
        return this._loaded;
    }
    set loaded(loaded) {
        this._loaded = loaded;
    }
}
const styles = css `
  :host {
    display: block;
  }
  .container {
    background-color: var(--jha-color-light, var(--secondary-content-background-color));
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    border: var(--jha-file-uploader-border, 1px dashed var(--jha-color-gray-medium, var(--body-text-secondary-color)));
    min-height: var(--jha-file-uploader-height, 175px);
  }
  .drop-zone {
    height: 100%;
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }
  .file-hover {
    background-color: var(--jha-border-color, var(--divider-default-color));
  }
  .render > div:not(.drop-zone) {
    display: var(--jha-file-uploader-slot-display, block);
  }
  .upload-button {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: var(--jha-file-uploader-height, 175px);
    padding: 40px 0;
    min-height: 70px;
  }
  jha-progress.upload-more {
    margin: 12px;
    height: 44.5px;
  }
  button.upload-more {
    flex-direction: row;
    flex: 0;
    gap: 12px;
    padding: 12px !important;
  }
  .button-reset {
    touch-action: manipulation;
    background: none;
    border: none;
    color: var(--jha-text-dark);
    cursor: pointer;
    font-family: -apple-system, system-ui, 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif;
    font-size: 14px;
    margin: 0;
    padding: 0;
    text-align: left;
    -webkit-appearance: none;
  }
  :host ::slotted(*),
  jha-icon-upload {
    fill: var(--jha-color-primary, #3aaeda);
    width: 36px;
    height: 36px;
  }
  input {
    display: none;
  }
  .files {
    padding: 8px;
    box-sizing: border-box;
    height: 100%;
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    overflow: auto;
    justify-content: center;
  }
  .file-info {
    background: var(--jha-component-background-color, #ffffff);
    padding: 6px 12px;
    margin: 8px 0;
    display: flex;
    align-items: center;
    max-height: 100%;
    height: auto;
    width: 60%;
  }
  .file-info span {
    flex: 1;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  .file-info[error] {
    outline: 1px solid var(--jha-color-danger);
  }
  .files > .error {
    margin-left: 20%;
    width: 80%;
    margin-top: -4px;
    margin-bottom: 8px;
  }
  .files img {
    max-width: calc(100% - 40px);
    max-height: var(--jha-file-uploader-preview-height, 400px);
  }
  .image-info {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
  }
  jha-icon-file {
    fill: var(--jha-color-primary, #006ee4);
    margin-right: 12px;
  }
  jha-progress {
    --jha-progress-color: var(--jha-color-primary, #006ee4);
    height: 24px;
    width: 24px;
  }
  jha-icon-delete {
    margin-left: 12px;
  }

  .error {
    font-size: 12px;
    margin: var(--error-text-top-margin, 10px) 0 0;
    text-align: var(--error-text-align, left);
    color: var(--jha-form-floating-group-error, var(--jha-color-danger, #f44336));
  }
  div[file-list] {
    justify-content: flex-start;
    padding: 24px 0;
    height: var(--jha-file-uploader-height, 175px);
  }
  .helper-text {
    word-break: normal;
    overflow-wrap: anywhere;
    color: var(--jh-input-helper-color-text, var(--jh-color-content-secondary-enabled));
    margin: 0;
    font: var(--jh-font-helper-regular);
  }
  .required-indicator {
    color: var(--jh-input-required-color-text, var(--jh-color-content-negative-enabled));
  }
  .file-details {
    display: flex;
    flex-direction: column;
    width: 100%;
  }
  .file-size {
    word-break: normal;
    overflow-wrap: anywhere;
    color: var(--jh-input-helper-color-text, var(--jh-color-content-secondary-enabled));
    margin: 0;
    font: var(--jh-font-helper-regular);
  }
  @media (max-width: 480px) {
    .file-info {
      width: 90%;
    }
  }
`;
/**@element jha-file-uploader */
export default class JhaFileUploader extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            name: {
                type: String,
            },
            text: {
                type: String,
            },
            multiple: {
                type: Boolean,
            },
            accept: {
                type: String,
            },
            queue: {
                type: Array,
            },
            loading: {
                type: Boolean,
            },
            error: {
                type: String,
            },
            label: {
                type: String,
            },
            helpText: {
                type: String,
            },
            hideRequiredIndicator: {
                type: Boolean,
            },
            required: {
                type: Boolean,
            },
            max: {
                type: Number,
            },
        };
    }
    constructor() {
        super();
        import('../icons/jha-icon-upload.js');
        import('../icons/jha-icon-file.js');
        import('../icons/jha-icon-delete.js');
        this.name = 'file';
        this.text = 'Upload files';
        this.multiple = false;
        this.accept = '';
        this.queue = [];
        this.loading = false;
        this.label = '';
        this.required = false;
        this.hideRequiredIndicator = false;
        this.helpText = '';
        this.max = undefined;
        this.error = '';
    }
    /** @return {!HTMLInputElement} */
    get fileInput() {
        return this.shadowRoot.querySelector('input#file-uploader');
    }
    _onFileInputChange(evt) {
        this._processFiles([].slice.call(evt.target.files));
        if (this.fileInput) {
            this.fileInput.value = '';
        }
    }
    checkValidity() {
        if (!this.required)
            return true;
        if (!this.queue.length)
            return false;
        return this.queue.some(({ file: { error } }) => !error);
    }
    /**
     * @param {!File} file
     * @returns {!boolean}
     */
    _invalidFileType(file) {
        if (!this.accept)
            return false;
        const acceptedValues = this.accept.split(',').map((item) => item.trim().toLowerCase());
        const fileType = file.type.toLowerCase();
        const fileName = file.name.toLowerCase();
        return !acceptedValues.some((item) => {
            if (item.includes('/*')) {
                return item.split('/')[0] === fileType.split('/')[0];
            }
            if (item[0] === '.') {
                return fileName.endsWith(item);
            }
            return item === fileType;
        });
    }
    _invalidFileSize(file) {
        if (!this.max)
            return false;
        return file.size > this.max;
    }
    validateFile(file) {
        if (this._invalidFileType(file))
            file.error = 'Invalid file type';
        if (this._invalidFileSize(file))
            file.error = 'Invalid file size';
        if (this.queue.length &&
            this.queue.some(({ file: { name, size } }) => {
                return name === file.name && size === file.size;
            }))
            return false;
        return file;
    }
    /** @param {!Array<!File>} files */
    _processFiles(files) {
        this.loading = true;
        this.error = '';
        if (files.length === 0) {
            this.loading = false;
            return;
        }
        const filesToQueue = (this.multiple ? files : [files[0]]).map(this.validateFile.bind(this)).filter(Boolean);
        if (!this.multiple && filesToQueue[0].error) {
            this.error = `${filesToQueue[0].error}, please select another file.`;
            this.loading = false;
            return;
        }
        const queuedFiles = filesToQueue.map((file) => new UploadFile(file, this.name));
        this.queue = this.multiple ? [...this.queue, ...queuedFiles] : queuedFiles;
        if (this.multiple && this.queue.some(({ file }) => file.error)) {
            this.error = 'One or more files are invalid. Invalid files will not be uploaded.';
        }
        setTimeout(() => {
            this.loading = false;
            this.queue.forEach((file) => {
                file.loaded = true;
            });
            this.dispatchChange();
        }, 500);
    }
    /** @param {!UploadFile} uploadFile */
    removeFile(uploadFile) {
        this.queue = this.queue.filter((item) => item !== uploadFile);
        if (!this.queue.some(({ file }) => file.error)) {
            this.error = '';
        }
        this.dispatchChange();
    }
    dispatchChange() {
        /** @type {import('../js/utils/types.js').InputFileListEvent} */
        const changeEvent = new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: this.queue.filter((item) => !item.file.error),
        });
        this.dispatchEvent(changeEvent);
    }
    _handleDrop(event) {
        event.preventDefault();
        this._processFiles([].slice.call(event.dataTransfer.files));
    }
    _handleDragEvent(event) {
        event.preventDefault();
    }
    _handleButtonClick() {
        const clickEvent = new MouseEvent('click', {
            bubbles: true,
            cancelable: false,
            view: window,
        });
        this.fileInput.dispatchEvent(clickEvent);
    }
    renderLabel() {
        return html `
      <label
        for="file-uploader"
        class="label">
        ${this.label}
        ${this.required && !this.hideRequiredIndicator ? html ` <span class="required-indicator">*</span> ` : ''}
      </label>
    `;
    }
    renderHelperText() {
        return html ` <p class="helper-text">${this.helpText}</p> `;
    }
    renderFilePreview(item) {
        if (!this.multiple && ((item.file || {}).type || '').split('/')[0] === 'image') {
            return html `
        <div class="image-info">
          <img
            src="${URL.createObjectURL(item.file)}"
            alt="${(item.file || {}).name}" />
          <button
            type="button"
            @click=${() => this.removeFile(item)}
            class="delete-button button-reset"
            aria-label="remove file">
            <jha-icon-delete></jha-icon-delete>
          </button>
        </div>
      `;
        }
        return html `
      <div
        class="file-info"
        title=${(item.file || {}).name}
        ?error=${item.file.error}>
        <jha-icon-file></jha-icon-file>
        <div class="file-details">
          <span>${(item.file || {}).name}</span>
          <span class="file-size"> ${bytesToFormattedFilesize(item.file.size)} </span>
        </div>
        <button
          type="button"
          @click=${() => this.removeFile(item)}
          class="delete-button button-reset"
          aria-label="remove file">
          <jha-icon-delete></jha-icon-delete>
        </button>
      </div>
      ${item.file.error
            ? html `
            <p
              aria-live="polite"
              class="error">
              ${item.file.error}
            </p>
          `
            : ''}
    `;
    }
    renderFileList() {
        if (!this.queue.length)
            return '';
        return html `
      <div
        class="files"
        ?file-list=${this.queue.length > 1}>
        ${this.queue.map((item) => (item.loaded ? this.renderFilePreview(item) : ''))}
      </div>
    `;
    }
    renderUploadButton() {
        const buttonClasses = () => ({
            'button-reset': true,
            'upload-button': true,
            'upload-more': this.queue.length && this.multiple,
        });
        if (!this.multiple && this.loading)
            return html ` <jha-progress></jha-progress> `;
        if (this.queue.length && !(this.queue.length && this.multiple))
            return '';
        return html `
      <button
        class=${classMap(buttonClasses())}
        type="button"
        @click=${this._handleButtonClick}>
        ${this.loading
            ? html ` <jha-progress></jha-progress> `
            : html `
              <slot name="icon">
                <jha-icon-upload></jha-icon-upload>
              </slot>
              <slot name="text">
                <p>${this.text}</p>
              </slot>
            `}
      </button>
    `;
    }
    renderFileUploader() {
        return html `
      <div
        class="drop-zone"
        @drop=${this._handleDrop}
        @dragend=${this._handleDragEvent}
        @dragover=${this._handleDragEvent}
        @dragenter=${this._handleDragEvent}
        @dragleave=${this._handleDragEvent}>
        ${this.queue.length ? this.renderFileList() : ''} ${this.renderUploadButton()}
      </div>
      <input
        id="file-uploader"
        type="file"
        ?multiple=${this.multiple}
        name=${this.name}
        accept=${this.accept}
        @change=${this._onFileInputChange} />
    `;
    }
    render() {
        return html `
      ${this.label ? this.renderLabel() : ''} ${this.helpText ? this.renderHelperText() : ''}
      <div class="container">${this.renderFileUploader()}</div>
      ${this.error
            ? html `
            <p
              aria-live="polite"
              class="error">
              ${this.error}
            </p>
          `
            : ''}
    `;
    }
}
export { styles as JhaFileUploaderStyles };
