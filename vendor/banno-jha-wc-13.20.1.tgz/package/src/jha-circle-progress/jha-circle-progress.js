import JhaCircleProgress from './JhaCircleProgress.js';
customElements.define('jha-circle-progress', JhaCircleProgress);
/** @customElement jha-circle-progress */
export default JhaCircleProgress;
