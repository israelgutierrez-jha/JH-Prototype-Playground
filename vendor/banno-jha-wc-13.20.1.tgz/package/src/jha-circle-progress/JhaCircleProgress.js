import { LitElement, html, css } from 'lit';
/**
 * A JHA Design circle progress component
 * A small circular chart of a percentage value
 *
 * * @element jha-circle-progress
 *
 * CSS VARIABLES
 *
 * @cssprop --jha-circle-progress-size - The size of the component
 * @cssprop --jha-circle-progress-track-thickness - the thickness of the background circle
 * @cssprop --jha-progress-track-color - the color of the background circle
 * @cssprop --jha-circle-progress-thickness - the thickness of the filled area
 * @cssprop --jha-circle-progress-color - the color of the filled area
 *
 */
export default class JhaCircleProgress extends LitElement {
    static get properties() {
        return {
            // value should be a percentage.  i.e. a number between 0 and 100 (inclusive)
            value: {
                type: Number,
            },
            label: {
                type: String,
            },
            showValueText: {
                type: Boolean,
            },
        };
    }
    constructor() {
        super();
        this.value = null;
        this.label = null;
        this.showValueText = false;
    }
    updated() {
        this.updateVariables();
    }
    connectedCallback() {
        super.connectedCallback();
        this.updateVariables();
    }
    updateVariables() {
        // makes sure the circle doesn't try to render values
        // below 0 or above 100, because that messes up the rotation math
        const clampedValue = Math.min(Math.max(this.value, 0), 100);
        const wrapperClip = clampedValue < 50 ? 'polygon(50% 0, 100% 0, 100% 100%, 50% 100%)' : 'auto';
        const leftRotate = `rotate(${this.percentageToDegrees(clampedValue)}deg)`;
        const rightRotate = `rotate(${Math.min(this.percentageToDegrees(clampedValue), 180)}deg)`;
        this.style.setProperty('--wrapper-clip', wrapperClip);
        this.style.setProperty('--left-rotate', leftRotate);
        this.style.setProperty('--right-rotate', rightRotate);
    }
    percentageToDegrees(percentage) {
        return 360 * (percentage / 100);
    }
    static get styles() {
        return css `
      :host {
        display: block;
        position: relative;
        text-align: center;
      }
      div.container {
        width: var(--jha-circle-progress-size, 36px);
        height: var(--jha-circle-progress-size, 36px);
        position: relative;
        margin: 0 auto;
      }
      .wrapper {
        position: absolute;
        inset: 0;
        clip-path: var(--wrapper-clip);
        border-radius: 50%;
      }
      .under-circle {
        position: absolute;
        inset: 0;
        border-radius: 50%;
        box-sizing: border-box;
        border: var(--jha-circle-progress-track-thickness, 1px) solid
          var(--jha-progress-track-color, var(--body-text-secondary-color, var(--jha-color-gray-medium)));
      }
      .circle {
        position: absolute;
        inset: 0;
        box-sizing: border-box;
        border: var(--jha-circle-progress-thickness, 3px) solid
          var(--jha-circle-progress-color, var(--jha-color-success, var(--body-text-completed-color, green)));
        border-radius: 50%;
        clip-path: polygon(0 0, 50% 0, 50% 100%, 0 100%);
      }
      .circle.left {
        transform: var(--left-rotate);
      }
      .circle.right {
        transform: var(--right-rotate);
      }
      .text-content {
        margin-top: 4px;
        color: var(--jha-circle-progress-label-color);
        font-size: var(--jha-circle-progress-label-size, 12px);
      }
    `;
    }
    render() {
        return html `
      <div class="container">
        <div class="under-circle"></div>
        <div class="wrapper">
          <div class="circle left"></div>
          <div class="circle right"></div>
        </div>
      </div>
      ${this.label || this.showValueText
            ? html `
            <div class="text-content">
              ${this.label ? html ` <div class="progress-label">${this.label}</div> ` : ''}
              ${this.showValueText ? html ` <div class="progress-label">${this.value}%</div> ` : ''}
            </div>
          `
            : ''}
    `;
    }
}
