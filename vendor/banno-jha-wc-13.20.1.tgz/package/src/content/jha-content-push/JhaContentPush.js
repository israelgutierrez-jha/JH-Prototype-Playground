import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
const styles = css `
  :host {
    display: block;
    margin-left: var(--jha-content-push-margin-left, 64px);
  }
  :host([x-small]) {
    margin-left: var(--jha-content-push-margin-left, 40px);
  }
  :host([small]) {
    margin-left: var(--jha-content-push-margin-left, 52px);
  }
  :host([large]) {
    margin-left: var(--jha-content-push-margin-left, 88px);
  }
  :host([x-large]) {
    margin-left: var(--jha-content-push-margin-left, 112px);
  }
`;
/**
 * A sub component of the jha-content component used to place text around a thumbnail.
 * @element jha-content-push
 * @slot unnamed slot for content
 */
export default class JhaContentPush extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    render() {
        return html ` <slot></slot> `;
    }
}
export { styles as JhaContentPushStyles };
