import JhaContentPush from './JhaContentPush.js';
customElements.define('jha-content-push', JhaContentPush);
/** @customElement jha-content-push */
export default JhaContentPush;
