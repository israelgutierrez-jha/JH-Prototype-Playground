import JhaContentHeading from './JhaContentHeading.js';
customElements.define('jha-content-heading', JhaContentHeading);
/** @customElement jha-content-heading */
export default JhaContentHeading;
