import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
const styles = css `
  :host {
    display: inline-flex;
    justify-content: flex-start;
    align-items: center;
  }
  :host ::slotted(jha-thumbnail),
  :host ::slotted(jha-avatar) {
    margin-right: 16px;
  }
`;
/**
 * A sub component of the jha-content component used to include a thumbnail or avatar along with a title of the content section.
 *
 * Typical usage:
 *
 *     <body>
 *       <jha-content-heading>
 *         <jha-thumbnail></jha-thumbnail>
 *         <div>...</div>
 *      </jha-content-heading>
 *
 * @element jha-content-heading
 *
 * @slot unnamed slot for content
 */
export default class JhaContentHeading extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    render() {
        return html ` <slot></slot> `;
    }
}
export { styles as JhaContentHeadingStyles };
