import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
const styles = css `
  :host {
    display: block;
    padding-top: 16px;
    margin-bottom: 16px;
  }
`;
/**
 * A JHA Design content component used on Platform apps as a page-wide container to set spacing at the top level of a view.
 *
 * @element jha-content
 *
 * @slot unnamed slot for content
 */
export default class JhaContent extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    render() {
        return html ` <slot></slot> `;
    }
}
export { styles as JhaContentStyles };
