import JhaContent from './JhaContent.js';
customElements.define('jha-content', JhaContent);
/** @customElement jha-content */
export default JhaContent;
