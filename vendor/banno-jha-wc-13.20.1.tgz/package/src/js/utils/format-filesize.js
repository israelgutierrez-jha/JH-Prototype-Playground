const units = ['bytes', 'kB', 'MB', 'GB', 'TB', 'PB'];
export default function bytesToFormattedFilesize(bytes, precision = 1) {
    if (bytes <= 0) {
        return `0 ${units[0]}`;
    }
    const number = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
    return `${(bytes / 1024 ** number).toFixed(precision)} ${units[number]}`;
}
