import { html } from 'lit';
import { format, isThisYear, isSameDay, isAfter, isBefore, endOfDay } from 'date-fns';
import { formatCurrency, isPositive } from './format-currency.js';
import { maybeFormatPhone } from './phone-numbers.js';
import { JhaTableFilterType } from '../../tables/advanced/jha-table-filter/JhaTableFilter.js';
import '../../jha-badge/jha-badge.js';
/** @enum {string} */
const DataType = {
    BADGE: 'badge',
    CURRENCY: 'currency',
    CURRENCY_DEBIT: 'currency-debit',
    NUMBER: 'number',
    DATE: 'date',
    DATE_PRETTY: 'date-pretty',
    DATE_TIME: 'date-time',
    PHONE: 'phone',
};
/** @typedef {import('../../tables/advanced/jha-advanced-table/jha-advanced-table.types.js').BadgeMap} BadgeMap */
/**
 * @typedef {object} dataRenderObject
 * @property {function} valueRenderer
 * @property {function} valueFormatter
 * @property {DataType} dataType
 * @property {BadgeMap=} badgeMap
 * @property {string=} trueString
 * @property {string=} falseString
 */
/**
 *
 * @param {string} value
 * @param {BadgeMap} badgeMap
 * @returns
 */
const renderBadge = (value, badgeMap) => {
    if (!value)
        return '';
    const [, badgeStyle] = badgeMap.find((item) => item[0] === value) || ['', 'neutral'];
    return html ` <jha-badge appearance=${badgeStyle}>${value}</jha-badge> `;
};
const renderCurrencyDebits = (value) => {
    return html `
    <span
      debit
      ?is-positive=${isPositive(value)}>
      ${formatCurrency(value, true, true)}
    </span>
  `;
};
const dateFormat = (value, longFormat) => {
    if (!value)
        return '';
    const DATE = new Date(value);
    if (!(DATE instanceof Date) || Number.isNaN(DATE.valueOf())) {
        return value;
    }
    if (longFormat) {
        return isThisYear(DATE) ? format(DATE, 'MMM d') : format(DATE, 'MMM d, yyyy');
    }
    return isThisYear(DATE) ? format(DATE, 'MM/dd') : format(DATE, 'MM/dd/yyyy');
};
const dateFormatTime = (value) => {
    if (!value)
        return '';
    const DATE = new Date(value);
    if (!(DATE instanceof Date) || Number.isNaN(DATE.valueOf())) {
        return value;
    }
    return format(DATE, "M/dd/yyyy 'at' HH:mm aaaa");
};
const getNestedValue = (item, path) => {
    const pathArray = path.split('.');
    return pathArray.reduce((acc, key) => acc?.[key], item || {});
};
const convertBooleanToString = (value, trueString, falseString) => {
    if (value === true) {
        return trueString;
    }
    return falseString;
};
const formatNumberUS = (value) => {
    const numberDisplay = new Intl.NumberFormat('en-US').format(value);
    if (numberDisplay === 'NaN') {
        return value;
    }
    return numberDisplay;
};
const renderDataType = (value, dataType, badgeMap, trueString, falseString) => {
    if (typeof value === 'boolean' && trueString && falseString) {
        value = convertBooleanToString(value, trueString, falseString);
    }
    switch (dataType) {
        case DataType.BADGE:
            return renderBadge(value, badgeMap);
        case DataType.CURRENCY:
            return formatCurrency(value);
        case DataType.CURRENCY_DEBIT:
            return renderCurrencyDebits(value);
        case DataType.DATE:
            return dateFormat(value);
        case DataType.DATE_PRETTY:
            return dateFormat(value, true);
        case DataType.DATE_TIME:
            return dateFormatTime(value);
        case DataType.PHONE:
            return maybeFormatPhone(value);
        case DataType.NUMBER:
            return formatNumberUS(value);
        default:
            return value;
    }
};
/**
 * @param {any} item
 * @param {string} id
 * @param {dataRenderObject} dataObject
 * @returns {!string}
 */
const getValueFromObject = (item, id, { dataType, badgeMap, valueRenderer, valueFormatter, trueString, falseString }) => {
    let value = getNestedValue(item, id);
    if ([null, undefined, ''].includes(value))
        return '—';
    const renderedValue = valueRenderer && valueRenderer(value, item);
    if (renderedValue) {
        return renderedValue;
    }
    if (valueFormatter) {
        const formattedValue = valueFormatter(value, item) ?? undefined;
        if (formattedValue !== undefined && formattedValue !== '') {
            return formattedValue;
        }
    }
    return renderDataType(value, dataType, badgeMap, trueString, falseString);
};
/**
 * @param {any} value
 * @param {any} item
 * @param {dataRenderObject} dataRenderObject
 * @returns {!string}
 */
const getValueString = (value, item, { dataType, badgeMap, valueFormatter, trueString, falseString }) => {
    if (typeof value === 'boolean' && trueString && falseString) {
        value = convertBooleanToString(value, trueString, falseString);
    }
    if (value === null || value === undefined || value === '') {
        return '';
    }
    if (dataType && dataType === DataType.CURRENCY_DEBIT) {
        return formatCurrency(value, true, true);
    }
    if (valueFormatter) {
        return valueFormatter(value, item);
    }
    if (dataType && dataType !== DataType.BADGE) {
        return renderDataType(value, dataType, badgeMap, trueString, falseString);
    }
    return value;
};
/**
 * Gets an array of filter property keys that have values
 * @param {Object} filters - The filters object
 * @returns {string[]} Array of filter property keys with values
 */
const getFilterProps = (filters) => {
    return Object.entries(filters || {})
        .filter(([, item]) => Boolean(item.value?.length))
        .map(([prop]) => prop);
};
/**
 * Checks if a numeric value is within a range
 * @param {string[]} range - Array with [min, max] values (empty string means no limit)
 * @param {string} value - The value to check
 * @returns {boolean} True if value is within range
 */
const rangeIncludes = (range, value) => {
    const val = Math.abs(parseFloat(value));
    if (range.length === 1) {
        return val === parseFloat(range[0]);
    }
    const isGreaterThanMin = !range[0] || val >= parseFloat(range[0]);
    const isLessThanMax = !range[1] || val <= parseFloat(range[1]);
    return isGreaterThanMin && isLessThanMax;
};
/**
 * Checks if a date is within a date range
 * @param {(Date|string|null)[]} dates - Array with [startDate, endDate]
 * @param {string} value - The date value to check
 * @returns {boolean} True if date is within range
 */
const dateInRange = (dates, value) => {
    const [startDate, endDate] = dates;
    if (dates.length === 1) {
        return isSameDay(startDate, value);
    }
    if (!startDate)
        return isBefore(value, endOfDay(endDate)) || isSameDay(endDate, value);
    if (!endDate)
        return isAfter(value, startDate) || isSameDay(startDate, value);
    return isAfter(value, startDate) && isBefore(value, endOfDay(endDate));
};
/**
 * Checks if a string value is in a list (case insensitive)
 * @param {string[]} list - Array of allowed values
 * @param {string} value - The value to check
 * @returns {boolean} True if value is in list
 */
const listIncludesString = (list, value) => {
    return list.map((i) => i.toLocaleLowerCase()).includes(value?.toLocaleLowerCase());
};
/**
 * Checks if any value in an array is in a list (case insensitive)
 * @param {string[]} list - Array of allowed values
 * @param {string[]} value - Array of values to check
 * @returns {boolean} True if any value is in list
 */
const listIncludesArray = (list, value) => {
    return list.map((i) => i.toLocaleLowerCase()).some((type) => value.map((i) => i.toLocaleLowerCase()).includes(type));
};
/**
 * Checks if an item value matches a filter value
 * @param {string} filterValue - The filter value
 * @param {string|boolean} itemValue - The item value to check
 * @param {string} prop - The property name
 * @param {Array} columns - Array of column definitions
 * @returns {boolean} True if item matches filter
 */
const itemMatchesFilter = (filterValue, itemValue, prop, columns) => {
    const column = columns.find((item) => item.id === prop);
    let value = itemValue;
    if (column?.trueString && column?.falseString) {
        value = itemValue ? column.trueString : column.falseString;
    }
    // Ensure value is a string
    const stringValue = String(value);
    return filterValue.toLocaleLowerCase() === stringValue.toLocaleLowerCase();
};
/**
 * Checks if a data item matches all active filters
 * @param {Object} item - The data item to check
 * @param {Object} filters - The filters object
 * @param {Array} columns - Array of column definitions
 * @returns {boolean} True if item matches all filters
 */
const filterMatches = (item, filters, columns) => {
    const filterProps = getFilterProps(filters);
    return filterProps.every((prop) => {
        const filter = filters[prop];
        const { filterType } = filter;
        const value = filter.value;
        const itemValue = getNestedValue(item, prop);
        switch (filterType) {
            case JhaTableFilterType.RANGE:
                return rangeIncludes(value, itemValue);
            case JhaTableFilterType.DATE:
                return dateInRange(value, itemValue);
            case JhaTableFilterType.LIST:
                if (Array.isArray(itemValue)) {
                    return listIncludesArray(value, itemValue);
                }
                return listIncludesString(value, itemValue);
            case JhaTableFilterType.SINGLE_SELECTION:
                return itemMatchesFilter(value[0], itemValue, prop, columns);
            case JhaTableFilterType.STRING:
                return (typeof itemValue === 'string' &&
                    value.some((val) => itemValue.toLocaleLowerCase().includes(`${val}`.toLocaleLowerCase())));
            default:
                return true;
        }
    });
};
export { DataType, renderDataType, getValueString, getNestedValue, getValueFromObject, getFilterProps, rangeIncludes, dateInRange, listIncludesString, listIncludesArray, itemMatchesFilter, filterMatches, };
