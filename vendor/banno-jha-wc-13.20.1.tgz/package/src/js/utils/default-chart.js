const defaultType = 'pie';
const defaultOptions = {
    plugins: {
        datalabels: {
            display: (value, ctx) => {
                let sum = 0;
                const dataArr = ctx.chart.data.datasets[0].data;
                dataArr.map((data) => {
                    sum += data;
                });
                // eslint-disable-next-line prefer-template
                const percentage = ((value * 100) / sum).toFixed(2) + '%';
                return percentage;
            },
            borderColor: 'white',
            borderRadius: 25,
            borderWidth: 2,
            color: 'white',
        },
        legend: {
            position: 'top',
            align: 'start',
            labels: {
                boxWidth: 14,
                boxHeight: 14,
            },
            title: {
                display: true,
            },
        },
    },
};
const defaultData = {
    labels: ['Label One', 'Label Two', 'Label Three', 'Label Four', 'Label Five'],
    datasets: [
        {
            label: 'Asset Class',
            data: [30467, 32678, 75020, 91303, 65242],
            borderWidth: 1,
            backgroundColor: ['#CB4335', '#1F618D', '#F1C40F', '#27AE60', '#884EA0', '#D35400'],
        },
    ],
};
export { defaultType, defaultOptions, defaultData };
