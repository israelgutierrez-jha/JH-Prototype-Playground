import { compareAsc, compareDesc } from 'date-fns';
import { DataType, getNestedValue } from './data-rendering-util.js';
/**
 * @typedef {Object} filterProp
 * @property {!string} id
 * @property {!Array<!string>} values
 */
/**
 * @template T
 * @param {!Array<T>} data
 * @param {!string} property
 * @param {boolean=} descending
 * @returns {!Array<T>}
 */
const sortAlphabeticallyByProperty = (data = [], property = '', descending = false) => {
    return data.sort((a, b) => {
        const aProp = a[property] || '';
        const bProp = b[property] || '';
        const floatA = parseFloat(aProp || 0);
        const floatB = parseFloat(bProp || 0);
        // Sort numbers
        if (!Number.isNaN(floatA) && !Number.isNaN(floatB) && /^[\d$,\-+.]*/.test(`${aProp}${bProp}`)) {
            return descending ? floatB - floatA : floatA - floatB;
        }
        // Sort dates
        const aDate = Date.parse(aProp);
        const bDate = Date.parse(bProp);
        if (!Number.isNaN(Date.parse(aProp)) && !Number.isNaN(Date.parse(bProp))) {
            return descending ? bDate - aDate : aDate - bDate;
        }
        return descending ? bProp.localeCompare(aProp) : aProp.localeCompare(bProp);
    });
};
/**
 * @param {string|number?} unParsedNumber
 * @returns {!number}
 */
const getFloat = (unParsedNumber) => {
    const value = unParsedNumber || 0;
    return parseFloat(`${value}`.replace(/[^0-9.-]+/g, ''));
};
/**
 * @param {Array<Object>} data
 * @param {!string} property
 * @param {DataType|string=} dataType
 * @param {boolean} descending
 * @returns
 */
const sortTableData = (data = [], property = '', dataType = 'string', descending = false) => {
    let sortFunction;
    switch (dataType) {
        case DataType.CURRENCY:
        case DataType.CURRENCY_DEBIT:
        case DataType.NUMBER:
            sortFunction = (a, b) => {
                const floatA = getFloat(a);
                const floatB = getFloat(b);
                if (Number.isNaN(floatA) && Number.isNaN(floatB)) {
                    return descending ? b.localeCompare(a) : a.localeCompare(b);
                }
                if (Number.isNaN(floatA))
                    return descending ? 1 : -1;
                if (Number.isNaN(floatB))
                    return descending ? -1 : 1;
                return descending ? floatB - floatA : floatA - floatB;
            };
            break;
        case DataType.DATE:
        case DataType.DATE_PRETTY:
        case DataType.DATE_TIME:
            sortFunction = (a, b) => (descending ? compareDesc(a, b) : compareAsc(a, b));
            break;
        default:
            sortFunction = (a, b) => (descending ? b.localeCompare(a) : a.localeCompare(b));
    }
    return data.slice(0).sort((itemA, itemB) => {
        const aProp = getNestedValue(itemA, property);
        const bProp = getNestedValue(itemB, property);
        const a = parseValue(aProp);
        const b = parseValue(bProp);
        return sortFunction(a, b);
    });
};
/**
 * @param {any} prop
 * @returns {string}
 */
const parseValue = (prop) => {
    if (typeof prop === 'boolean') {
        return prop ? '1' : '0';
    }
    if (Array.isArray(prop)) {
        return prop.join(',');
    }
    return prop ?? '';
};
/**
 * @template T
 * @param {!Array<T>} data
 * @param {Array<filterProp>=} filterProperties
 * @returns {!Array<T>}
 */
const filterByPropertyValues = (data = [], filterProperties = []) => {
    if (!filterProperties.length)
        return data;
    return data.filter((item) => filterProperties.some((filterProp) => filterProp.values.includes(getNestedValue(item, filterProp.id))));
};
const valueChanged = (oldValue, newValue) => {
    if (oldValue === newValue)
        return false;
    if (Array.isArray(oldValue) && Array.isArray(newValue)) {
        return oldValue.length !== newValue.length || !oldValue.every((val, i) => val === newValue[i]);
    }
    return JSON.stringify(oldValue) !== JSON.stringify(newValue);
};
export { sortAlphabeticallyByProperty, filterByPropertyValues, sortTableData, DataType, valueChanged };
