const formatter = new Intl.NumberFormat('en-us', {
    style: 'decimal',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
    minimumIntegerDigits: 1,
});
const wholeNumberFormatter = new Intl.NumberFormat('en-us', {
    style: 'decimal',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
    minimumIntegerDigits: 1,
});
/**
 * @param {?number} amount
 * @param {boolean} showPositiveSign
 * @param {boolean} hideNegativeSign
 * @returns {string}
 * @private
 */
function getSign(amount, showPositiveSign, hideNegativeSign) {
    if (amount === null || amount === undefined || amount === 0) {
        return '';
    }
    if (amount < 0) {
        return hideNegativeSign ? '' : '-';
    }
    return showPositiveSign ? '+' : '';
}
/**
 * @param {string|number|null|undefined} amount
 * @returns {number}
 * @private
 */
function parseCurrencyAsFloat(amount) {
    if (amount === null || amount === undefined) {
        return NaN;
    }
    if (typeof amount === 'number') {
        return amount;
    }
    return parseFloat(amount.replace(/[$,]/g, ''));
}
/**
 * @param {string|number|null|undefined} amount
 * @returns {boolean}
 */
function isPositive(amount) {
    const amountValue = parseCurrencyAsFloat(amount);
    return amountValue > 0;
}
/**
 * Given a number or currency string, returns a formatted string with two decimal places thousands
 * separators. By default the sign (either negative or positive) is omitted.
 * @see https://docs.banno.com/consumer-api/about/currency/#transactions
 *
 * @param {string|number|null|undefined} amount The amount
 * @param {boolean} showPositiveSign Whether positive amounts should be prefixed with '+'
 * @param {boolean} hideNegativeSign Whether negative numbers should be prefixed with '-'
 * @param {boolean=} hideWholeAmountDecimal
 * @returns {string}
 */
const formatCurrency = (amount, showPositiveSign = false, hideNegativeSign = true, hideWholeAmountDecimal = false) => {
    let amountString;
    let amt = parseCurrencyAsFloat(amount);
    if (Number.isNaN(amt) || !Number.isFinite(amt)) {
        return '-.--';
    }
    const sign = getSign(amt, showPositiveSign, hideNegativeSign);
    amt = Math.abs(amt);
    if (amt % 1 === 0 && hideWholeAmountDecimal) {
        amountString = wholeNumberFormatter.format(amt);
    }
    else {
        amountString = formatter.format(amt);
    }
    return `${sign}$${amountString}`;
};
export { formatCurrency, isPositive };
