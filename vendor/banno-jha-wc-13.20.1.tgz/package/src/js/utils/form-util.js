/**
 * @param {string} prop
 * @param {any} value
 * @returns {Record<string, any>}
 */
export const createPropertyObject = (prop, value) => {
    const propArray = prop.split('.');
    return propArray.reverse().reduce((acc, key, index) => {
        if (index === 0) {
            return { ...acc, ...{ [key]: value ?? '' } };
        }
        return { [key]: acc };
    }, {});
};
/**
 * @param {Record<string, any>} obj
 * @param {string} prop
 * @returns {any}
 */
export const getNestedValue = (obj, prop) => {
    const propArray = prop.split('.');
    return propArray.reduce((acc, key) => acc?.[key], obj || {});
};
