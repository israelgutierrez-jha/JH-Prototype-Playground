var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { property } from 'lit/decorators.js';
import { createPropertyObject, getNestedValue } from '../utils/form-util.js';
import { deepEquals, deepMerge } from '@jkhy/frontend-utils/functions/object.helpers.js';
const formElementMixin = (superClass) => {
    class FormElement extends superClass {
        constructor() {
            super(...arguments);
            this.formData = {};
            this.cacheId = '';
            this.formValid = false;
            this.formDirty = false;
            this._defaultFormData = {};
        }
        disconnectedCallback() {
            super.disconnectedCallback();
            if (this.submitButton) {
                this.submitButton.removeEventListener('keydown', this.onFormEnter);
                this.submitButton.removeEventListener('click', this.submitFormData);
            }
        }
        firstUpdated() {
            this._defaultFormData = this.formData;
            const cachedData = window.sessionStorage.getItem(this.cacheId);
            if (this.cacheId && cachedData) {
                this.formData = JSON.parse(cachedData);
                this.validateForm();
            }
            this.setFormEnterEvent();
        }
        updated(changedProperties) {
            if (!changedProperties.has('formData')) {
                return;
            }
            this.validateForm();
        }
        resetFormData(newDefault) {
            // Update stored defaults if passed
            if (newDefault) {
                this._defaultFormData = newDefault;
            }
            this.formData = { ...{}, ...this._defaultFormData };
            this.formInputs.forEach((input) => {
                /* eslint-disable no-param-reassign */
                input.hasInteraction_ = false;
            });
        }
        async setFormEnterEvent() {
            await this.updateComplete;
            if (this.formElement && this.submitButton) {
                this.submitButton.addEventListener('keydown', this.onFormEnter);
                this.submitButton.addEventListener('click', this.submitFormData);
            }
        }
        onFormEnter(evt) {
            if (evt.key === 'Enter') {
                this.submitFormData();
            }
        }
        hasInternals(element) {
            try {
                element.attachInternals();
                return false; // If attachInternals doesn't throw, internals weren't attached before
            }
            catch (error) {
                return true; // If attachInternals throws, it's likely that internals are already attached
            }
        }
        submitFormData() {
            if (!this.formElement || !this.formValid) {
                return;
            }
            if (this.submitButton && this.hasInternals(this.submitButton)) {
                if (typeof this.formElement?.requestSubmit === 'function') {
                    // Use requestSubmit if available for native form submission including validation
                    this.formElement.requestSubmit();
                }
                else {
                    this.formElement?.dispatchEvent(new Event('submit', { cancelable: true }));
                }
            }
            else {
                this.formElement.dispatchEvent(new CustomEvent('submit', {
                    composed: true,
                    bubbles: true,
                    cancelable: true,
                }));
            }
        }
        inputValueChange(evt) {
            const { target, detail } = evt;
            const isCheckbox = Object.prototype.hasOwnProperty.call(detail || {}, 'checked');
            const newValue = isCheckbox
                ? detail.checked
                : detail?.value !== undefined
                    ? detail.value
                    : detail || target?.value;
            const prop = target.getAttribute('data-id');
            this.updateProperty(prop, newValue);
        }
        updateProperty(prop, newValue) {
            const value = newValue ?? '';
            const currentValue = getNestedValue(this.formData, prop);
            // Prevent unnecessary update
            if (value === currentValue) {
                return;
            }
            const newData = createPropertyObject(prop, value);
            this.formData = deepMerge(this.formData, newData);
        }
        get formInputs() {
            return Array.from(this.shadowRoot?.querySelectorAll('form [data-id]') ?? []);
        }
        /**
         * @returns {!HTMLElement}
         */
        get formElement() {
            return this.shadowRoot?.querySelector('form');
        }
        /**
         * @returns {!HTMLElement}
         */
        get submitButton() {
            const jhDesignButton = this.shadowRoot?.querySelector('jh-button[submit]');
            if (jhDesignButton) {
                return jhDesignButton;
            }
            return this.shadowRoot?.querySelector('[type="submit"]');
        }
        isFormValid() {
            // check all fields that have a checkValidity method
            return this.formInputs.every((i) => {
                if (typeof i.checkValidity === 'function') {
                    return i.checkValidity();
                }
                return this.checkDSInputValidity(i);
            });
        }
        checkDSInputValidity(input) {
            if (input.hasAttribute('invalid')) {
                return false;
            }
            if (input.required) {
                const prop = input.getAttribute('data-id');
                const value = prop && getNestedValue(this.formData, prop);
                if (value === '' || value === undefined) {
                    return false;
                }
            }
            return true;
        }
        isFormDirty() {
            return !deepEquals(this.formData, this._defaultFormData);
        }
        async validateForm() {
            await this.updateComplete;
            this.formValid = this.isFormValid();
            this.formDirty = this.isFormDirty();
            if (!this.cacheId)
                return;
            if (this.formDirty) {
                window.sessionStorage.setItem(this.cacheId, JSON.stringify(this.formData));
            }
            else {
                window.sessionStorage.removeItem(this.cacheId);
            }
        }
    }
    __decorate([
        property({ type: Object }),
        __metadata("design:type", Object)
    ], FormElement.prototype, "formData", void 0);
    __decorate([
        property({ type: String }),
        __metadata("design:type", String)
    ], FormElement.prototype, "cacheId", void 0);
    __decorate([
        property({ type: Boolean }),
        __metadata("design:type", Boolean)
    ], FormElement.prototype, "formValid", void 0);
    __decorate([
        property({ type: Boolean }),
        __metadata("design:type", Boolean)
    ], FormElement.prototype, "formDirty", void 0);
    return FormElement;
};
export default formElementMixin;
