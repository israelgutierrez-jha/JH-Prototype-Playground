import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../styles/jha-styles.js';
import '../dropdowns/jha-dropdown/jha-dropdown.js';
import '../dropdowns/jha-dropdown-toggle/jha-dropdown-toggle.js';
import '../dropdowns/jha-dropdown-menu/jha-dropdown-menu.js';
import '../dropdowns/jha-dropdown-menu-item/jha-dropdown-menu-item.js';
import '../forms/jha-form-checkbox/jha-form-checkbox.js';
import '../buttons/jha-button/jha-button.js';
/**
 * @typedef {Object} FilterOption
 * @property {!string} label
 * @property {!string} id
 * @property {boolean=} selected
 */
/**
 * @typedef {Object} FilterGroup
 * @property {!string} label
 * @property {!string} id
 * @property {Array<!FilterOption>} options
 */
const styles = css `
  :host {
    display: inline-block;
  }
  jha-dropdown-toggle {
    max-width: var(--jha-filter-menu-button-width, 200px);
    color: var(--jha-button-outline-text, var(--jha-color-neutral, #707070));
    background-color: var(--jha-button-outline-background, transparent);
    --jha-button-slotted-icon-fill-color: var(--jha-button-outline-text, var(--jha-text-light, #8c989f));
    height: var(--jha-filter-menu-button-height, 36px);
    border-radius: var(--jha-button-border-radius, 3px);
    padding: var(--jha-filter-menu-padding-vertical, var(--jha-button-padding-vertical, 0px))
      var(--jha-filter-menu-padding-horizontal, var(--jha-button-padding-horizontal, 18px));
    border: 1px solid var(--jha-filter-menu-border, var(--jha-button-outline-border, var(--jha-border-color, #e4e7ea)));
    gap: 8px;
  }
  .filter-list {
    max-height: var(--jha-filter-menu-max-height, none);
    overflow: scroll;
  }
  jha-icon-filter,
  ::slotted([slot='button-icon']) {
    --jha-icon-fill-color: var(--jha-color-neutral, #707070);
  }
  label {
    color: var(--jha-text-light);
    font-size: 12px;
    padding: 12px 16px 2px;
    display: block;
  }
  jha-dropdown-menu {
    padding-bottom: 8px;
  }
  jha-dropdown-menu[no-label] {
    padding-top: 8px;
  }
  jha-dropdown-menu-item {
    padding: 0;
  }
  jha-form-checkbox {
    display: block;
    padding: 0;
    --jha-form-checkbox-padding: 10px 16px;
  }
  footer {
    padding: 16px 0;
    margin: 16px 16px 0;
    display: flex;
    justify-content: center;
    gap: 8px;
    border-top: 1px solid var(--jha-button-outline-border, var(--jha-border-color, #e4e7ea));
  }
  :host([icon-only]) jha-dropdown-toggle {
    gap: 0;
  }
  @media (max-width: 480px) {
    .button-label {
      display: none;
    }
  }
`;
/**@element jha-filter-menu */
export default class JhaFilterMenu extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            filters: {
                type: Array,
            },
            buttonLabel: {
                type: String,
            },
            menuId: {
                type: String,
            },
            requireConfirmation: {
                type: Boolean,
            },
            openLeft: {
                type: Boolean,
            },
            open: {
                type: Boolean,
                reflect: true,
            },
        };
    }
    constructor() {
        super();
        import('../icons/jha-icon-filter.js');
        /** @type {Array<!FilterGroup>} */
        this.filters = [];
        this.buttonLabel = '';
        this.requireConfirmation = true;
        this.menuId = '';
        this.openLeft = false;
        this.open = false;
    }
    get dropDown() {
        return this.shadowRoot.querySelector('jha-dropdown');
    }
    dispatchChange() {
        this.dispatchEvent(new CustomEvent('change', {
            detail: { filters: this.filters, menuId: this.menuId },
            bubbles: true,
            composed: true,
        }));
    }
    handleKeyDown(evt) {
        if (evt.code !== 'Enter')
            return;
        const checkBox = evt.target && evt.target.querySelector('jha-form-checkbox');
        if (checkBox) {
            const input = checkBox.shadowRoot.querySelector('input');
            input.click();
        }
    }
    renderOptionItem(option) {
        if (!(option.label && option.id))
            return '';
        return html `
      <jha-dropdown-menu-item @keydown=${this.handleKeyDown}>
        <jha-form-checkbox
          .checked=${option.selected}
          .label=${option.label}
          .name=${option.id}
          @change=${(evt) => {
            evt.stopPropagation();
            option.selected = evt.detail.checked;
            this.requestUpdate();
            if (!this.requireConfirmation) {
                this.dispatchChange();
            }
        }}>
          ${option.label}
        </jha-form-checkbox>
      </jha-dropdown-menu-item>
    `;
    }
    clearSelected() {
        this.filters = this.filters.map((filter) => ({
            ...filter,
            ...{
                options: filter.options.map((opt) => ({
                    ...opt,
                    ...{ selected: false },
                })),
            },
        }));
        // dispatch change but don't close the menu
        this.dispatchChange();
    }
    applyFilters() {
        this.dispatchChange();
        if (this.dropDown) {
            this.dropDown.open = false;
        }
    }
    renderFilter(filter) {
        if (!(filter.options || []).length)
            return '';
        return html `
      ${this.filters.length === 1 ? '' : html ` <label>${filter.label}</label> `}
      ${filter.options.map((option) => this.renderOptionItem(option))}
    `;
    }
    render() {
        if (!this.filters.length)
            return '';
        return html `
      <jha-dropdown
        disableItemMenuClose
        @openDropdown=${() => {
            this.open = true;
        }}
        @closeDropdown=${() => {
            this.open = false;
        }}>
        <jha-dropdown-toggle
          slot="toggle"
          aria-label="Edit user">
          <slot name="filter-button">
            <div class="button-label">${this.buttonLabel}</div>
            <slot name="button-icon">
              <jha-icon-filter></jha-icon-filter>
            </slot>
          </slot>
        </jha-dropdown-toggle>
        <jha-dropdown-menu
          ?no-label=${this.filters.length === 1}
          .openLeft=${this.openLeft}>
          <slot name="filter-menu-header"></slot>
          <div class="filter-list">${this.filters.map((filter) => this.renderFilter(filter))}</div>
          <slot name="filter-menu-footer"></slot>
          ${this.requireConfirmation
            ? html `
                <footer tabindex="-1">
                  <jha-button
                    type="button"
                    sync
                    @click=${() => {
                this.applyFilters();
            }}>
                    Apply
                  </jha-button>
                  <jha-button
                    type="button"
                    sync
                    tertiary
                    @click=${() => {
                this.clearSelected();
            }}>
                    Clear filters
                  </jha-button>
                </footer>
              `
            : ''}
        </jha-dropdown-menu>
      </jha-dropdown>
    `;
    }
}
export { styles as JhaFilterMenuStyles };
