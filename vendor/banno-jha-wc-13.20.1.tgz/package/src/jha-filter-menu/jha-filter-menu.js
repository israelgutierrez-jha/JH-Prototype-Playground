import JhaFilterMenu from './JhaFilterMenu.js';
customElements.define('jha-filter-menu', JhaFilterMenu);
/** @customElement jha-filter-menu */
export default JhaFilterMenu;
