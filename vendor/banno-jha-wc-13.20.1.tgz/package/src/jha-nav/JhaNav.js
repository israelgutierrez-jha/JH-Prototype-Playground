import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../styles/jha-styles.js';
const styles = css `
  :host {
    display: block;
    padding-left: var(--jha-nav-left-padding, 0px);
    padding-top: var(--jha-nav-top-padding, 0px);
  }
  button[button-reset],
  :host ::slotted(a) {
    box-sizing: border-box;
    width: 100%;
    border-width: 0;
    cursor: pointer;
    text-align: left;
    display: flex;
    align-items: center;
    position: relative;
    outline: none;
    text-decoration: none;
    height: var(--jha-nav-link-height, 48px);
    padding: var(--jha-nav-link-padding, 0px 16px);
    margin: var(--jha-nav-link-margin, 0);
    font-size: var(--jha-nav-link-font-size, 16px);
    font-weight: var(--jha-nav-link-font-weight, 400);
    color: var(--jha-nav-link-color, var(--jha-menu-text-color));
    border-radius: var(--jha-nav-link-border-radius, 0);
    background-color: var(--jha-nav-link-background-color, transparent);

    --jha-icon-fill-color: var(--jha-menu-icon-color);
    --jha-icon-margin: 0 10px 0 0;
    --jha-icon-padding: 6px;
  }
  button[button-reset]:hover,
  :host ::slotted(a:focus),
  :host ::slotted(a:hover) {
    --jha-nav-link-color: var(--jha-menu-text-pressed-color);
    --jha-nav-link-background-color: var(--jha-menu-item-pressed-color);
    --jha-icon-fill-color: var(--jha-menu-icon-pressed-color);
  }

  :host ::slotted(a[active]),
  :host ::slotted(a:active) {
    --jha-nav-link-background-color: var(--jha-menu-item-selected-color);
    --jha-nav-link-color: var(--jha-menu-text-selected-color);
    --jha-nav-link-font-weight: 500;
    --jha-icon-fill-color: var(--jha-menu-icon-selected-color);
  }

  :host ::slotted(a[active]):before,
  :host ::slotted(a:active):before {
    content: '';
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    width: var(--jha-nav-link-active-indicator-width, 4px);
    background: var(--jha-nav-link-active-indicator-background-color, var(--jha-menu-item-selected-accent-color));
  }
  ::slotted([slot='header']) {
    display: flex;
    align-items: center;
    flex: 2;
  }
  :host([collapsible]) .nav-list {
    --jha-nav-link-padding: var(--jha-nav-sub-link-padding, 0px 16px 0 64px);
  }

  :host(:not([open])[collapsible]) .nav-list {
    display: none;
  }
  .nav-list {
    display: block;
  }

  jha-icon-chevron-down {
    --jha-icon-margin: 0;
    --jha-icon-padding: 0;
    --jha-icon-fill-color: var(--jha-menu-text-color);
    transition: transform 0.2s ease-in-out;
  }
  button[button-reset]:hover jha-icon-chevron-down {
    --jha-icon-fill-color: var(--jha-menu-icon-pressed-color);
  }
  :host([open]) jha-icon-chevron-down {
    transform: rotate(-180deg);
  }
`;
/**
 * JHA design for a navigation list
 *
 * @element jha-nav
 *
 * @prop {string} title - adds title attribute for semantic markup
 * @prop {boolean} collapsible - wether to show a open/close button in the nav
 * @prop {boolean} open - wether the menu is open or closed
 *
 * @slot unnamed - add a tags here with or without icons
 * @slot header - add a div with a name for the nav open button and an optional icon
 *
 * @cssprop
 * @cssprop --jha-nav-link-height - height of the nav links
 * @cssprop --jha-nav-link-padding - padding of the links
 * @cssprop --jha-nav-link-font-size - font-size of links
 * @cssprop --jha-nav-link-font-weight - font-weight of links
 * @cssprop --jha-nav-link-color - text color of links
 * @cssprop --jha-nav-link-background-color - background color of links, changes when active or hovered
 * @cssprop --jha-nav-link-active-indicator-width - active links have a border left, this is its width
 * @cssprop --jha-nav-link-active-indicator-background-color - active border color
 * @cssprop --jha-nav-sub-link-padding - sets the sub link items inset from the reset
 */
export default class JhaNav extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            title: {
                type: String,
            },
            collapsible: {
                type: Boolean,
                reflect: true,
            },
            open: {
                type: Boolean,
                reflect: true,
            },
        };
    }
    constructor() {
        super();
        import('../icons/jha-icon-chevron-down.js');
        // eslint-disable-next-line wc/no-constructor-attributes
        this.title = 'Navigation';
        this.collapsible = false;
        this.open = false;
    }
    render() {
        return html `
      <nav title=${this.title}>
        ${this.collapsible
            ? html `
              <button
                button-reset
                type="button"
                @click=${() => {
                this.open = !this.open;
            }}>
                <slot name="header"></slot>
                <jha-icon-chevron-down></jha-icon-chevron-down>
              </button>
            `
            : ''}
        <div class="nav-list">
          <slot></slot>
        </div>
      </nav>
    `;
    }
}
export { styles as JhaNavStyles };
