import JhaNav from './JhaNav.js';
customElements.define('jha-nav', JhaNav);
/** @customElement jha-nav */
export default JhaNav;
