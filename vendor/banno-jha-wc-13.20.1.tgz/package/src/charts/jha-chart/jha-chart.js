import JhaChart from './JhaChart.js';
customElements.define('jha-chart', JhaChart);
/** @customElement jha-chart */
export default JhaChart;
