import { LitElement, html, css } from 'lit';
import Chart from 'chart.js/auto';
import { jhaStyles } from '../../styles/jha-styles.js';
import { defaultOptions, defaultData, defaultType } from '../../js/utils/default-chart.js';
/**@element jha-chart */
export default class JhaChart extends LitElement {
    static get styles() {
        return [
            jhaStyles,
            css `
        :host {
          display: block;
          margin: 16px;
        }
      `,
        ];
    }
    static get properties() {
        return {
            data: {
                type: Object,
            },
            type: {
                type: String,
            },
            options: {
                type: Object,
            },
        };
    }
    constructor() {
        super();
        // customize the chart type, options and data. More info at https://www.chartjs.org/docs/latest/configuration/
        this.type = defaultType;
        this.options = defaultOptions;
        this.data = defaultData;
        this.chart = null;
    }
    drawChart() {
        if (!this.chart) {
            this.chart = this.createPieChart(this.type, this.options, this.data);
        }
        else {
            this.chart.options = this.options;
            this.chart.data.labels = this.data.labels;
            this.chart.data.datasets.forEach((d) => {
                const newData = this.data.datasets.find((ds) => ds.label === d.label);
                if (newData) {
                    d.data = newData.data;
                }
            });
            this.chart.update();
        }
    }
    updated() {
        this.drawChart();
    }
    createPieChart(type, options, newData) {
        const ctx = /** @type {HTMLCanvasElement} */ (this.shadowRoot.getElementById('myChart'));
        return new Chart(ctx, {
            type,
            data: newData,
            options,
        });
    }
    render() {
        return html ` <canvas id="myChart"></canvas> `;
    }
}
