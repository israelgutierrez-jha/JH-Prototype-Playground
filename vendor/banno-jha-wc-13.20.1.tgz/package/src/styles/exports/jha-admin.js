import { css } from 'lit';
export default css `
  * {
    --jha-background-color: #f8f8f8;
    --jha-border-color-hover: #d3d8dd;
    --jha-border-color: #e4e7ea;
    --jha-button-border-radius: 8px;
    --jha-color-danger: #db2012;
    --jha-color-dark: #191919;
    --jha-color-gray-light: #e6e6e6;
    --jha-color-light: #f0f5f9;
    --jha-color-muted: var(--jha-text-muted);
    --jha-color-neutral: #8d99a0;
    --jha-color-primary: #006ee4;
    --jha-color-success: #118315;
    --jha-color-warning: #c98702;
    --jha-component-background-color: #ffffff;
    --jha-focus-highlight-color: rgba(153, 153, 153, 0.12);
    --jha-card-box-shadow: 0 3px 12px 0 rgba(0, 0, 0, 0.15);
    --jha-text-base: #707070;
    --jha-text-danger: #db2012;
    --jha-text-dark: #191919;
    --jha-text-light: #8c989f;
    --jha-text-muted: #b0b0b0;
    --jha-text-neutral: #8d99a0;
    --jha-text-size-base: 14px;
    --jha-text-success: #118315;
    --jha-text-theme: var(--jha-color-primary);
    --jha-text-warning: #bb5c04;
    --jha-text-white: #ffffff;

    --jha-menu-text-color: var(--jha-text-dark);
    --jha-menu-icon-color: var(--jha-icon-color, var(--jha-text-base), #000);
    --jha-menu-text-pressed-color: var(--jha-text-dark);
    --jha-menu-item-pressed-color: var(--jha-color-gray-light);
    --jha-menu-icon-pressed-color: var(--jha-icon-color, var(--jha-text-base), #000);
    --jha-menu-item-selected-color: #dbe8fb;
    --jha-menu-text-selected-color: var(--jha-text-theme);
    --jha-menu-icon-selected-color: var(--jha-text-theme);
    --jha-menu-item-selected-accent-color: transparent;

    /** JHA to DS */
    --jh-color-container-primary-enabled: var(--jha-background-color);
    --jh-color-control-hover: var(--jha-border-color-hover);
    --jh-color-divider-primary: var(--jha-border-color);
    --jh-color-content-negative-enabled: var(--jha-color-danger);
    --jh-color-content-primary-enabled: var(--jha-color-dark);
    --jh-color-content-brand-enabled: var(--jha-color-primary);
    --jh-color-content-positive-enabled: var(--jha-color-success);
    --jh-color-content-negative-enabled: var(--jha-color-warning);
    --jh-color-container-primary-enabled: var(--jha-component-background-color);
    --jh-color-content-primary-enabled: var(--jha-text-base);

    --jha-currency-input-dollar-top: 46px;
    --jha-currency-input-dollar-no-label-top: 24px;
    --jha-currency-input-dollar-bottom: auto;
    --jha-currency-input-small-dollar-bottom: 4px;
    --jha-form-date-input-icon-top: auto;
    --jha-form-date-input-icon-bottom: 16px;
    --jha-slotted-input-top: auto;
    --jha-slotted-input-bottom: 12px;
    --jha-slotted-input-small-bottom: 10px;
    --jha-slotted-icon-left-position: 16px;
    --jha-slotted-icon-right-position: 16px;
    --jha-input-label-position: absolute;
    --jha-input-opacity-disabled: 0.7;
    --jha-input-label-pointer-events: none;

    --card-shadow: 0 3px 12px 0 rgba(0, 0, 0, 0.15);
    --jh-form-select-input-right-top: 30px;
  }
`;
