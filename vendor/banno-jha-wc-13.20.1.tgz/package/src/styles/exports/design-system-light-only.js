import { css } from 'lit';
import { jhaWcDesignSystemConversions, designSystemOverridesLight } from './design-system.js';
export default css `
  ${jhaWcDesignSystemConversions}
  ${designSystemOverridesLight}
`;
