import { css } from 'lit';
export const jhaWcDesignSystemConversions = css `
  * {
    --jha-background-color: var(--jh-color-container-primary-enabled);
    --jha-border-color-hover: var(--jh-color-control-hover);
    --jha-border-color: var(--jh-color-divider-primary);
    --jha-button-background-active: var(--jh-color-content-brand-active);
    --jha-button-background-hover: var(--jh-color-content-brand-hover);
    --jha-button-background: var(--jh-color-content-brand-enabled);
    --jha-button-border-radius: var(--jh-border-radius-200);
    --jha-button-danger-background: var(--jh-color-content-negative-enabled);
    --jha-button-font-weight: var(--jh-font-weight-500);
    --jha-button-line-height: var(--jh-size-1000);
    --jha-button-padding-horizontal: var(--jh-dimension-400);
    --jha-button-outline-danger-background-hover: var(--jh-color-content-negative-hover);
    --jha-button-default-background-active: var(--jh-color-content-brand-active);
    --jha-button-default-background-hover: var(--jh-color-content-brand-hover);
    --jha-button-link-text-hover: var(--jh-color-content-brand-hover);
    --jha-button-link-text: var(--jh-color-content-brand-enabled);
    --jha-button-neutral-background: var(--jh-color-container-secondary-enabled);
    --jha-button-outline-border: var(--jh-color-divider-primary);
    --jha-button-outline-text: var(--jh-color-content-brand-enabled);
    --jha-button-primary-background: var(--jh-color-content-brand-enabled);
    --jha-button-text: var(--jh-color-content-on-brand-enabled);
    --jha-button-toggle-text: var(--jh-color-content-secondary-enabled);

    --jha-button-group-background-hover: var(--jh-color-container-secondary-enabled);
    --jha-button-group-border-hover: var(--jh-color-container-secondary-enabled);
    --jha-button-group-active-background: var(
      --jh-button-color-background-secondary-hover,
      var(--jh-color-content-brand-hover)
    );
    --jha-button-group-text-color: var(--jh-color-content-secondary-enabled);
    --jha-button-group-active-text-color: var(--jh-color-content-on-brand-hover);
    --jha-button-group-border-color: var(--jh-color-content-secondary-enabled);
    --jha-button-group-active-border-color: var(
      --jh-button-color-background-secondary-hover,
      var(--jh-color-content-brand-hover)
    );

    --jha-card-article-margin-left: var(--jh-dimension-600);
    --jha-card-article-padding-right: var(--jh-dimension-600);
    --jha-card-border-radius: var(--jh-border-radius-400);
    --jha-card-header-margin-left: var(--jh-dimension-600);
    --jha-card-header-padding-right: var(--jh-dimension-600);
    --jha-color-danger: var(--jh-color-content-negative-enabled);
    --jha-color-dark: var(--jh-color-content-primary-enabled);
    --jha-color-light: var(--jh-color-container-primary-active);
    --jha-color-neutral: var(--jh-color-content-secondary-enabled);
    --jha-color-primary: var(--jh-color-content-brand-enabled);
    --jha-color-success: var(--jh-color-content-positive-enabled);
    --jha-color-warning: var(--jh-color-content-negative-enabled);
    --jha-component-background-color: var(--jh-color-container-page);
    --jha-date-picker-in-range-after: var(--jh-color-container-secondary-enabled);
    --jha-date-picker-in-range-before: var(--jh-color-container-secondary-enabled);
    --jha-date-picker-in-range: var(--jh-color-container-secondary-enabled);
    --jha-dropdown-menu-item-background-hover: var(--jh-color-container-primary-hover);
    --jha-dropdown-toggle-icon-color: var(--jh-color-content-secondary-enabled);
    --jha-focus-highlight-color: var(--jh-color-content-inverse-hover);
    --jha-form-checkbox-background-color: var(--jh-color-content-brand-active);
    --jha-form-checkbox-check-color: var(--jh-color-container-primary-enabled);
    --jha-form-floating-group-filled-background: var(--jh-color-container-secondary-enabled);
    --jha-form-radio-size: var(--jh-size-500);
    --jha-form-radio-margin-top: 0px;
    --jha-form-radio-checked-background-color: var(--jh-color-container-primary-enabled);
    --jha-form-radio-checked-dot-color: var(--jh-color-content-brand-enabled);
    --jha-form-radio-checked-dot-size: var(--jh-size-300);
    --jha-form-switch-active-color: var(--jh-color-content-brand-enabled);
    --jha-card-box-shadow: var(--jh-shadow-low);
    --jha-switch-shadow-focus: var(--jh-shadow-low);
    --jha-dropdown-menu-box-shadow: var(--jh-shadow-mid);
    --jha-input-placeholder-color: var(--jh-color-content-secondary-enabled);
    --jha-list-item-horizontal-spacing: var(--jh-dimension-400);
    --jha-list-item-vertical-spacing: var(--jh-dimension-400);
    --jh-list-item-space-padding-left: var(--jh-list-item-space-padding-left);
    --jha-pagination-dot-color-selected: var(--jh-color-content-brand-enabled);
    --jha-pagination-dot-color: var(--jh-color-divider-secondary);
    --jha-progress-color-button-outline: var(--jh-color-content-brand-enabled);
    --jha-progress-color-button: var(--jh-color-content-brand-enabled);
    --jha-progress-color-button: var(--jh-color-content-brand-enabled);
    --jha-progress-color: var(--jh-color-content-brand-enabled);
    --jha-circle-progress-color: var(--jh-color-content-brand-enabled);
    --jha-progress-track-color: var(--jh-color-control-enabled);
    --jha-progress-card-border-width: 4px;
    --jha-circle-progress-track-thickness: 4px;
    --jha-progress-linear-progress-text: var(--jh-progress-track-color);
    --jha-progress-linear-background: var(--jh-progress-track-color);
    --jha-progress-linear-value-background: var(--jh-color-content-brand-enabled);
    --jha-progress-linear-span: var(--jh-progress-label-color);
    --jha-select-text: var(--jh-color-content-brand-enabled);
    --jha-tab-item-color-active: var(--jha-color-primary);
    --jha-tab-item-color: var(--jh-color-content-primary-enabled);
    --jha-tab-item-padding: 0 16px 3px;
    --jha-tab-item-margin-right: 8px;
    --jha-tab-item-border-size: 4px;
    --jha-tab-item-font-weight: 400;
    --jha-tab-item-background-color: transparent;
    --jha-tab-item-hover-color: var(--jha-color-primary);
    --jha-text-base: var(--jh-color-content-primary-enabled);
    --jha-text-dark: var(--jh-color-content-primary-enabled);
    --jha-text-light: var(--jh-color-content-secondary-enabled);
    --jha-text-muted: var(--jh-color-control-active);
    --jha-text-neutral: var(--jh-color-content-secondary-enabled);
    --jha-text-white: var(--jh-color-brand-on-primary);
    --jha-toast-background: var(--jh-color-content-primary-enabled);
    --jha-toast-border-radius: var(--jh-border-radius-400);
    --jha-tooltip-border-radius: var(--jh-border-radius-200);
    --jha-tooltip-color-background: var(--jh-color-content-primary-enabled);
    --jha-tooltip-text-color: var(--jh-color-content-on-primary-enabled);
    --jha-well-background-color: var(--jh-color-container-primary-enabled);
    --jha-table-row-hover-background: var(--jh-color-container-primary-hover);
    --jha-table-header-hover-background: var(--jh-color-container-primary-hover);
    --jha-nav-left-padding: 8px;
    --jha-nav-top-padding: 30px;
    --jha-nav-link-font-size: 14px;
    --jha-nav-link-font-weight: 500;
    --jha-menu-text-pressed-color: var(--jha-color-primary);
    --jha-menu-icon-pressed-color: var(--jha-color-primary);
    --jha-menu-text-selected-color: var(--jha-color-primary);
    --jha-menu-icon-selected-color: var(--jha-color-primary);
    --jha-color-gray-medium: var(--jh-color-content-primary-enabled);

    scrollbar-color: var(--jh-color-content-secondary-enabled) var(--jh-color-container-primary-enabled);
  }
`;
export const designSystemOverridesLight = css `
  @media (prefers-color-scheme: light) {
    * {
      --jh-color-container-page: var(--jh-color-white-alpha-100);
      --jh-color-overlay: rgb(44, 44, 44, 0.6);

      --jh-color-container-primary-enabled: #f4f4f4;
      --jh-color-container-primary-hover: #ebebeb;
      --jh-color-container-primary-active: #d7d7d7;

      --jh-color-container-secondary-enabled: var(--jh-color-white-alpha-100);
      --jh-color-container-secondary-hover: #f4f4f4;
      --jh-color-container-secondary-active: #ebebeb;
      --jh-color-container-secondary-selected: var(--jh-color-blue-50);

      --jh-color-container-neutral-enabled: #d7d7d7;
      --jh-color-container-neutral-hover: #ebebeb;
      --jh-color-container-neutral-active: var(--jh-color-white-alpha-100);

      --jh-color-content-primary-enabled: #2a2a2a;
      --jh-color-content-primary-hover: #1e1e1e;

      --jh-color-content-secondary-enabled: #5f5f5f;
      --jh-color-content-secondary-hover: #575757;
      --jh-color-content-secondary-active: #4e4e4e;

      --jh-color-control-enabled: #d3d3d3;
      --jh-color-control-hover: #c9c9c9;
      --jh-color-control-active: #b6b6b6;
      --jh-color-divider-primary: #e7e7e7;
      --jh-color-divider-secondary: #707070;

      --jha-input-color-scheme: light;
    }
  }
`;
export const designSystemOverridesDark = css `
  @media (prefers-color-scheme: dark) {
    * {
      --jh-color-container-page: #111111;
      --jh-color-overlay: rgb(44, 44, 44, 0.6);
      --jh-color-container-primary-enabled: #1e1e1e;
      --jh-color-container-primary-hover: #2a2a2a;
      --jh-color-container-primary-active: #3e3e3e;

      --jh-color-container-secondary-enabled: #343434;
      --jh-color-container-secondary-hover: #414141;
      --jh-color-container-secondary-active: #4a4a4a;
      --jh-color-container-secondary-selected: var(--jh-color-blue-850);

      --jh-color-container-neutral-enabled: #4a4a4a;
      --jh-color-container-neutral-hover: #414141;
      --jh-color-container-neutral-active: #343434;

      --jh-color-container-brand-enabled: var(--jh-color-blue-950);
      --jh-color-container-brand-hover: var(--jh-color-blue-900);
      --jh-color-container-brand-active: var(--jh-color-blue-850);

      --jh-color-container-positive-enabled: var(--jh-color-green-950);
      --jh-color-container-positive-hover: var(--jh-color-green-900);
      --jh-color-container-positive-active: var(--jh-color-green-850);

      --jh-color-container-negative-enabled: var(--jh-color-red-950);
      --jh-color-container-negative-hover: var(--jh-color-red-900);
      --jh-color-container-negative-active: var(--jh-color-red-850);

      --jh-color-content-primary-enabled: #ebebeb;
      --jh-color-content-primary-hover: #f4f4f4;

      --jh-color-content-secondary-enabled: #989898;
      --jh-color-content-secondary-hover: #8a8a8a;
      --jh-color-content-secondary-active: #747474;

      /** newly added from sheet, currently not mapped to any jha-wc vars */
      --jh-color-content-inverse-enabled: #2a2a2a;
      --jh-color-content-inverse-hover: #2a2a2a;
      --jh-color-content-inverse-active: #2a2a2a;

      --jh-color-content-on-primary-enabled: #2a2a2a;
      --jh-color-content-on-primary-hover: #2a2a2a;
      --jh-color-content-on-primary-active: #2a2a2a;

      --jh-color-content-on-secondary-active: #2a2a2a;
      --jh-color-content-on-secondary-enabled: #2a2a2a;
      --jh-color-content-on-secondary-hover: #2a2a2a;

      --jh-color-content-on-brand-active: #2a2a2a;
      --jh-color-content-on-brand-enabled: #2a2a2a;
      --jh-color-content-on-brand-hover: #2a2a2a;

      --jh-color-content-on-positive-active: #2a2a2a;
      --jh-color-content-on-positive-enabled: #2a2a2a;
      --jh-color-content-on-positive-hover: #2a2a2a;

      --jh-color-content-on-negative-active: #2a2a2a;
      --jh-color-content-on-negative-enabled: #2a2a2a;
      --jh-color-content-on-negative-hover: #2a2a2a;

      --jh-color-content-on-inverse-hover: var(--jh-color-white-alpha-100);
      --jh-color-content-on-inverse-active: var(--jh-color-white-alpha-100);
      /** end */

      --jh-color-divider-primary: #474747;
      --jh-color-divider-secondary: #989898;
      --jh-color-divider-inverse: #2c2c2c;

      --jh-color-control-enabled: #8a8a8a;
      --jh-color-control-hover: #747474;
      --jh-color-control-active: #6a6a6a;

      --jh-color-interactive-focus-inner: #2a2a2a;
      --jha-input-color-scheme: dark;
    }
  }
`;
export default css `
  ${jhaWcDesignSystemConversions}
  ${designSystemOverridesLight}
  ${designSystemOverridesDark}
`;
