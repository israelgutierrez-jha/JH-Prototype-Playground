import { css } from 'lit';
export default css `
  * {
    --jh-chart-container-0: #f1f6fb;
    --jh-chart-container-1: #eef1f6;
    --jh-chart-container-2: #f8f2f9;
    --jh-chart-container-3: #edf3f1;
    --jh-chart-container-4: #eef7f0;
    --jh-chart-container-5: #f3f0f5;
    --jh-chart-container-6: #fdf3ed;
    --jh-chart-container-7: #f8efef;
    --jh-chart-container-8: #fbf3f3;
    --jh-chart-container-9: #f0f0f0;
    --jh-chart-container-10: #f5f5f5;
    --jh-chart-container-11: #f6f1ee;
    --jh-chart-container-12: #f7f5f1;
    --jh-chart-container-13: #f2f2ed;
    --jh-chart-container-14: #edf7f5;
    --jh-chart-container-15: #edf7f5;
    --jh-chart-container-16: #f5f6ed;
    --jh-chart-container-17: #f2f1eb;

    --jh-chart-graphic-0: #4e93d0;
    --jh-chart-graphic-1: #2f5898;
    --jh-chart-graphic-2: #ae63bb;
    --jh-chart-graphic-3: #1d6957;
    --jh-chart-graphic-4: #2ca047;
    --jh-chart-graphic-5: #6b4a87;
    --jh-chart-graphic-6: #d96e20;
    --jh-chart-graphic-7: #aa3c3c;
    --jh-chart-graphic-8: #d66c6c;
    --jh-chart-graphic-9: #454545;
    --jh-chart-graphic-10: #8c8c8c;
    --jh-chart-graphic-11: #98592b;
    --jh-chart-graphic-12: #998c56;
    --jh-chart-graphic-13: #5d6125;
    --jh-chart-graphic-14: #1da081;
    --jh-chart-graphic-15: #306a16;
    --jh-chart-graphic-16: #87951e;
    --jh-chart-graphic-17: #614f00;

    --jh-chart-text-0: #2573b8;
    --jh-chart-text-1: #3f81c7;
    --jh-chart-text-2: #9a54a8;
    --jh-chart-text-3: #1d6957;
    --jh-chart-text-4: #238039;
    --jh-chart-text-5: #6b4a87;
    --jh-chart-text-6: #b25612;
    --jh-chart-text-7: #d94c4c;
    --jh-chart-text-8: #a85959;
    --jh-chart-text-9: #6c7d85;
    --jh-chart-text-10: #707070;
    --jh-chart-text-11: #c16828;
    --jh-chart-text-12: #7a7045;
    --jh-chart-text-13: #7d8232;
    --jh-chart-text-14: #197d62;
    --jh-chart-text-15: #338f49;
    --jh-chart-text-16: #68780c;
    --jh-chart-text-17: #b09b38;
  }

  @media (prefers-color-scheme: dark) {
    * {
      --jh-chart-container-0: #272c30;
      --jh-chart-container-1: #21261b;
      --jh-chart-container-2: #2d262f;
      --jh-chart-container-3: #1f2625;
      --jh-chart-container-4: #262f28;
      --jh-chart-container-5: #28232c;
      --jh-chart-container-6: #312822;
      --jh-chart-container-7: #2c2222;
      --jh-chart-container-8: #302828;
      --jh-chart-container-9: #242526;
      --jh-chart-container-10: #2e2e2e;
      --jh-chart-container-11: #2c2520;
      --jh-chart-container-12: #2a292c;
      --jh-chart-container-13: #252620;
      --jh-chart-container-14: #232e2b;
      --jh-chart-container-15: #202722;
      --jh-chart-container-16: #2d2e20;
      --jh-chart-container-17: #272620;

      --jh-chart-graphic-0: #8cc3f3;
      --jh-chart-graphic-1: #3a76b6;
      --jh-chart-graphic-2: #d179e9;
      --jh-chart-graphic-3: #227c67;
      --jh-chart-graphic-4: #79e693;
      --jh-chart-graphic-5: #8f54c6;
      --jh-chart-graphic-6: #ff974c;
      --jh-chart-graphic-7: #c04343;
      --jh-chart-graphic-8: #fb8f8f;
      --jh-chart-graphic-9: #637279;
      --jh-chart-graphic-10: #e0e0e0;
      --jh-chart-graphic-11: #c16828;
      --jh-chart-graphic-12: #aea374;
      --jh-chart-graphic-13: #71762d;
      --jh-chart-graphic-14: #4edbba;
      --jh-chart-graphic-15: #2f8343;
      --jh-chart-graphic-16: #cdd930;
      --jh-chart-graphic-17: #867527;

      --jh-chart-text-0: #8cc3f3;
      --jh-chart-text-1: #4e9ff5;
      --jh-chart-text-2: #d179e9;
      --jh-chart-text-3: #31b092;
      --jh-chart-text-4: #79e693;
      --jh-chart-text-5: #be83f0;
      --jh-chart-text-6: #ff974c;
      --jh-chart-text-7: #ff6e6b;
      --jh-chart-text-8: #fb8f8f;
      --jh-chart-text-9: #8a9fa8;
      --jh-chart-text-10: #e0e0e0;
      --jh-chart-text-11: #eb8034;
      --jh-chart-text-12: #aea374;
      --jh-chart-text-13: #9ca33e;
      --jh-chart-text-14: #4edbba;
      --jh-chart-text-15: #41b05b;
      --jh-chart-text-16: #cdd930;
      --jh-chart-text-17: #b09b38;
    }
  }
`;
