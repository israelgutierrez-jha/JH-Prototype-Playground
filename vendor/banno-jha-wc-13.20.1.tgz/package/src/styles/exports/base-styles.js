import { css } from 'lit';
export default css `
  * {
    --jha-platform-font: system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
  }
  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }
  *::before,
  *::after {
    user-select: none;
    -webkit-user-select: none;
  }
  body {
    margin: 0;
    padding: 0;
    -webkit-font-smoothing: antialiased;
    -webkit-text-size-adjust: 100%;
    text-size-adjust: 100%;
    color: var(--jha-text-base);
    font-family: var(--jha-platform-font);
    line-height: 1.4;
  }
`;
