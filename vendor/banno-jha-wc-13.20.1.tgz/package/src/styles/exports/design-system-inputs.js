import { css } from 'lit';
export default css `
  * {
    --jha-input-height: 48px;
    --jha-input-height-small: 40px;
    --jha-input-padding: 1px 16px;
    --jha-multiselect-input-padding: 8px;
    --jha-multiselect-chip-padding: 7px;
    --jha-multiselect-icon-top: 3px;
    --jha-input-label-padding: 0;
    --jha-form-floating-group-padding-top: 0;
    --jh-input-color-border-enabled: var(--jh-color-divider-secondary);
    --jha-input-border: 1px solid var(--jh-input-color-border-enabled, var(--jh-color-divider-secondary));
    --jha-input-margin: var(--jh-dimension-200, 8px) 0 0;
    --jha-input-border-radius: 4px;
    --jha-input-hover-color: var(--jh-input-color-border-hover, var(--jh-color-content-brand-hover));
    --jha-input-focus-shadow: var(--jh-input-shadow-focus, var(--jh-shadow-focus));
    --jha-input-chip-color: var(--jh-color-container-neutral-enabled);
    --jha-input-label-position: static;
    --jha-input-label-transform: none;
    --jha-input-content-display: flex;
    --jha-input-content-flex-direction: column-reverse;
    --jha-form-floating-group-label-top: 0;
    --jha-input-slotted-label-offset-left: 0;
    --jha-input-label-font-size: 12px;
    --jha-input-focused-label-color: var(--jh-input-label-color-text, var(--jh-color-content-primary-enabled));
    --jha-input-label-color: var(--jh-input-label-color-text, var(--jh-color-content-primary-enabled));
    --jha-input-label-error-color: var(--jh-input-label-color-text, var(--jh-color-content-primary-enabled));
    --jha-input-opacity-disabled: var(--jh-opacity-300);
    --jha-input-label-background: transparent;
    --jha-input-background: var(--jh-color-container-secondary-enabled);
    --jh-input-color-background: var(--jh-color-container-secondary-enabled);
    --jh-input-field-color-background: var(--jh-color-container-secondary-enabled);
    --jha-form-floating-group-label-max-width: auto;
    --jha-form-floating-group-input-line-height: 16px;
    --error-text-top-margin: 8px;

    --jha-slotted-input-top: auto;
    --jha-slotted-input-bottom: 12px;
    --jha-slotted-input-small-bottom: 10px;
    --jha-slotted-icon-left-position: 16px;
    --jha-slotted-icon-right-position: 16px;

    --jha-search-icon-top: auto;
    --jha-search-icon-bottom: 4px;
    --jha-search-transform: none;

    --jha-currency-input-dollar-top: 32px;
    --jha-currency-input-dollar-small-top: 28px;
    --jha-currency-input-dollar-no-label-top: 32px;
    --jha-currency-input-dollar-bottom: auto;
    --jha-currency-input-small-dollar-bottom: auto;

    --jha-form-date-input-icon-top: auto;
    --jha-form-date-input-icon-bottom: 12px;
    --jha-form-date-input-small-icon-bottom: 8px;

    --jha-input-mask-top: auto;
    --jha-input-mask-bottom: 15px;
    --jha-input-small-mask-bottom: 12px;
    --jha-input-mask-left: 1px;

    --jha-input-outline-transition: none;
    --jha-input-content-position: relative;
    --jha-form-select-icon-top: auto;
    --jha-form-select-icon-bottom: 12px;
    --jha-form-select-small-icon-bottom: 6px;
    --jha-form-select-small-chevron-position-top: auto;

    --jha-form-row-item-margin-bottom: 16px;

    --jh-chip-input-options-top: calc(100% + 12px);
  }
`;
