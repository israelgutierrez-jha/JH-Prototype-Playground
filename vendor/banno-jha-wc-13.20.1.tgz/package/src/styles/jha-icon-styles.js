import { css } from 'lit';
const styles = css `
  :host {
    display: inline-block;
    width: 24px;
    height: 24px;
    fill: var(--jha-icon-fill-color, var(--jha-icon-color, var(--jha-text-base)));
    box-sizing: content-box !important;
    margin: var(--jha-icon-margin, 0);
    padding: var(--jha-icon-padding, 0);
  }
  svg {
    width: 100%;
    height: 100%;
    display: block;
  }
  :host([x-small]) {
    width: 16px;
    height: 16px;
  }
  :host([small]) {
    width: 18px;
    height: 18px;
  }
  :host([large]) {
    width: 36px;
    height: 36px;
  }
  :host([x-large]) {
    width: 60px;
    height: 60px;
  }
  :host([primary]) {
    fill: var(--jha-color-primary, #3aaeda);
  }
  :host([success]) {
    fill: var(--jha-color-success, #4caf50);
  }
  :host([danger]) {
    fill: var(--jha-color-danger, #f44336);
  }
  :host([base]) {
    fill: var(--jha-text-base, #6b757b);
  }
  :host([light]) {
    fill: var(--jha-color-light, #8c989f);
  }
  :host([muted]) {
    fill: var(--jha-color-muted, #b3bfc9);
  }
  :host([neutral]) {
    fill: var(--jha-color-neutral, #8d99a0);
  }
`;
export { styles as jhaIconStyles };
