import { css } from 'lit';
import JhaStyleElement from '../style-element/JhaStyleElement.js';
import { jhaStyles } from '../styles/jha-styles.js';
const styles = css `
  :host {
    display: block;
    padding: var(--jha-container-padding, 0 40px);
    margin: var(--jha-container-margin, 0 auto);
    max-width: var(--jha-container-max-width, 1170px);
  }
  @media (max-width: 1024px) {
    :host {
      --jha-container-padding: 0 30px;
    }
  }
  @media (max-width: 600px) {
    :host {
      --jha-container-padding: 0 8px;
    }
  }
  @media print {
    :host {
      max-width: none;
      --jha-container-padding: 0;
    }
  }
`;
/**
 * A JHA Design container component used as a page-wide container to set spacing at the top level of a view.
 *
 * @element jha-container
 * @slot unnamed slot for content
 */
export default class JhaContainer extends JhaStyleElement {
    static get styles() {
        return [jhaStyles, styles];
    }
}
export { styles as jhaContainerStyles };
