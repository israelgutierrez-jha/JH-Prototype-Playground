import JhaContainer from './JhaContainer.js';
customElements.define('jha-container', JhaContainer);
/** @customElement jha-container */
export default JhaContainer;
