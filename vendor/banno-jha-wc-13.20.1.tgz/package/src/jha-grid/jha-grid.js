import JhaGrid from './JhaGrid.js';
customElements.define('jha-grid', JhaGrid);
/** @customElement jha-grid */
export default JhaGrid;
