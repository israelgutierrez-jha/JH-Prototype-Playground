import { html, css } from 'lit';
import { jhaStyles } from '../styles/jha-styles.js';
import JhaStyleElement from '../style-element/JhaStyleElement.js';
const styles = css `
  :host {
    --jha-popover-position-area-adjusted: bottom center;
  }

  #anchor {
    anchor-name: --my-anchor;
    width: auto !important;
  }

  :host:not([inline]) button {
    width: auto !important;
  }

  :host([inline]) button:hover {
    background: var(--jh-color-container-neutral-hover);
  }

  :host([inline]) button:active {
    background: var(--jh-tag-color-background-active, var(--jh-color-container-neutral-active));
  }
  .popover-background {
    display: none;
  }

  [popover] {
    position-anchor: --my-anchor;
    position-area: var(--jha-popover-position-area, bottom span-right);
    position-try: normal flip-back;
    width: max-content;
    border: none;
    margin: 0;
    overflow: visible;
    background: transparent;
    padding: var(--jha-popover-padding, 8px 0);
  }

  [popover]:popover-open {
    animation: fadeIn 0.1s forwards;
  }

  @keyframes fadeIn {
    from {
      opacity: 0;
    }

    to {
      opacity: 1;
    }
  }

  [popover][position-adjusted] {
    position-area: var(--jha-popover-position-area-adjusted);
  }

  #popoverContent:not([popover]) {
    display: none;
  }

  #popoverContent[inline-open] {
    display: block;
  }

  [popover] ::slotted(jh-menu) {
    height: auto;
    overflow: var(--jha-popover-overflow, auto);
    min-height: 100%;
    min-width: var(--jha-popover-min-with, 100%);
    max-height: var(--jha-popover-max-height, 500px);
  }

  [popover][fixed-height] ::slotted(jh-menu) {
    height: 100%;
  }

  @media (max-width: 480px) {
    [popover] {
      inset-area: bottom span-right;
    }
    [popover] ::slotted(jh-menu) {
      max-width: 100%;
    }
  }

  @media (prefers-color-scheme: light) {
    [popover] ::slotted(jh-menu) {
      --jh-menu-color-background: var(--jh-color-container-secondary-enabled);
    }
  }
`;
/**@element jha-popover */
export default class JhaPopover extends JhaStyleElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            open: {
                type: Boolean,
                reflect: true,
            },
            inline: {
                type: Boolean,
                reflect: true,
            },
            disableBackground: {
                type: Boolean,
            },
            positionAdjusted: {
                type: Boolean,
            },
            slottedButtonTabbable: {
                type: Boolean,
            },
        };
    }
    constructor() {
        super();
        this.open = false;
        this.inline = false;
        this.disableBackground = true;
        this._backdrop = null;
        this.positionAdjusted = false;
        this.slottedButtonTabbable = false;
    }
    disconnectedCallback() {
        this._backdrop?.remove();
        super.disconnectedCallback();
    }
    async firstUpdated() {
        await this.updateComplete;
    }
    updated(ChangedProperties) {
        if (ChangedProperties.has('open')) {
            this.dispatchEvent(new CustomEvent('popover-open-changed', {
                detail: this.open,
                bubbles: true,
                composed: true,
            }));
        }
    }
    /** @returns {HTMLElement} */
    get popoverEl() {
        return this.shadowRoot.querySelector('[popover]#popoverContent');
    }
    /** @returns {HTMLElement} */
    get buttonEl() {
        return this.shadowRoot.querySelector('#anchor');
    }
    openPopover() {
        if (this.inline) {
            this.open = !this.open;
            return;
        }
        if (!this.popoverEl)
            return;
        if (this.open) {
            this.popoverEl.hidePopover();
        }
        else {
            this.popoverEl.showPopover();
        }
    }
    closePopover() {
        if (this.inline) {
            this.open = !this.open;
            this.positionAdjusted = false;
            return;
        }
        if (!this.popoverEl)
            return;
        this.popoverEl.hidePopover();
    }
    handleBackdrop_() {
        if (!this.disableBackground)
            return;
        if (this.open) {
            this._backdrop = document.createElement('div');
            this._backdrop.classList.add('popover-background');
            this._backdrop.style.position = 'fixed';
            this._backdrop.style.top = '0';
            this._backdrop.style.left = '0';
            this._backdrop.style.width = '100%';
            this._backdrop.style.height = '100%';
            this._backdrop.style.background = 'transparent';
            document.body.appendChild(this._backdrop);
        }
        else if (this._backdrop) {
            this._backdrop?.remove?.();
        }
    }
    handlePopoverToggle_(evt) {
        const { newState } = evt;
        this.open = newState === 'open';
        this.handleBackdrop_();
        if (this.open) {
            this.setPopoverPosition();
        }
    }
    get slottedPopoverButton() {
        const slottedButton = this.querySelector('[slot="button"]');
        if (!slottedButton)
            return null;
        if (slottedButton.tagName === 'BUTTON') {
            return slottedButton;
        }
        if (slottedButton.shadowRoot === null) {
            return slottedButton.querySelector('button');
        }
        return slottedButton.shadowRoot?.querySelector('button');
    }
    get popoverPositionAreaArray() {
        const positionArea = getComputedStyle(this).getPropertyValue('--jha-popover-position-area') || 'bottom center';
        return positionArea.split(' ').map((item) => item.trim());
    }
    set popoverPositionArea(position) {
        this.style.setProperty('--jha-popover-position-area-adjusted', position);
        this.positionAdjusted = true;
    }
    async maybeAdjustPopoverPosition() {
        this.handleHeight();
        await this.updateComplete;
        let positionAreaArray = this.popoverPositionAreaArray;
        let hasChanged = false;
        const { top, left, bottom, right } = this.popoverEl.getBoundingClientRect();
        if (top < 0) {
            positionAreaArray[0] = 'bottom';
            hasChanged = true;
        }
        else if (bottom > window.innerHeight) {
            positionAreaArray[0] = 'top';
            hasChanged = true;
        }
        if (left < 0) {
            positionAreaArray[1] = 'span-right';
            hasChanged = true;
        }
        else if (right > window.innerWidth) {
            positionAreaArray[1] = 'span-left';
            hasChanged = true;
        }
        if (hasChanged) {
            this.popoverPositionArea = positionAreaArray.join(' ');
        }
    }
    setPopoverPosition() {
        if (!this.popoverEl)
            return;
        const hasAnchorPositioning = this.popoverEl &&
            // @ts-ignore
            Boolean(getComputedStyle(this.popoverEl).positionAnchor);
        if (hasAnchorPositioning) {
            this.maybeAdjustPopoverPosition();
            return;
        }
        const buttonPosition = this.buttonEl && this.buttonEl.getBoundingClientRect();
        if (!buttonPosition)
            return;
        const { top, bottom, left } = buttonPosition;
        const popoverPosition = this.popoverEl.getBoundingClientRect();
        const { width, height } = popoverPosition;
        const leftPos = window.innerWidth < left + width ? window.innerWidth - width - 10 : left;
        const topPos = window.innerHeight < top + height && top - height > 0 ? top - height : bottom;
        this.popoverEl.style.left = `${leftPos}px`;
        this.popoverEl.style.top = `${topPos}px`;
        this.handleHeight();
    }
    handleHeight() {
        this.popoverEl.removeAttribute('fixed-height');
        this.popoverEl.style.height = '';
        const popoverPosition = this.popoverEl.getBoundingClientRect();
        const { height, top } = popoverPosition;
        if (window.innerHeight < top + height && window.innerHeight - top > 100) {
            this.popoverEl.style.height = `${window.innerHeight - top}px`;
            this.popoverEl.setAttribute('fixed-height', 'true');
        }
    }
    handleButtonSlotChange() {
        this.slottedButtonTabbable =
            this.slottedPopoverButton && this.slottedPopoverButton?.getAttribute('tabindex') !== '-1';
    }
    render() {
        return html `
      <div
        popovertarget="popoverContent"
        id="anchor"
        role="button"
        aria-haspopup="true"
        aria-expanded="${this.open}"
        tabindex=${this.slottedButtonTabbable ? '-1' : '0'}
        @click=${this.openPopover}
        @keydown=${(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.openPopover();
            }
        }}>
        <slot
          name="button"
          @slotchange=${this.handleButtonSlotChange}></slot>
      </div>

      <div
        ?inline-open=${this.inline && this.open}
        ?popover=${!this.inline}
        ?position-adjusted=${this.positionAdjusted}
        id="popoverContent"
        @toggle=${this.handlePopoverToggle_}>
        <slot></slot>
      </div>
    `;
    }
}
export { styles as JhaPopoverStyles };
