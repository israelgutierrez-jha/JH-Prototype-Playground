import JhaPopover from './JhaPopover.js';
customElements.define('jha-popover', JhaPopover);
/** @customElement jha-popover */
export default JhaPopover;
