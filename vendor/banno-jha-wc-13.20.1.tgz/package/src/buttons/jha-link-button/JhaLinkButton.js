import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
const styles = css `
  :host {
    position: relative;
    display: inline-block;
    margin-bottom: 0;
    text-align: center;
    contain: layout;
    cursor: pointer;
    background-image: none;
    border: 1px solid transparent;
    white-space: var(--jha-link-button-white-space, nowrap);
    background-color: var(--jha-button-background, var(--jha-color-primary));
    text-transform: none;
    font-size: var(--jha-button-text-size, 14px);
    line-height: var(--jha-button-line-height, 34px);
    border-radius: var(--jha-button-border-radius, 4px);
    transition: background-color ease 0.2s;
    color: var(--jha-button-text, var(--jha-text-white));
    font-weight: var(--jha-button-font-weight, 500);
  }

  a:hover,
  a:focus {
    text-decoration: none;
  }

  :host(:active) {
    background-color: var(--jha-button-background-active, var(--jha-color-primary));
  }

  a {
    display: block;
    text-decoration: none;
    padding: var(--jha-button-padding-vertical, 0px) var(--jha-button-padding-horizontal, 18px);
    color: inherit;
    transition: background-color ease 0.2s;
    border-radius: var(--jha-button-border-radius, 4px);
  }

  :host() a:hover {
    text-decoration: none;
    text-decoration: none;
    background-color: var(--jha-button-background-hover, var(--jha-color-primary, #3aaeda));
    border-color: var(--jha-button-border-color-hover, transparent);
  }

  :host([disabled]),
  :host([disabled]) a {
    cursor: default;
    pointer-events: none;
  }

  :host([disabled]) {
    opacity: var(--jha-button-disabled-opacity, 0.3);
  }

  :host ::slotted(.icon) {
    position: relative;
    top: -2px;
  }
  ::slotted([slot='icon-left']),
  ::slotted([slot='icon-right']) {
    margin-right: var(--jha-button-icon-padding, 4px);
    vertical-align: middle;
    fill: var(--jha-button-slotted-icon-fill-color, var(--jha-text-white, #ffffff));
  }

  ::slotted([slot='icon-right']) {
    margin-right: 0;
    margin-left: var(--jha-button-icon-padding, 4px);
  }

  :host([flex]) a {
    display: flex;
    align-items: var(--jha-link-button-align-items, center);
    justify-content: var(--jha-link-button-justify-content, flex-start);
    text-align: left;
  }

  :host([outline]) {
    background-color: transparent;
    border-color: var(--jha-button-outline-border, var(--jha-color-primary));
    transition: background-color ease 0.2s;
  }

  :host([outline]) a {
    color: var(--jha-button-outline-text, var(--jha-color-primary));
  }

  :host([outline]) a:hover {
    color: var(--jha-button-outline-text, var(--jha-color-primary));
    background-color: rgba(153, 153, 153, 0.12);
  }

  :host([outline]) a:active {
    background-color: var(
      --jha-button-outline-background-active,
      var(--jh-button-color-background-secondary-active, rgba(153, 153, 153, 0.4))
    );
  }

  :host([outline-primary]) {
    background-color: transparent;
    border-color: var(--jha-button-primary-background, var(--jha-color-primary));
  }

  :host([outline-primary]) a {
    color: var(--jha-button-primary-background, var(--jha-color-primary));
    background-color: transparent;
  }

  :host([outline-primary]) a:hover {
    background-color: var(
      --jha-button-outline-primary-background-hover,
      var(--jha-button-default-background-hover, rgba(52, 177, 224, 0.12))
    );
  }

  :host([outline-primary]) a:active {
    background-color: var(
      --jha-button-primary-background,
      var(--jha-button-default-background-active, var(--jha-color-primary, #3aaeda))
    );
    color: var(--jha-button-text, var(--jha-text-white));
  }

  :host([outline-success]) {
    background-color: transparent;
    border-color: var(--jha-button-success-background, var(--jha-color-success));
  }

  :host([outline-success]) a {
    color: var(--jha-button-success-background, var(--jha-color-success));
    background-color: transparent;
  }

  :host([outline-success]) a:hover {
    background-color: var(--jha-button-outline-success-background-hover, rgba(70, 181, 74, 0.12));
  }

  :host([outline-success]) a:active {
    color: var(--jha-button-text, var(--jha-text-white));
    background-color: var(--jha-button-success-background, var(--jha-color-success, #4caf50));
  }

  :host([outline-danger]) {
    background-color: transparent;
    border-color: var(--jha-button-danger-background, var(--jha-color-danger));
  }

  :host([outline-danger]) a {
    color: var(--jha-button-danger-background, var(--jha-color-danger));
    background-color: transparent;
  }

  :host([outline-danger]) a:hover {
    background-color: var(--jha-button-outline-danger-background-hover, rgba(249, 62, 49, 0.12));
  }

  :host([outline-danger]) a:active {
    background-color: var(--jha-button-danger-background, var(--jha-color-danger, #f44336));
    color: var(--jha-button-text, var(--jha-text-white));
  }

  :host([icon]) {
    background-color: transparent;
  }

  :host([icon]):hover,
  :host([icon]):focus {
    background-color: transparent;
    box-shadow: none;
  }

  :host([icon]) a:hover {
    background-color: transparent;
  }

  :host([primary]) {
    background-color: var(--jha-button-primary-background, var(--jha-color-primary));
  }

  :host([primary]) a:hover {
    background-color: transparent;
  }

  :host([neutral]) {
    background-color: var(--jha-button-neutral-background, transparent);
  }

  :host([neutral]) a:hover {
    background-color: transparent;
  }

  :host([success]) {
    background-color: var(--jha-button-success-background, var(--jha-color-success));
  }

  :host([success]) a:hover {
    background-color: transparent;
  }

  :host([danger]) {
    background-color: var(--jha-button-danger-background, var(--jha-color-danger));
  }

  :host([danger]) a:hover {
    background-color: transparent;
  }

  :host([toggle]) {
    background-color: transparent;
  }

  :host([toggle]) a {
    color: var(--jha-button-toggle-text, var(--jha-color-neutral));
    font-size: var(--jha-button-toggle-text-size, 13px);
    font-weight: 600;
    text-transform: uppercase;
  }

  :host([toggle]) a:hover {
    color: var(--jha-button-primary-background, var(--jha-color-primary));
    background-color: transparent;
  }
  :host([small]) a {
    font-size: calc(var(--jha-button-text-size, 14px) - 1);
    line-height: var(--jha-button-line-height-small, 28px);
  }

  :host([large]) a {
    line-height: var(--jha-button-line-height-large, 48px);
    padding-left: calc(var(--jha-button-padding-horizontal, 18px) * 2);
    padding-right: calc(var(--jha-button-padding-horizontal, 18px) * 2);
  }

  :host([wide]) a {
    padding-left: calc(var(--jha-button-padding-horizontal, 18px) * 2);
    padding-right: calc(var(--jha-button-padding-horizontal, 18px) * 2);
  }

  :host([block]) {
    display: block;
    width: 100%;
    margin-bottom: 5px;
  }

  :host([block]:last-of-type) {
    margin-bottom: 0;
  }

  :host([default]) {
    color: var(--jha-button-default-text, var(--jha-text-base, #6b757b));
    background-color: var(--jha-button-default-background, transparent);
    border-color: var(--jha-button-default-border, var(--jha-border-color, #e4e7ea));
    font-weight: var(--jha-button-default-font-weight, 400);
    font-size: var(--jha-button-default-font-size, 14px);
    transition: background-color ease 0.2s;
  }

  :host([default]):hover {
    background-color: var(--jha-button-default-background-hover, rgba(153, 153, 153, 0.12));
  }

  :host([default]):active {
    background-color: var(--jha-button-default-background-active, rgba(153, 153, 153, 0.4));
  }

  :host([tertiary]) {
    background-color: transparent;
  }

  :host([tertiary]) a {
    --jha-button-slotted-icon-fill-color: var(--jha-button-outline-text, var(--jha-text-light, #8c989f));
    color: var(--jha-button-tertiary-text, var(--jha-color-primary));
    background-color: var(--jha-button-tertiary-background, transparent);
    border-color: var(--jha-button-tertiary-border, transparent);
    transition: background-color ease 0.2s;
  }

  :host([tertiary]) a:hover {
    background-color: var(--jha-button-tertiary-background-hover, rgba(0, 110, 228, 0.1));
  }

  :host([tertiary]) a:active {
    background-color: var(--jha-button-tertiary-background-active, rgba(153, 153, 153, 0.4));
  }
`;
/**@element jha-link-button */
export default class JhaLinkButton extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            href: { type: String },
            rel: { type: String },
            target: { type: String },
            disabled: {
                type: Boolean,
                reflect: true,
            },
            nonInteractive: {
                type: Boolean,
                attribute: 'non-interactive',
                reflect: true,
            },
        };
    }
    constructor() {
        super();
        this.href = '';
        this.rel = '';
        // default to empty string to prevent web-component-router from ignoring the link, causing a full page reload.
        /** @type {''|'_blank'|'_parent'|'_self'|'_top'} */
        this.target = '';
        this.disabled = false;
        this.nonInteractive = false;
        // trap clicks on the element itself. this prevents the element from stll
        // registing clicks on it's content (usually a label) while the internal
        // button is disabled.
        // eslint-disable-next-line @jkhy/ux/prefer-arrow-event-handler
        this.addEventListener('click', (event) => {
            if (this.disabled) {
                event.preventDefault();
                event.stopImmediatePropagation();
                event.stopPropagation();
            }
        });
    }
    render() {
        return html `
      <a
        href=${this.href}
        rel=${this.rel}
        target=${this.target}
        ?disabled=${this.disabled}
        tabindex=${this.nonInteractive ? '-1' : '0'}
        aria-hidden=${this.nonInteractive ? 'true' : 'false'}>
        <slot name="icon-left"></slot>
        <slot></slot>
        <slot name="icon-right"></slot>
      </a>
    `;
    }
}
export { styles as JhaLinkButtonStyles };
