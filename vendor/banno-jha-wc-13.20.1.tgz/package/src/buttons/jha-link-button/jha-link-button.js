import JhaLinkButton from './JhaLinkButton.js';
customElements.define('jha-link-button', JhaLinkButton);
/** @customElement jha-link-button */
export default JhaLinkButton;
