import JhaButton from './JhaButton.js';
customElements.define('jha-button', JhaButton);
/** @customElement jha-button */
export default JhaButton;
