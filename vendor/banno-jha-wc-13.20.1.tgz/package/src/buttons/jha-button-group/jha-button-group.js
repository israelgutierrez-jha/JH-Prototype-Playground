import JhaButtonGroupElement from './JhaButtonGroup.js';
customElements.define('jha-button-group', JhaButtonGroupElement);
/** @customElement jha-button-group */
export default JhaButtonGroupElement;
