import { css } from 'lit';
import JhaStyleElement from '../../style-element/JhaStyleElement.js';
import { jhaStyles } from '../../styles/jha-styles.js';
const styles = css `
  :host {
    display: flex;
    align-items: center;
    position: relative;
    margin-bottom: 16px;
  }
  :host ::slotted(button) {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    color: var(--jha-button-group-text-color, var(--jha-text-base, #8c989f));
    font-size: var(--jha-button-group-text-size, 14px);
    border: 1px solid var(--jha-button-group-border-color, var(--jha-border-color, #e4e7ea));
    line-height: var(--jha-button-line-height, 34px);
    background-color: var(--jha-button-group-background-color, var(--jha-component-background-color, #ffffff));
    padding: 0;
    box-shadow: none;
    cursor: pointer;
    flex-grow: 1;
    position: relative;
    margin-left: -1px;
    z-index: 1;
    border-radius: 0;
  }
  :host ::slotted(button:hover) {
    background-color: var(--jha-button-group-background-hover, var(--jha-button-group-background-color, #fff));
    border-color: var(--jha-button-group-border-hover, var(--jha-border-color-hover, #d3d8dd));
    --jha-button-group-border-color: var(--jha-border-color-hover, #d3d8dd);
    color: var(--jha-button-group-text-color-hover, var(--jha-button-group-text-color, var(--jha-text-base, #8c989f)));
    z-index: 2;
  }
  :host ::slotted(button:first-of-type) {
    border-top-left-radius: 3px;
    border-bottom-left-radius: 3px;
  }
  :host ::slotted(button:last-of-type) {
    border-top-right-radius: 3px;
    border-bottom-right-radius: 3px;
  }
  :host ::slotted(button[active]) {
    z-index: 2;
    background-color: var(--jha-button-group-active-background, var(--jha-border-color-hover, #d3d8dd));
    color: var(--jha-button-group-active-text-color, var(--jha-button-group-text-color, var(--jha-text-base, #8c989f)));
    border-color: var(--jha-button-group-active-border-color, var(--jha-border-color-hover, #d3d8dd));
    box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.08);
  }
  :host([primary]) ::slotted(button) {
    --jha-button-group-text-color: var(--jha-color-primary, #3aaeda);
    --jha-button-group-border-color: var(--jha-color-primary, #3aaeda);
  }
  :host([primary]) ::slotted(button:hover) {
    --jha-button-group-background-color: rgba(52, 177, 224, 0.12);
    --jha-button-group-text-color: #259ac6;
    --jha-button-group-border-color: #259ac6;
    z-index: 2;
  }
  :host([primary]) ::slotted(button[active]) {
    --jha-button-group-background-color: var(--jha-color-primary, #3aaeda);
    color: var(--jha-text-white, #ffffff);
    --jha-button-group-border-color: var(--jha-color-primary, #3aaeda);
    box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.08);
  }
`;
/**@element jha-button-group */
export default class JhaButtonGroupElement extends JhaStyleElement {
    static get styles() {
        return [jhaStyles, styles];
    }
}
export { styles as JhaButtonGroupStyles };
