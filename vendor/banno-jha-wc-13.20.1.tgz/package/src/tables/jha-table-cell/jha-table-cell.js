import JhaTableCell from './JhaTableCell.js';
customElements.define('jha-table-cell', JhaTableCell);
/** @customElement jha-table-cell */
export default JhaTableCell;
