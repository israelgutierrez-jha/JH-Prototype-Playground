import JhaTable from './JhaTable.js';
customElements.define('jha-table', JhaTable);
/** @customElement jha-table */
export default JhaTable;
