import JhaTableAction from './JhaTableAction.js';
customElements.define('jha-table-action', JhaTableAction);
/** @customElement jha-table-action */
export default JhaTableAction;
