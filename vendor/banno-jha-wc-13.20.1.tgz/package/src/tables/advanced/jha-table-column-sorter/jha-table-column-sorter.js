import JhaTableColumnSorter from './JhaTableColumnSorter.js';
customElements.define('jha-table-column-sorter', JhaTableColumnSorter);
/** @customElement jha-table-column-sorter */
export default JhaTableColumnSorter;
