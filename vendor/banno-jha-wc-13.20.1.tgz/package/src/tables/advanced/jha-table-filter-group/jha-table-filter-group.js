import JhaTableFilterGroup from './JhaTableFilterGroup.js';
customElements.define('jha-table-filter-group', JhaTableFilterGroup);
/** @customElement jha-table-filter-group */
export default JhaTableFilterGroup;
