import { html, css } from 'lit';
import { format, isValid } from 'date-fns';
import JhaStyleElement from '../../../style-element/JhaStyleElement.js';
import { jhaStyles } from '../../../styles/jha-styles.js';
import { JhaTableFilterType } from './JhaTableFilter.js';
import '@jack-henry/jh-elements/components/tag/tag.js';
import '@jack-henry/jh-icons/icons-wc/icon-chevron-down-small.js';
const styles = css `
  :host {
    display: block;
    --jh-tag-size-max-width: 300px;
    --jha-popover-overflow: visible;
  }
  span.value {
    color: var(--jh-color-content-brand-enabled);
    padding-left: 4px;
  }
  .filter-button {
    display: flex;
    align-items: center;
    justify-content: space-between;
    cursor: pointer;
    border: none;
    border-radius: var(--jha-filter-button-border-radius, 4px);
    font-size: var(--jha-filter-button-font-size, 12px);
    color: var(--jh-color-content-secondary-enabled);
    background: var(--jha-filter-button-background-color, transparent);
    padding: 4px 8px;
    gap: 8px;
    text-overflow: ellipsis;
    white-space: nowrap;
    line-height: var(--jha-filter-button-line-height, 24px);
    width: 100%;
    box-sizing: border-box;
  }

  :host([selected]) .filter-button {
    --jha-filter-button-background-color: var(--jh-color-container-primary-enabled);
  }
  .filter-button:hover {
    --jha-filter-button-background-color: var(--jh-color-container-secondary-hover);
  }

  :host([selected]) .filter-button {
    color: var(--jh-color-content-primary-enabled);
  }

  :host([disabled]) .filter-button {
    opacity: var(--jha-button-disabled-opacity, 0.3);
  }

  jh-tag {
    --jh-tag-color-background-enabled: var(--jh-color-content-brand-enabled);
    --jh-tag-color-text-enabled: var(--jh-color-container-page);
  }

  jh-tag[disabled] {
    opacity: var(--jh-input-opacity-disabled, var(--jh-opacity-300));
    cursor: default;
    --jh-tag-color-background-hover: var(--jh-tag-color-background-enabled, var(--jh-color-container-neutral-enabled));
    --jh-tag-color-background-active: var(--jh-tag-color-background-enabled, var(--jh-color-container-neutral-enabled));
  }
  jh-tag[has-filter] {
    --jh-tag-color-text-enabled: var(--jh-color-content-brand-enabled);
    --jh-tag-color-text-hover: var(--jh-color-content-brand-hover);
  }
`;
/**@element jha-table-filter-button */
export default class JhaTableFilterButton extends JhaStyleElement {
    static get properties() {
        return {
            filterType: {
                type: String,
            },
            label: {
                type: String,
            },
            value: {
                type: Array,
            },
            disabled: {
                type: Boolean,
            },
            displayIcon: {
                type: Boolean,
                reflect: true,
                attribute: 'display-icon',
            },
            open: {
                type: Boolean,
            },
            tempValue: {
                type: Array,
            },
            loading: {
                type: Boolean,
                reflect: true,
            },
            itemId: {
                type: String,
            },
        };
    }
    constructor() {
        super();
        this.filterType = JhaTableFilterType.LIST;
        this.value = [];
        this.label = '';
        this.disabled = false;
        this.displayIcon = false;
        this.itemId = '';
    }
    static get styles() {
        return [jhaStyles, styles];
    }
    renderValueList() {
        if (!this.value?.length)
            return '';
        if (this.value.length === 1) {
            return this.value[0];
        }
        return this.value.length;
    }
    renderAmountText() {
        if (this.value.length === 1) {
            return `Equals ${this.value[0]}`;
        }
        if (this.value[0] && !this.value[1]) {
            return `Above ${this.value[0]}`;
        }
        if (this.value[1] && !this.value[0]) {
            return `Under ${this.value[1]}`;
        }
        return `${this.value.join(' to ')}`;
    }
    renderDateText() {
        const dates = this.formattedDateArray;
        if (dates[0] === dates[1]) {
            return `${dates[0]}`;
        }
        if (this.value.length === 1 && dates[0]) {
            return `On ${dates[0]}`;
        }
        if (dates[0] && !dates[1]) {
            return `After ${dates[0]}`;
        }
        if (!dates[0] && dates[1]) {
            return `Before ${dates[1]}`;
        }
        return `${dates.join(' - ')}`;
    }
    get filterText() {
        if (!this.value?.length) {
            return '';
        }
        switch (this.filterType) {
            case JhaTableFilterType.LIST:
                return this.renderValueList();
            case JhaTableFilterType.SINGLE_SELECTION:
                return this.value;
            case JhaTableFilterType.RANGE:
                return this.renderAmountText();
            case JhaTableFilterType.DATE:
                return this.renderDateText();
            case JhaTableFilterType.DATE_CUSTOM:
                return this.value;
            default:
                return this.value.join(' ');
        }
    }
    get formattedDateArray() {
        return (this.value || []).map((d) => {
            if (isValid(d)) {
                return format(d, 'MM/dd/yyyy');
            }
            if (typeof d === 'string' && d.length) {
                return format(new Date(d), 'MM/dd/yyy');
            }
            return null;
        });
    }
    render() {
        return html `
      <button
        tabindex="-1"
        class="filter-button"
        aria-label="${this.label}"
        @click=${(evt) => {
            if (this.disabled) {
                evt.stopPropagation();
            }
        }}>
        <span>${this.label}</span>
        ${this.filterText ? html ` <jh-tag .label=${this.filterText}></jh-tag> ` : ''}
        ${this.displayIcon ? html ` <jh-icon-chevron-down-small></jh-icon-chevron-down-small>` : ''}
      </button>
    `;
    }
}
customElements.define('jha-table-filter-button', JhaTableFilterButton);
