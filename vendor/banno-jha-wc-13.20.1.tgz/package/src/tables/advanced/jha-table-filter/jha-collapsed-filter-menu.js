import { html, css } from 'lit';
import JhaStyleElement from '../../../style-element/JhaStyleElement.js';
import { jhaStyles } from '../../../styles/jha-styles.js';
import { JhaTableFilterType } from './JhaTableFilter.js';
import '@jack-henry/jh-elements/components/tag/tag.js';
import '@jack-henry/jh-elements/components/menu/menu.js';
import '@jack-henry/jh-icons/icons-wc/icon-chevron-down-small.js';
import '../../../jha-popover/jha-popover.js';
import './jha-table-filter-button.js';
import './jha-table-filter-control.js';
const styles = css `
  :host {
    display: block;
    --jh-tag-size-max-width: 300px;
    --jha-popover-overflow: visible;
  }
  .filter-button {
    display: flex;
    align-items: center;
    justify-content: space-between;
    cursor: pointer;
    border: none;
    border-radius: 4px;
    font-size: var(--jha-collapsed-filter-menu-font-size, 12px);
    color: var(--jha-collapsed-filter-menu-color, var(--jh-color-content-secondary-enabled));
    background: var(--jha-collapsed-filter-menu-background, transparent);
    padding: 4px 8px;
    gap: 4px;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
  }

  jha-popover[open] .filter-button,
  .filter-button:hover {
    background-color: var(--jha-collapsed-filter-menu-background-hover, var(--jh-color-container-secondary-hover));
  }

  .filter-button[disabled] {
    opacity: var(--jha-button-disabled-opacity, 0.3);
  }

  jha-popover[has-change],
  jha-table-filter[has-change] {
    position: relative;
    overflow: visible;
  }
  jh-tag {
    margin-left: 4px;
    --jh-tag-color-background-enabled: var(--jh-color-content-brand-enabled);
    --jh-tag-color-text-enabled: var(--jh-color-container-page);
  }

  jh-menu .menu-content {
    display: flex;
    flex-direction: row;
    padding: 0;
    max-height: var(--jha-collapsed-filter-menu-max-height, 400px);
  }
  .buttons {
    min-width: 225px;
    padding: 16px 0 16px 8px;
    display: flex;
    flex-direction: column;
    gap: 4px;
    background: var(--jh-color-container-page);
    overflow-y: auto;
  }
  jha-table-filter-button {
    width: 100%;
    box-sizing: border-box;
    --jha-filter-button-border-radius: 4px 0 0 4px;
    --jha-filter-button-font-size: 14px;
    --jha-filter-button-line-height: 32px;
  }
  jha-table-filter-control {
    background: var(--jh-color-container-primary-enabled);
    padding: 8px;
    border-radius: 0 4px 4px 0;
    --jh-menu-shadow: none;
    --jh-menu-space-padding: 0;
    --jh-menu-color-background: var(--jh-color-container-primary-enabled);
    --jha-table-filter-list-height: 100%;
  }
  jha-popover {
    --jha-popover-position-area: var(--jha-collapsed-filter-menu-position-area, bottom center);
  }
`;
/**@element jha-table-filter-button */
export default class JhaCollapsedFilterMenu extends JhaStyleElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            filters: {
                type: Array,
            },
            loading: {
                type: Boolean,
                reflect: true,
            },
            label: {
                type: String,
            },
            selectedMoreFilterId: {
                type: String,
            },
        };
    }
    constructor() {
        super();
        this.filters = [];
        this.loading = false;
        this.label = 'Filters';
        this.selectedMoreFilterId = '';
    }
    get activeFilterCount() {
        return (this.filters || []).filter((item) => item.value?.length).length;
    }
    handleMoreClicked(evt) {
        if (this.loading) {
            evt.stopPropagation();
        }
    }
    handlePopoverChange_(evt) {
        if (evt.detail) {
            if (!this.selectedMoreFilterId) {
                this.selectedMoreFilterId = this.filters[0]?.id;
            }
        }
    }
    renderSelectedMoreFilter() {
        const selectedFilter = (this.filters || []).find((item) => item.id === this.selectedMoreFilterId);
        if (!selectedFilter)
            return '';
        return html `
      <jha-table-filter-control
        .filterType=${selectedFilter.filterType}
        .options=${selectedFilter.options}
        .label=${selectedFilter.label}
        .value=${selectedFilter.value}
        .itemId=${selectedFilter.id}
        .loading=${this.loading}></jha-table-filter-control>
    `;
    }
    render() {
        return html `
      <jha-popover @popover-open-changed=${this.handlePopoverChange_}>
        <button
          type="button"
          slot="button"
          class="filter-button"
          aria-label=${this.label}
          ?disabled=${this.loading}
          @click=${this.handleMoreClicked}>
          ${this.label} ${this.activeFilterCount > 0 ? html ` <jh-tag label=${this.activeFilterCount}></jh-tag> ` : ''}
          <slot name="icon"><jh-icon-chevron-down-small></jh-icon-chevron-down-small></slot>
        </button>

        <jh-menu>
          <div class="menu-content">
            <div class="buttons">
              ${(this.filters || []).map((item) => html `
                  <jha-table-filter-button
                    .itemId=${item.id}
                    .label=${item.label}
                    .filterType=${item.filterType}
                    .value=${item.value}
                    ?disabled=${this.loading}
                    ?selected=${this.selectedMoreFilterId === item.id}
                    @click=${() => {
            this.selectedMoreFilterId = item.id;
        }}></jha-table-filter-button>
                `)}
            </div>
            ${this.renderSelectedMoreFilter()}
          </div>
        </jh-menu>
      </jha-popover>
    `;
    }
}
customElements.define('jha-collapsed-filter-menu', JhaCollapsedFilterMenu);
