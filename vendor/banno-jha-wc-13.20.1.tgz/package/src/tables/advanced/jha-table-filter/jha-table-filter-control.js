import { html, css } from 'lit';
import { format, isValid } from 'date-fns';
import JhaStyleElement from '../../../style-element/JhaStyleElement.js';
import { jhaStyles } from '../../../styles/jha-styles.js';
import { JhaTableFilterType } from './JhaTableFilter.js';
import '@jack-henry/jh-elements/components/button/button.js';
import '@jack-henry/jh-elements/components/menu/menu.js';
import '@jack-henry/jh-elements/components/tag/tag.js';
import '@jack-henry/jh-elements/components/input/input.js';
import '@jack-henry/jh-elements/components/list-group/list-group.js';
import '@jack-henry/jh-elements/components/list-item/list-item.js';
import '@jack-henry/jh-elements/components/radio/radio.js';
import '@jack-henry/jh-elements/components/radio-group/radio-group.js';
import '@jack-henry/jh-elements/components/checkbox/checkbox.js';
import '../../../forms/jha-form-date-input/jha-form-date-input.js';
import '../../../forms/jha-form-input-base/jha-form-input.js';
import '../../../forms/jha-form-select/jha-form-select.js';
import '../../../jha-popover/jha-popover.js';
import '@jack-henry/jh-icons/icons-wc/icon-chevron-down-small.js';
import './jha-table-filter-button.js';
const INITIAL_OPTION_COUNT = 10;
const exactMatchOptions = [
    {
        name: 'is between',
        value: 'range',
    },
    {
        name: 'is equal to',
        value: 'exact',
    },
];
const styles = css `
  :host {
    display: block;
    --jh-tag-size-max-width: 300px;
    --jha-popover-overflow: visible;

    --jh-menu-color-background: var(--jh-color-container-secondary-enabled);
    --jh-radio-input-color-background-unselected-enabled: var(--jh-color-container-secondary-enabled);
    --jh-radio-input-color-background-unselected-hover: var(--jh-color-container-secondary-enabled);
    --jh-radio-input-color-border-unselected-enabled: var(--jh-color-gray-500);

    --jh-checkbox-input-color-background-unselected-hover: var(--jh-color-container-secondary-enabled);
    --jh-checkbox-input-color-background-unselected-enabled: var(--jh-color-container-secondary-enabled);
    --jh-checkbox-input-color-border-unselected-enabled: var(--jh-color-gray-500);
  }
  jh-menu {
    width: 225px;
    font-size: 14px;
    overflow: visible;
    height: 100%;
  }
  :host([loading]) jh-menu {
    visibility: hidden;
  }
  .content {
    display: flex;
    flex-direction: column;
    height: 100%;
    overflow: hidden;
  }
  :host([filter-type='list']) jh-menu .content,
  :host([filter-type='single-selection']) jh-menu .content {
    max-height: var(--jha-table-filter-list-height, 440px);
  }

  jh-list-item {
    --jh-list-item-space-padding-left: 16px;
    padding-bottom: 4px;
    --jh-dimension-400: 4px;
    margin: 0;
  }
  jh-list-item:hover {
    background-color: var(--jh-color-container-primary-hover);
  }
  jh-radio,
  jh-checkbox {
    width: 100%;
    padding: 8px 0;
  }
  form {
    padding: 0;
    display: flex;
    flex-direction: column;
    overflow: auto;
    flex: 2;
  }
  .form-content {
    flex: 2;
    overflow: auto;
    display: flex;
    flex-direction: column;
  }
  jh-radio-group,
  jh-list-group {
    overflow: auto;
    margin: 8px 8px 0;
    padding-bottom: 16px;
  }
  section {
    padding: 8px 16px;
  }
  footer {
    border-top: 1px solid var(--jh-color-divider-primary);
    padding: 8px 16px;
    display: flex;
    gap: 8px;
    justify-content: space-between;
    --jh-button-size: 32px;
  }
  jh-button {
    flex: 2;
  }

  p {
    margin: 8px 16px 0;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    flex-shrink: 0;
  }

  p.help-text {
    font-weight: 500;
    margin-top: 0;
  }

  p.no-results {
    font-weight: 500;
    margin: 16px;
  }

  .inputs {
    margin: 16px 0;
  }

  .inputs[range] {
    display: flex;
    flex-direction: column;
    gap: 4px;
    align-items: center;
  }

  jh-input {
    margin: 8px 16px;
    width: auto;
    display: block;
  }

  jh-input#string-input {
    margin: 8px 0;
  }

  [range] jha-form-input,
  [range] jha-form-date-input,
  [range] jh-input {
    width: 100%;
  }

  @media (prefers-color-scheme: dark) {
    :host {
      --jh-radio-input-color-border-unselected-enabled: var(--jh-color-gray-400);
      --jh-checkbox-input-color-border-unselected-enabled: var(--jh-color-gray-400);
    }
  }
`;
/**@element jha-table-filter */
export default class JhaTableFilterControl extends JhaStyleElement {
    static get properties() {
        return {
            filterType: {
                type: String,
                reflect: true,
                attribute: 'filter-type',
            },
            options: {
                type: Array,
            },
            label: {
                type: String,
            },
            value: {
                type: Array,
            },
            itemId: {
                type: String,
            },
            minNumber: {
                type: String,
            },
            maxNumber: {
                type: String,
            },
            minDate: {
                type: String,
            },
            maxDate: {
                type: String,
            },
            exactMatch: {
                type: Boolean,
            },
            showDateForm: {
                type: Boolean,
            },
            searchQuery: {
                type: String,
            },
            tempValue: {
                type: Array,
            },
            loading: {
                type: Boolean,
                reflect: true,
            },
            hasFilter: {
                type: Boolean,
                reflect: true,
                attribute: 'has-filter',
            },
            visibleOptionCount: {
                type: Number,
            },
        };
    }
    constructor() {
        super();
        this.filterType = undefined;
        this.options = [];
        this.value = [];
        this.tempValue = [];
        this.label = '';
        this.itemId = '';
        this.minNumber = '';
        this.maxNumber = '';
        this.minDate = '';
        this.maxDate = '';
        this.exactMatch = false;
        this.showDateForm = false;
        this.searchQuery = '';
        this.tempFilterType_ = undefined;
        this.loading = false;
        this.hasFilter = false;
        this.visibleOptionCount = INITIAL_OPTION_COUNT;
    }
    static get styles() {
        return [jhaStyles, styles];
    }
    willUpdate(changedProperties) {
        if (changedProperties.has('filterType') && this.filterType && this.filterType !== this.tempFilterType_) {
            this.tempFilterType_ = this.filterType;
        }
        if (changedProperties.has('options')) {
            this.visibleOptionCount = INITIAL_OPTION_COUNT;
        }
        if (!changedProperties.has('value'))
            return;
        this.value = this.value ?? [];
        this.handleClear();
        if (this.value?.length || changedProperties.get('value')?.length) {
            if (this.filterType === JhaTableFilterType.RANGE) {
                this.minNumber = this.value[0] || '';
                this.maxNumber = this.value[1] || '';
            }
            if (this.filterType === JhaTableFilterType.DATE) {
                this.minDate = this.value[0] ? this.getDateString(this.value[0]) : '';
                this.maxDate = this.value[1] ? this.getDateString(this.value[1]) : '';
                if (this.options?.length) {
                    this.showDateForm = true;
                }
                this.exactMatch = this.value.length === 1;
            }
            this.tempValue = [...this.value];
            this.hasFilter = this.value.length > 0;
        }
    }
    getDateString(date) {
        const d = new Date(date);
        return isValid(d) ? d.toISOString().substring(0, 10) : date;
    }
    get showRangeWarning() {
        if (this.exactMatch || !(this.minNumber && this.maxNumber))
            return false;
        return parseFloat(this.minNumber) > parseFloat(this.maxNumber);
    }
    get showDateWarning() {
        if (this.exactMatch)
            return false;
        const start = this.minDate && new Date(this.minDate);
        const end = this.maxDate && new Date(this.maxDate);
        if (!(start && end))
            return false;
        return start > end;
    }
    get disableSubmit() {
        const filterType = this.tempFilterType_ || this.filterType;
        if (filterType === JhaTableFilterType.STRING) {
            const requiredLength = this.options?.length ? 2 : 1;
            return this.tempValue?.filter(Boolean).length !== requiredLength;
        }
        if (this.showRangeWarning || this.showDateWarning)
            return true;
        const { RANGE, DATE } = JhaTableFilterType;
        if (![RANGE, DATE].includes(filterType))
            return false;
        const min = RANGE === filterType ? this.minNumber : this.minDate;
        const max = RANGE === filterType ? this.maxNumber : this.maxDate;
        return this.exactMatch ? !min : !(min || max);
    }
    get filteredOptions() {
        if (!this.searchQuery) {
            return this.options;
        }
        return this.options.filter((item) => item.toLowerCase().includes(this.searchQuery));
    }
    get visibleOptions() {
        return this.filteredOptions.slice(0, this.visibleOptionCount);
    }
    get stringSelectedOption() {
        if (this.filterType !== JhaTableFilterType.STRING || !this.value?.length) {
            return this.options?.[0] || '';
        }
        return this.value[0];
    }
    itemSelected(item) {
        return Boolean(this.tempValue.find((i) => `${i}`.toLowerCase() === `${item}`.toLowerCase()));
    }
    handleItemClicked(evt, item) {
        const selected = evt.target.checked;
        if (selected) {
            if (this.filterType === JhaTableFilterType.SINGLE_SELECTION) {
                this.tempValue = [item];
            }
            else {
                this.tempValue = [...this.tempValue, ...[item]];
            }
        }
        else {
            this.tempValue = this.tempValue.filter((i) => i !== item);
        }
    }
    handleSelectChange_(evt) {
        this.exactMatch = evt.detail === 'exact';
    }
    renderDateHelperText() {
        if ((this.exactMatch && !this.minDate) || !(this.minDate || this.maxDate))
            return '';
        const dates = [this.minDate, this.maxDate].map((d) => (d ? format(`${d}T12:00:00.000Z`, 'MM/dd/yyyy') : null));
        let text = '';
        if (this.exactMatch && dates[0]) {
            text = `On ${dates[0]}`;
        }
        else if (dates[0] && !dates[1]) {
            text = `After ${dates[0]}`;
        }
        else if (!dates[0] && dates[1]) {
            text = `Before ${dates[1]}`;
        }
        else {
            text = `${dates.join(' - ')}`;
        }
        return html ` <p class="help-text"><em>${text}</em></p> `;
    }
    dispatchChange() {
        this.hasFilter = this.value.length > 0;
        this.dispatchEvent(new CustomEvent('filter-change', {
            detail: {
                id: this.itemId,
                filter: {
                    filterType: this.filterType,
                    value: this.value,
                },
            },
            bubbles: true,
            composed: true,
        }));
    }
    handleRangeUpdate() {
        this.value = this.exactMatch ? [this.minNumber] : [this.minNumber, this.maxNumber];
        this.dispatchChange();
    }
    handleDateUpdate() {
        this.value = (this.exactMatch ? [this.minDate] : [this.minDate, this.maxDate]).map((dStr) => dStr ? new Date(dStr.replace(/-/g, '/')) : null);
        this.dispatchChange();
    }
    handleListScroll_(evt) {
        const { target } = evt;
        const distanceToBottom = target.scrollHeight - (target.scrollTop + target.clientHeight);
        if (distanceToBottom < 50 && this.visibleOptionCount < this.options.length) {
            this.visibleOptionCount += INITIAL_OPTION_COUNT;
        }
    }
    handleUpdateSubmit_(evt) {
        if (this.disableSubmit)
            return;
        if (this.tempFilterType_ && this.tempFilterType_ !== this.filterType) {
            this.filterType = this.tempFilterType_;
            this.tempFilterType_ = undefined;
        }
        evt.preventDefault();
        evt.stopPropagation();
        switch (this.filterType) {
            case JhaTableFilterType.RANGE:
                this.handleRangeUpdate();
                break;
            case JhaTableFilterType.DATE:
                this.handleDateUpdate();
                break;
            default:
                this.value = [...[], ...this.tempValue];
                this.dispatchChange();
                break;
        }
    }
    handleClear() {
        this.minNumber = '';
        this.maxNumber = '';
        this.minDate = '';
        this.maxDate = '';
        this.tempValue = [];
    }
    handleClearClick_() {
        this.value = [];
        this.tempValue = [];
        const stringInput = /** @type {import('@jack-henry/jh-elements/components/input/input.js').default} */ (this.shadowRoot.querySelector('jh-input#string-input'));
        if (stringInput) {
            stringInput.value = '';
        }
        this.dispatchChange();
    }
    handleFormEnter_(evt) {
        if (evt.key === 'Enter') {
            this.handleUpdateSubmit_(evt);
        }
    }
    handleCustomDateOption_(option) {
        if (option === 'Custom') {
            this.tempFilterType_ = JhaTableFilterType.DATE;
            this.showDateForm = true;
            this.tempValue = [option];
            return;
        }
        this.showDateForm = false;
        this.tempFilterType_ = JhaTableFilterType.DATE_CUSTOM;
        this.tempValue = [option];
    }
    handleSearchInput(evt) {
        this.searchQuery = (evt.target?.value || '').toLowerCase().trim();
    }
    handleStringSelectChange_(evt) {
        this.value = [evt.detail, (this.value || [])[1]];
    }
    handleStringInput_(evt) {
        const strVal = evt.target?.value || '';
        if (this.options?.length) {
            const optVal = this.tempValue[0] || this.options[0];
            this.tempValue = [optVal, strVal];
            return;
        }
        this.tempValue = [strVal];
    }
    renderOptionSearch() {
        if (this.options.length < INITIAL_OPTION_COUNT)
            return '';
        return html `
      <jh-input
        placeholder="Search the list"
        show-clear-button
        type="search"
        size="small"
        autocomplete="off"
        @jh-clear=${this.handleSearchInput}
        @input=${this.handleSearchInput}></jh-input>

      ${!this.visibleOptions.length ? html ` <p class="no-results">No results found</p> ` : ''}
    `;
    }
    renderOptionList() {
        if (!this.options?.length)
            return '';
        return html `
      ${this.renderOptionSearch()}
      <jh-list-group @scroll=${this.handleListScroll_}>
        ${this.visibleOptions.map((option) => html `
            <jh-list-item>
              <jh-checkbox
                .checked=${this.itemSelected(option)}
                .label=${option}
                .name=${option}
                @jh-change=${(evt) => this.handleItemClicked(evt, option)}>
                ${option}
              </jh-checkbox>
            </jh-list-item>
          `)}
      </jh-list-group>
    `;
    }
    renderSingleSelection() {
        if (!this.options?.length)
            return '';
        return html `
      ${this.renderOptionSearch()}
      <jh-radio-group @scroll=${this.handleListScroll_}>
        ${this.visibleOptions.map((option) => html `
            <jh-list-item
              class="date-option"
              ?selected=${this.itemSelected(option)}>
              <jh-radio
                label=${option}
                name="date-option"
                .checked=${this.itemSelected(option)}
                @jh-change=${(evt) => this.handleItemClicked(evt, option)}>
              </jh-radio>
            </jh-list-item>
          `)}
      </jh-radio-group>
    `;
    }
    renderRangeSelector() {
        return html `
      <section>
        <jha-form-select
          small
          .options=${exactMatchOptions}
          .value=${this.exactMatch ? 'exact' : 'range'}
          @change=${this.handleSelectChange_}></jha-form-select>

        <div
          class="inputs"
          ?range=${!this.exactMatch}>
          <jha-form-input
            small
            .value=${this.minNumber}
            placeholder="0"
            @change=${(evt) => {
            this.minNumber = evt.detail;
        }}></jha-form-input>

          ${this.exactMatch
            ? ''
            : html `
                <span>and</span>
                <jha-form-input
                  small
                  .value=${this.maxNumber}
                  placeholder="Infinity"
                  warning="Min value must be smaller than Max value"
                  @change=${(evt) => {
                this.maxNumber = evt.detail;
            }}
                  .showWarning=${this.showRangeWarning}></jha-form-input>
              `}
        </div>
      </section>
    `;
    }
    renderDateRangeSelector() {
        return html `
      <section>
        <jha-form-select
          small
          .options=${exactMatchOptions}
          @change=${this.handleSelectChange_}
          .value=${this.exactMatch ? 'exact' : 'range'}></jha-form-select>
        <div
          class="inputs"
          ?range=${!this.exactMatch}>
          <jha-form-date-input
            small
            max=""
            .value=${this.minDate}
            @change=${(evt) => {
            this.minDate = evt.detail;
        }}></jha-form-date-input>
          ${this.exactMatch
            ? ''
            : html `
                <span>and</span>
                <jha-form-date-input
                  small
                  max=""
                  .value=${this.maxDate}
                  @change=${(evt) => {
                this.maxDate = evt.detail;
            }}
                  warning="The start date must be before the end date"
                  .showWarning=${this.showDateWarning}></jha-form-date-input>
              `}
        </div>
      </section>
      ${this.renderDateHelperText()}
    `;
    }
    renderFooter() {
        return html `
      <footer>
        <jh-button
          type="button"
          label="Clear"
          appearance="tertiary"
          size="small"
          @click=${this.handleClearClick_}
          block></jh-button>
        <jh-button
          type="button"
          label="Apply"
          appearance="primary"
          size="small"
          block
          @click=${this.handleUpdateSubmit_}
          ?disabled=${this.disableSubmit}></jh-button>
      </footer>
    `;
    }
    renderDateOptions() {
        if (!this.options?.length) {
            return this.renderDateRangeSelector();
        }
        return html `
      <jh-list-group>
        ${[...this.options, ...['Custom']].map((option) => html `
            <jh-list-item
              tabindex="0"
              class="date-option">
              <jh-radio
                label=${option}
                name="date-option"
                .checked=${(this.tempFilterType_ === JhaTableFilterType.DATE_CUSTOM && this.itemSelected(option)) ||
            (option === 'Custom' && this.showDateForm)}
                @jh-change=${(evt) => this.handleCustomDateOption_(option)}>
              </jh-radio>
            </jh-list-item>
          `)}
        ${this.showDateForm ? this.renderDateRangeSelector() : ''}
      </jh-list-group>
    `;
    }
    renderStringFilter() {
        return html `
      <section>
        ${this.options
            ? html `
              <jha-form-select
                small
                .options=${this.options.map((option) => ({
                name: option,
                value: option,
            }))}
                .value=${this.stringSelectedOption}
                @change=${this.handleStringSelectChange_}></jha-form-select>
            `
            : ''}
        <jh-input
          id="string-input"
          size="small"
          autocomplete="off"
          .value=${this.tempValue?.[1] || ''}
          @input=${this.handleStringInput_}></jh-input>
      </section>
    `;
    }
    renderFormContent() {
        switch (this.filterType) {
            case JhaTableFilterType.LIST:
                return this.renderOptionList();
            case JhaTableFilterType.SINGLE_SELECTION:
                return this.renderSingleSelection();
            case JhaTableFilterType.RANGE:
                return this.renderRangeSelector();
            case JhaTableFilterType.DATE:
            case JhaTableFilterType.DATE_CUSTOM:
                return this.renderDateOptions();
            case JhaTableFilterType.STRING:
                return this.renderStringFilter();
            default:
                return '';
        }
    }
    render() {
        return html `
      <jh-menu>
        <div class="content">
          <p title="Filter by ${(this.label || '').toLocaleLowerCase()}">
            Filter by ${(this.label || '').toLocaleLowerCase()}
          </p>
          <form @keyup=${this.handleFormEnter_}>
            <div class="form-content">${this.renderFormContent()}</div>
            ${this.renderFooter()}
          </form>
        </div>
      </jh-menu>
    `;
    }
}
customElements.define('jha-table-filter-control', JhaTableFilterControl);
