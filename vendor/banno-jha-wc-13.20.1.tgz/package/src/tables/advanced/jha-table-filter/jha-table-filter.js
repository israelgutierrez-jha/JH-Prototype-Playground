import JhaTableFilter from './JhaTableFilter.js';
customElements.define('jha-table-filter', JhaTableFilter);
/** @customElement jha-table-filter */
export default JhaTableFilter;
