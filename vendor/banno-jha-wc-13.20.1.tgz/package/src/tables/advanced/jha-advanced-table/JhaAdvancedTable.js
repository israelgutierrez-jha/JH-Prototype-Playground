var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { css, html, LitElement, nothing } from 'lit';
import { property, state } from 'lit/decorators.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { styleMap } from 'lit/directives/style-map.js';
import { classMap } from 'lit/directives/class-map.js';
import { jhaStyles } from '../../../styles/jha-styles.js';
import { sortTableData, valueChanged } from '../../../js/utils/data-mapping-util.js';
import { DataType, getNestedValue, getValueFromObject, getValueString, getFilterProps, filterMatches, } from '../../../js/utils/data-rendering-util.js';
import '../jha-table-filter/jha-table-filter.js';
import '../jha-table-filter-group/jha-table-filter-group.js';
import '../jha-table-column-sorter/jha-table-column-sorter.js';
import '../table-views/jha-table-views/jha-table-views.js';
import '../../jha-table-header/jha-table-header.js';
import '../../jha-table-row/jha-table-row.js';
import '../../jha-table-cell/jha-table-cell.js';
import '../../../jha-tab/jha-tab.js';
import '../../../jha-tab-item/jha-tab-item.js';
import '../../../jha-badge/jha-badge.js';
import '@jack-henry/jh-elements/components/input/input.js';
import '@jack-henry/jh-elements/components/button/button.js';
import '@jack-henry/jh-elements/components/progress/progress.js';
import '@jack-henry/jh-elements/components/menu/menu.js';
import '@jack-henry/jh-elements/components/badge/badge.js';
// Import Icons Statically, importing these dynamically is causing issues in the consuming code
import '../../../icons/jha-icons.js';
import '@jack-henry/jh-icons/icons-wc/icon-arrow-up-small.js';
import '@jack-henry/jh-icons/icons-wc/icon-arrow-up-arrow-down.js';
import '@jack-henry/jh-icons/icons-wc/icon-magnifying-glass.js';
import '@jack-henry/jh-icons/icons-wc/icon-arrow-rotate-right.js';
import '@jack-henry/jh-icons/icons-wc/icon-chevron-down-small.js';
import '@jack-henry/jh-icons/icons-wc/icon-ellipsis.js';
import '@jack-henry/jh-icons/icons-wc/icon-checkmark.js';
import '@jack-henry/jh-icons/icons-wc/icon-square-checkmark.js';
import '@jack-henry/jh-icons/icons-wc/icon-square.js';
import '@jack-henry/jh-icons/icons-wc/icon-sliders.js';
const DEFAULT_PAGE_LIMIT = 10;
const DEFAULT_PAGE_LIMIT_OPTIONS = [10, 25, 50, 100];
const styles = css `
  :host {
    display: flex;
    flex-direction: column;
    overflow: hidden;
    height: 100%;
    width: 100%;
    font-size: 14px;
    --jha-table-cell-padding: 0;
    box-sizing: border-box;
    --jha-advanced-table-cell-border: transparent;
    --jha-table-cell-border-color: var(--jh-color-divider-primary);
    --jh-icon-size-medium: 24px;
    --column-max-width: var(--jha-advanced-table-column-max-width, 250px);
  }

  #component-content {
    display: flex;
    flex-direction: column;
    position: relative;
    overflow: hidden;
    height: 100%;
    width: 100%;
    padding: 4px 0; /** To avoid hiding focus state of input */
  }

  #main-search {
    width: var(--jha-advanced-table-search-width, 260px);
  }

  button {
    color: var(--jha-text-base);
  }

  @media (prefers-color-scheme: light) {
    :host {
      --jh-color-container-primary-enabled: rgb(244, 244, 244);
      --jh-color-container-primary-hover: rgb(235, 235, 235);
    }
  }

  :host([full-width-columns]) {
    --column-max-width: none;
  }

  :host([bordered]) {
    --jha-advanced-table-cell-border: var(--jh-color-divider-primary);
    --jha-table-cell-border-color: var(--jh-color-divider-primary);
  }

  :host ::slotted(h1),
  :host ::slotted(h2) {
    font-size: var(--jha-advanced-table-header-font-size, 32px);
    margin: var(--jha-advanced-table-header-margin, 0);
  }

  jha-table-cell {
    position: relative;
  }

  .header-section {
    display: flex;
    gap: 8px;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    margin-left: var(--jha-advanced-table-header-margin-left, var(--jha-advanced-table-header-margin-x, 0));
    margin-right: var(--jha-advanced-table-header-margin-right, var(--jha-advanced-table-header-margin-x, 0));
    margin-top: var(--jha-advanced-table-header-margin-top, var(--jha-advanced-table-header-margin-y, 0));
    margin-bottom: var(--jha-advanced-table-header-margin-bottom, var(--jha-advanced-table-header-margin-y, 0));
  }

  .header-section .slot {
    flex-grow: 2;
  }

  /** TABLE CONTAINER */
  div.table {
    display: table;
    width: 100%;
    height: 1px; /** trick to get buttons to fill the cells  */
    max-width: 100%;
    font-size: var(--jha-table-size, 13px);
    color: var(--jha-table-color, var(--jha-text-base, #6b757b));
  }

  jha-table-header {
    background: var(--jh-color-container-primary-enabled, rgb(244, 244, 244));
    border-top: 1px solid var(--jh-color-divider-primary);
  }

  jha-table-row:not([expand-all-columns]) jha-table-cell:not([checkbox]) {
    max-width: var(--column-max-width);
    min-width: 120px;
    overflow: hidden;
  }
  jha-table-column-sorter[has-change],
  .sort-button[has-change] {
    position: relative;
  }
  jha-table-column-sorter[has-change]:after,
  .sort-button[has-change]:after {
    content: '';
    background-color: var(--jha-color-warning);
    position: absolute;
    right: 10px;
    top: 10px;
    width: 6px;
    height: 6px;
    border-radius: 50%;
  }
  jha-table-column-sorter[has-change]:after {
    right: 2px;
    top: 8px;
  }

  jha-table-cell[row-action-offset],
  jha-table-header[row-action-offset] .col-header {
    padding-left: 24px;
  }

  div.row-actions-wrapper {
    position: absolute;
    right: 0;
    top: 0;
    padding-left: 8px;
    overflow: hidden;
    border-top: 1px solid var(--jh-color-divider-primary);
  }

  div.row-actions-header {
    background-color: var(--jh-color-container-primary-enabled, rgb(244, 244, 244));
  }

  div.row-actions-shadow {
    box-shadow: var(--jh-shadow-low);
  }

  div.row-actions-container {
    overflow: hidden;
    border-top: 1px solid var(--jh-color-divider-primary);
  }

  div.row-actions-table {
    display: table;
  }

  div.row-actions-table jha-table-cell {
    max-width: none !important;
    min-width: 0 !important;
    padding: 0;
  }

  div.row-actions-table jha-table-cell[last] {
    border-bottom: none;
  }

  jha-popover.row-actions {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  button.row-action-button {
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: var(--jha-table-row-action-cursor, inherit);
    padding: 0;
    background: transparent;
    border: none;
  }

  jha-popover.row-actions jh-icon-ellipsis {
    padding: 0 12px;
    border-radius: 0;
    box-sizing: content-box;
    max-height: 24px;
  }

  jha-popover.row-actions[open],
  jha-table-row:hover jha-popover.row-actions {
    display: block;
  }
  jha-popover jh-menu {
    min-width: 100px;
  }

  jha-popover.row-actions jh-menu {
    min-width: 200px;
  }

  jha-popover jh-menu button {
    display: flex;
    align-items: center;
    gap: 8px;
    border: none;
    padding: 12px 16px;
    cursor: pointer;
    background: transparent;
  }

  jha-popover jh-menu button:disabled {
    background: var(--jh-color-container-primary-disabled);
    color: var(--jh-color-content-primary-disabled);
    cursor: not-allowed;
    opacity: 0.5;
  }

  jha-popover jh-menu button:focus,
  jha-popover jh-menu button:hover {
    background: var(--jh-color-container-secondary-hover);
  }

  jha-popover jh-menu button[selected] {
    color: var(--jh-color-content-brand-hover);
    background: var(--jh-color-container-neutral-enabled);
    --jh-icon-color-fill: var(--jh-color-content-brand-hover);
  }

  span.icon-placeholder {
    width: 18px;
    height: 18px;
    display: block;
  }

  jha-icons {
    display: flex;
  }

  button[data-button] {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    padding: 16px;
    max-width: 100%;
    box-sizing: border-box;
    user-select: text;
    color: var(--jha-advanced-table-data-color, currentColor);
    cursor: var(--jha-table-row-cursor, inherit);
    font-feature-settings: 'tnum';
  }

  jha-table-row {
    cursor: var(--jha-table-row-cursor, inherit);
  }

  jha-table-cell[custom-value],
  jha-table-cell[custom-value] button[data-button] {
    overflow: visible !important;
  }

  jha-table-cell:first-child button[data-button] {
    color: var(--jha-advanced-table-data-color-column-1, var(--jha-advanced-table-data-color, currentColor));
    font-weight: var(--jha-advanced-table-data-font-weight-column-1, 400);
  }

  [is-grouped] jha-table-header[first] .sort-button,
  [is-grouped] jha-table-header[first] .col-header > span,
  [is-grouped] jha-table-cell[first] button[data-button] {
    padding-left: 48px;
  }

  div.table-header-content {
    padding: 0 var(--jha-advanced-table-horizontal-padding, 0) 8px;
    padding-right: var(--jha-advanced-table-horizontal-padding, 4px);
  }

  div.table-header-container {
    overflow: clip visible;
    table-layout: fixed;
    width: auto;
  }

  div.table-header-container jha-header .col-header {
    max-width: var(--column-max-width);
  }

  :host([top-table-border]) div.table-header-container {
    border-top: 1px solid var(--jha-table-header-border-color, var(--jha-border-color, #e4e7ea));
  }

  /** TABLE CONTROLS */
  jh-input {
    width: 260px;
  }

  /** Prevents cutoff of selected input border */
  .search {
    padding: 0 var(--jha-advanced-table-search-padding-x, 0);
    display: flex;
    gap: 8px;
  }

  .flex-container {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
  }

  .flex-container-end {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 8px;
  }

  .controls {
    padding: var(--jha-advanced-table-controls-padding-y, var(--jha-advanced-table-controls-padding, 0))
      var(--jha-advanced-table-controls-padding-x, var(--jha-advanced-table-controls-padding, 0));
    margin-top: var(--jha-advanced-table-controls-margin-top, 8px);
    max-height: 76px;
    flex-wrap: nowrap;
    row-gap: 20px;
  }

  .controls.has-groupings {
    margin: 8px 0;
  }

  .right-header-controls {
    --jh-button-icon-color-fill-tertiary-enabled: var(--jh-color-content-secondary-enabled);
    --jh-button-size: var(--jh-size-1000);
    margin: var(--jha-advanced-table-header-controls-margin, 8px 0);
  }

  .actions-toolbar {
    padding: var(--jha-advanced-table-controls-padding-y, var(--jha-advanced-table-controls-padding, 6px))
      var(--jha-advanced-table-controls-padding-x, var(--jha-advanced-table-controls-padding, 4px));
  }

  .actions-toolbar.compact {
    margin-top: 0;
  }

  jha-table-filter-group {
    flex: 2;
    margin: 8px 0;
  }

  jha-table-filter-group[border-left] {
    border-left: 1px solid var(--jh-color-divider-primary);
    margin-left: 8px;
    padding-left: 16px;
  }

  .refresh-button {
    white-space: nowrap;
  }
  #reset-button[hide] {
    visibility: hidden;
  }
  .edit-refresh {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
  }

  /** TABLE HEADER STYLES */
  .sort-button {
    display: flex;
    align-items: var(--jha-table-header-align-items, center);
    justify-content: space-between;
  }
  .sort-button,
  .col-header > span {
    padding: var(--jha-table-header-padding, 14px 16px);
    font-size: var(--jha-table-header-font-size, 14px);
    font-weight: var(--jha-table-header-font-weight, 700);
    text-transform: var(--jha-table-header-transform, none);
    color: var(--jha-table-header-color, var(--jha-text-light, #8c989f));
  }
  .col-header > span,
  .sort-button span {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    display: block;
  }
  .sort-button:not([disabled]):hover {
    background: var(--jh-color-container-primary-hover);
  }
  .sort-button jh-icon-arrow-up-arrow-down,
  .sort-button jh-icon-arrow-up-small {
    visibility: hidden;
  }
  .sort-button:not([disabled]):hover jh-icon-arrow-up-arrow-down,
  .sort-button:not([disabled]):hover jh-icon-arrow-up-small,
  [sort-field] .sort-button:not([disabled]) jh-icon-arrow-up-small {
    visibility: visible;
  }
  .sort-button[descending] jh-icon-arrow-up-small {
    transform: rotate(180deg);
  }

  [align-right] {
    text-align: right;
  }
  [align-right] span {
    justify-content: flex-end;
  }

  [align-right] .sort-button {
    flex-direction: row-reverse;
  }

  /** Sticky Header */
  :host([sticky-header]) div#table-header {
    position: absolute;
    top: 0;
    z-index: var(--jha-table-fixed-header-z-index, 100);
    overflow-x: clip;
    overflow-y: visible;
    width: 100%;
    background-color: var(--jha-card-background-color, var(--jha-component-background-color, #ffffff));
  }
  :host([sticky-header]) div#table-header[scrolling] {
    position: fixed;
    top: var(--jha-table-fixed-header-top, 0);
  }
  div.table-wrapper {
    overflow-x: auto;
    padding: 0 var(--jha-advanced-table-horizontal-padding, 0);
    position: relative;
  }
  div.table-wrapper:not([empty]) {
    flex-grow: 1;
  }
  div.table-wrapper.has-row-actions {
    margin-right: 42px;
  }

  jha-table-row[last-row] jha-table-cell,
  #sticky-rows jha-table-row:last-of-type jha-table-cell {
    --jha-table-cell-border-color: transparent;
  }

  jha-table-header[checkbox],
  jha-table-cell[checkbox] {
    width: 51px;
    border-left-color: transparent;
  }

  jha-form-checkbox {
    margin-left: 16px;
  }

  jha-table-header[left-border],
  jha-table-cell[left-border] {
    --jha-advanced-table-cell-border: var(--jh-color-divider-primary);
  }
  .row-actions-header,
  jha-table-cell,
  jha-table-header {
    border-left: 1px solid var(--jha-advanced-table-cell-border);
  }

  jha-table-row[selected],
  jha-table-row:not([id='table-header']):hover {
    background: var(--jha-table-hover-row-background, var(--jh-color-container-primary-hover));
  }

  jha-table-row[active] {
    background: var(--jha-table-active-row-background, var(--jh-color-container-primary-active));
  }

  #footer-container {
    display: block;
    container-type: inline-size;
    container-name: AdvancedTableFooter;
  }

  #footer {
    border-top: 1px solid var(--jh-color-divider-primary);
    width: 100%;
    display: flex;
    padding: 0;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
  }
  #footer .left {
    display: flex;
    flex-grow: 2;
  }
  #footer .right {
    display: flex;
    flex-grow: 0;
  }

  #footer .count {
    padding: 16px;
    display: flex;
    align-items: center;
  }

  #footer .pager,
  #footer .pagination {
    display: flex;
    justify-content: flex-end;
    gap: 0;
    border-left: 1px solid var(--jh-color-divider-primary);
  }

  #footer jha-popover {
    width: 100%;
  }

  #footer .page-limit {
    border-right: 1px solid var(--jh-color-divider-primary);
  }

  #footer .page-limit span,
  #footer .pager span {
    padding: 16px;
    display: flex;
    align-items: center;
  }

  #footer jha-popover[open] span,
  #footer jha-popover span:hover {
    color: var(--jh-color-content-brand-hover);
    background: var(--jh-color-container-secondary-hover);
    --jh-icon-color-fill: var(--jh-color-content-brand-hover);
  }

  @container AdvancedTableFooter (width < 600px) {
    #footer[has-pager][has-page-limit] > div {
      flex-basis: 100%;
    }

    #footer[has-pager][has-page-limit] .right {
      border-top: 1px solid var(--jha-table-header-border-color, var(--jha-border-color, #e4e7ea));
    }

    #footer[has-page-limit][has-pager] .count {
      flex-grow: 2;
      justify-content: flex-end;
    }
    #footer[has-page-limit][has-pager] .pager {
      border-left: none;
      flex-grow: 2;
      justify-content: flex-start;
    }
  }

  @container AdvancedTableFooter (width < 400px) {
    #footer[has-pager] > div,
    #footer[has-page-limit] > div {
      flex-basis: 100%;
    }

    #footer[has-pager] .right,
    #footer[has-page-limit] .right {
      border-top: 1px solid var(--jha-table-header-border-color, var(--jha-border-color, #e4e7ea));
    }

    #footer[has-page-limit] .count {
      flex-grow: 2;
      justify-content: flex-end;
    }
    #footer[has-pager] .pager {
      border-left: none;
      flex-grow: 2;
      justify-content: flex-start;
    }
    #footer[has-page-limit]:not([has-pager]) .right {
      justify-content: flex-end;
    }

    #footer[has-page-limit]:not([has-pager]) .pagination {
      border-left: none;
    }
  }

  .pagination-button {
    --jh-button-border-radius: 0;
    --jh-button-color-background-tertiary-hover: var(--jh-color-container-secondary-hover);
    --jh-button-icon-color-fill-tertiary-hover: var(--jh-color-content-brand-hover);
    --jh-button-icon-color-fill-tertiary-enabled: var(--jh-color-content-secondary-enabled);
  }

  .pagination-button svg {
    fill: var(--jh-icon-color-fill);
  }

  .pagination-button[disabled] {
    cursor: not-allowed;
    opacity: 0.3;
  }

  ::slotted([slot='custom-footer']) {
    border-top: 1px solid var(--jh-color-divider-primary) !important;
    padding: 16px 0 16px 16px;
  }
  #sticky-rows-wrapper {
    border-top: 1px solid var(--jh-color-divider-primary);
  }
  .col-header {
    position: relative;
  }
  .col-header:hover .expand-button {
    opacity: 1;
  }
  .expand-button {
    position: absolute;
    top: 16px;
    opacity: 0;
    --jh-button-size: 34px;
    right: 8px;
  }
  .expand-button *[icon] {
    --jha-icon-fill-color: var(--jh-button-label-color-text-secondary-enabled, var(--jh-color-content-brand-enabled));
    transform: rotate(90deg);
  }
  .expand-button:hover *[icon] {
    --jha-icon-fill-color: var(--jh-button-label-color-text-secondary-hover, var(--jh-color-content-on-brand-hover));
  }
  *[icon] {
    --jh-icon-color-fill: var(--jh-color-content-secondary-enabled);
  }
  jh-icon-magnifying-glass {
    --icon-size: 24px;
  }
  jh-button:not([disabled]):hover *[icon] {
    --jh-icon-color-fill: var(--jh-button-label-color-text-secondary-hover, var(--jh-color-content-on-brand-hover));
  }
  .no-content {
    width: 100%;
    flex: 2;
    text-align: center;
    align-content: center;
    min-height: var(--jha-table-no-content-min-height, 200px);
  }
  div.no-content {
    flex-direction: column;
  }
  .loading {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-grow: 2;
    padding: 32px 0;
    min-height: var(--jha-table-no-content-min-height, 200px);
  }
  jh-button[size='small'] {
    --jh-button-label-color-text-secondary-enabled: var(--jh-color-content-secondary-enabled);
    --jh-button-color-border-secondary-enabled: var(--jh-color-content-secondary-enabled);
  }
  jh-button[disabled] {
    --jh-button-label-color-text-secondary-disabled: var(--jh-color-content-primary-enabled);
    --jh-button-color-border-secondary-disabled: var(--jh-color-content-primary-enabled);
  }
  div.actions-count {
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 2px 0;
  }
  span.count {
    padding-right: 16px;
  }
  .actions-list {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
  }
  span[debit] {
    font-weight: var(--jha-table-amount-font-weight, 700);
  }
  span[debit][is-positive] {
    color: var(--jha-table-credit-amount-color, var(--jh-color-content-positive-enabled));
  }
  /** Table Grouping */
  .group-header {
    cursor: pointer;
  }
  .group-header td {
    padding: 0;
  }
  .group-header .content {
    display: flex;
    overflow: visible;
    align-items: center;
    gap: 8px;
    width: 100%;
    padding: 8px 16px;
    border-left: 1px solid var(--jha-advanced-table-cell-border);
    border-bottom: 1px solid var(--jha-table-cell-border-color);
    background: transparent;
    border-right: none;
    border-top: none;
  }
  .group-header div.content[bulk-actions] {
    padding-left: 0;
  }
  .group-header jha-form-checkbox {
    margin-right: 8px;
  }
  .group-header .group-label {
    display: flex;
    align-items: flex-start;
    flex-direction: column;
    font-size: 14px;
  }
  .group-header label {
    cursor: pointer;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .group-header .collapse-icon {
    display: flex;
    align-items: center;
    border-radius: var(--jh-border-radius-100);
  }
  .group-header .collapse-icon[collapsed] {
    transform: rotate(-90deg);
  }
  .group-header:hover {
    background: var(--jha-table-hover-row-background, var(--jh-color-container-primary-hover));
  }
  .group-header:hover:not(:has(jha-form-checkbox:hover)) .collapse-icon {
    background-color: var(--jh-color-container-primary-hover);
  }
  jh-badge {
    --jh-dimension-100: 4px;
    --jh-dimension-0: 0;
    --jh-dimension-400: 16px;
    --jh-font-helper-medium-font-size: 12px;
  }

  .grouping-controls {
    padding-left: 4px;
  }

  .grouping-button {
    --jh-button-icon-color-fill-secondary-enabled: var(--jh-color-content-secondary-enabled);
  }

  .grouping-button[active] {
    --jh-button-icon-color-fill-secondary-enabled: var(--jh-color-content-brand-enabled);
    --jh-button-color-border-secondary-enabled: var(--jh-color-content-brand-enabled);
    --jh-button-label-color-text-secondary-enabled: var(--jh-color-content-brand-enabled);
    --jh-button-color-background-secondary-enabled: var(--jh-color-container-primary-selected);
  }

  .grouping-label {
    border: 1px solid var(--jh-color-content-secondary-enabled);
    --jh-icon-color-fill: var(--jh-color-content-secondary-enabled);
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 4px 16px;
    border-radius: 4px;
    height: 40px;
  }

  .grouping-controls jh-menu {
    min-width: 200px;
    padding: 8px;
  }

  .grouping-controls jh-menu label {
    text-transform: uppercase;
    font-size: 12px;
    font-weight: 700;
    color: var(--jh-color-content-secondary-enabled);
    margin-left: 8px;
  }

  .grouping-controls jh-menu button {
    border-radius: 4px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 8px;
    line-height: 24px;
  }
  .grouping-controls jh-menu .buttons {
    display: flex;
    flex-direction: column;
    gap: 4px;
  }
  .grouping-controls jh-menu button[active] {
    background: var(--jh-color-container-secondary-hover);
  }
`;
export default class JhaAdvancedTable extends LitElement {
    constructor() {
        super(...arguments);
        this.columns = [];
        this.data = [];
        this.pageLimitOptions = DEFAULT_PAGE_LIMIT_OPTIONS;
        this.rowActions = [];
        this.selectedItems = [];
        this.stickyRows = [];
        this.views = [];
        this.allowPageChange = false;
        this.allowPageLimitChange = false;
        this.allowRefresh = false;
        this.apiHasMoreData = false;
        this.bulkActions = false;
        this.canEditColumns = false;
        this.canEditViews = false;
        this.fullWidthColumns = false;
        this.hideAllView = false;
        this.loading = false;
        this.loadingMore = false;
        this.noPagination = false;
        this.stickyHeader = false;
        this.pageLimit = DEFAULT_PAGE_LIMIT;
        this.pageOffset = 0;
        this.maxVisibleFilters = undefined;
        this.actionPositionValues = null;
        this.columnWidths = {};
        this.tableConfig = null;
        this.activeViewId = null;
        this.dataPlural = 'items';
        this.noContentMessage = '';
        this.searchPlaceholderText = null;
        this.selectedItemIdentifier = 'id';
        this.collapsedGroupIds = [];
        this.componentWidth = null;
        this.tableHeaderWidth = null;
        this.headerFixed = false;
        this.handleSearchButtonEnter = (evt) => {
            if ((evt.code === 'Enter' || evt.code === 'NumpadEnter') && this.tableConfig?.showSearchButton) {
                this.dispatchTableUpdate('searchQuery');
            }
        };
        this.handleTableResize = async () => {
            this.columnWidths = {};
            await this.updateComplete;
            this.componentWidth = null;
            this.tableHeaderWidth = null;
            const tableElementsExist = Boolean(this.tableHeader && this.componentHeader && this.tableEl);
            if (!this.visibleColumns.length || !tableElementsExist) {
                return;
            }
            const componentHeaderHeight = this.componentHeader.getBoundingClientRect().height;
            this.tableEl.style.marginTop = `${(this.stickyHeader ? componentHeaderHeight : 0) - this.tableHeaderHeight}px`;
            await this.updateComplete;
            if (this.tableHeader.getBoundingClientRect().width <= this.componentContent?.getBoundingClientRect().width &&
                !this.tableFirstRow) {
                this.adjustHeaderWidths();
                return;
            }
            await this.updateComplete;
            this.columnWidths = {};
            (this.tableFirstRow?.querySelectorAll('jha-table-cell') || []).forEach((item) => {
                if (item.id) {
                    this.columnWidths[item.id] = item.getBoundingClientRect().width;
                }
            });
            this.componentWidth = `${this.componentContent?.getBoundingClientRect().width}px`;
            this.tableHeaderWidth = this.tableFirstRow?.getBoundingClientRect().width;
            await this.calculateTableActionsPosition();
        };
        this.handleTableScroll = () => {
            if (this.stickyTableHeaderContainer && this.tableWrapper) {
                const headerWrapper = this.stickyTableHeaderContainer;
                headerWrapper.style.marginLeft = `-${this.tableWrapper.scrollLeft}px`;
            }
            if (this.stickyRows.length) {
                const stickyRows = this.shadowRoot.querySelector('div#sticky-rows');
                stickyRows.style.marginLeft = `-${this.tableWrapper.scrollLeft}px`;
            }
            if (this.rowActionTable) {
                this.rowActionTable.style.marginTop = `-${this.tableWrapper.scrollTop}px`;
            }
        };
        this.handlePageScroll = () => {
            if (!this.stickyHeader)
                return;
            const { top } = this.componentContent?.getBoundingClientRect();
            this.headerFixed = top < this.fixedHeaderTop;
        };
    }
    static get styles() {
        return [jhaStyles, styles];
    }
    connectedCallback() {
        super.connectedCallback();
        this.initializeTable();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        this.shadowRoot.removeEventListener('resize', this.handleTableResize);
        if (this.resizeObserver_) {
            this.resizeObserver_.unobserve(this);
        }
        document.removeEventListener('scroll', this.handlePageScroll);
        document.removeEventListener('keyup', this.handleSearchButtonEnter);
    }
    updated(ChangedProperties) {
        // The table will reset pageOffset when the loading property changes
        // but not when the data property changes, so that you can add data to the array without resetting to the first page.
        if (ChangedProperties.has('loading') && ChangedProperties.get('loading') && !this.loading) {
            this.pageOffset = 0;
            this.selectedItems = [];
            this.handleTableResize();
        }
        if (ChangedProperties.has('pageOffset') && ChangedProperties.get('pageOffset') !== undefined) {
            this.scrollToTopOfTable_();
        }
        if (ChangedProperties.has('selectedItems') || (ChangedProperties.has('loadingMore') && !this.loadingMore)) {
            this.handleTableResize();
        }
        if ((ChangedProperties.has('views') && this.views?.length) || ChangedProperties.get('views')?.length) {
            this.setClonedViews_();
        }
    }
    setClonedViews_() {
        this.clonedViews_ = (this.views || []).map((item) => ({
            id: item.id,
            label: item.label,
            actions: item.actions,
            config: {
                filters: item.config?.filters
                    ? Object.entries(item.config.filters).reduce((acc, [key, value]) => {
                        acc[key] = { ...value };
                        return acc;
                    }, {})
                    : {},
                sort: { ...(item.config?.sort || {}), ...{} },
                columnOrder: item.config?.columnOrder ? [...(item.config?.columnOrder || []), ...[]] : undefined,
                searchQuery: item.config?.searchQuery || '',
                groupings: item.config?.groupings ? [...(item.config?.groupings || []), ...[]] : undefined,
            },
        }));
        // Reset active id if view no longer exists
        if (this.activeViewId && !(this.views || []).find((item) => item.id === this.activeViewId)) {
            this.activeViewId = null;
        }
        else {
            this.requestUpdate();
        }
    }
    async initializeTable() {
        await this.updateComplete;
        this.resizeObserver_ = new ResizeObserver(this.handleTableResize);
        this.resizeObserver_.observe(this);
        document.addEventListener('scroll', this.handlePageScroll);
        document.addEventListener('keyup', this.handleSearchButtonEnter);
    }
    dispatchTableUpdate(type) {
        this.dispatchEvent(new CustomEvent('table-update', {
            detail: {
                type,
                config: this.currentConfig,
                viewId: this.activeViewId,
            },
            bubbles: true,
            composed: true,
        }));
    }
    dispatchBulkSelection() {
        this.dispatchEvent(new CustomEvent('bulk-select', {
            bubbles: true,
            composed: true,
            detail: {
                items: this.selectedItems,
            },
        }));
    }
    get currentConfig() {
        const { sort, filters, ...rest } = this.tableConfig ?? {};
        return ((this.clonedViews_ || []).find((item) => item.id === this.activeViewId)?.config ||
            { sort: sort ?? {}, filters: filters ?? {}, ...rest });
    }
    set currentConfig(config) {
        if (this.activeViewId && this.clonedViews_?.length) {
            const view = this.clonedViews_.find((item) => item.id === this.activeViewId);
            view.config = config;
            return;
        }
        // reset the collapsed groups array for now
        if (config.activeGroupingId && config.activeGroupingId !== this.tableConfig?.activeGroupingId) {
            this.collapsedGroupIds = [];
        }
        this.tableConfig = config;
    }
    get filters() {
        return this.currentConfig?.filters || {};
    }
    set filters(filters) {
        this.pageOffset = 0;
        this.currentConfig = {
            ...(this.currentConfig || {}),
            ...{ filters },
        };
        this.dispatchTableUpdate('filters');
    }
    get activeViewHasChanges() {
        if (this.activeViewId) {
            return Boolean(this.changedViewProperties);
        }
        const hasFilters = Object.keys(this.filters || {})?.length > 0;
        return hasFilters || Boolean(this.searchQuery);
    }
    get changedViewProperties() {
        if (!this.activeViewId)
            return null;
        let changedProps = {};
        const baseConfig = this.views?.find((item) => item.id === this.activeViewId)?.config;
        if (!baseConfig)
            return null;
        const { filters, sort, columnOrder, searchQuery } = baseConfig;
        if (sort?.columnId !== this.currentConfig.sort?.columnId ||
            sort?.descending !== this.currentConfig.sort?.descending) {
            changedProps = { ...changedProps, ...{ sort: this.currentConfig.sort } };
        }
        const filterChanges = this.filterColumns
            .filter((item) => valueChanged(filters?.[item.id]?.value, this.currentConfig.filters?.[item.id]?.value))
            .map((item) => item.id);
        if (filterChanges.length) {
            changedProps = { ...changedProps, ...{ filters: filterChanges } };
        }
        const defaultColumnOrder = this.columns.map((item) => item.id);
        const ordersDontMatch = valueChanged(columnOrder || defaultColumnOrder, this.currentConfig.columnOrder || defaultColumnOrder);
        if (ordersDontMatch) {
            changedProps = { ...changedProps, ...{ columnOrder: true } };
        }
        if ((searchQuery || this.searchQuery) && searchQuery !== this.searchQuery) {
            changedProps = { ...changedProps, ...{ searchQuery } };
        }
        return Object.keys(changedProps).length ? changedProps : null;
    }
    get filtersChanged() {
        const filterProps = this.activeViewId ? this.changedViewProperties : this.filters;
        return Object.keys(filterProps || {})?.length > 0;
    }
    get searchQuery() {
        return this.currentConfig?.searchQuery || '';
    }
    set searchQuery(searchQuery) {
        this.pageOffset = 0;
        this.currentConfig = /** @type {?dataConfiguration} */ {
            ...(this.currentConfig || {}),
            ...{ searchQuery },
        };
        if (!searchQuery || !this.tableConfig?.showSearchButton) {
            this.dispatchTableUpdate('searchQuery');
        }
        this.handleTableResize();
    }
    get sortColumnId() {
        return ((this.currentConfig || {}).sort || {}).columnId || '';
    }
    get sortDescending() {
        return Boolean(((this.currentConfig || {}).sort || {}).descending);
    }
    set sort(sort) {
        this.pageOffset = 0;
        this.currentConfig = /** @type {?dataConfiguration} */ {
            ...(this.currentConfig || {}),
            ...{ sort },
        };
        this.dispatchTableUpdate('sort');
    }
    get columnOrder() {
        return (this.currentConfig || {}).columnOrder || this.columns.map((item) => item.id);
    }
    set columnOrder(columnOrder) {
        this.currentConfig = /** @type {?dataConfiguration} */ {
            ...(this.currentConfig || {}),
            ...{ columnOrder },
        };
        this.dispatchTableUpdate('columnOrder');
        this.handleTableResize();
    }
    get listLength() {
        return this.tableConfig?.apiTotal || this.visibleData?.length || 0;
    }
    get startEnd() {
        const first = 1 + this.pageLimit * this.pageOffset;
        const last = this.pageLimit * this.pageOffset + this.pageLimit;
        return [first, last > this.listLength ? this.listLength : last];
    }
    get disableNext() {
        const loadingMore = !this.visibleSlice.length && this.loadingMore;
        const hasNoMoreData = !this.apiHasMoreData && this.startEnd[1] >= this.listLength;
        return hasNoMoreData || loadingMore;
    }
    get totalPages() {
        return Math.ceil(this.listLength / this.pageLimit);
    }
    get searchableCols() {
        return (this.columns || []).filter((item) => item.searchable) || [];
    }
    get tableHeader() {
        return this.shadowRoot.querySelector('div.table jha-table-row#table-header');
    }
    get tableHeaderHeight() {
        return this.tableHeader?.getBoundingClientRect().height;
    }
    get componentHeader() {
        return this.shadowRoot.querySelector('div#table-header');
    }
    get tablePositionTop() {
        const componentHeaderHeight = this.componentHeader?.getBoundingClientRect().height;
        const tableHeaderHeight = this.tableHeader?.getBoundingClientRect().height;
        if (!(componentHeaderHeight && tableHeaderHeight))
            return 0;
        return componentHeaderHeight - tableHeaderHeight + 5;
    }
    get componentContent() {
        return this.shadowRoot.querySelector('div#component-content');
    }
    get tableEl() {
        return this.shadowRoot.querySelector('div.table');
    }
    get tableWrapper() {
        return this.shadowRoot.querySelector('div.table-wrapper');
    }
    get tableWrapperHeight() {
        return this.tableWrapper?.getBoundingClientRect().height;
    }
    get tableFirstRow() {
        return this.shadowRoot.querySelector('div.table jha-table-row[first-row]');
    }
    get tableRowHeight() {
        return this.tableFirstRow?.getBoundingClientRect().height;
    }
    get stickyTableHeaderContainer() {
        return this.shadowRoot.querySelector('div.table-header-container');
    }
    get rowActionTable() {
        return this.shadowRoot.querySelector('div.row-actions-table');
    }
    get stickyTableHeader() {
        return this.shadowRoot.querySelector('div.table-header-container jha-table-row#table-header');
    }
    get filterProps() {
        return getFilterProps(this.filters);
    }
    get filterColumns() {
        const orderedColumns = [...this.visibleColumns, ...this.hiddenColumns];
        return orderedColumns
            .filter((item) => Boolean(item.filterType))
            .map((item) => ({
            label: item.filterLabel || item.label,
            filterType: this.filters[item.id]?.filterType || item.filterType,
            value: this.filters[item.id]?.value || [],
            id: item.id,
            options: item.options,
        }));
    }
    searchableFieldsMatch(item) {
        const searchVal = this.searchQuery.toLocaleLowerCase().trim();
        const searchableProps = this.searchableCols.map((i) => i.id);
        return searchableProps.some((prop) => {
            const val = getNestedValue(item, prop);
            if (Array.isArray(val)) {
                return val.some((v) => v && String(v).toLocaleLowerCase().includes(searchVal));
            }
            return val && String(val).toLocaleLowerCase().includes(searchVal);
        });
    }
    filterMatches(item) {
        return filterMatches(item, this.filters, this.columns);
    }
    get visibleData() {
        if (!this.data)
            return [];
        let dataset = this.data.slice(0);
        if (this.apiControlled) {
            return dataset;
        }
        if (this.filterProps.length) {
            dataset = dataset.filter(this.filterMatches.bind(this));
        }
        if (this.searchQuery) {
            dataset = dataset.filter(this.searchableFieldsMatch.bind(this));
        }
        const column = this.columns.find((item) => item.id === this.sortColumnId);
        return !this.sortColumnId
            ? dataset
            : sortTableData(dataset, this.sortColumnId, column?.dataType, this.sortDescending);
    }
    /** Table Grouping */
    get groupings() {
        return this.currentConfig?.groupings || [];
    }
    get activeGrouping() {
        const activeGroupingId = this.currentConfig?.activeGroupingId;
        if (!activeGroupingId) {
            return null;
        }
        return this.groupings.find((grouping) => grouping.id === activeGroupingId) || null;
    }
    set activeGroupingId(activeGroupingId) {
        this.currentConfig = {
            ...(this.currentConfig || {}),
            ...{ activeGroupingId },
        };
        this.dispatchTableUpdate('grouping');
        this.handleTableResize();
    }
    get groupedData() {
        if (!this.activeGrouping) {
            return null;
        }
        const groups = this.activeGrouping?.groups.reduce((acc, group) => {
            acc[group.id] = [];
            return acc;
        }, {});
        return this.visibleData.reduce((acc, item) => {
            const group = this.activeGrouping?.groups.find((group) => this.activeGrouping?.itemMatchFunction(item, group));
            if (group) {
                acc[group.id].push(item);
            }
            return acc;
        }, groups);
    }
    get allGroupsCollapsed() {
        return this.activeGrouping?.groups.every((group) => this.collapsedGroupIds.includes(group.id));
    }
    get hidePagination() {
        // We don't want to paginate if the table has stickyRows
        return this.noPagination || this.stickyRows?.length > 0 || Boolean(this.activeGrouping);
    }
    get visibleSlice() {
        if (this.hidePagination) {
            return this.visibleData;
        }
        return this.visibleData.slice(this.startEnd[0] - 1, this.startEnd[1]);
    }
    get allSelected() {
        return this.visibleSlice.length && this.visibleSlice.every((item) => this.isSelected(item));
    }
    get someVisibleItemsSelected() {
        return this.visibleSlice.some((item) => this.isSelected(item));
    }
    get selectedItemsLength() {
        return this.selectedItems?.length;
    }
    isSelected(item) {
        return (this.selectedItems || []).includes(item[this.selectedItemIdentifier]);
    }
    get visibleColumns() {
        if (!this.columnOrder)
            return this.columns;
        return this.columnOrder
            .map((id) => this.columns.find((item) => item.id === id))
            .filter((item) => item !== undefined);
    }
    get hiddenColumns() {
        if (!this.columnOrder)
            return [];
        return this.columns.filter((item) => !this.columnOrder.includes(item.id));
    }
    get tableEmpty() {
        return this.loading || !this.visibleSlice.length;
    }
    get fixedHeaderTop() {
        const topStyle = getComputedStyle(this).getPropertyValue('--jha-table-fixed-header-top') || '0';
        return Number(topStyle.replace(/\D/g, ''));
    }
    get apiControlled() {
        return this.tableConfig?.apiControlled;
    }
    setSort(columnId) {
        const descending = this.sortColumnId === columnId ? !this.sortDescending : false;
        this.sort = {
            columnId,
            descending,
        };
        this.handleTableResize();
    }
    handleRefresh() {
        this.dispatchEvent(new CustomEvent('refresh-table-data', {
            bubbles: true,
            composed: true,
        }));
    }
    handleFilters(evt) {
        const { id, filter } = evt.detail;
        if (!filter.value.length) {
            delete this.filters[id];
            this.pageOffset = 0;
            this.requestUpdate();
            this.dispatchTableUpdate('filters');
        }
        else {
            const newFilterObj = {};
            newFilterObj[id] = filter;
            this.filters = { ...this.filters, ...newFilterObj };
        }
        this.handleTableResize();
    }
    clearAllFilters() {
        this.filters = {};
        this.handleTableResize();
    }
    handleResetFilters() {
        if (!this.activeViewId) {
            this.clearAllFilters();
            return;
        }
        const baseViewConfig = this.views?.find(({ id }) => id === this.activeViewId)?.config;
        const filters = Object.entries(baseViewConfig?.filters || {}).reduce((acc, [key, val]) => {
            acc[key] = { ...val };
            return acc;
        }, {});
        const sort = { ...baseViewConfig?.sort, ...{} };
        const columnOrder = baseViewConfig?.columnOrder ? [...(baseViewConfig?.columnOrder || [])] : undefined;
        const searchQuery = baseViewConfig?.searchQuery || '';
        this.currentConfig = {
            ...(this.currentConfig || {}),
            ...{ filters, sort, columnOrder, searchQuery },
        };
        this.dispatchTableUpdate('view-reset');
        this.requestUpdate();
    }
    handleSearchInput(evt) {
        this.searchQuery = evt.target?.value || '';
    }
    handleSearchButtonClick() {
        if (this.tableConfig?.showSearchButton) {
            this.dispatchTableUpdate('searchQuery');
        }
    }
    // This handles tabbing from the last cell in a row to the next row or group or row action
    handleCellKeydown(evt) {
        const { target, code, shiftKey } = evt;
        // Only handle Tab key events
        if (code !== 'Tab') {
            return;
        }
        const nextCell = target.parentElement?.nextElementSibling;
        const prevCell = target.parentElement?.previousElementSibling;
        const containingRow = target.closest('jha-table-row');
        const isLast = shiftKey ? !prevCell : !nextCell;
        // Only handle tabbing from first or last cell in a row, when row actions are present
        if (!isLast || !this.rowActions?.length || !containingRow) {
            return;
        }
        //If tabbing back, and the previous row is a group header, let base tabbing behavior occur
        if (shiftKey && containingRow?.previousElementSibling?.classList.contains('group-header')) {
            return;
        }
        // determine next row index
        let nextIndex = containingRow?.getAttribute('row-index');
        nextIndex = parseInt(nextIndex, 10);
        nextIndex = shiftKey ? nextIndex - 1 : nextIndex;
        const rowActionElement = this.shadowRoot.querySelector(`div.row-actions-table jha-table-row[row-index="${nextIndex}"] jha-popover`);
        if (rowActionElement) {
            evt.preventDefault();
            rowActionElement.querySelector('button')?.focus();
        }
    }
    handleCellKeydownRowAction(evt) {
        const { target, code, shiftKey } = evt;
        const popoverOpen = target.closest('jha-popover').hasAttribute('open');
        if (code === 'Tab' && !popoverOpen) {
            let rowIndex = target.closest('jha-table-row')?.getAttribute('row-index');
            rowIndex = parseInt(rowIndex, 10);
            const matchingRow = this.shadowRoot.querySelector(`div.table jha-table-row[row-index="${rowIndex}"]`);
            if (!matchingRow)
                return;
            const nextRow = shiftKey ? matchingRow : matchingRow.nextElementSibling;
            if (!nextRow) {
                return;
            }
            evt.preventDefault();
            if (nextRow.tagName.toLocaleLowerCase() === 'tr') {
                nextRow.querySelector('td .content')?.focus();
            }
            else {
                const cellIdentifier = shiftKey ? 'last-child' : 'first-child';
                const nextCell = nextRow.querySelector(`jha-table-cell:${cellIdentifier}`);
                const focusableElement = (nextCell.querySelector('button, [tabindex]:not([tabindex="-1"])') ||
                    nextCell.querySelector('jha-form-checkbox')?.shadowRoot?.querySelector('input'));
                focusableElement?.focus();
            }
        }
    }
    handleGroupHeaderClick(groupId) {
        if (this.collapsedGroupIds.includes(groupId)) {
            this.collapsedGroupIds = this.collapsedGroupIds.filter((id) => id !== groupId);
        }
        else {
            this.collapsedGroupIds = [...this.collapsedGroupIds, groupId];
        }
        this.dispatchEvent(new CustomEvent('collapsed-groups-change', {
            detail: this.collapsedGroupIds,
            bubbles: true,
            composed: true,
        }));
    }
    handleCheckAllInGroup(items, select) {
        const groupItemIds = items.map((item) => item[this.selectedItemIdentifier]);
        const otherSelectedItems = this.selectedItems.filter((id) => !groupItemIds.includes(id));
        this.selectedItems = select ? [...groupItemIds, ...otherSelectedItems] : otherSelectedItems;
        this.dispatchBulkSelection();
    }
    adjustHeaderWidths() {
        // RULE: If bulk actions are enabled, subtract the width of the bulk actions checkbox column from the header
        const totalWidth = this.bulkActions
            ? this.componentContent?.getBoundingClientRect().width - 51
            : this.componentContent?.getBoundingClientRect().width;
        const columnWidth = totalWidth / this.visibleColumns.length;
        this.columnWidths = this.visibleColumns.reduce((acc, item) => {
            acc[item.id] = columnWidth;
            return acc;
        }, {});
    }
    async calculateTableActionsPosition() {
        if (!this.rowActions?.length)
            return;
        await this.updateComplete;
        if (!(this.tablePositionTop && this.tableWrapperHeight && this.tableRowHeight && this.tableHeaderHeight)) {
            this.actionPositionValues = null;
            return;
        }
        this.actionPositionValues = {
            top: this.tablePositionTop - 1,
            containerHeight: this.tableWrapperHeight + this.tableHeaderHeight + 1,
            headerHeight: this.tableHeaderHeight - 2,
            rowHeight: this.tableRowHeight,
        };
    }
    scrollToTopOfTable_() {
        if (this.tableWrapper && this.tableWrapper.scrollTop !== 0) {
            this.tableWrapper.scrollTop = 0;
        }
    }
    async handleColumnChange(evt) {
        this.columnOrder = evt.detail;
    }
    handleItemCheck(checkedItem) {
        const selected = !this.isSelected(checkedItem);
        this.selectedItems = selected
            ? [...this.selectedItems, checkedItem[this.selectedItemIdentifier]]
            : this.selectedItems.filter((item) => item !== checkedItem[this.selectedItemIdentifier]);
        this.dispatchBulkSelection();
    }
    handleCheckAll() {
        const visibleItemIds = this.visibleSlice.map((item) => item[this.selectedItemIdentifier]);
        const otherSelectedItems = this.selectedItems.filter((id) => !visibleItemIds.includes(id));
        this.selectedItems = this.allSelected ? otherSelectedItems : [...visibleItemIds, ...otherSelectedItems];
        this.dispatchBulkSelection();
    }
    handleDeselectAll() {
        this.selectedItems = [];
        this.dispatchBulkSelection();
    }
    getColValueString(item, col) {
        const value = getNestedValue(item, col.id);
        return getValueString(value, item, {
            dataType: col.dataType,
            valueFormatter: col.valueFormatter,
            badgeMap: col.badgeMap,
            trueString: col.trueString,
            falseString: col.falseString,
            valueRenderer: undefined,
        });
    }
    isActive(item) {
        return this.tableConfig?.activeProperty && getNestedValue(item, this.tableConfig.activeProperty);
    }
    async handlePaginationBack(evt) {
        const { target } = evt;
        if (target.disabled)
            return;
        this.pageOffset -= 1;
        const { bulkActions } = this;
        if (this.bulkActions) {
            this.bulkActions = false;
        }
        await this.handleTableResize();
        this.bulkActions = bulkActions;
        this.scrollToTopOfTable_();
        this.dispatchEvent(new CustomEvent('pagination-backward', {
            detail: this.startEnd[0],
            bubbles: true,
            composed: true,
        }));
    }
    async handlePaginationForward(evt) {
        const { target } = evt;
        if (target.disabled)
            return;
        this.pageOffset += 1;
        const { bulkActions } = this;
        if (this.bulkActions) {
            this.bulkActions = false;
        }
        await this.handleTableResize();
        this.bulkActions = bulkActions;
        this.dispatchEvent(new CustomEvent('pagination-forward', {
            detail: this.startEnd[1],
            bubbles: true,
            composed: true,
        }));
    }
    setPageLimit(limit) {
        this.pageLimit = limit;
        this.pageOffset = 0;
        const popover = this.shadowRoot.querySelector('jha-popover#page-limit');
        if (popover) {
            popover.closePopover();
        }
        this.dispatchEvent(new CustomEvent('page-limit-change', {
            detail: this.pageLimit,
            bubbles: true,
            composed: true,
        }));
    }
    jumpToPage(page) {
        this.pageOffset = page;
        this.scrollToTopOfTable_();
        const popover = this.shadowRoot.querySelector('jha-popover#pager');
        if (popover) {
            popover.closePopover();
        }
    }
    handleSetView_(evt) {
        const { viewId } = evt.detail;
        this.activeViewId = viewId;
        this.pageOffset = 0;
        this.handleTableResize();
        this.dispatchEvent(new CustomEvent('view-change', {
            detail: this.activeViewId,
            bubbles: true,
            composed: true,
        }));
        // dispatching deprecated 'preset-change' event for backwards compatibility
        this.dispatchEvent(new CustomEvent('preset-change', {
            detail: this.activeViewId,
            bubbles: true,
            composed: true,
        }));
    }
    handleItemClicked(colId, item, doubleClick) {
        const eventType = doubleClick ? 'table-cell-double-click' : 'table-cell-click';
        this.dispatchEvent(new CustomEvent(eventType, {
            bubbles: true,
            composed: true,
            detail: {
                colId,
                item,
            },
        }));
    }
    itemRowActions(item) {
        return this.rowActions.filter((action) => {
            if (action.hiddenCondition) {
                return typeof action.hiddenCondition === 'function' ? !action.hiddenCondition(item) : !action.hiddenCondition;
            }
            return true;
        });
    }
    isActionDisabled(item, action) {
        if (!action.disabledCondition)
            return false;
        return typeof action.disabledCondition === 'function'
            ? action.disabledCondition(item)
            : Boolean(action.disabledCondition);
    }
    handleRowAction(evt, item, action) {
        evt.stopPropagation();
        if (this.isActionDisabled(item, action))
            return;
        this.dispatchEvent(new CustomEvent('table-row-action', {
            bubbles: true,
            composed: true,
            detail: {
                item,
                action: action.id,
            },
        }));
        const popover = this.shadowRoot.querySelector('jha-popover.row-actions[open]');
        if (popover) {
            popover.closePopover();
        }
    }
    handleBulkAction_(evt) {
        evt.stopPropagation();
        let { detail } = evt;
        detail = { ...detail, ...{ items: this.selectedItems } };
        this.dispatchEvent(new CustomEvent('bulk-action', {
            detail,
            bubbles: true,
            composed: true,
        }));
    }
    renderSort(item) {
        const isSortItem = item.id === this.sortColumnId;
        const labelTitle = !item.sortBy ? item.label : null;
        const label = html ` <span title=${ifDefined(labelTitle)}>${item.label}</span> `;
        if (!item.sortBy)
            return label;
        return html `
      <button
        class="sort-button"
        ?descending=${this.sortDescending && isSortItem}
        button-reset
        type="button"
        ?disabled=${this.loading || !this.visibleData.length}
        title=${`Sort by ${item.label} ${this.sortDescending && isSortItem ? 'ascending' : 'descending'}`}
        @click=${() => this.setSort(item.id)}>
        ${label}
        ${isSortItem
            ? html ` <jh-icon-arrow-up-small></jh-icon-arrow-up-small> `
            : html ` <jh-icon-arrow-up-arrow-down></jh-icon-arrow-up-arrow-down> `}
      </button>
    `;
    }
    renderSearch() {
        if (!this.searchableCols.length)
            return '';
        const searchPlaceholder = this.searchPlaceholderText ??
            `Search ${this.searchableCols
                .map((item) => item.label)
                .join(', ')
                .toLocaleLowerCase()}`;
        return html `
      <div class="search">
        <jh-input
          id="main-search"
          title="${searchPlaceholder}"
          .placeholder=${searchPlaceholder}
          size="small"
          show-clear-button
          .value=${this.searchQuery}
          ?disabled=${(this.apiControlled && this.selectedItemsLength) || this.loading}
          @jh-input:clear-button-click=${this.handleSearchInput}
          @input=${this.handleSearchInput}>
          <jh-icon-magnifying-glass slot="jh-input-left"></jh-icon-magnifying-glass>
        </jh-input>
        ${this.tableConfig?.showSearchButton
            ? html `
              <jh-button
                appearance="secondary"
                size="small"
                label="Search"
                ?disabled=${Boolean(this.selectedItemsLength) || this.loading}
                @click=${this.handleSearchButtonClick}></jh-button>
            `
            : ''}
      </div>
    `;
    }
    renderFilters() {
        if (!this.filterColumns?.length) {
            return '';
        }
        return html `
      <jha-table-filter-group
        ?border-left=${this.groupings?.length}
        .filters=${this.filterColumns}
        .loading=${this.loading}
        .maxVisibleFilters=${this.maxVisibleFilters}
        @filter-change=${(evt) => this.handleFilters(evt)}
        .changedFilters=${this.changedViewProperties?.filters}></jha-table-filter-group>
    `;
    }
    renderBulkEditControls() {
        if (this.selectedItemsLength < 1)
            return '';
        return html `
      <div
        class=${classMap({
            'actions-toolbar': true,
            'controls': true,
            'flex-container': true,
            'compact': !this.apiControlled,
        })}>
        <div class="actions-count">
          <span class="count">${this.selectedItemsLength} selected</span>
          |
          <jh-button
            class="small"
            id="deselect"
            appearance="tertiary"
            size="small"
            label="Deselect"
            ?disabled=${this.loading}
            @click=${this.handleDeselectAll}></jh-button>
        </div>
        <div
          class="actions-list"
          @bulk-action=${this.handleBulkAction_}>
          <slot name="table-actions"></slot>
        </div>
      </div>
    `;
    }
    maybeRenderGroupingControls() {
        if (!this.groupings?.length) {
            return '';
        }
        if (this.groupings.length === 1) {
            if (this.currentConfig?.disableChangeGrouping) {
                return html `
          <div class="grouping-controls">
            <div
              id="grouping-indicator"
              class="grouping-label">
              <jh-icon-sliders size="small"></jh-icon-sliders>
              Group: ${this.groupings[0].label}
            </div>
          </div>
        `;
            }
            return html `
        <div class="grouping-controls">
          <jh-button
            id="grouping-toggle"
            class="grouping-button"
            label="Group: ${this.groupings[0].label}"
            size="small"
            appearance="secondary"
            @click=${() => {
                this.activeGroupingId = this.activeGrouping ? null : this.groupings[0].id;
            }}
            ?active=${Boolean(this.activeGrouping)}>
            ${this.activeGrouping
                ? html ` <jh-icon-square-checkmark slot="jh-button-icon-left"></jh-icon-square-checkmark> `
                : html ` <jh-icon-square slot="jh-button-icon-left"></jh-icon-square> `}
          </jh-button>
        </div>
      `;
        }
        return html `
      <div class="grouping-controls">
        <jha-popover id="grouping-menu">
          <jh-button
            class="grouping-button"
            ?active=${Boolean(this.activeGrouping)}
            label="Group${this.activeGrouping ? `: ${this.activeGrouping.label}` : ''}"
            size="small"
            appearance="secondary"
            slot="button">
            <jh-icon-chevron-down-small slot="jh-button-icon-right"></jh-icon-chevron-down-small>
          </jh-button>
          <jh-menu>
            <label>Group by</label>
            <div class="buttons">
              <button
                class="grouping-option"
                ?active=${!this.activeGrouping}
                @click=${() => {
            this.activeGroupingId = null;
        }}>
                None ${!this.activeGrouping ? html `<jh-icon-checkmark></jh-icon-checkmark>` : ''}
              </button>
              ${this.groupings.map((grouping) => html `
                  <button
                    class="grouping-option"
                    ?active=${this.activeGrouping?.id === grouping.id}
                    @click=${() => {
            this.activeGroupingId = grouping.id;
        }}>
                    ${grouping.label}
                    ${this.activeGrouping?.id === grouping.id ? html `<jh-icon-checkmark></jh-icon-checkmark>` : ''}
                  </button>
                `)}
            </div>
          </jh-menu>
        </jha-popover>
      </div>
    `;
    }
    renderTableControls() {
        const hasSlottedControls = this.querySelector('[slot="table-controls"]') !== null;
        const apiControlledWithItemsSelected = this.apiControlled && this.selectedItemsLength > 0;
        const nothingToShow = !this.filterColumns?.length &&
            !this.groupings?.length &&
            !this.allowRefresh &&
            !this.canEditColumns &&
            !hasSlottedControls;
        if (nothingToShow || apiControlledWithItemsSelected) {
            return nothing;
        }
        return html `
      <div
        class=${classMap({
            controls: true,
            'has-groupings': this.groupings?.length,
            'flex-container': this.filterColumns?.length,
            'flex-container-end': !this.filterColumns?.length,
        })}>
        ${this.maybeRenderGroupingControls()} ${this.renderFilters()}
        <div class="flex-container edit-refresh right-header-controls">
          <jh-button
            id="reset-button"
            ?hide=${!this.filtersChanged}
            label=${this.activeViewId ? 'Reset view' : 'Clear filters'}
            @click=${this.handleResetFilters}
            appearance="tertiary"
            size="small"></jh-button>
          ${this.allowRefresh
            ? html `
                <jh-button
                  accessible-label="Refresh"
                  class="refresh-button"
                  appearance="tertiary"
                  title="Reload data"
                  size="small"
                  @click=${this.handleRefresh}
                  ?disabled=${this.loading}>
                  <jh-icon-arrow-rotate-right
                    slot="jh-button-icon-left"
                    size="small"
                    icon></jh-icon-arrow-rotate-right>
                </jh-button>
              `
            : ''}
          ${this.canEditColumns
            ? html `
                <jha-table-column-sorter
                  .columns=${this.columns}
                  @column-change=${this.handleColumnChange}
                  ?disabled=${this.loading}
                  .columnOrder=${this.columnOrder}
                  .activeViewId=${this.activeViewId}></jha-table-column-sorter>
              `
            : ''}
          <slot name="table-controls"></slot>
        </div>
      </div>
    `;
    }
    renderViews() {
        if (this.canEditViews || (this.clonedViews_ ?? []).length) {
            return html `
        <jha-table-views
          .activeViewHasChanges=${this.activeViewHasChanges}
          .activeViewId=${this.activeViewId}
          .views=${this.clonedViews_}
          .canEditViews=${this.canEditViews}
          .currentConfig=${this.currentConfig}
          .hideAllView=${this.hideAllView}
          @active-view-change=${this.handleSetView_}
          @view-update=${this.handleTableResize}>
          <div slot="view-controls-right">
            <slot name="table-views-right"></slot>
          </div>
        </jha-table-views>
      `;
        }
        return nothing;
    }
    renderRowSelect(item) {
        if (!this.bulkActions)
            return '';
        return html `
      <jha-table-cell checkbox>
        <jha-form-checkbox
          @change=${() => this.handleItemCheck(item)}
          label="Select/deselect item"
          .checked=${this.isSelected(item)}
          style=${this.checkboxStyleMap(item)}></jha-form-checkbox>
      </jha-table-cell>
    `;
    }
    checkboxStyleMap(item) {
        if (!item.checkboxColor) {
            return styleMap({});
        }
        return styleMap({
            '--jha-form-checkbox-checked-background-color': item.checkboxColor,
            '--jha-form-checkbox-checked-border-color': item.checkboxColor,
        });
    }
    renderCheckAll() {
        if (!this.bulkActions || this.loading)
            return '';
        return html `
      <jha-table-header
        checkbox
        title="Select all visible items"
        id="selectColumn">
        <jha-form-checkbox
          ?disabled=${this.loading || !this.visibleData.length}
          @change=${this.handleCheckAll}
          label="Select/deselect all"
          .checked=${this.allSelected}
          .indeterminate=${this.someVisibleItemsSelected}></jha-form-checkbox>
      </jha-table-header>
    `;
    }
    renderTableHeader(setWidth = false) {
        if (!this.visibleColumns.length)
            return '';
        return html `
      <jha-table-row
        id="table-header"
        ?expand-all-columns=${this.fullWidthColumns}>
        ${this.renderCheckAll()}
        ${this.visibleColumns.map((item, index) => html `
            <jha-table-header
              id=${item.id}
              ?first=${index === 0}
              ?left-border=${item.leftBorder}
              style=${styleMap(setWidth && this.columnWidths[item.id]
            ? {
                width: `${this.columnWidths[item.id]}px`,
            }
            : {})}
              ?sort-field=${item.id === this.sortColumnId}>
              <div
                class="col-header"
                ?align-right=${item.alignRight}
                ?hasInteraction=${item.sortBy}
                style=${styleMap(setWidth && this.columnWidths[item.id]
            ? {
                width: `${this.columnWidths[item.id] - 1}px`,
            }
            : {})}>
                ${this.renderSort(item)}
              </div>
            </jha-table-header>
          `)}
        <div class="header-right">
          <slot name="header-right"></slot>
        </div>
      </jha-table-row>
    `;
    }
    renderHeader() {
        return html `
      <div
        id="table-header"
        ?scrolling=${this.headerFixed}
        style=${styleMap({ width: this.componentWidth })}>
        <div class="table-header-content">
          <div class="header-section">
            <div class="slot">
              <slot></slot>
            </div>
            ${this.renderSearch()}
          </div>
          ${this.renderViews()} ${this.renderTableControls()} ${this.renderBulkEditControls()}
        </div>
        <div
          class="table-header-container"
          role="table"
          style=${styleMap({
            width: this.tableHeaderWidth ? `${this.tableHeaderWidth}px` : 'auto',
        })}>
          ${this.renderTableHeader(true)}
        </div>
      </div>
    `;
    }
    renderRowActionsPopoverMenu(item) {
        if (this.itemRowActions(item)?.length < 1) {
            return nothing;
        }
        return html `
      <jha-popover class="row-actions">
        <button
          class="row-action-button"
          style=${styleMap({
            height: `${this.actionPositionValues.rowHeight - 4}px`,
        })}
          slot="button">
          <jh-icon-ellipsis
            slot="button"
            size="x-small"
            aria-label="Actions"></jh-icon-ellipsis>
        </button>
        <jh-menu>
          ${this.itemRowActions(item).map((action) => html `
              <button
                class="row-action"
                type="button"
                tabindex="0"
                ?disabled=${this.isActionDisabled(item, action)}
                aria-label=${action.ariaLabel}
                @click=${(evt) => this.handleRowAction(evt, item, action)}>
                ${action.iconRenderer
            ? action.iconRenderer(item)
            : action.icon
                ? html `
                        <jha-icons
                          .icon=${action.icon}
                          small></jha-icons>
                      `
                : html ` <span class="icon-placeholder"></span> `}
                <span>${action.label}</span>
              </button>
            `)}
        </jh-menu>
      </jha-popover>
    `;
    }
    renderRowActionForItem(item, index) {
        return html `<jha-table-row
      style=${styleMap({
            height: `${this.actionPositionValues.rowHeight}px`,
        })}
      row-index=${index}
      action-item
      @keydown=${this.handleCellKeydownRowAction}>
      <jha-table-cell ?last=${index === this.visibleSlice.length - 1}>
        ${this.renderRowActionsPopoverMenu(item)}
      </jha-table-cell>
    </jha-table-row> `;
    }
    renderRowActionsContent() {
        if (this.activeGrouping && this.groupedData) {
            if (this.allGroupsCollapsed) {
                return '';
            }
            let index = 0;
            return Object.entries(this.groupedData).map(([groupId, items]) => {
                return html `
          <jha-table-row
            style=${styleMap({
                    height: `${this.actionPositionValues.rowHeight}px`,
                })}>
            <jha-table-cell></jha-table-cell>
          </jha-table-row>
          ${this.collapsedGroupIds.includes(groupId)
                    ? ''
                    : items.map((item) => {
                        const row = this.renderRowActionForItem(item, index);
                        index += 1;
                        return row;
                    })}
        `;
            });
        }
        return this.visibleSlice.map((item, index) => this.renderRowActionForItem(item, index));
    }
    renderRowActions() {
        if (!this.rowActions?.length || this.loading || !this.actionPositionValues)
            return '';
        return html `
      <div
        class="row-actions-wrapper"
        style=${styleMap({
            height: `${this.actionPositionValues.containerHeight}px`,
            top: `${this.actionPositionValues.top}px`,
        })}>
        <div class="row-actions-shadow">
          <div
            class="row-actions-header"
            style=${styleMap({
            height: `${this.actionPositionValues.headerHeight}px`,
        })}></div>
          <div
            class="row-actions-container"
            style=${styleMap({
            height: `${this.actionPositionValues.containerHeight + 2}px`,
        })}>
            <div class="row-actions-table">${this.renderRowActionsContent()}</div>
          </div>
        </div>
      </div>
    `;
    }
    renderTableRow(item, index, stickyRow) {
        return html `
      <jha-table-row
        ?expand-all-columns=${this.fullWidthColumns}
        ?active=${this.isActive(item)}
        ?last-row=${index === this.visibleSlice.length - 1}
        ?first-row=${index === 0}
        ?selected=${this.isSelected(item)}
        row-index=${index}
        @keydown=${this.handleCellKeydown}>
        ${this.renderRowSelect(item)}
        ${this.visibleColumns.map((col, colIndex) => html `
            <jha-table-cell
              id=${col.id}
              class="button-cell"
              ?first=${colIndex === 0}
              ?left-border=${col.leftBorder}
              ?custom-value=${Boolean(col.valueRenderer)}
              style=${styleMap(stickyRow && this.columnWidths[col.id]
            ? {
                width: `${this.columnWidths[col.id] + 1}px`,
            }
            : {})}>
              <button
                data-button
                title=${this.getColValueString(item, col)}
                arial-label=${String(this.getColValueString(item, col)) || 'No value'}
                type="button"
                button-reset
                ?align-right=${col.alignRight}
                ?sortable=${col.sortBy}
                style=${styleMap(stickyRow && this.columnWidths[col.id]
            ? {
                width: `${this.columnWidths[col.id]}px`,
            }
            : {})}
                @click=${() => {
            this.handleItemClicked(col.id, item);
        }}
                @dblclick=${() => {
            this.handleItemClicked(col.id, item, true);
        }}>
                ${getValueFromObject(item, col.id, {
            dataType: col.dataType,
            badgeMap: col.badgeMap,
            valueRenderer: col.valueRenderer,
            valueFormatter: col.valueFormatter,
            trueString: col.trueString,
            falseString: col.falseString,
        })}
              </button>
            </jha-table-cell>
          `)}
      </jha-table-row>
    `;
    }
    renderTableData() {
        return html ` ${this.visibleSlice.map((item, index) => this.renderTableRow(item, index))} `;
    }
    renderGroupedRows() {
        if (!this.groupedData) {
            return '';
        }
        let index = 0;
        return Object.entries(this.groupedData).map(([groupId, items]) => {
            const group = this.activeGrouping?.groups.find((g) => g.id === groupId);
            const isCollapsed = this.collapsedGroupIds.includes(groupId);
            let columnSpan = this.visibleColumns.length;
            if (this.bulkActions) {
                columnSpan += 1;
            }
            if (this.rowActions?.length && !isCollapsed) {
                columnSpan += 1;
            }
            if (!group) {
                return '';
            }
            return html `
        <tr class="group-header">
          <td colspan=${columnSpan}>
            <button
              tabindex="0"
              class="content"
              ?bulk-actions=${this.bulkActions}
              @click=${() => this.handleGroupHeaderClick(group.id)}
              style=${styleMap({
                height: `${this.tableRowHeight}px`,
            })}>
              ${this.renderGroupBulkActions(groupId, items)}
              <div
                class="collapse-icon"
                ?collapsed=${isCollapsed}>
                <jh-icon-chevron-down-small></jh-icon-chevron-down-small>
              </div>
              ${this.activeGrouping?.headerLeftRenderer ? this.activeGrouping.headerLeftRenderer(group) : ''}
              <div class="group-label">
                <label>${group.label} <jh-badge count=${items.length}></jh-badge></label>
                ${group.description ? html ` <span class="group-description">${group.description}</span> ` : ''}
              </div>
            </button>
          </td>
        </tr>
        ${isCollapsed
                ? ''
                : items.map((item) => {
                    const row = this.renderTableRow(item, index);
                    index += 1;
                    return row;
                })}
      `;
        });
    }
    renderGroupBulkActions(groupId, items) {
        if (!this.bulkActions) {
            return '';
        }
        const isCollapsed = this.collapsedGroupIds.includes(groupId);
        const allSelected = items.every((item) => this.isSelected(item));
        const someSelected = !allSelected && items.some((item) => this.isSelected(item));
        return html `
      <jha-form-checkbox
        ?disabled=${this.loading || isCollapsed}
        @change=${() => {
            this.handleCheckAllInGroup(items, !allSelected);
        }}
        @click=${(evt) => evt.stopPropagation()}
        label="Select/deselect all"
        .checked=${allSelected}
        .indeterminate=${someSelected}></jha-form-checkbox>
    `;
    }
    renderLoading() {
        const loadingMore = !this.visibleSlice.length && this.loadingMore;
        if (!(this.loading || loadingMore))
            return '';
        return html `
      <div class="loading">
        <jh-progress
          type="circular"
          size="large"
          indeterminate></jh-progress>
      </div>
    `;
    }
    renderNoContentMessage() {
        if (!this.visibleColumns.length) {
            return html ` <p class="no-content">No columns visible</p> `;
        }
        if (this.loading || this.loadingMore || this.visibleSlice.length)
            return '';
        return html `
      <div class="no-content">
        <slot name="no-content-message">
          <p class="no-content">
            ${this.noContentMessage
            ? this.noContentMessage
            : `No ${this.visibleData.length ? 'more' : ''} ${this.dataPlural} found.`}
          </p>
        </slot>
      </div>
    `;
    }
    renderContent() {
        const loadingMore = !this.visibleSlice.length && this.loadingMore;
        if (this.loading || loadingMore || !this.visibleColumns.length)
            return '';
        if (this.activeGrouping) {
            return this.renderGroupedRows();
        }
        return this.renderTableData();
    }
    renderCount() {
        const numberWithCommas = (x) => {
            return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        };
        if (this.listLength === 1) {
            return `1 result`;
        }
        const currentRange = this.startEnd.join('-');
        if (this.apiControlled && !this.tableConfig?.apiTotal) {
            return currentRange;
        }
        return `${currentRange} of ${numberWithCommas(this.listLength)} items`;
    }
    renderStickyRows() {
        if (!this.stickyRows?.length)
            return '';
        return html `
      <div id="sticky-rows-wrapper">
        <div id="sticky-rows">${this.stickyRows.map((item, index) => this.renderTableRow(item, index, true))}</div>
      </div>
    `;
    }
    renderFooter() {
        if (this.loading || !this.visibleData?.length || this.hidePagination) {
            return '';
        }
        return html `
      <div id="footer-container">
        <div
          id="footer"
          ?has-pager=${this.allowPageChange}
          ?has-page-limit=${this.allowPageLimitChange}>
          <div
            class="left"
            ?large=${this.allowPageLimitChange}>
            ${this.allowPageLimitChange && this.pageLimitOptions.length > 1
            ? html `
                  <div class="page-limit">
                    <jha-popover id="page-limit">
                      <span slot="button">
                        Items per page: ${this.pageLimit}
                        <jh-icon-chevron-down-small></jh-icon-chevron-down-small>
                      </span>

                      <jh-menu>
                        ${this.pageLimitOptions.map((item) => html `
                            <button
                              type="button"
                              ?selected=${this.pageLimit === item}
                              @click=${() => {
                this.setPageLimit(item);
            }}>
                              ${item}
                            </button>
                          `)}
                      </jh-menu>
                    </jha-popover>
                  </div>
                `
            : ''}
            <span class="count">${this.renderCount()}</span>
          </div>

          <div class="right">
            ${this.allowPageChange
            ? html `
                  <div class="pager">
                    ${this.totalPages > 1
                ? html `
                          <jha-popover id="pager">
                            <span slot="button">
                              ${this.pageOffset + 1}
                              <jh-icon-chevron-down-small></jh-icon-chevron-down-small>
                              of ${this.totalPages} pages
                            </span>
                            <jh-menu>
                              ${[...Array(this.totalPages).keys()].map((i) => html `
                                  <button
                                    type="button"
                                    ?selected=${this.pageOffset === i}
                                    @click=${() => {
                    this.jumpToPage(i);
                }}>
                                    ${i + 1}
                                  </button>
                                `)}
                            </jh-menu>
                          </jha-popover>
                        `
                : html `
                          <span>
                            ${this.pageOffset + 1}
                            <jh-icon-chevron-down-small></jh-icon-chevron-down-small>
                            of ${this.totalPages} page
                          </span>
                        `}
                  </div>
                `
            : ''}
            <div class="pagination">
              <jh-button
                accessible-label="Previous"
                class="pagination-button"
                type="button"
                title="Previous"
                appearance="tertiary"
                slot="jh-button-icon-left"
                size="large"
                ?disabled=${this.pageOffset === 0}
                @click=${this.handlePaginationBack}>
                <svg
                  slot="jh-button-icon-left"
                  xmlns="http://www.w3.org/2000/svg"
                  width="36"
                  height="36"
                  viewBox="0 0 36 36"
                  fill="none">
                  <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    d="M21.7955 11.2045C22.2348 11.6438 22.2348 12.3562 21.7955 12.7955L16.591 18L21.7955 23.2045C22.2348 23.6438 22.2348 24.3561 21.7955 24.7955C21.3562 25.2348 20.6439 25.2348 20.2045 24.7955L14.2045 18.7955C13.7652 18.3562 13.7652 17.6438 14.2045 17.2045L20.2045 11.2045C20.6439 10.7652 21.3562 10.7652 21.7955 11.2045Z" />
                </svg>
              </jh-button>
              <jh-button
                accessible-label="Next"
                class="pagination-button"
                type="button"
                title="Next"
                appearance="tertiary"
                size="large"
                ?disabled=${this.disableNext}
                @click=${this.handlePaginationForward}>
                <svg
                  slot="jh-button-icon-left"
                  xmlns="http://www.w3.org/2000/svg"
                  width="36"
                  height="36"
                  viewBox="0 0 36 36"
                  fill="none">
                  <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    d="M14.2045 11.2045C14.6438 10.7652 15.3562 10.7652 15.7955 11.2045L21.7955 17.2045C22.2348 17.6438 22.2348 18.3562 21.7955 18.7955L15.7955 24.7955C15.3562 25.2348 14.6438 25.2348 14.2045 24.7955C13.7652 24.3561 13.7652 23.6438 14.2045 23.2045L19.409 18L14.2045 12.7955C13.7652 12.3562 13.7652 11.6438 14.2045 11.2045Z" />
                </svg>
              </jh-button>
            </div>
          </div>
        </div>
      </div>
    `;
    }
    render() {
        if (!this.visibleColumns) {
            return '';
        }
        return html `
      <div
        id="component-content"
        ?is-grouped=${Boolean(this.activeGrouping)}>
        ${this.renderHeader()}
        <div
          class="table-wrapper
          ${classMap({
            'has-row-actions': Boolean(!this.allGroupsCollapsed && this.rowActions?.length),
        })}"
          ?empty=${this.tableEmpty}
          @scroll=${this.handleTableScroll}>
          <div
            class="table"
            role="table">
            ${this.renderTableHeader()} ${this.renderContent()}
          </div>
        </div>
        ${this.renderRowActions()} ${this.renderLoading()} ${this.renderNoContentMessage()} ${this.renderFooter()}
        ${this.renderStickyRows()}
        <slot name="custom-footer"></slot>
      </div>
    `;
    }
}
__decorate([
    property({ type: Array }),
    __metadata("design:type", Array)
], JhaAdvancedTable.prototype, "columns", void 0);
__decorate([
    property({ type: Array }),
    __metadata("design:type", Array)
], JhaAdvancedTable.prototype, "data", void 0);
__decorate([
    property({ type: Array }),
    __metadata("design:type", Array)
], JhaAdvancedTable.prototype, "pageLimitOptions", void 0);
__decorate([
    property({ type: Array }),
    __metadata("design:type", Array)
], JhaAdvancedTable.prototype, "rowActions", void 0);
__decorate([
    property({ type: Array }),
    __metadata("design:type", Array)
], JhaAdvancedTable.prototype, "selectedItems", void 0);
__decorate([
    property({ type: Array }),
    __metadata("design:type", Array)
], JhaAdvancedTable.prototype, "stickyRows", void 0);
__decorate([
    property({ type: Array }),
    __metadata("design:type", Array)
], JhaAdvancedTable.prototype, "views", void 0);
__decorate([
    property({
        type: Boolean,
        reflect: true,
        attribute: 'allow-page-change',
    }),
    __metadata("design:type", Boolean)
], JhaAdvancedTable.prototype, "allowPageChange", void 0);
__decorate([
    property({
        type: Boolean,
        reflect: true,
        attribute: 'allow-page-limit-change',
    }),
    __metadata("design:type", Boolean)
], JhaAdvancedTable.prototype, "allowPageLimitChange", void 0);
__decorate([
    property({ type: Boolean, reflect: true, attribute: 'allow-refresh' }),
    __metadata("design:type", Boolean)
], JhaAdvancedTable.prototype, "allowRefresh", void 0);
__decorate([
    property({ type: Boolean, reflect: true, attribute: 'api-has-more-data' }),
    __metadata("design:type", Boolean)
], JhaAdvancedTable.prototype, "apiHasMoreData", void 0);
__decorate([
    property({ type: Boolean, reflect: true, attribute: 'bulk-actions' }),
    __metadata("design:type", Boolean)
], JhaAdvancedTable.prototype, "bulkActions", void 0);
__decorate([
    property({ type: Boolean, reflect: true, attribute: 'can-edit-columns' }),
    __metadata("design:type", Boolean)
], JhaAdvancedTable.prototype, "canEditColumns", void 0);
__decorate([
    property({ type: Boolean, reflect: true, attribute: 'can-edit-views' }),
    __metadata("design:type", Boolean)
], JhaAdvancedTable.prototype, "canEditViews", void 0);
__decorate([
    property({ type: Boolean, reflect: true, attribute: 'full-width-columns' }),
    __metadata("design:type", Boolean)
], JhaAdvancedTable.prototype, "fullWidthColumns", void 0);
__decorate([
    property({ type: Boolean, reflect: true, attribute: 'hide-all-view' }),
    __metadata("design:type", Boolean)
], JhaAdvancedTable.prototype, "hideAllView", void 0);
__decorate([
    property({ type: Boolean }),
    __metadata("design:type", Boolean)
], JhaAdvancedTable.prototype, "loading", void 0);
__decorate([
    property({ type: Boolean }),
    __metadata("design:type", Boolean)
], JhaAdvancedTable.prototype, "loadingMore", void 0);
__decorate([
    property({ type: Boolean, reflect: true, attribute: 'no-pagination' }),
    __metadata("design:type", Boolean)
], JhaAdvancedTable.prototype, "noPagination", void 0);
__decorate([
    property({ type: Boolean, reflect: true, attribute: 'sticky-header' }),
    __metadata("design:type", Boolean)
], JhaAdvancedTable.prototype, "stickyHeader", void 0);
__decorate([
    property({ type: Number }),
    __metadata("design:type", Number)
], JhaAdvancedTable.prototype, "pageLimit", void 0);
__decorate([
    property({ type: Number }),
    __metadata("design:type", Number)
], JhaAdvancedTable.prototype, "pageOffset", void 0);
__decorate([
    property({ type: Number, reflect: true, attribute: 'max-visible-filters' }),
    __metadata("design:type", Number)
], JhaAdvancedTable.prototype, "maxVisibleFilters", void 0);
__decorate([
    property({ type: Object }),
    __metadata("design:type", Object)
], JhaAdvancedTable.prototype, "actionPositionValues", void 0);
__decorate([
    property({ type: Object }),
    __metadata("design:type", Object)
], JhaAdvancedTable.prototype, "columnWidths", void 0);
__decorate([
    property({ type: Object }),
    __metadata("design:type", Object)
], JhaAdvancedTable.prototype, "tableConfig", void 0);
__decorate([
    property({ type: String }),
    __metadata("design:type", String)
], JhaAdvancedTable.prototype, "activeViewId", void 0);
__decorate([
    property({ type: String }),
    __metadata("design:type", String)
], JhaAdvancedTable.prototype, "dataPlural", void 0);
__decorate([
    property({ type: String }),
    __metadata("design:type", String)
], JhaAdvancedTable.prototype, "noContentMessage", void 0);
__decorate([
    property({ type: String }),
    __metadata("design:type", String)
], JhaAdvancedTable.prototype, "searchPlaceholderText", void 0);
__decorate([
    property({ type: String }),
    __metadata("design:type", String)
], JhaAdvancedTable.prototype, "selectedItemIdentifier", void 0);
__decorate([
    property({ type: Array, attribute: 'collapsed-group-ids' }),
    __metadata("design:type", Array)
], JhaAdvancedTable.prototype, "collapsedGroupIds", void 0);
__decorate([
    state(),
    __metadata("design:type", String)
], JhaAdvancedTable.prototype, "componentWidth", void 0);
__decorate([
    state(),
    __metadata("design:type", Number)
], JhaAdvancedTable.prototype, "tableHeaderWidth", void 0);
__decorate([
    state(),
    __metadata("design:type", Boolean)
], JhaAdvancedTable.prototype, "headerFixed", void 0);
export { styles as JhaAdvancedTableStyles, DataType };
