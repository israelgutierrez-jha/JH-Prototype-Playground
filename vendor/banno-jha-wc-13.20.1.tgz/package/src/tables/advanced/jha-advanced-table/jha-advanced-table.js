import JhaAdvancedTable from './JhaAdvancedTable';
customElements.define('jha-advanced-table', JhaAdvancedTable);
/** @customElement jha-advanced-table */
export default JhaAdvancedTable;
