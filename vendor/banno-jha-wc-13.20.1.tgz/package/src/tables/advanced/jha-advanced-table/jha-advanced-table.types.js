export const VIEW_ACTION_EVENTS = {
    CREATE_VIEW: 'create',
    UPDATE_VIEW: 'update',
    RENAME_VIEW: 'rename',
    DUPLICATE_VIEW: 'duplicate',
    DELETE_VIEW: 'delete',
};
