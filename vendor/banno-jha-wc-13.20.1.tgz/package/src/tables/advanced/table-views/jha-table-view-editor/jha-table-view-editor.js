import JhaTableViewEditor from './JhaTableViewEditor.js';
customElements.define('jha-table-view-editor', JhaTableViewEditor);
/** @customElement jha-table-view-editor */
export default JhaTableViewEditor;
