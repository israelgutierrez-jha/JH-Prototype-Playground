import JhaTableViews from './JhaTableViews.js';
customElements.define('jha-table-views', JhaTableViews);
/** @customElement jha-table-views */
export default JhaTableViews;
