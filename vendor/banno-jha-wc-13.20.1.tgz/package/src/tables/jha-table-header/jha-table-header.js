import JhaTableHeader from './JhaTableHeader.js';
customElements.define('jha-table-header', JhaTableHeader);
/** @customElement jha-table-header */
export default JhaTableHeader;
