import JhaTableRow from './JhaTableRow.js';
customElements.define('jha-table-row', JhaTableRow);
/** @customElement jha-table-row */
export default JhaTableRow;
