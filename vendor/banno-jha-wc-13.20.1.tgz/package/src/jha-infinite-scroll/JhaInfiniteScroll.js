// JR: temp ignore tsc
import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../styles/jha-styles.js';
import '../progress/jha-progress/jha-progress.js';
const styles = css `
  :host {
    display: block;
  }
  article {
    padding: var(--jha-infinite-scroll-article-padding, 75px 0);
  }
  .progress-spinner-container {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 200px;
    width: 100%;
  }
  jha-progress[card] {
    margin: 0;
  }
`;
/*
 *  `<jha-infinite-scroll>` A JHA Design lazy load scroll container component.
 *
 * The following attributes are available:
 *
 * Attribute | Description
 * ----------------|-------------|----------
 * `([loading])` | Show loading indicator at bottom of list.
 * `([on-load-more])` | Event that is fired when the scroll conditions are met.
 *
 * Typical usage:
 *
 *    <body>
 *      <jha-infinite-scroll>
 *        ...data
 *      </jha-infinite-scroll>
 *
 * @element jha-infinite-scroll
 *
 */
export default class JhaInfiniteScroll extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            loading: {
                type: Boolean,
            },
        };
    }
    constructor() {
        super();
        this.loading = false;
    }
    render() {
        return html `
      <slot></slot>
      ${this.loading
            ? html `
            <article loading="">
              <div class="progress-spinner-container">
                <jha-progress card=""></jha-progress>
              </div>
            </article>
          `
            : ''}
    `;
    }
    connectedCallback() {
        super.connectedCallback();
        this.windowScrollBefore = 0;
        this._boundThrottle = this._throttle.bind(this);
        document.addEventListener('scroll', this._boundThrottle, { passive: true });
    }
    _throttle() {
        clearTimeout(this.wait);
        this.wait = setTimeout(() => {
            this._checkScrollPosition();
        }, 200);
    }
    _checkScrollPosition() {
        const windowHeight = window.innerHeight;
        const scrollHeight = this._getDocHeight();
        const windowScrollCurrent = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
        const isScrollingDown = this.windowScrollBefore - windowScrollCurrent <= 0;
        const pixelsToBottom = scrollHeight - (windowHeight + windowScrollCurrent);
        if (pixelsToBottom < 500 && isScrollingDown && !this.loading) {
            this.dispatchEvent(new CustomEvent('load-more', {
                bubbles: true,
                composed: true,
            }));
        }
        this.windowScrollBefore = windowScrollCurrent;
    }
    _getDocHeight() {
        const D = document;
        return Math.max(D.body.scrollHeight, D.documentElement.scrollHeight);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        clearTimeout(this.wait);
        document.removeEventListener('scroll', this._boundThrottle);
    }
}
export { styles as JhaInfiniteScrollStyles };
