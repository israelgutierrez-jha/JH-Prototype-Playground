import JhaInfiniteScroll from './JhaInfiniteScroll.js';
customElements.define('jha-infinite-scroll', JhaInfiniteScroll);
/** @customElement jha-infinite-scroll */
export default JhaInfiniteScroll;
