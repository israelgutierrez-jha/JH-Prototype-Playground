import JhaWell from './JhaWell.js';
customElements.define('jha-well', JhaWell);
/** @customElement jha-well */
export default JhaWell;
