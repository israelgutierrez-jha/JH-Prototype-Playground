import JhaFormRangeSlider from './JhaFormRangeSlider.js';
customElements.define('jha-form-range-slider', JhaFormRangeSlider);
/** @customElement jha-form-range-slider */
export default JhaFormRangeSlider;
