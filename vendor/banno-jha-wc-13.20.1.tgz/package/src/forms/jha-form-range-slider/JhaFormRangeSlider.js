import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
const styles = css `
  :host {
    display: block;
  }
  input[type='range'] {
    height: 50%;
    -webkit-appearance: none;
    margin: 10px 0;
    width: 100%;
  }
  input[type='range']:focus {
    outline: none;
  }
  input[type='range']::-webkit-slider-runnable-track {
    width: 100%;
    height: var(--jha-form-range-slider-track-height, 1px);
    cursor: pointer;
    animate: 0.2s;
    background: var(--jha-form-range-slider-track-color, var(--jha-text-light));
    border-radius: 1px;
  }
  input[type='range']::-webkit-slider-thumb {
    border: 1px solid var(--jha-form-range-slider-thumb-border-color, var(--jha-text-light));
    height: var(--jha-form-range-slider-thumb-size, 12px);
    width: var(--jha-form-range-slider-thumb-size, 12px);
    border-radius: 50%;
    background: var(--jha-component-background-color);
    cursor: pointer;
    -webkit-appearance: none;
    margin-top: calc(
      (var(--jha-form-range-slider-thumb-size, 12px) - var(--jha-form-range-slider-track-height, 1px)) / 2 * -1
    );
  }
  input[type='range']:focus::-webkit-slider-thumb {
    border: 1px solid var(--jha-form-range-slider-thumb-focus-color, var(--jha-text-theme));
    background: var(--jha-form-range-slider-thumb-focus-color, var(--jha-text-theme));
    box-shadow: 0px 0px 0px 10px rgba(0, 0, 0, 0.05);
  }
  input[type='range']::-moz-range-track {
    width: 100%;
    height: 1px;
    cursor: pointer;
    animate: 0.2s;
    background: var(--jha-form-range-slider-track-color, var(--jha-text-light));
    border-radius: 1px;
  }
  input[type='range']::-moz-range-thumb {
    border: 1px solid var(--jha-form-range-slider-thumb-border-color, var(--jha-text-light));
    height: var(--jha-form-range-slider-thumb-size, 12px);
    width: var(--jha-form-range-slider-thumb-size, 12px);
    border-radius: 50%;
    background: var(--jha-component-background-color);
    cursor: pointer;
  }
  input[type='range']:focus::-moz-range-thumb {
    border: 1px solid var(--jha-form-range-slider-thumb-focus-color, var(--jha-text-theme));
    background: var(--jha-form-range-slider-thumb-focus-color, var(--jha-text-theme));
  }
  input[type='range']::-ms-track {
    width: 100%;
    height: 1px;
    cursor: pointer;
    animate: 0.2s;
    background: transparent;
    border-color: transparent;
    color: transparent;
  }
  input[type='range']::-ms-fill-lower {
    background: var(--jha-form-range-slider-track-color, var(--jha-text-light));
    border-radius: 1px;
  }
  input[type='range']::-ms-fill-upper {
    background: var(--jha-form-range-slider-track-color, var(--jha-text-light));
    border-radius: 1px;
  }
  input[type='range']::-ms-thumb {
    margin-top: 1px;
    border: 1px solid var(--jha-form-range-slider-thumb-border-color, var(--jha-text-light));
    height: var(--jha-form-range-slider-thumb-size, 12px);
    width: var(--jha-form-range-slider-thumb-size, 12px);
    border-radius: 50%;
    background: var(--jha-component-background-color);
    cursor: pointer;
  }
  input[type='range']:focus::-ms-thumb {
    border: 1px solid var(--jha-form-range-slider-thumb-focus-color, var(--jha-text-theme));
    background: var(--jha-form-range-slider-thumb-focus-color, var(--jha-text-theme));
  }
`;
/** @element jha-form-range-slider */
export default class JhaFormRangeSlider extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            min: {
                type: Number,
            },
            max: {
                type: Number,
            },
            value: {
                type: Number,
            },
        };
    }
    constructor() {
        super();
        this.min = 0;
        this.max = Infinity;
    }
    handleInput(e) {
        this.value = e.currentTarget.value;
        /** @type {import('../../js/utils/types.js').InputChangeEvent} */
        const changeEvent = new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: {
                value: this.value,
            },
        });
        this.dispatchEvent(changeEvent);
    }
    render() {
        return html `
      <input
        type="range"
        min=${this.min}
        max=${this.max}
        .value=${this.value}
        @input=${this.handleInput} />
    `;
    }
}
export { styles as JhaFormRangeSliderStyles };
