import JhaFormMultiSelect from './JhaFormMultiSelect.js';
customElements.define('jha-form-multi-select', JhaFormMultiSelect);
/** @customElement jha-form-multi-select */
export default JhaFormMultiSelect;
