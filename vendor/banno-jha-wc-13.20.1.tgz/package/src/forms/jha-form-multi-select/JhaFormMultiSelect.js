import { LitElement, css, html } from 'lit';
import '../jha-form-floating-group/jha-form-floating-group.js';
import { jhaStyles } from '../../styles/jha-styles.js';
const styles = css `
  :host {
    display: block;
    position: relative;
  }
  :host([disabled]) {
    opacity: var(--jha-input-opacity-disabled, 0.7);
    cursor: default;
  }
  label {
    z-index: 1;
    width: calc(100% - 50px);
  }
  .input {
    position: relative;
    line-height: 18px;
    display: flex;
    justify-content: flex-start;
    gap: 8px;
    overflow: hidden;
    align-items: flex-start;
    --jha-input-padding: var(--jha-multiselect-input-padding, 10px 8px 8px);
    --jha-input-box-sizing: border-box;
  }
  .chips {
    display: flex;
    gap: 100px 8px;
    flex-wrap: wrap;
    align-self: flex-start;
    flex: none;
    flex-direction: row-reverse;
    justify-content: flex-end;
    max-width: calc(50% - 40px);
  }
  :host([outline]:not([small])) .input {
    --jha-input-padding: 17px 8px;
    height: 56px;
  }
  :host([outline][small]) .input {
    --jha-input-padding: 8px 8px 2px;
  }
  :host([filled]) .input {
    padding-top: 22px;
  }
  :host([filled]) .chip {
    --jha-input-chip-color: var(--jha-component-background-color, #f0f5f9);
  }
  :host([filled]) .icon {
    background-color: var(--jha-input-background, var(--jha-component-background-color, #fff));
  }
  input {
    flex: 1 1 auto;
    min-width: 100px;
    border: none;
    font: inherit;
    background: transparent;
    color: var(--jha-text-base, #333333);
    height: 100%;
  }
  input:focus {
    outline: none;
  }
  .icon {
    position: relative;
    top: var(--jha-multiselect-icon-top, 0);
    bottom: 0;
    right: 0;
    display: flex;
    align-items: center;
    z-index: 0;
    padding: 0 8px;
    background-color: var(--jha-input-background, var(--jha-component-background-color, #fff));
  }
  .icon button[disabled] jha-icon-chevron-down {
    fill: var(--jha-color-muted);
  }
  jha-icon-chevron-down {
    width: 24px;
    height: 24px;
    fill: var(--jha-color-neutral);
  }
  jha-icon-chevron-down[open] {
    transform: rotate(180deg);
  }
  :host([outline]:not([small])) jha-icon-chevron-down {
    --jha-form-select-icon-top: 28px;
  }
  .chip {
    color: var(--jha-text-dark);
    background: var(--jha-input-chip-color, var(--jha-color-light, #f0f5f9));
    font-size: var(--jha-input-font-size, 14px);
    padding: var(--jha-multiselect-chip-padding, 3px 8px);
    border-radius: 2px;
    line-height: 1.2;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    gap: 2px;
    max-width: 95%;
  }
  .chip span {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  .all-selected {
    color: var(--jha-text-base, #333333);
  }
  jha-icon-close {
    width: 12px;
    height: 12px;
    fill: currentColor;
  }
  .chip[selected] {
    background: var(--jha-text-theme, var(--body-text-theme-color));
    color: var(--jha-background-color, var(--primary-content-background-color));
  }
  button {
    font: inherit;
    color: inherit;
  }
  .chip button {
    background: none;
    border: none;
    padding: 0;
    margin: 0;
    cursor: pointer;
    font-size: 10px;
    top: 2px;
    position: relative;
  }
  [popover] {
    box-shadow: var(--jha-card-box-shadow, var(--card-shadow));
    max-height: 200px;
    overflow-y: auto;
    background: var(--jha-component-background-color, var(--primary-content-background-color));
    margin: 0px;
    margin-top: 4px;
    border: none;
    padding: 0;
    color: inherit;
  }

  :host([outline]:not([small])) .options-dropdown {
    top: 72px;
  }
  :host([filled]:not([small])) .options-dropdown {
    top: 65px;
  }
  ul {
    list-style-type: none;
    padding: 0;
    margin: 0;
  }
  li button {
    border: none;
    background: none;
    padding: 8px;
    margin: 0;
    cursor: pointer;
    font-size: 14px;
    display: flex;
    align-items: center;
    border-radius: none;
    width: 100%;
    text-align: left;
  }
  li button:focus {
    outline: none;
  }
  li:hover,
  li:focus-within {
    background: var(--jha-focus-highlight-color, var(--link-button-pressed-color));
  }
  button jha-icon-checkmark {
    opacity: 0;
    vertical-align: middle;
    fill: var(--jha-color-primary);
    margin-right: 4px;
  }
  button[selected] jha-icon-checkmark {
    opacity: 1;
  }
  .options-dropdown[show] {
    display: block;
  }
  .tagLimit {
    text-align: right;
    font-size: 12px;
    color: var(--body-text-secondary-color);
  }
  .info-area {
    display: flex;
    justify-content: space-between;
    margin: var(--jha-chip-info-margin-top, 10px) 0 0 0;
    box-sizing: border-box;
    width: 100%;
  }
  .no-results {
    padding: 12px;
    color: var(--body-text-secondary-color);
  }
  .helperText {
    font-size: 12px;
    color: var(--body-text-secondary-color);
    margin-left: var(--jha-chip-helper-margin-left, 0);
  }
  .required-indicator {
    color: var(
      --jh-input-required-color-text,
      var(--jh-color-content-negative-enabled, var(--jha-color-danger, #db2012))
    );
  }
  slot[name='input-right']::slotted(*) {
    position: absolute;
    right: var(--jha-multiselect-right-slot-right-position, 35px);
    background-color: var(--jh-input-color-background, var(--jh-color-container-primary-enabled));
    backdrop-filter: var(--jh-input-slot-right-backgdrop-filter, blur(5px));
    border-radius: var(--jh-input-slot-right-border-radius, 12px);
  }
`;
/**
 * @typedef {Object} MultiSelectOption
 * @property {!string} name
 */
/**
 * JHA select input that allows you to choose multiple options
 *
 * @element jha-form-multi-select
 *
 * @prop {Boolean} allowSelectAll - Adds select all option if a chip limit is not set
 * @prop {String} selectAllLabel - Change the label for the select all option
 * @prop {String} allSelectedText - Change the text display when all options are selected
 * @prop {Number} chipLimit - the max number of options users can select
 * @prop {Boolean} filled - adds background to input
 * @prop {String} focused - Adds focused attribute to component
 * @prop {String} helperText - help text below the input
 * @prop {String} inputValue - text typed in the input field that filters options shown
 * @prop {String} label = inputs label
 * @prop {Boolean} menuOpen - if the options menu is open
 * @prop {Array<string|MultiSelectOption>} options - array of string values
 * @prop {Boolean} outline - adds border around input
 * @prop {Array} selectedOptions - array of selected options
 * @prop {Boolean} required - adds error if component is focused and then nothing is selected
 * @prop {Boolean} small - changes padding of input
 * @prop {String} warning - message to show when there is an error
 * @prop {boolean} hideRequiredIndicator - Removes the required asterisk from the input label.  Please only use if marking optional fields with '(optional)'.
 *
 * @cssprop --jha-input-chip-color - Background color for a chip item in the input
 */
export default class JhaFormMultiSelect extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            allowSelectAll: {
                type: Boolean,
            },
            chipLimit: {
                type: Number,
            },
            filled: {
                type: Boolean,
                reflect: true,
            },
            focused: {
                type: String,
                reflect: true,
            },
            helperText: {
                type: String,
            },
            inputValue: {
                type: String,
            },
            label: {
                type: String,
            },
            menuOpen: {
                type: Boolean,
            },
            options: {
                type: Array,
            },
            outline: {
                type: Boolean,
                reflect: true,
            },
            selectedOptions: {
                type: Array,
            },
            required: {
                type: Boolean,
                reflect: true,
            },
            hideRequiredIndicator: {
                type: Boolean,
            },
            small: {
                type: Boolean,
                reflect: true,
            },
            warning: {
                type: String,
                reflect: true,
            },
            chipsOverFlowing: {
                type: Boolean,
            },
            selectAllLabel: {
                type: String,
            },
            allSelectedText: {
                type: String,
            },
            visibleChipsCount: {
                type: Number,
            },
            inputBounds: {
                type: Object,
                state: true,
            },
            disabled: {
                type: Boolean,
                reflect: true,
            },
        };
    }
    constructor() {
        super();
        import('../../icons/jha-icon-close.js');
        import('../../icons/jha-icon-checkmark.js');
        import('../../icons/jha-icon-chevron-down.js');
        this.allowSelectAll = false;
        this.chipLimit = null;
        this.filled = false;
        this.focused = false;
        this.helperText = null;
        this.inputValue = '';
        this.label = '';
        this.menuOpen = false;
        this.options = [];
        this.outline = false;
        this.selectedOptions = [];
        this.required = false;
        this.small = false;
        this.warning = '';
        this.chipsOverflowing = false;
        this.hideRequiredIndicator = false;
        this.selectAllLabel = 'Select All';
        this.allSelectedText = null;
        this.visibleChipsCount = 0;
        this.disabled = false;
        this.boundCloseMenu_ = this.closeMenu.bind(this);
        this.boundOnResize_ = this.onResize.bind(this);
        this.boundOnScroll_ = this.onScroll.bind(this);
        this.hasInteraction_ = false;
        this.selectedChipIndex_ = null;
        this.inputBounds = {};
        this.updateBoundsDebounce = null;
        // eslint-disable-next-line @jkhy/ux/prefer-arrow-event-handler
        this.addEventListener('click', () => {
            this.focusInput();
        });
    }
    updated(changedProperties) {
        if (changedProperties.has('selectedOptions') || changedProperties.has('inputBounds')) {
            this.checkChipsOverflowing();
        }
        if (changedProperties.has('disabled') && this.disabled && this.menuOpen) {
            this.closeMenu();
        }
    }
    firstUpdated() {
        // bounds are still not calculated correctly on first render
        // wait a frame to get the correct bounds
        window.requestAnimationFrame(() => {
            this.updateBounds();
        });
    }
    connectedCallback() {
        super.connectedCallback();
        window.addEventListener('resize', this.boundOnResize_);
        window.addEventListener('scroll', this.boundOnScroll_);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        window.removeEventListener('click', this.boundCloseMenu_);
        window.removeEventListener('resize', this.boundOnResize_);
        window.removeEventListener('scroll', this.boundOnScroll_);
    }
    focusListItemButton(index) {
        const list = this.shadowRoot.querySelectorAll('li.option');
        if (list && list[index]) {
            const button = list[index].querySelector('button');
            if (button) {
                button.focus();
            }
        }
    }
    getOption(item) {
        return typeof item === 'string' ? item : item.name;
    }
    onInputKeyup(e) {
        e.preventDefault();
        if (e.key === 'ArrowLeft') {
            this.selectPreviousChip();
        }
        else if (e.key === 'ArrowRight') {
            this.selectNextChip();
        }
        else if (e.key === 'ArrowDown') {
            this.focusListItemButton(0);
        }
        else if ((e.key === 'Backspace' || e.key === 'Delete') && !this.inputValue) {
            this.removeItemAtIndex(0);
        }
        else if (e.key === 'Escape') {
            this.closeMenu();
            if (!this.menuOpen) {
                this.blurInput();
            }
            return;
        }
        else {
            this.selectedChipIndex = null;
        }
        const { value } = e.target;
        this.inputValue = value;
    }
    filterDropDown(item) {
        return item.toLowerCase().includes(this.inputValue.toLowerCase());
    }
    get selectedOptionsLength() {
        return (this.selectedOptions || []).length;
    }
    selectPreviousChip() {
        if (!this.selectedOptions.length)
            return;
        this.selectedChipIndex = this.selectedChipIndex
            ? (this.selectedChipIndex - 1) % this.selectedOptionsLength
            : this.selectedOptionsLength - 1;
    }
    selectNextChip() {
        if (!this.selectedOptionsLength)
            return;
        this.selectedChipIndex =
            this.selectedChipIndex !== null ? (this.selectedChipIndex + 1) % this.selectedOptionsLength : 0;
    }
    selectOption(option) {
        if (this.selectedOptions.some((o) => (typeof o === 'string' ? o === option : o.name === option.name))) {
            this.selectedOptions = this.selectedOptions.filter((o) => typeof o === 'string' ? o !== option : o.name !== option.name);
        }
        else if (!this.atChipLimit) {
            // don't allow selection if over the limit
            this.selectedOptions = [option, ...this.selectedOptions];
        }
        this.inputValue = '';
        this.focusInput();
        this.dispatchChangeEvent();
        // if now at or over the limit, close the menu
        if (this.atChipLimit) {
            // need to wait a frame before closing the menu
            window.requestAnimationFrame(() => {
                this.closeMenu();
            });
        }
    }
    get allSelected() {
        return this.selectedOptionsLength === this.options.length;
    }
    toggleAll() {
        this.selectedOptions = this.allSelected ? [] : [...this.options];
        this.dispatchChangeEvent();
    }
    onOptionKeydown_(event, option) {
        if (event.code === 'Enter') {
            this.selectOption(option);
        }
        else if (['ArrowDown', 'ArrowUp'].includes(event.code)) {
            event.preventDefault();
            const li = event.target.parentNode;
            if (li) {
                const list = Array.from(this.shadowRoot.querySelectorAll('li.option') || []);
                const index = list.findIndex((item) => item === li);
                const sibling = event.code === 'ArrowUp' ? index - 1 : index + 1;
                if (sibling > -1 && sibling <= list.length) {
                    this.focusListItemButton(sibling);
                }
            }
        }
    }
    floatLabel(inputValue, options) {
        return inputValue || options.length;
    }
    removeItemAtIndex(selectedIndex) {
        this.selectedOptions = this.selectedOptions.filter((option, index) => index !== selectedIndex);
        this.dispatchChangeEvent();
    }
    removeItem(option) {
        if (this.disabled)
            return;
        this.selectedOptions = this.selectedOptions.filter((o) => typeof o === 'string' ? o !== option : o.name !== option.name);
        this.focusInput();
        this.dispatchChangeEvent();
    }
    dispatchChangeEvent() {
        this.dispatchEvent(new CustomEvent('change', {
            detail: this.selectedOptions,
        }));
    }
    focusInput() {
        this.shadowRoot.getElementById('input').focus();
    }
    blurInput() {
        this.shadowRoot.getElementById('input').blur();
    }
    get atChipLimit() {
        return this.chipLimit && this.selectedOptions.length >= this.chipLimit;
    }
    get hiddenChipValue() {
        return this.selectedOptions
            .slice(this.visibleChipsCount, this.selectedOptionsLength)
            .reverse()
            .map((item) => this.getOption(item))
            .join(', ');
    }
    onFocus() {
        this.focused = true;
        this.showMenu();
        this.dispatchEvent(new CustomEvent('focus'));
    }
    showMenu() {
        if (this.atChipLimit)
            return;
        this.updateBounds();
        const el = /** @type {HTMLElement} */ (this.shadowRoot.querySelector('#options-dropdown'));
        el?.showPopover();
    }
    closeMenu() {
        this.inputValue = '';
        const el = /** @type {HTMLElement} */ (this.shadowRoot.querySelector('#options-dropdown'));
        el?.hidePopover();
    }
    handleToggleArrow(evt) {
        // due to lit's rendering (recreating the div at times)
        // calling togglePopover does not work as expected.
        // workaround by explicitly closing or opening the menu
        if (this.menuOpen) {
            this.closeMenu();
        }
        else {
            this.showMenu();
        }
        evt.stopPropagation();
    }
    onBlur() {
        this.focused = false;
        this.hasInteraction_ = true;
    }
    checkValidity() {
        if (this.required) {
            return this.selectedOptionsLength > 0;
        }
        if (this.chipLimit !== null) {
            return this.selectedOptionsLength <= this.chipLimit;
        }
        return true;
    }
    /**@description suppress warnings until the user has interacted (focused) the input */
    showWarning() {
        return this.hasInteraction_ ? !this.checkValidity() : false;
    }
    calculateVisibleChips(chipsContainer) {
        const chips = Array.from(chipsContainer.children);
        const baseOffset = chips[0].offsetTop;
        const breakIndex = chips.findIndex((item) => item.offsetTop > baseOffset);
        const chipsPerRow = breakIndex === -1 ? chips.length : breakIndex;
        this.visibleChipsCount = chipsPerRow;
    }
    onResize() {
        this.updateBounds();
        this.checkChipsOverflowing();
    }
    onScroll() {
        this.updateBounds();
    }
    updateBounds() {
        const el = this.shadowRoot.querySelector('.input');
        this.inputBounds = el ? el.getBoundingClientRect() : {};
    }
    checkChipsOverflowing() {
        const container = this.shadowRoot.querySelector('.input');
        const chips = this.shadowRoot.querySelector('.chips');
        if (!(container && chips)) {
            this.chipsOverflowing = false;
            return;
        }
        this.chipsOverflowing = chips.clientHeight > container.clientHeight;
        this.calculateVisibleChips(chips);
        this.requestUpdate();
    }
    /** @param {ToggleEvent} event */
    onPopoverToggle(event) {
        this.menuOpen = event.newState === 'open';
        // if this is in a dialog, we need to disable scrolling
        this.dispatchEvent(new CustomEvent('popover-open', {
            detail: this.menuOpen,
            bubbles: true,
            composed: true,
        }));
    }
    renderChips() {
        if (this.selectedOptionsLength === 0)
            return '';
        if (this.allSelected && this.allSelectedText) {
            return html ` <span class="all-selected">${this.allSelectedText}</span> `;
        }
        return html `
      ${this.chipsOverflowing
            ? html `
            <div
              class="overflow-indicator"
              title=${this.hiddenChipValue}>
              <div class="chip">
                <span> ${this.selectedOptionsLength - this.visibleChipsCount} ... </span>
              </div>
            </div>
          `
            : ``}
      <div class="chips">
        ${(this.selectedOptions || []).map((o) => html `
            <div class="chip">
              <span title=${this.getOption(o)}>${this.getOption(o)}</span>
              ${this.disabled
            ? ''
            : html `
                    <button @click=${() => this.removeItem(o)}>
                      <jha-icon-close></jha-icon-close>
                    </button>
                  `}
            </div>
          `)}
      </div>
    `;
    }
    maybeRenderRequiredIndicator() {
        if (this.required && !this.hideRequiredIndicator) {
            return html ` <span class="required-indicator">*</span> `;
        }
        return '';
    }
    render() {
        return html `
      <jha-form-floating-group
        ?outline=${this.outline}
        ?small=${this.small}
        ?filled=${this.filled}
        ?persist-value=${this.selectedOptionsLength > 0}
        .error=${this.showWarning() ? this.warning : null}
        ?has-value=${this.menuOpen || (this.selectedOptions && this.selectedOptionsLength > 0)}>
        <div
          class="input"
          ?focus=${this.focused}
          ?disabled=${this.disabled}>
          ${this.renderChips()}
          <input
            id="input"
            autocomplete="off"
            type="text"
            ?disabled=${this.atChipLimit || this.disabled}
            .value=${this.inputValue}
            @keyup=${this.onInputKeyup}
            @blur=${this.onBlur}
            @focus=${this.onFocus}
            @click=${() => {
            this.showMenu();
            this.focusInput();
        }} />
          <slot name="input-right"></slot>
          <div class="icon">
            <button
              button-reset
              type="button"
              ?disabled=${this.atChipLimit || this.disabled}
              @click=${this.handleToggleArrow}>
              <jha-icon-chevron-down ?open=${this.menuOpen}></jha-icon-chevron-down>
            </button>
          </div>
        </div>
        ${this.label
            ? html `
              <label
                for=${this.id}
                class="label">
                ${this.label} ${this.maybeRenderRequiredIndicator()}
              </label>
            `
            : ''}
        ${this.showWarning() && this.warning
            ? ''
            : html `
              ${this.helperText || this.chipLimit
                ? html `
                    <div
                      class="info-area"
                      slot="assistive-text">
                      <div class="helperText">${this.helperText}</div>
                      ${this.chipLimit
                    ? html ` <div class="tagLimit">${this.selectedOptionsLength}/${this.chipLimit}</div> `
                    : ''}
                    </div>
                  `
                : ''}
            `}
        <div
          style="top:${this.inputBounds.bottom}px; left: ${this.inputBounds.left}px; width: ${this.inputBounds
            .width}px;"
          tabindex="-1"
          class="options-dropdown"
          id="options-dropdown"
          popover
          @toggle=${this.onPopoverToggle}
          @click=${(evt) => {
            evt.stopPropagation();
        }}>
          ${this.options.some((o) => this.filterDropDown(this.getOption(o)))
            ? html `
                <ul tabindex="0">
                  ${this.allowSelectAll && !this.chipLimit && !this.inputValue
                ? html `
                        <li tabindex="-1">
                          <button
                            @click=${() => this.toggleAll()}
                            ?selected=${this.allSelected}>
                            <jha-icon-checkmark></jha-icon-checkmark>
                            <span>${this.selectAllLabel}</span>
                          </button>
                        </li>
                      `
                : ''}
                  ${this.options
                .filter((o) => this.filterDropDown(this.getOption(o)))
                .map((o) => html `
                        <li
                          class="option"
                          tabindex="-1">
                          <button
                            @click=${() => this.selectOption(o)}
                            @keydown=${(evt) => this.onOptionKeydown_(evt, o)}
                            ?selected=${this.selectedOptions.some((s) => typeof s === 'string' ? s === o : s.name === o.name)}>
                            <jha-icon-checkmark></jha-icon-checkmark>
                            <span>${this.getOption(o)}</span>
                          </button>
                        </li>
                      `)}
                </ul>
              `
            : html ` <div class="no-results">No results found</div> `}
        </div>
      </jha-form-floating-group>
    `;
    }
}
export { styles as JhaFormMultiSelectStyles };
