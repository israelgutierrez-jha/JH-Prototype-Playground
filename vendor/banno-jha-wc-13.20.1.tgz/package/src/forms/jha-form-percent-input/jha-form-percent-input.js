import JhaFormPercentInput from './JhaFormPercentInput.js';
customElements.define('jha-form-percent-input', JhaFormPercentInput);
/** @customElement jha-form-percent-input */
export default JhaFormPercentInput;
