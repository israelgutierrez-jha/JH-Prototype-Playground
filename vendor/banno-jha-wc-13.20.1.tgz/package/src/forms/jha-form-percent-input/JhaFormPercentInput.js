import { html, css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
import JhaFormInput from '../jha-form-input-base/JhaFormInput.js';
import '../jha-form-floating-group/jha-form-floating-group.js';
const styles = css `
  :host {
    display: block;
    --jha-input-symbol-right-width: 18px;
  }
  :host([disabled]) {
    opacity: var(--jha-input-opacity-disabled, 0.7);
    cursor: default;
  }
  span {
    padding: 4px 0;
  }

  .required-indicator {
    color: var(--jh-input-required-color-text, var(--jh-color-content-negative-enabled));
  }
  div[slot='input-right'] {
    display: flex;
    align-items: center;
    line-height: 18px;
  }
  slot[name='input-right']::slotted(*) {
    margin-right: var(--jha-text-input-right-slot-right-position, 18px);
    background-color: var(--jh-input-color-background, var(--jh-color-container-primary-enabled));
    backdrop-filter: var(--jh-input-slot-right-backgdrop-filter, blur(5px));
    border-radius: var(--jh-input-slot-right-border-radius, 12px);
  }
`;
/**
 * @element jha-form-currency-input
 *
 * Extends Jha-form-input see: forms/jha-form-input-base/jhaFormInput.js for list of properties
 */
export default class JhaFormPercentInput extends JhaFormInput {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            min: {
                type: Number,
            },
            max: {
                type: Number,
            },
            placeholder: {
                type: String,
            },
            noLabel: {
                type: Boolean,
            },
            noDecimal: {
                type: Boolean,
            },
            outline: {
                type: Boolean,
                reflect: true,
            },
            alwaysFloat: {
                type: Boolean,
                reflect: true,
            },
            step: {
                type: String,
            },
            value_: {
                type: String,
            },
        };
    }
    constructor() {
        super();
        this.step = '0.01';
        this.amount = '';
        this.min = 0;
        this.max = 100;
        this.noLabel = false;
        this.noDecimal = false;
        this.outline = false;
        this.small = false;
        this.placeholder = null;
        this.alwaysFloat = false;
        this.value_ = '';
    }
    /**
     * @description re-formats amount to 2 decimal places (or '')
     * @param {string} value
     */
    formatValue(value) {
        if (value) {
            const decimalPlaces = this.step && this.step.split('.').length > 1 ? this.step.split('.')[1].length : 0;
            const amount = parseFloat(String(value).replace(/,/g, ''));
            const val = Number.isNaN(amount) ? '' : Math.abs(amount).toFixed(decimalPlaces);
            if (this.noDecimal) {
                this.value_ = String(parseInt(val, 10));
            }
            else {
                this.value_ = val;
            }
        }
    }
    checkValidity() {
        if (this.input_.validity.stepMismatch) {
            return true;
        }
        return super.checkValidity();
    }
    render() {
        return html `
      <jha-form-floating-group
        ?outline=${this.outline}
        ?small=${this.small}
        ?filled=${this.filled}
        ?no-label=${this.noLabel}
        ?always-float=${this.alwaysFloat}
        ?has-value=${Boolean(this.value)}
        .assistiveText=${this.assistiveText}
        .error=${this.showWarning_() ? this.warning : null}>
        <input
          id=${this.id}
          aria-label=${this.label}
          ?readonly=${this.readonly}
          type="number"
          inputmode="decimal"
          min=${this.min}
          max=${this.max}
          step=${parseFloat(this.step)}
          .value=${this.value_}
          ?disabled=${this.disabled}
          ?required=${this.required}
          placeholder=${this.placeholder}
          @keyup=${this.onInput_}
          @change=${this.onChange_}
          @blur=${this.onBlur_}
          @keydown=${this.onKeydown_}
          class="${this.showWarning_() ? 'warning' : ''}"
          autocomplete="off" />
        ${this.label
            ? html `
              <label
                for=${this.id}
                class="label">
                ${this.required
                ? html `
                      ${this.label}
                      ${this.hideRequiredIndicator ? '' : html ` <span class="required-indicator">*</span> `}
                    `
                : this.label}
              </label>
            `
            : ''}
        <div slot="input-right">
          <slot name="input-right"></slot>
          <span>%</span>
        </div>
      </jha-form-floating-group>
    `;
    }
}
export { styles as JhaFormPercentInputStyles };
