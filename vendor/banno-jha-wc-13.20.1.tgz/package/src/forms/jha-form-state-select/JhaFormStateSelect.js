import JhaFormSelect from '../jha-form-select/jha-form-select.js';
import { statesAsSelectArray } from '../../js/utils/state-abbreviations.js';
/**@element jha-form-state-select */
export default class JhaFormStateSelect extends JhaFormSelect {
    constructor() {
        super();
        this.options = statesAsSelectArray();
        this.label = 'State';
        this.emptyOptionLabel = '- Select a state -';
    }
}
