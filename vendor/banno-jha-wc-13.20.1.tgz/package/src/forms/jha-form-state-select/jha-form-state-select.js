import JhaFormStateSelect from './JhaFormStateSelect.js';
customElements.define('jha-form-state-select', JhaFormStateSelect);
/** @customElement jha-form-state-select */
export default JhaFormStateSelect;
