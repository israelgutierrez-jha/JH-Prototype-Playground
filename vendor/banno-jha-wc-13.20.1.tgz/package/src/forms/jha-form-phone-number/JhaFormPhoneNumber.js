import JhaFormInput from '../jha-form-input-base/JhaFormInput.js';
import { formatPhone, cleanPhoneNumber } from '../../js/utils/phone-numbers.js';
/**
 * @element jha-form-phone-number
 *
 * Extends Jha-form-input see: forms/jha-form-input-base/jhaFormInput.js for list of properties
 */
export default class JhaFormPhoneNumber extends JhaFormInput {
    static get properties() {
        return {
            format: {
                type: Boolean,
            },
        };
    }
    constructor() {
        super();
        /** @type {"tel"} */
        this.type = 'tel';
        this.label = 'Phone Number';
        this.warning = 'Please provide a valid phone number.';
        this.maxlength = 15;
        this.minlength = 10;
        this.format = false;
        this.allowedCharacters = '[0-9 ]'; // Allow only numbers
    }
    formatValue(value) {
        if (this.format) {
            this.value_ = formatPhone(value);
        }
    }
    checkValidity() {
        if (!this.value_ && !this.required) {
            return true;
        }
        const baseNumber = cleanPhoneNumber(this.value_);
        if (this.format)
            return baseNumber.length === 10;
        const lengthRange = new RegExp(`^[0-9]{${this.minlength},${this.maxlength}}$`);
        return lengthRange.test(baseNumber);
    }
}
