import JhaFormPhoneNumber from './JhaFormPhoneNumber.js';
customElements.define('jha-form-phone-number', JhaFormPhoneNumber);
/** @customElement jha-form-phone-number */
export default JhaFormPhoneNumber;
