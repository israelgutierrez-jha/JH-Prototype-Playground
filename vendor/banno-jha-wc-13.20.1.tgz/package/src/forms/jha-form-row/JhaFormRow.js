import { css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
import JhaStyleElement from '../../style-element/JhaStyleElement.js';
const styles = css `
  :host {
    --jha-form-row-gap-vertical: 0;
    --jha-form-row-gap-horizontal: 8px;
    --jha-form-row-item-flex: 1;
    --jha-form-row-align-items: flex-start;
    --jha-form-row-justify-content: space-between;
    --jha-form-row-item-flex: 1;
    display: flex;
    align-items: var(--jha-form-row-align-items, center);
    gap: var(--jha-form-row-gap-vertical, 0) var(--jha-form-row-gap-horizontal, 0);
    justify-content: var(--jha-form-row-justify-content, inherit);
  }
  :host([space-between]) {
    --jha-form-row-justify-content: space-between;
  }
  :host([flex-start]) {
    --jha-form-row-justify-content: flex-start;
  }
  :host ::slotted(*) {
    flex: var(--jha-form-row-item-flex, none);
    --jha-input-label-font-size: 12px;
    --jha-input-font-size: 14px;
    --jha-input-padding-top: 12px;
    --jha-list-margin-top: 12px;
    --jha-input-margin-bottom: 4px;
    --jha-list-margin-bottom: 4px;
    --jha-text-input-margin-bottom: var(--jha-form-row-item-margin-bottom, 4px);
    --error-text-top-margin: 2px;
    --jha-chip-info-margin-top: 2px;
    margin-bottom: 0;
  }
  :host ::slotted(*[outline]) {
    --error-text-left-margin: 12px;
    --jha-chip-helper-margin-left: 12px;
  }
  :host ::slotted(*[flex-two]) {
    --jha-form-row-item-flex: 2;
  }
  :host ::slotted(*[flex-three]) {
    --jha-form-row-item-flex: 3;
  }

  @media (max-width: 480px) {
    :host {
      flex-wrap: wrap;
    }
    :host ::slotted(*[mobile-break]) {
      flex-basis: 100%;
    }
  }
`;
/**@element jha-form-row */
export default class JhaFormRow extends JhaStyleElement {
    static get styles() {
        return [jhaStyles, styles];
    }
}
export { styles as JhaFormRowStyles };
