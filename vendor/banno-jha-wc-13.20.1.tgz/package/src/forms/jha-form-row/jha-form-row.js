import JhaFormRow from './JhaFormRow.js';
customElements.define('jha-form-row', JhaFormRow);
/** @customElement jha-form-row */
export default JhaFormRow;
