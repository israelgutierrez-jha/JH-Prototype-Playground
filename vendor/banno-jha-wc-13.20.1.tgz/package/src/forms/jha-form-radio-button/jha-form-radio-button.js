import JhaFormRadioButton from './JhaFormRadioButton.js';
customElements.define('jha-form-radio-button', JhaFormRadioButton);
/** @customElement jha-form-radio-button */
export default JhaFormRadioButton;
