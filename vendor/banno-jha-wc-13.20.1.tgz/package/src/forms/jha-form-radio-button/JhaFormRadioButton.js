import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
const styles = css `
  :host {
    display: block;
    text-align: left;
  }
  :host([disabled]) {
    opacity: var(--jha-input-opacity-disabled, 0.7);
    cursor: default;
  }
  label {
    position: relative;
    display: flex;
    align-items: flex-start;
    padding: var(--jha-form-radio-padding, 0);
    color: var(--jha-form-radio-text-color, var(--jha-text-base, #8c989f));
    cursor: pointer;
    margin-bottom: var(--jha-form-radio-margin-bottom, 8px);
    font-size: var(--jha-form-radio-font-size, 14px);
  }
  .input-container {
    position: relative;
    margin-left: 4px;
    margin-right: 16px;
    margin-top: var(--jha-form-radio-margin-top, 2px);
    width: calc(var(--jha-form-radio-size, 14px) + 2px);
    height: calc(var(--jha-form-radio-size, 14px) + 2px);
  }
  input,
  span {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
  }
  input {
    width: calc(var(--jha-form-radio-size, 14px) + 2px);
    height: calc(var(--jha-form-radio-size, 14px) + 2px);
    margin: 0;
    opacity: 0;
    z-index: -1;
    touch-action: manipulation;
  }
  span {
    display: block;
    width: var(--jha-form-radio-size, 14px);
    height: var(--jha-form-radio-size, 14px);
    line-height: var(--jha-form-radio-size, 14px);
    text-align: center;
    border: 1px solid var(--jha-form-radio-border-color, var(--jha-color-neutral, #8d99a0));
    background-size: 18px;
    background-position: center center;
    background-repeat: no-repeat;
    cursor: pointer;
    border-radius: 50%;
    transition: all 0.2s ease;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    z-index: 0;
  }
  input:focus ~ span {
    border-color: var(--jha-form-radio-focused-border-color, var(--jha-color-primary, #3aaeda));
    box-shadow: 0 0 0 2px var(--jha-form-radio-focused-shadow-color, var(--jha-color-primary, #3aaeda));
  }
  input[disabled] ~ span {
    cursor: default;
  }
  :host([disabled]) label {
    cursor: default;
  }
  input[checked] ~ span {
    background-color: var(--jha-form-radio-checked-background-color, var(--jha-color-primary, #3aaeda));
    border-color: var(--jha-form-radio-checked-border-color, var(--jha-color-primary, #3aaeda));
  }
  input[checked] ~ span::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: var(--jha-form-radio-checked-dot-size, 50%);
    height: var(--jha-form-radio-checked-dot-size, 50%);
    transform: translate(-50%, -50%);
    background-color: var(--jha-form-radio-checked-dot-color, var(--jha-text-white, #ffffff));
    border-radius: 50%;
  }
  .slot-container {
    display: flex;
    gap: var(--jh-dimension-100);
  }
  .helper-text {
    word-break: normal;
    overflow-wrap: anywhere;
    color: var(--jh-input-helper-color-text, var(--jh-color-content-secondary-enabled));
    margin: 0;
    font: var(--jh-font-helper-regular);
  }
`;
/**
 * A styled radio button with slot for label
 *
 * @element jha-form-radio-button
 *
 * @prop {boolean} checked - Whether the input is checked or not
 * @prop {boolean} disabled - Disables the input
 * @prop {string} id - ID of the radio
 * @prop {string} name - Name of the radio group
 * @prop {string} value - The value, set by the input itself when checked changes
 * @prop {string} for - The for property of the label
 *
 * @slot unnamed slot - the label of the radio
 *
 * @cssprop --jha-form-radio-size
 * @cssprop --jha-form-radio-text-color
 * @cssprop --jha-form-radio-font-size
 * @cssprop --jha-form-radio-border-color
 * @cssprop --jha-form-radio-focused-border-color
 * @cssprop --jha-form-radio-focused-shadow-color
 * @cssprop --jha-form-radio-checked-background-color
 * @cssprop --jha-form-radio-checked-border-color
 * @cssprop --jha-form-radio-checked-dot-color
 */
export default class JhaFormRadioButton extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            checked: {
                type: Boolean,
                reflect: true,
            },
            name: {
                type: String,
                reflect: true,
            },
            value: {
                type: String,
            },
            for: {
                type: String,
                reflect: true,
            },
            id: {
                type: String,
                reflect: true,
            },
            disabled: {
                type: Boolean,
                reflect: true,
            },
            required: {
                type: Boolean,
                reflect: true,
            },
            helpText: {
                type: String,
            },
        };
    }
    constructor() {
        super();
        /** @type {"hidden" | "text" | "search" | "tel" | "url" | "email" | "password" | "datetime" | "date" | "month" | "week" | "time" | "datetime-local" | "number" | "range" | "color" | "checkbox" | "radio" | "file" | "submit" | "image" | "reset" | "button"} */
        this.type = 'radio';
        this.name = '';
        this.value = '';
        this.for = '';
        // eslint-disable-next-line wc/no-constructor-attributes
        this.id = 'radioInput';
        this.disabled = false;
        this.required = false;
        this.helpText = '';
    }
    connectedCallback() {
        super.connectedCallback();
    }
    firstUpdated() {
        this.addEventListener('click', this.onClick_);
    }
    renderHelperText() {
        return html ` <p class="helper-text">${this.helpText}</p> `;
    }
    render() {
        return html `
      <label for=${this.for}>
        <div class="input-container">
          <input
            id=${this.id}
            type=${this.type}
            name=${this.name}
            .value=${this.value}
            ?checked=${this.checked}
            .checked=${this.checked}
            ?disabled=${this.disabled}
            ?required=${this.required} />
          <span></span>
        </div>
        <div class="slot-container">
          <div>
            <slot></slot>
            ${this.helpText ? this.renderHelperText() : ''}
          </div>
          <slot name="input-label-icon"></slot>
        </div>
      </label>
    `;
    }
    /**
     * @returns {?Array<JhaFormRadioButton>}
     * */
    getSiblingButtons_() {
        const selector = this.tagName.toLowerCase();
        const { parentNode } = this;
        if (parentNode instanceof ShadowRoot && parentNode.host instanceof HTMLElement) {
            return Array.from(parentNode.host.shadowRoot.querySelectorAll(selector));
        }
        if (parentNode instanceof HTMLElement) {
            return Array.from(parentNode.querySelectorAll(selector));
        }
        throw new Error('No valid parent node found');
    }
    /**
     * @description `click` event handler -- sets `checked = true` and sets the `checked` property
     * of any other `<jha-form-radio-button>`s with the same `name` in the same form to `false`
     */
    onClick_(evt) {
        if (this.disabled) {
            evt.preventDefault();
            return;
        }
        this.checked = true;
        /** @type {import('../../js/utils/types.js').InputChangeEvent} */
        const changeEvent = new CustomEvent('checked', {
            bubbles: true,
            composed: true,
            detail: {
                value: this.value,
            },
        });
        this.dispatchEvent(changeEvent);
        const els = this.getSiblingButtons_();
        els.forEach((radio) => {
            if (radio !== this && radio.name === this.name) {
                radio.checked = false;
            }
        });
    }
}
export { styles as jhaFormRadioButtonStyles };
