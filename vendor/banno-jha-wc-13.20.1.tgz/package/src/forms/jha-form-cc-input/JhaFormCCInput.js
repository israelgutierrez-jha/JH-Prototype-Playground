import JhaFormInput from '../jha-form-input-base/JhaFormInput.js';
/**
 * @element jha-form-cc-input
 *
 * Extends Jha-form-input see: forms/jha-form-input-base/jhaFormInput.js for list of properties
 */
export default class JhaFormCCInput extends JhaFormInput {
    static get properties() {
        return {
            label: {
                type: String,
            },
            warning: {
                type: String,
            },
        };
    }
    constructor() {
        super();
        this.label = 'Card number';
        this.warning = 'Please enter a valid credit card number.';
        this.pattern = '[0-9]{19}';
        this.maxlength = 19;
        this.allowedCharacters = '[0-9 ]+'; // Allow only numbers and spaces
    }
    checkValidity() {
        if (`${this.value}`.length <= 0) {
            return !this.required;
        }
        const validCardFormats = /^(?:(?<visa>4[0-9]{12}(?:[0-9]{3})?)|(?<mastercard>5[1-5][0-9]{14})|(?<discover>6(?:011|5[0-9]{2})[0-9]{12})|(?<amex>3[47][0-9]{13})|(?<diners>3(?:0[0-5]|[68][0-9])[0-9]{11})|(?<jcb>(?:2131|1800|35[0-9]{3})[0-9]{11}))$/;
        return validCardFormats.test(String(this.value).replace(/ /g, ''));
    }
    formatValue(value) {
        const clean = String(value).replace(/ /g, '');
        this.value_ = `${clean.substr(0, 4)} ${clean.substr(4, 4)} ${clean.substr(8, 4)} ${clean.substr(12, 4)}`.trim();
    }
}
