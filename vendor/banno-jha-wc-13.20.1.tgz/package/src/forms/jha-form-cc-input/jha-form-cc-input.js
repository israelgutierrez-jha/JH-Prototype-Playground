import JhaFormCCInput from './JhaFormCCInput.js';
customElements.define('jha-form-cc-input', JhaFormCCInput);
/** @customElement jha-form-cc-input */
export default JhaFormCCInput;
