import JhaFormCheckbox from './JhaFormCheckbox.js';
customElements.define('jha-form-checkbox', JhaFormCheckbox);
/** @customElement jha-form-checkbox */
export default JhaFormCheckbox;
