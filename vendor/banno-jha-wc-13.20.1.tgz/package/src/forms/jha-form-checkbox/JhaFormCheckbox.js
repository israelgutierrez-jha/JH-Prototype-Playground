import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
const styles = css `
  :host {
    display: inline-block;
  }
  :host([disabled]) {
    opacity: var(--jha-input-opacity-disabled, 0.7);
    cursor: default;
  }
  label {
    position: relative;
    display: var(--jha-form-checkbox-label-display, flex);
    align-items: var(--jha-form-checkbox-label-align-items, center);
    justify-content: var(--jha-form-checkbox-label-justify-content, flex-start);
    padding: var(--jha-form-checkbox-padding, 3px 0 0);
    margin-bottom: 3px;
    line-height: 18px;
    font-size: var(--jha-form-checkbox-font-size, 13px);
    cursor: pointer;
    color: var(--jha-form-checkbox-text-color, var(--jha-text-base, #8c989f));
  }
  label * {
    pointer-events: none;
  }
  label > input {
    position: relative;
    opacity: 0;
    z-index: 1;
    margin-right: 15px;
    flex-shrink: 0;
  }
  label > input:focus ~ span {
    width: 18px;
    height: 18px;
    outline: 1px dotted #212121;
    outline: 5px auto -webkit-focus-ring-color;
  }
  label > input:disabled {
    visibility: hidden;
  }
  label > input:disabled ~ span {
    cursor: default;
  }
  label > span {
    border-radius: 2px;
    margin-left: -28px;
    margin-right: 12px;
    display: block;
    width: 18px;
    height: 18px;
    line-height: 18px;
    text-align: center;
    border: 1px solid var(--jha-form-checkbox-border-color, var(--jha-color-neutral, #8d99a0));
    background-size: 18px;
    background-position: center center;
    background-repeat: no-repeat;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    z-index: 0;
    box-sizing: border-box;
    flex-shrink: 0;
  }
  label > input:checked ~ span {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSIjRkZGIj48cGF0aCBkPSJNOSAxNi4xN2wtNC4xNy00LjE3LTEuNDIgMS40MSA1LjU5IDUuNTkgMTItMTItMS40MS0xLjQxeiIvPjwvc3ZnPg0K);
    border-color: var(--jha-form-checkbox-checked-border-color, var(--jha-color-primary));
    background-color: var(--jha-form-checkbox-checked-background-color, var(--jha-color-primary));
  }

  label > input:indeterminate ~ span {
    background-image: url(data:image/svg+xml;base64,PHN2ZyBmaWxsPSIjZmZmZmZmIiBzdHJva2U9IiNmZmZmZmYiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgdmlld0JveD0iMCAwIDI0IDI0Ij4gIDxwb2x5Z29uIHBvaW50cz0iNCAxMSA0IDEzIDIwIDEzIDIwIDExIi8+PC9zdmc+);
    background-size: contain;
    border-color: var(--jha-form-checkbox-checked-border-color, var(--jha-color-primary));
    background-color: var(--jha-form-checkbox-checked-background-color, var(--jha-color-primary));
  }

  :host([invite-dialog]) {
    width: 100%;
  }
  .slot-container {
    display: flex;
    gap: var(--jh-dimension-100);
  }
  .helper-text {
    word-break: normal;
    overflow-wrap: anywhere;
    color: var(--jh-input-helper-color-text, var(--jh-color-content-secondary-enabled));
    margin: 0;
    font: var(--jh-font-helper-regular);
  }
`;
/**
 * A JHA Design checkbox element
 * @element jha-form-checkbox
 *
 * @prop {boolean} checked - whether or not the checkbox is checked
 * @prop {boolean} disabled - whether or not the checkbox is disabled
 * @prop {boolean} indeterminate - use indeterminate checkbox state
 * @prop {string} label - used for aria-label
 *
 * @fires change - fired when the checkbox state is changed
 *
 * @slot unnamed slot for custom content wrapped inside the label
 *
 * @cssprop --jha-form-checkbox-checked-border-color - border color when checked
 * @cssprop --jha-form-checkbox-checked-background-color - background color when checked
 * @cssprop --jha-form-checkbox-border-color - border color when not checked
 * @cssprop --jha-form-checkbox-text-color - color for the label
 * @cssprop --jha-form-checkbox-font-size - font size for the label
 * @cssprop --jha-form-checkbox-label-display - display mode for the label
 * @cssprop --jha-form-checkbox-label-align-items - alignment mode
 * @cssprop --jha-form-checkbox-label-justify-content - justify-content mode
 */
export default class JhaFormCheckbox extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            checked: {
                type: Boolean,
            },
            disabled: {
                type: Boolean,
                reflect: true,
            },
            indeterminate: {
                type: Boolean,
            },
            label: {
                type: String,
            },
            name: {
                type: String,
                reflect: true,
            },
            value: {
                type: String,
            },
            helpText: {
                type: String,
            },
        };
    }
    constructor() {
        super();
        this.checked = false;
        this.disabled = false;
        this.indeterminate = false;
        this.label = '';
        this.name = '';
        this.value = 'on'; // default value for checkboxes
        this.helpText = '';
    }
    onInputChanged(event) {
        this.checked = event.target.checked;
        this.value = event.target.value;
        /** @type {import('../../js/utils/types.js').InputCheckedEvent} */
        const checkedEvent = new CustomEvent('change', {
            composed: true,
            bubbles: true,
            detail: {
                checked: this.checked,
                label: this.label,
            },
        });
        this.dispatchEvent(checkedEvent);
    }
    renderHelperText() {
        return html ` <p class="helper-text">${this.helpText}</p> `;
    }
    render() {
        return html `
      <label>
        <input
          aria-label=${this.label}
          type="checkbox"
          ?checked=${this.checked}
          .checked=${this.checked}
          ?disabled=${this.disabled}
          @change=${(event) => this.onInputChanged(event)}
          .indeterminate=${this.indeterminate}
          ?indeterminate=${this.indeterminate}
          .name=${this.name}
          .value=${this.value} />
        <span></span>
        <div class="slot-container">
          <div>
            <slot></slot>
            ${this.helpText ? this.renderHelperText() : ''}
          </div>
          <slot name="input-label-icon"></slot>
        </div>
      </label>
    `;
    }
}
export { styles as jhaListItemStyles };
