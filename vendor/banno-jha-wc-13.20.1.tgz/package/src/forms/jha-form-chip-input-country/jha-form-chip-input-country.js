import JhaFormChipInputCountry from './JhaFormChipInputCountry.js';
customElements.define('jha-form-chip-input-country', JhaFormChipInputCountry);
/** @customElement jha-form-chip-input-country */
export default JhaFormChipInputCountry;
