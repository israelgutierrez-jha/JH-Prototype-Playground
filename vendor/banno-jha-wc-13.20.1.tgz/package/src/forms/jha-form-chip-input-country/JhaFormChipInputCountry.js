import JhaFormChipInput from '../jha-form-chip-input/jha-form-chip-input.js';
import { countriesAsSelectArray } from '../../js/utils/country-abbreviations.js';
/**@element jha-form-chip-input-country */
export default class JhaFormChipInputCountry extends JhaFormChipInput {
    constructor() {
        super();
        const countries = countriesAsSelectArray();
        this.options = countries.map((country) => country.name);
    }
}
