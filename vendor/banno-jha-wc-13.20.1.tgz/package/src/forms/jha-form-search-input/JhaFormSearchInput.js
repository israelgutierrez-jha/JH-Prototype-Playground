import { html, css } from 'lit';
import JhaFormInput from '../jha-form-input-base/JhaFormInput.js';
import { jhaStyles } from '../../styles/jha-styles.js';
import '../../forms/jha-form-floating-group/jha-form-floating-group.js';
const styles = css `
  :host {
    display: block;
  }
  :host([disabled]) {
    opacity: var(--jha-input-opacity-disabled, 0.7);
    cursor: default;
  }
  jha-icon-search {
    position: absolute;
    font-size: 0;
    left: 12px;
    top: var(--jha-search-icon-top, calc(50% + 6px));
    bottom: var(--jha-search-icon-bottom, auto);
    z-index: 4;
    transform: translateY(-50%);
    height: var(--jha-search-box-icon-size, 24px);
    width: var(--jha-search-box-icon-size, 24px);
    fill: var(
      --jha-search-icon-fill,
      var(--jha-color-gray-medium, var(--body-text-secondary-color, var(--jha-text-light)))
    );
  }

  jha-icon-circle-close {
    fill: var(
      --jha-search-icon-fill,
      var(--jha-color-gray-medium, var(--body-text-secondary-color, var(--jha-text-light)))
    );
    height: var(--jha-search-box-icon-size, 24px);
    width: var(--jha-search-box-icon-size, 24px);
  }

  jha-form-floating-group {
    --jha-input-box-sizing: border-box;
  }

  jha-form-floating-group:not([filled]):not([always-float]):not([has-value]):not([has-focus]) {
    --jha-form-floating-group-label-left: 46px;
    --jha-form-floating-group-label-max-width: calc(100% - 48px);
  }

  jha-form-floating-group[has-value] jha-icon-search,
  jha-form-floating-group[has-focus] jha-icon-search,
  jha-form-floating-group[has-value] jha-icon-circle-close,
  jha-form-floating-group[has-focus] jha-icon-circle-close {
    fill: var(
      --jha-search-icon-active-fill,
      var(--jha-color-gray-medium, var(--body-text-secondary-color, var(--jha-text-light)))
    );
  }

  input {
    --jha-input-padding: 18px 48px;
    height: auto;
  }

  :host([small]) {
    --jha-search-box-icon-size: 18px;
  }

  :host([small]) input {
    --jha-input-padding: 10px 36px;
  }

  button#clear {
    position: absolute;
    right: 8px;
    top: var(--jha-slotted-input-top, calc(50% + 6px));
    bottom: var(--jha-search-icon-bottom, auto);
    transform: var(--jha-search-transform, translateY(-50%));
    width: auto;
    padding: 8px;
  }

  :host([small]) button#clear {
    padding-right: 0;
  }
`;
/**
 * @element jha-form-search-input
 *
 * Extends Jha-form-input see: forms/jha-form-input-base/jhaFormInput.js for list of properties
 */
export default class JhaFormSearchInput extends JhaFormInput {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            value_: {
                type: String,
            },
            debounceInterval: {
                type: Number,
            },
            label: {
                type: String,
            },
            placeholder: {
                type: String,
            },
        };
    }
    constructor() {
        super();
        import('../../icons/jha-icon-search.js');
        import('../../icons/jha-icon-circle-close.js');
        this.debounceInterval = 0;
        this.debounceSearch_ = null;
        this.label = '';
        this.placeholder = '';
        this.value_ = '';
    }
    get value() {
        // Input values should always be strings regardless of the input type
        return [null, undefined].includes(this.value_) ? '' : `${this.value_}`;
    }
    set value(newValue) {
        this.value_ = newValue;
        this.onSearchValueChange();
    }
    clear() {
        this.value = '';
    }
    onInput_(event) {
        this.value = event.target.value;
    }
    onSearchValueChange() {
        if (this.debounceSearch_) {
            clearTimeout(this.debounceSearch_);
            this.debounceSearch_ = null;
        }
        this.debounceSearch_ = setTimeout(() => {
            /** @type {import('../../js/utils/types.js').InputChangeEvent} */
            const searchEvent = new CustomEvent('search', {
                bubbles: true,
                composed: true,
                detail: this.value,
            });
            this.dispatchEvent(searchEvent);
        }, this.debounceInterval);
    }
    render() {
        return html `
      <div>
        <jha-form-floating-group
          ?outline=${this.outline}
          ?small=${this.small}
          ?always-float=${this.placeholder}
          .hasValue=${Boolean(this.value)}
          no-label>
          <input
            id=${this.id}
            type="text"
            .value=${this.value}
            aria-label=${this.placeholder}
            @input=${this.onInput_}
            placeholder=${this.placeholder}
            ?disabled=${this.disabled} />
          <jha-icon-search></jha-icon-search>
          <label
            for=${this.id}
            class="label">
            ${this.label}
          </label>
          ${this.value
            ? html `
                <button
                  id="clear"
                  button-reset
                  type="button"
                  @click=${this.clear}>
                  <jha-icon-circle-close aria-label="Cancel"></jha-icon-circle-close>
                </button>
              `
            : ''}
        </jha-form-floating-group>
      </div>
    `;
    }
}
export { styles as JhaFormSearchInputStyles };
