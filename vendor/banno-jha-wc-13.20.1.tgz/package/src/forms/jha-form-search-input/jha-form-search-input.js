import JhaFormSearchInput from './JhaFormSearchInput.js';
customElements.define('jha-form-search-input', JhaFormSearchInput);
/** @customElement jha-form-search-input */
export default JhaFormSearchInput;
