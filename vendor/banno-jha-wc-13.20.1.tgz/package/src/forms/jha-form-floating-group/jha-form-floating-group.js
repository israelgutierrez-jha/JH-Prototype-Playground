import JhaFormFloatingGroup from './JhaFormFloatingGroup.js';
customElements.define('jha-form-floating-group', JhaFormFloatingGroup);
/** @customElement jha-form-floating-group */
export default JhaFormFloatingGroup;
