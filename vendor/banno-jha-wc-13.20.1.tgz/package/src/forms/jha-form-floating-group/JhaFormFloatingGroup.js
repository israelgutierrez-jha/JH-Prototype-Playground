// @ts-nocheck
import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
let id = 0;
const styles = css `
  :host {
    display: block;
    position: relative;
    padding-top: var(--jha-form-floating-group-padding-top, 12px);
    margin-bottom: var(--jha-input-margin-bottom, 16px);
    line-height: var(--jha-form-floating-group-input-line-height, inherit);
  }
  slot#main-slot {
    display: var(--jha-input-content-display, block);
    flex-direction: var(--jha-input-content-flex-direction, unset);
    position: var(--jha-input-content-position, static);
  }
  .input-content {
    position: var(--jha-input-content-position, static);
  }
  :host ::slotted(input),
  :host ::slotted(.input),
  :host ::slotted(textarea),
  :host ::slotted(select) {
    font-family: inherit;
    margin: var(--jha-input-margin, 0);
    display: block;
    width: 100%;
    height: var(--jha-input-height, 40px);
    padding: var(--jha-input-padding, 6px 0 3px);
    border: 0;
    font-size: var(--jha-input-font-size, 14px);
    font-weight: var(--jha-input-font-weight, 400);
    border-radius: var(--jha-input-border-radius, 0);
    color: var(--jha-text-dark);
    border-top: var(--jha-input-border, none);
    border-right: var(--jha-input-border, none);
    border-left: var(--jha-input-border, none);
    border-bottom: var(--jha-input-border, 1px solid var(--jha-border-color, #e4e7ea));
    -webkit-transition: border-bottom 0.2s cubic-bezier(0.1, 0.5, 0.1, 1);
    transition: border-bottom 0.2s cubic-bezier(0.1, 0.5, 0.1, 1);
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    box-sizing: border-box;
    line-height: var(--jha-form-floating-group-input-line-height, inherit);
    background-color: var(--jha-input-background, var(--jha-component-background-color, #fff));
  }

  :host ::slotted(input:not([disabled]):hover),
  :host ::slotted(.input:not([disabled]):hover),
  :host ::slotted(textarea:not([disabled]):hover),
  :host ::slotted(select:not([disabled]):hover),
  :host ::slotted(input:not([disabled]):active),
  :host ::slotted(.input:not([disabled]):active),
  :host ::slotted(textarea:not([disabled]):active),
  :host ::slotted(select:not([disabled]):active),
  :host ::slotted(input:not([disabled]):focus),
  :host ::slotted(.input:not([disabled]):focus),
  :host ::slotted(textarea:not([disabled]):focus),
  :host ::slotted(select:not([disabled]):focus),
  :host([outline]) ::slotted(input:not([disabled]):hover),
  :host([outline]) ::slotted(.input:not([disabled]):hover),
  :host([outline]) ::slotted(textarea:not([disabled]):hover),
  :host([outline]) ::slotted(select:not([disabled]):hover) {
    border-color: var(--jha-input-hover-color, inherit);
  }

  :host(:not([error])) ::slotted(input:focus),
  :host(:not([error])) ::slotted(.input[focus]),
  :host(:not([error])) ::slotted(textarea:focus),
  :host(:not([error])) ::slotted(select:focus),
  :host([outline]:not([error])) ::slotted(input:focus),
  :host([outline]:not([error])) ::slotted(.input:focus),
  :host([outline]:not([error])) ::slotted(textarea:focus),
  :host([outline]:not([error])) ::slotted(select:focus) {
    box-shadow: var(--jha-input-focus-shadow, none);
  }

  :host ::slotted(select) {
    padding: var(--jha-input-padding, 6px 32px 3px 0);
  }

  :host ::slotted(*[slot='input-right']),
  :host ::slotted(*[slot='input-left']) {
    font-size: 18px;
    color: var(--jha-text-light, #8c989f);
    position: absolute;
    top: var(--jha-slotted-input-top, 20px);
    bottom: var(--jha-slotted-input-bottom, auto);
    left: var(--jha-slotted-icon-left-position, 0);
    z-index: 1;
    --jha-icon-fill-color: var(--jha-text-light, #8c989f);
  }
  :host ::slotted(*[slot='input-right']) {
    right: var(--jha-slotted-icon-right-position, 0);
    left: auto;
  }
  :host([filled]) ::slotted(*[slot='input-right']),
  :host([outline]) ::slotted(*[slot='input-right']) {
    right: var(--jha-slotted-icon-right-position, 12px);
  }
  :host([filled]) ::slotted(*[slot='input-left']),
  :host([outline]) ::slotted(*[slot='input-left']) {
    left: var(--jha-slotted-icon-left-position, 12px);
  }

  :host([outline]:not([small])) ::slotted(*[slot='input-right']),
  :host([outline]:not([small])) ::slotted(*[slot='input-left']) {
    top: var(--jha-slotted-input-top, 28px);
  }

  :host([outline][small]) ::slotted(*[slot='input-right']),
  :host([outline][small]) ::slotted(*[slot='input-left']) {
    top: var(--jha-slotted-input-top, 20px);
    bottom: var(--jha-slotted-input-small-bottom, var(--jha-slotted-input-bottom, auto));
  }

  :host([filled]) ::slotted(*[slot='input-right']),
  :host([filled]) ::slotted(*[slot='input-left']) {
    top: var(--jha-slotted-input-top, 32px);
  }

  /* CSS to prevent zooming on iOS when input is focused */
  @supports (-webkit-overflow-scrolling: touch) {
    :host ::slotted(input),
    :host ::slotted(.input),
    :host ::slotted(textarea),
    :host ::slotted(select) {
      font-size: var(--jha-input-font-size, 16px);
    }
  }
  :host ::slotted(textarea) {
    min-height: 38px;
    overflow: hidden;
    resize: none;
    height: auto;
    padding-top: 12px;
  }
  :host ::slotted(input:focus),
  :host ::slotted(.input:focus),
  :host ::slotted(textarea:focus) {
    outline: 0;
    border-bottom-color: var(--jha-form-floating-group-input-border-color, --jha-text-theme, #3aaeda);
  }
  :host ::slotted(input:-moz-ui-invalid) {
    box-shadow: none;
  }
  :host ::slotted(.input[disabled]),
  :host ::slotted(select[disabled]),
  :host ::slotted(input[disabled]),
  :host ::slotted(textarea[disabled]),
  :host ::slotted(input.is-disabled) {
    color: var(--jha-form-floating-group-input-disabled-text-color, var(--jha-text-light));
  }

  :host ::slotted(.label-container),
  :host ::slotted(.label) {
    position: var(--jha-input-label-position, absolute);
    font-size: var(--jha-input-label-font-size, 14px);
    line-height: var(--jha-form-floating-group-input-line-height, inherit);
    color: var(--jha-input-label-color, var(--jha-text-light, #8c989f));
    font-weight: 400;
    left: var(--jha-input-slotted-label-offset-left, var(--jha-form-floating-group-label-left, 0));
    top: var(--jha-form-floating-group-label-top, 23px);
    -webkit-transition: all 0.2s cubic-bezier(0.1, 0.5, 0.1, 1);
    transition: all 0.2s cubic-bezier(0.1, 0.5, 0.1, 1);
    background-color: var(--jha-input-label-background, var(--jha-component-background-color, #fff));
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    z-index: 1;
    width: 100%;
    box-sizing: border-box;
  }
  :host ::slotted(.label-container) {
    pointer-events: var(--jha-input-label-pointer-events, auto);
  }
  :host([always-float]) ::slotted(.label),
  :host([has-value]) ::slotted(.label),
  :host([has-focus]) ::slotted(.label),
  :host([always-float]) ::slotted(.label-container),
  :host([has-value]) ::slotted(.label-container),
  :host([has-focus]) ::slotted(.label-container) {
    font-size: var(--jha-input-label-font-size, 12px);
    top: var(--jha-form-floating-group-label-top, 5px);
    left: var(--jha-form-floating-group-label-left, 0);
    width: auto !important;
  }
  :host([has-focus]) ::slotted(.label) {
    color: var(--jha-input-focused-label-color, var(--jha-text-theme, #3aaeda));
  }
  :host([error]) ::slotted(input),
  :host([error]) ::slotted(.input),
  :host([error]) ::slotted(select) {
    /* background-color: var(--color-danger); */
    border-color: var(--jha-form-floating-group-error, var(--jha-color-danger, #f44336));
  }
  :host([error][outline]) ::slotted(.label),
  :host([error]) ::slotted(.label) {
    color: var(--jha-input-label-error-color, var(--jha-form-floating-group-error, var(--jha-color-danger, #f44336)));
  }
  .error,
  .assistive {
    font-size: 12px;
    margin: var(--error-text-top-margin, 10px) var(--error-text-right-margin, 0) var(--error-text-bottom-margin, 0)
      var(--error-text-left-margin, 0);
    text-align: var(--error-text-align, left);
    position: var(--jha-input-error-position, static);
  }
  :host([error]) .error {
    color: var(--jha-form-floating-group-error, var(--jha-color-danger, #f44336));
  }
  :host([indent-error]) .error,
  :host([indent-error]) .assistive {
    margin-left: 10px;
  }
  :host([filled]:not([outline])) ::slotted(input),
  :host([filled]:not([outline])) ::slotted(.input),
  :host([filled]:not([outline])) ::slotted(textarea),
  :host([filled]:not([outline])) ::slotted(select) {
    height: 50px;
    background: var(--jha-color-light, var(--secondary-content-background-color));
    border-bottom: 1px solid var(--jha-border-color, #e4e7ea);
    font-size: var(--jha-input-font-size, 14px);
    padding: var(--jha-input-padding, 12px 8px 0);
  }
  :host([filled]:not([outline])) ::slotted(textarea) {
    min-height: 48px;
    height: auto;
    padding: var(--jha-input-padding, 24px 12px 8px);
  }
  :host([filled]:not([outline])) ::slotted(.label) {
    font-size: var(--jha-input-label-font-size, 14px);
    top: var(--jha-form-floating-group-label-top, 33px);
    left: var(--jha-input-slotted-label-offset-left, var(--jha-form-floating-group-label-left, 8px));
    max-width: calc(100% - 24px);
    background: var(--secondary-content-background-color);
    color: var(--jha-text-light, #8c989f);
    background: var(--secondary-content-background-color);
  }
  :host([filled][always-float]:not([outline])) ::slotted(.label),
  :host([filled][has-value]:not([outline])) ::slotted(.label),
  :host([filled][has-focus]:not([outline])) ::slotted(.label),
  :host([filled][always-float]:not([outline])) ::slotted(.label-container),
  :host([filled][has-value]:not([outline])) ::slotted(.label-container),
  :host([filled][has-focus]:not([outline])) ::slotted(.label-container) {
    font-size: var(--jha-input-label-font-size, 10px);
    top: var(--jha-form-floating-group-label-top, 20px);
    left: var(--jha-form-floating-group-label-left, 12px);
  }
  :host([filled][has-focus]:not([outline])) ::slotted(.label) {
    color: var(--jha-text-theme, #3aaeda);
  }
  .underline {
    display: none;
  }
  :host([filled]:not([outline])) .underline {
    transform: scaleX(0);
    transition: transform 0.2s cubic-bezier(0.1, 0.5, 0.1, 1);
    display: block;
    margin-top: -2px;
    width: 100%;
    height: 2px;
    background: var(--jha-text-theme, #3aaeda);
  }
  :host([filled][error]:not([outline])) ::slotted(.label) {
    color: var(--jha-form-floating-group-error, var(--jha-color-danger, #f44336));
  }
  :host([error]) .underline {
    background: var(--jha-form-floating-group-error, var(--jha-color-danger, #f44336));
  }
  :host([filled][has-focus]:not([outline])) .underline {
    transform: scaleX(1);
  }
  :host([filled][no-label]:not([outline])) {
    padding-top: 0;
    margin-bottom: 0;
  }

  :host([filled][no-label]:not([outline])) ::slotted(input) {
    height: 42px;
    font-size: var(--jha-input-font-size, 16px);
    padding: var(--jha-input-padding, 10px 17px 10px);
  }
  :host([filled][no-label]:not([outline])) ::slotted(textarea) {
    min-height: 42px;
    height: 42px;
    padding: var(--jha-input-padding, 14px 17px 10px);
  }
  :host([outline]) {
    padding-left: 1px;
    padding-right: 1px;
    box-sizing: border-box;
    line-height: var(--jha-form-floating-group-input-line-height, 18px);
  }
  :host([outline]) ::slotted(input),
  :host([outline]) ::slotted(.input),
  :host([outline]) ::slotted(textarea),
  :host([outline]) ::slotted(select),
  :host([outline]) ::slotted(jha-form-select) {
    --jha-input-box-sizing: border-box;
    font-size: var(--jha-input-font-size, 16px);
    line-height: var(--jha-form-floating-group-input-line-height, 18px);
    height: var(--jha-input-height, auto);
    border: var(
      --jha-input-border,
      1px solid var(--jha-form-floating-group-outline-border-color, var(--jha-border-color, #8c989f))
    );
    border-radius: var(--jha-input-border-radius, 4px);
    padding: var(--jha-input-padding, 18px 12px);
    transition: var(--jha-input-outline-transition, all 0.2s ease);
  }
  :host([outline]) ::slotted(textarea) {
    padding: var(--jha-input-textarea-padding, 10px);
  }
  :host([outline]) ::slotted(select) {
    padding: var(--jha-input-padding, 18px 32px 18px 12px);
  }
  :host([outline][has-focus]) ::slotted(input),
  :host([outline][has-focus]) ::slotted(.input),
  :host([outline][has-focus]) ::slotted(textarea),
  :host([outline][has-focus]) ::slotted(select),
  :host([outline][has-focus]) ::slotted(jha-form-select) {
    border-color: var(--jha-input-hover-color, var(--jha-text-theme, #3aaeda));
    box-shadow: 0 0 0 1px var(--jha-form-floating-group-input-box-shadow, var(--jha-text-theme, #3aaeda));
  }
  :host([outline]) ::slotted(.label),
  :host([outline]) ::slotted(.label-container) {
    border-radius: 3px;
    font-size: var(--jha-input-label-font-size, 16px);
    font-weight: 400;
    padding: var(--jha-input-label-padding, 3px 4px);
    transform-origin: 0 center;
    left: var(--jha-input-slotted-label-offset-left, var(--jha-form-floating-group-label-left, 10px));
    top: var(--jha-form-floating-group-label-top, 28px);
    width: var(--jha-form-floating-group-label-max-width, calc(100% - 16px));
  }

  :host([outline][has-focus]) ::slotted(.label) {
    color: var(--jha-input-focused-label-color, var(--jha-text-theme, #3aaeda));
  }

  :host([outline][error][has-focus]) ::slotted(.label) {
    color: var(--jha-input-label-error-color, var(--jha-form-floating-group-error, var(--jha-color-danger, #f44336)));
  }

  :host([outline][always-float]) ::slotted(.label),
  :host([outline][has-focus]) ::slotted(.label),
  :host([outline][has-value]) ::slotted(.label),
  :host([outline][always-float]) ::slotted(.label-container),
  :host([outline][has-focus]) ::slotted(.label-container),
  :host([outline][has-value]) ::slotted(.label-container) {
    transform: var(--jha-input-label-transform, translateY(-25px) scale(0.75));
    left: var(--jha-form-floating-group-label-left, 8px);
  }

  :host([outline][error]) ::slotted(select),
  :host([outline][error]) ::slotted(jha-form-select),
  :host([outline][error]) ::slotted(textarea),
  :host([outline][error]) ::slotted(input),
  :host([outline][error]) ::slotted(.input) {
    border-color: var(--jha-color-danger, #f44336);
  }
  :host([outline][has-focus][error]) ::slotted(jha-form-select),
  :host([outline][has-focus][error]) ::slotted(select),
  :host([outline][has-focus][error]) ::slotted(textarea),
  :host([outline][has-focus][error]) ::slotted(input),
  :host([outline][has-focus][error]) ::slotted(.input) {
    box-shadow: 0 0 0 1px var(--jha-color-danger, #f44336);
  }

  :host([small]) ::slotted(select),
  :host([small]) ::slotted(textarea),
  :host([small]) ::slotted(input),
  :host([small]) ::slotted(.input) {
    height: var(--jha-input-height-small, var(--jha-input-height, 40px));
  }

  :host([outline][small]) ::slotted(select),
  :host([outline][small]) ::slotted(jha-form-select) {
    padding: var(--jha-input-padding, 2px);
  }
  :host([outline][small]) ::slotted(textarea),
  :host([outline][small]) ::slotted(input),
  :host([outline][small]) ::slotted(.input) {
    padding: var(--jha-input-padding, 10px 10px);
  }
  :host([outline][small]) ::slotted(.label),
  :host([outline][small]) ::slotted(.label-container) {
    top: var(--jha-form-floating-group-label-top, 20px);
  }
  :host([outline][small][always-float]) ::slotted(.label),
  :host([outline][small][has-focus]) ::slotted(.label),
  :host([outline][small][has-value]) ::slotted(.label),
  :host([outline][small][always-float]) ::slotted(.label-container),
  :host([outline][small][has-focus]) ::slotted(.label-container),
  :host([outline][small][has-value]) ::slotted(.label-container) {
    top: var(--jha-form-floating-group-label-top, 3px);
    transform: var(--jha-input-label-transform, translateY(-19px) scale(0.75));
  }

  :host ::slotted(.input-mask) {
    pointer-events: none;
    line-height: var(--jha-form-floating-group-input-line-height, inherit);
    color: var(--jha-text-neutral, #8d99a0);
    padding: var(--jha-input-padding, 6px 0 3px);
    font-size: var(--jha-input-font-size, 14px);
    position: absolute;
    top: var(--jha-input-mask-top, 18px);
    bottom: var(--jha-input-mask-bottom, auto);
    box-sizing: border-box;
  }
  :host([outline]) ::slotted(.input-mask) {
    line-height: var(--jha-form-floating-group-input-line-height, 18px);
    font-size: var(--jha-input-font-size, 16px);
    padding: var(--jha-input-padding, 18px 12px);
    height: auto;
    left: var(--jha-input-mask-left, 2px);
    top: var(--jha-input-mask-top, 13px);
  }
  :host([outline][small]) ::slotted(.input-mask) {
    bottom: var(--jha-input-small-mask-bottom, var(--jha-input-mask-bottom, auto));
    padding: var(--jha-input-padding, 10px 10px);
  }
  :host([filled]) ::slotted(.input-mask) {
    padding: var(--jha-input-padding, 12px 8px 0);
    top: var(--jha-input-mask-top, 21px);
  }

  :host([input-symbol-left]) ::slotted(jha-form-select),
  :host([input-symbol-left]) ::slotted(select),
  :host([input-symbol-left]) ::slotted(textarea),
  :host([input-symbol-left]) ::slotted(input),
  :host([input-symbol-left]) ::slotted(.input),
  :host([input-symbol-left]) ::slotted(.input-mask) {
    padding-left: calc(var(--jha-input-symbol-left-width) + var(--jha-slotted-icon-left-position, 8px));
  }
  :host([input-symbol-left]) {
    --jha-input-slotted-label-offset-left: calc(var(--jha-input-symbol-left-width) + 8px);
  }

  :host([input-symbol-left][filled]) ::slotted(jha-form-select),
  :host([input-symbol-left][filled]) ::slotted(select),
  :host([input-symbol-left][filled]) ::slotted(textarea),
  :host([input-symbol-left][filled]) ::slotted(input),
  :host([input-symbol-left][filled]) ::slotted(.input),
  :host([input-symbol-left][filled]) ::slotted(.input-mask),
  :host([input-symbol-left][outline]) ::slotted(jha-form-select),
  :host([input-symbol-left][outline]) ::slotted(select),
  :host([input-symbol-left][outline]) ::slotted(textarea),
  :host([input-symbol-left][outline]) ::slotted(input),
  :host([input-symbol-left][outline]) ::slotted(.input),
  :host([input-symbol-left][outline]) ::slotted(.input-mask) {
    padding-left: calc(var(--jha-input-symbol-left-width) + 16px);
  }

  :host([input-symbol-left]) ::slotted(.label) {
    --jha-input-slotted-label-offset-left: calc(var(--jha-input-symbol-left-width) + 8px);
    max-width: calc(100% - var(--jha-input-slotted-label-offset-left) - 8px);
  }

  :host([input-symbol-left][filled]) ::slotted(.label) {
    --jha-input-slotted-label-offset-left: calc(var(--jha-input-symbol-left-width) + 16px);
    max-width: calc(100% - var(--jha-input-slotted-label-offset-left) - 16px);
  }

  :host([input-symbol-right]) ::slotted(.label) {
    max-width: calc(100% - var(--jha-input-symbol-right-width) - 16px);
  }
  :host([input-symbol-right][outline]) ::slotted(.label),
  :host([input-symbol-right][filled]) ::slotted(.label) {
    max-width: calc(100% - var(--jha-input-symbol-right-width) - 24px);
  }
  :host([input-symbol-left][input-symbol-right]) ::slotted(.label) {
    --jha-input-slotted-label-offset-left: calc(var(--jha-input-symbol-left-width) + 16px);
    max-width: calc(100% - var(--jha-input-slotted-label-offset-left) - var(--jha-input-symbol-right-width) - 16px);
  }

  :host([input-symbol-left][input-symbol-right][filled]) ::slotted(.label),
  :host([input-symbol-left][input-symbol-right][outline]) ::slotted(.label) {
    --jha-input-slotted-label-offset-left: calc(var(--jha-input-symbol-left-width) + 16px);
    max-width: calc(100% - var(--jha-input-slotted-label-offset-left) - var(--jha-input-symbol-right-width) - 16px);
  }

  :host([input-symbol-left][outline]) ::slotted(.label) {
    --jha-input-slotted-label-offset-left: calc(var(--jha-input-symbol-left-width) + 14px);
    max-width: calc(100% - var(--jha-input-slotted-label-offset-left) - 14px);
  }

  :host([input-symbol-right]) ::slotted(jha-form-select),
  :host([input-symbol-right]) ::slotted(select),
  :host([input-symbol-right]) ::slotted(textarea),
  :host([input-symbol-right]) ::slotted(input),
  :host([input-symbol-right]) ::slotted(.input) {
    padding-right: calc(var(--jha-input-symbol-right-width) + 8px);
  }

  :host([input-symbol-right][filled]) ::slotted(jha-form-select),
  :host([input-symbol-right][filled]) ::slotted(select),
  :host([input-symbol-right][filled]) ::slotted(textarea),
  :host([input-symbol-right][filled]) ::slotted(input),
  :host([input-symbol-right][filled]) ::slotted(.input),
  :host([input-symbol-right][outline]) ::slotted(jha-form-select),
  :host([input-symbol-right][outline]) ::slotted(select),
  :host([input-symbol-right][outline]) ::slotted(textarea),
  :host([input-symbol-right][outline]) ::slotted(input),
  :host([input-symbol-right][outline]) ::slotted(.input) {
    padding-right: calc(var(--jha-input-symbol-right-width) + 16px);
  }

  :host ::slotted(input:-webkit-autofill),
  :host ::slotted(input:-webkit-autofill:hover),
  :host ::slotted(input:-webkit-autofill:focus) {
    -webkit-text-fill-color: #31b0dd;
    -webkit-box-shadow: 0 0 0px 40rem var(--jha-component-background-color, #fff) inset;
  }

  /* Edge specific styles */
  @supports (-ms-ime-align: auto) {
    :host ::slotted(.label) {
      top: var(--jha-form-floating-group-label-top, 18px);
    }
    :host([always-float]) ::slotted(.label),
    :host([has-value]) ::slotted(.label),
    :host([has-focus]) ::slotted(.label) {
      top: var(--jha-form-floating-group-label-top, 0);
    }
    :host([outline][always-float]) ::slotted(.label),
    :host([outline][has-focus]) ::slotted(.label),
    :host([outline][has-value]) ::slotted(.label) {
      top: var(--jha-form-floating-group-label-top, 25px);
    }
  }
  /* IE 11 specific styles */
  @media all and (-ms-high-contrast: none) {
    :host ::slotted(.label) {
      top: var(--jha-form-floating-group-label-top, 18px);
    }
    :host([always-float]) ::slotted(.label),
    :host([has-value]) ::slotted(.label),
    :host([has-focus]) ::slotted(.label) {
      top: var(--jha-form-floating-group-label-top, 0);
    }
    :host([outline][always-float]) ::slotted(.label),
    :host([outline][has-focus]) ::slotted(.label),
    :host([outline][has-value]) ::slotted(.label) {
      top: var(--jha-form-floating-group-label-top, 25px);
    }
  }
`;
/**
 * JHA Design form floating group
 *
 * @element jha-form-floating-group
 *
 * @prop {string} error
 * @prop {boolean} hasValue
 * @prop {boolean} hasFocus
 * @prop {boolean} enableDefaultValidation
 *
 * @cssprop --jha-color-primary - The theme's primary color
 */
export default class JhaFormFloatingGroup extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            error: {
                type: String,
                reflect: true,
            },
            assistiveText: {
                type: String,
            },
            hasValue: {
                type: Boolean,
                reflect: true,
                attribute: 'has-value',
            },
            persistValue: {
                type: Boolean,
                reflect: true,
                attribute: 'persist-value',
            },
            hasFocus: {
                type: Boolean,
                reflect: true,
                attribute: 'has-focus',
            },
            enableDefaultValidation: {
                type: Boolean,
            },
            inputSymbolLeft: {
                type: Boolean,
                reflect: true,
                attribute: 'input-symbol-left',
            },
            inputSymbolRight: {
                type: Boolean,
                reflect: true,
                attribute: 'input-symbol-right',
            },
            _hasAssistiveTextSlot: {
                type: Boolean,
                state: true,
            },
        };
    }
    constructor() {
        super();
        this.boundInputFocus = this.onInputFocus.bind(this);
        this.boundInputBlur = this.onInputBlur.bind(this);
        this.boundOnInput = this.onInput.bind(this);
        this.boundInputInvalid = this.onInputInvalid.bind(this);
        this.inputs_ = [];
        this.label = null;
        this.enableDefaultValidation = false;
        this.error = null;
        this.assistiveText = null;
        this.inputSymbolLeft = false;
        this.inputSymbolRight = false;
        this.hasValue = false;
        this.persistValue = false;
        this._hasAssistiveTextSlot = false;
        this._id = id++;
    }
    get errorId() {
        return this.error && `input-${this._id}-error-text`;
    }
    get assistiveId() {
        return this.assistiveText && `input-${this._id}-help-text`;
    }
    get _slottedAssistiveTextContent() {
        const slot = /** @type {HTMLSlotElement | undefined} */ this.shadowRoot.querySelector('slot[name=assistive-text]');
        return slot?.assignedElements({ flatten: true });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        this.inputs_.forEach((elem) => {
            elem.removeEventListener('focus', this.boundInputFocus, true);
            elem.removeEventListener('blur', this.boundInputBlur, true);
            elem.removeEventListener('input', this.boundOnInput);
            if (!this.enableDefaultValidation) {
                elem.removeEventListener('invalid', this.boundInputInvalid);
            }
        });
    }
    firstUpdated() {
        this.label = this.querySelector('label');
        this.inputs_ = Array.from(this.querySelectorAll('input, textarea, select, jha-form-select'));
        // we *should* only ever have one input,
        // but if not, we consider all of them.
        this.inputs_.forEach((elem) => {
            elem.addEventListener('focus', this.boundInputFocus, true);
            elem.addEventListener('blur', this.boundInputBlur, true);
            // This event isn't triggered when the input's value
            // is changed programmatically. Any code that changes the value
            // should also dispatch the event.
            elem.addEventListener('input', this.boundOnInput);
            if (!this.enableDefaultValidation) {
                elem.addEventListener('invalid', this.boundInputInvalid);
            }
            const currentLabel = elem.getAttribute('aria-label');
            if (this.label && this.label.innerText && !currentLabel) {
                // sets an aria-label on the input, if there is not one already
                elem.setAttribute('aria-label', this.label.innerText);
            }
            window.requestAnimationFrame(() => {
                const value = Boolean(elem.value && elem.value.trim().length > 0);
                this.hasValue = value || this.persistValue;
            });
            //  Check to see if there is a value in an attempt to reduce the dispatching of an event when there isn't any
            //  value associated to the input.
            if (this.hasValue) {
                // trigger an event in case input already has a value
                const event = new Event('Event', { composed: true, bubbles: true });
                elem.dispatchEvent(event);
            }
        });
    }
    updated(changedProperties) {
        if (changedProperties.has('error') || changedProperties.has('assistiveText')) {
            this.updateDescribedBy();
        }
    }
    updateDescribedBy() {
        this.inputs_.forEach((elem) => {
            if (this.error || this.assistiveText) {
                elem.setAttribute('aria-describedby', [this.errorId, this.assistiveId].join(' '));
                if (this.error) {
                    elem.setAttribute('aria-invalid', 'true');
                }
                else {
                    elem.removeAttribute('aria-invalid');
                }
            }
            else {
                elem.removeAttribute('aria-describedby');
            }
        });
    }
    onInputFocus() {
        this.hasFocus = true;
    }
    onInputBlur() {
        this.hasFocus = false;
    }
    /**@param {InputEvent=} evt */
    onInput(evt) {
        const el = /** @type {HTMLFormElement} */ (evt.currentTarget);
        if (el.nodeName === 'TEXTAREA') {
            el.style.height = '5px';
            el.style.height = `${el.scrollHeight}px`;
        }
    }
    /**@param {Event=} evt */
    onInputInvalid(evt) {
        evt.preventDefault();
        evt.stopPropagation();
    }
    handleSlotSymbols(evt) {
        const side = evt.target.name;
        const symbol = (evt.target.assignedElements({ flatten: true }) || [])[0];
        if (side === 'input-left') {
            this.inputSymbolLeft = Boolean(symbol);
        }
        else {
            this.inputSymbolRight = Boolean(symbol);
        }
    }
    async _handleAssistiveTextSlotChange() {
        await this.updateComplete;
        this._hasAssistiveTextSlot = this._slottedAssistiveTextContent?.length > 0;
    }
    renderErrorOrAssistiveText() {
        if (this.error) {
            return html `
        <p
          id="input-${this._id}-error-text"
          aria-live="polite"
          class="error">
          ${this.error}
        </p>
      `;
        }
        if (this.assistiveText) {
            return html `
        <p
          id="input-${this._id}-help-text"
          aria-live="polite"
          class="assistive">
          ${this.assistiveText}
        </p>
      `;
        }
        return '';
    }
    render() {
        return html `
      <div class="input-content">
        <slot
          name="input-left"
          @slotchange=${this.handleSlotSymbols}></slot>
        <slot id="main-slot"></slot>
        <slot
          name="input-right"
          @slotchange=${this.handleSlotSymbols}></slot>
      </div>
      <div class="underline"></div>
      ${!this.error
            ? html `<slot
            name="assistive-text"
            @slotchange=${this._handleAssistiveTextSlotChange}></slot>`
            : ''}
      ${!this._hasAssistiveTextSlot ? this.renderErrorOrAssistiveText() : ''}
    `;
    }
}
export { styles as jhaFormFloatingGroupStyles };
