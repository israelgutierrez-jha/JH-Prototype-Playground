import JhaFormZipInput from './JhaFormZipInput.js';
customElements.define('jha-form-zip-input', JhaFormZipInput);
/** @customElement jha-form-zip-input */
export default JhaFormZipInput;
