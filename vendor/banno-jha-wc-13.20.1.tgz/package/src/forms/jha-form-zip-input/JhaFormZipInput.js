import JhaFormInput from '../jha-form-input-base/JhaFormInput.js';
/**
 * @element jha-form-zip-input
 *
 * Extends Jha-form-input see: forms/jha-form-input-base/jhaFormInput.js for list of properties
 */
export default class JhaFormZipInput extends JhaFormInput {
    constructor() {
        super();
        this.label = 'Zip code';
        this.warning = 'Please provide a valid zip.';
        this.maxlength = 10;
        this.pattern = '(^[0-9]{5}$)|(^[0-9]{5}-[0-9]{4}$)|(^[0-9]{9}$)';
        this.allowedCharacters = '[0-9-]+';
    }
    formatValue(value) {
        const regex = /[0-9]{9}/;
        if (regex.test(value)) {
            this.value_ = `${value.slice(0, 5)}-${value.slice(5, 9)}`;
        }
    }
}
