import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
const styles = css `
  :host {
    display: inline-block;
    --jha-form-switch-label-margin: 16px;
  }
  :host([disabled]) {
    opacity: var(--jha-input-opacity-disabled, 0.7);
    cursor: default;
  }
  label {
    position: relative;
    display: inline-block;
    margin: 0;
    margin-left: -4px;
    padding: 4px;
    cursor: pointer;
  }
  input {
    opacity: 0;
    width: 0;
    height: 0;
  }
  span {
    display: inline-block;
    position: relative;
    outline: none;
    user-select: none;
    pointer-events: none;
    vertical-align: middle;
    width: 58px;
    height: 26px;
    border-radius: 13px;
    padding: 1px;
    transition: background-color 0.3s cubic-bezier(0.1, 0.5, 0.1, 1);
    box-sizing: border-box;
  }
  span::before,
  span::after {
    content: '';
    position: absolute;
    box-sizing: border-box;
  }
  span::before {
    top: 1px;
    bottom: 1px;
    left: 1px;
    right: 1px;
    background-color: var(--jha-form-switch-inactive-color, rgba(128, 139, 150, 0.5));
    border-radius: 13px;
    transition: background-color 0.3s cubic-bezier(0.1, 0.5, 0.1, 1);
    border: var(--jh-form-switch-border, none);
  }
  span::after {
    top: 4px;
    bottom: 0;
    left: 5px;
    width: 18px;
    height: 18px;
    background-color: var(--jha-form-switch-button-color, var(--jha-background-color, #ffffff));
    border: none;
    border-radius: 100%;
    box-shadow: var(--jha-switch-shadow-focus, 0 1px 1px 0px rgba(0, 0, 0, 0.2));
    transition: all 0.3s cubic-bezier(0.1, 0.5, 0.1, 1);
  }
  :host([disabled]) label {
    cursor: default;
  }
  input[checked] + span::before {
    background-color: var(--jha-form-switch-active-color, var(--jha-color-success, #4caf50));
  }
  input[checked] + span::after {
    transform: translateX(30px);
  }
  :host([checked][disabled]) span::before {
    opacity: 0.4;
    background-color: var(--jha-form-switch-active-color, var(--jha-color-success, #4caf50));
  }
  input:focus + span::after {
    box-shadow: var(--jha-switch-shadow-focus, 0 0 0px 10px rgb(128, 139, 150, 0.4));
  }
  input[checked]:focus + span::after {
    box-shadow: var(--jha-switch-shadow-focus, 0 0 0px 10px rgba(98, 161, 46, 0.4));
  }
  :host([is-loading]) span::before {
    opacity: 0.5;
  }
  ::slotted([slot='left-label']) {
    margin-right: var(--jha-form-switch-label-margin);
  }
  ::slotted([slot='right-label']) {
    margin-left: var(--jha-form-switch-label-margin);
  }
  label {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .slot-container {
    display: flex;
    gap: var(--jh-dimension-100);
  }
`;
/**
 * A JHA Design Switch input for toggling something on/off
 *
 * @prop {boolean} async - whether the switch is used to initiate an async process. If enabled, the component will not manage it's own `checked` property.
 * @prop {boolean} checked - whether the switch is on or off.
 * @prop {boolean} disabled - Disables the input
 * @prop {string} label - Aria Label for the switch
 *
 * @slot left-label slot, Use to insert label to the left of switch
 * @slot right-label slot, Use to insert label to the right of switch
 *
 * @cssprop --jha-form-switch-active-color - Active toggle track color
 * @cssprop --jha-form-switch-inactive-color - Inactive toggle track color
 * @cssprop --jha-form-switch-button-color - Background color of the button
 * @cssprop --jha-form-switch-label-margin - margin between switch and slotted label content
 *
 * @element jha-form-switch */
export default class JhaFormSwitch extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            checked: {
                type: Boolean,
                reflect: true,
                hasChanged: () => true,
            },
            isLoading: {
                type: Boolean,
                reflect: true,
            },
            disabled: {
                type: Boolean,
                reflect: true,
            },
            label: {
                type: String,
            },
            helpText: {
                type: String,
            },
            async: {
                type: Boolean,
            },
        };
    }
    constructor() {
        super();
        this.checked = false;
        this.disabled = false;
        this.isLoading = false;
        this.label = '';
        this.async = false;
    }
    onInputChanged_(event) {
        if (!this.async) {
            this.checked = event.target.checked;
        }
        /** @type {import('../../js/utils/types.js').InputCheckedEvent} */
        const checkedEvent = new CustomEvent('change', {
            composed: true,
            bubbles: true,
            detail: {
                checked: event.target.checked,
                label: this.label,
            },
        });
        this.dispatchEvent(checkedEvent);
    }
    render() {
        return html `
      <label>
        <div class="slot-container">
          <slot name="left-input-label-icon"></slot>
          <slot name="left-label"> </slot>
        </div>
        <input
          aria-label=${this.label}
          type="checkbox"
          ?is-loading=${this.isLoading}
          ?checked=${this.checked}
          .checked=${this.checked}
          ?disabled=${this.disabled}
          @change=${(event) => this.onInputChanged_(event)} />
        <span></span>
        <div class="slot-container">
          <slot name="right-label"> </slot>
          <slot name="right-input-label-icon"></slot>
        </div>
      </label>
    `;
    }
}
export { styles as jhaFormSwitchStyles };
