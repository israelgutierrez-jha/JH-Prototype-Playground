import JhaFormSwitch from './JhaFormSwitch.js';
customElements.define('jha-form-switch', JhaFormSwitch);
/** @customElement jha-form-switch */
export default JhaFormSwitch;
