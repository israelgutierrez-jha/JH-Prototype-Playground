import JhaFormCurrencyInput from './JhaFormCurrencyInput.js';
customElements.define('jha-form-currency-input', JhaFormCurrencyInput);
/** @customElement jha-form-currency-input */
export default JhaFormCurrencyInput;
