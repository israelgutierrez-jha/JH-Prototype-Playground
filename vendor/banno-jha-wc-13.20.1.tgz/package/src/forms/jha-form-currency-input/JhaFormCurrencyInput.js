import { html, css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
import JhaFormInput from '../jha-form-input-base/JhaFormInput.js';
import '../jha-form-floating-group/jha-form-floating-group.js';
const styles = css `
  :host {
    display: block;
  }
  jha-form-floating-group {
    --jha-input-content-flex-direction: column;
  }
  jha-form-floating-group::before {
    content: '$';
    font-size: 18px;
    position: absolute;
    top: var(--jha-currency-input-dollar-top, var(--jha-currency-input-dollar-no-label-top, 35px));
    bottom: var(--jha-currency-input-dollar-bottom, auto);
    left: 15px;
    transform: translateY(50%);
    color: var(--jha-text-light);
    display: block;
    z-index: 1;
  }
  :host([disabled]) {
    opacity: var(--jha-input-opacity-disabled, 0.7);
    cursor: default;
  }
  :host([noLabel]) jha-form-floating-group::before {
    transform: translateY(-50%);
    top: var(--jha-currency-input-dollar-no-label-top, 35px);
  }
  :host([filled]) {
    --jha-currency-input-dollar-top: 44px;
  }
  :host([outline]) {
    --jha-currency-input-dollar-top: 40px;
  }
  :host([small]) jha-form-floating-group::before {
    --jha-currency-input-dollar-top: var(--jha-currency-input-dollar-small-top, 32px);
    bottom: var(--jha-currency-input-small-dollar-bottom, var(--jha-currency-input-dollar-bottom, auto));
  }
  input {
    text-align: right;
  }

  :host([left]) input {
    text-align: left;
    padding-left: 32px;
  }

  input[type='number']::-webkit-inner-spin-button,
  input[type='number']::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }
  .label-container {
    display: flex;
    justify-content: space-between;
  }
  .label-container > span {
    display: flex;
    justify-content: flex-start;
    gap: 8px;
    white-space: nowrap;
    align-items: center;
  }
  /* People-specific styles */
  /* JR: these have all been replaced by css variables (see :host),
   but leaving this here for a reference when the input breaks in People.
  */
  /*
  :host([is-in-people]) #currency-container {
    width: 150px;
  }
  :host([is-in-people]) input {
    color: var(--jha-text-base);
    background: transparent;
    border: 1px solid var(--jha-border-color);
    border-radius: 3px;
  }
  :host([is-in-people]) input:focus {
    border: 1px solid var(--jha-color-primary);
  }
  */

  /* CSS to prevent zooming on iOS when input is focused */
  @supports (-webkit-overflow-scrolling: touch) {
    :host([floating]) input {
      font-size: 16px;
    }
  }
`;
/**
 * @element jha-form-currency-input
 *
 * Extends Jha-form-input see: forms/jha-form-input-base/jhaFormInput.js for list of properties
 */
export default class JhaFormCurrencyInput extends JhaFormInput {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            min: {
                type: Number,
            },
            max: {
                type: Number,
            },
            placeholder: {
                type: String,
            },
            noLabel: {
                type: Boolean,
                reflect: true,
            },
            noDecimal: {
                type: Boolean,
            },
            allowNegative: {
                type: Boolean,
            },
            outline: {
                type: Boolean,
                reflect: true,
            },
            alwaysFloat: {
                type: Boolean,
                reflect: true,
            },
            step: {
                type: String,
            },
            hideRequiredIndicator: {
                type: Boolean,
            },
            useCommas: {
                type: Boolean,
            },
            allowedCharacters: {
                type: String,
            },
            hasFocus: {
                type: Boolean,
            },
            warning: {
                type: String,
            },
        };
    }
    constructor() {
        super();
        this.step = '0.01';
        this.amount = '';
        this.min = 0;
        this.max = Infinity;
        this.placeholder = '0.00';
        this.noLabel = false;
        this.noDecimal = false;
        this.outline = false;
        this.small = false;
        this.allowNegative = false;
        this.hideRequiredIndicator = false;
        this.useCommas = false;
        this.allowedCharacters = '[0-9.,-]+';
        this.hasFocus = false;
        this.warning = '';
        this.validator = null;
    }
    /**
     * @description getters and setters for amount for backward compatibility
     *
     */
    set amount(newVal) {
        this.value_ = newVal;
    }
    get amount() {
        return this.value_;
    }
    onFocus_() {
        this.hasFocus = true;
    }
    onBlur_() {
        super.onBlur_();
        this.hasFocus = false;
    }
    get displayCommas() {
        return this.useCommas && !this.hasFocus;
    }
    renderLabel() {
        return html `
      <div class="label-container">
        <span>
          <label
            for=${this.id}
            class="label">
            ${this.label}${this.required && !this.hideRequiredIndicator
            ? html `
                  <span
                    class="required-indicator"
                    style="color: var(--jh-input-required-color-text, var(--jh-color-content-negative-enabled, var(--jha-color-danger, #DB2012)))">
                    *
                  </span>
                `
            : ''}
          </label>
          <slot name="input-label-icon"></slot>
        </span>

        <slot name="input-top-right"></slot>
      </div>
    `;
    }
    /** @override */
    render() {
        return html `
      <jha-form-floating-group
        ?outline=${this.outline}
        ?small=${this.small}
        always-float
        ?filled=${this.filled}
        ?no-label=${this.noLabel}
        .assistiveText=${this.assistiveText}
        .error=${this.showWarning_() ? this.warning || '' : null}>
        ${this.label ? this.renderLabel() : ''}
        <input
          id=${this.id}
          aria-label=${this.label}
          ?readonly=${this.readonly}
          type="text"
          inputmode="decimal"
          .value=${this.formattedValue}
          ?disabled=${this.disabled}
          ?required=${this.required}
          placeholder=${this.placeholder}
          @focus=${this.onFocus_}
          @keypress=${this.onKeypress_}
          @keyup=${this.onInput_}
          @change=${this.onChange_}
          @blur=${this.onBlur_}
          @keydown=${this.onKeydown_}
          class="${this.showWarning_() ? 'warning' : ''}"
          autocomplete="off" />

        <slot
          name="assistive-text"
          slot="assistive-text"></slot>
      </jha-form-floating-group>
    `;
    }
    /**
     * @description re-formats amount to 2 decimal places (or '')
     * @param {string} value
     */
    formatValue(value) {
        if (value) {
            const floatAmount = parseFloat(String(value).replace(/,/g, ''));
            if (Number.isNaN(floatAmount)) {
                this.value_ = '';
            }
            else {
                const dollars = value.split('.')[0].replace(/\D+/g, '');
                const cents = this.noDecimal
                    ? ''
                    : `.${value.split('.').length <= 1 ? '00' : value.split('.')[1].replace(/\D+/g, '').padEnd(2, '0').slice(0, 2)}`;
                const sign = this.allowNegative && floatAmount < 0 ? '-' : '';
                this.value_ = `${sign}${dollars}${cents}`;
            }
            if (this.displayCommas) {
                this.value_ = this.value_.replace(/,/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            }
        }
    }
    get formattedValue() {
        return this.displayCommas
            ? this.value_
                .toString()
                .replace(/,/g, '')
                .replace(/\B(?=(\d{3})+(?!\d))/g, ',')
            : this.value_;
    }
    get notInRange() {
        const floatVal = parseFloat(this.value);
        const belowMin = this.min && floatVal < this.min;
        const aboveMax = this.max && floatVal > this.max;
        return belowMin || aboveMax;
    }
    checkValidity() {
        const { value } = this;
        if (this.validator) {
            return this.validator(value);
        }
        // Allow formatter to fix stepMismatch
        if (this.input_?.validity.stepMismatch) {
            return true;
        }
        if (this.notInRange) {
            return false;
        }
        return super.checkValidity();
    }
    /**
     * For browsers that allow commas when entering a value into an `<input type="number">`, but sets its `value`
     * to an empsty string and doesn't recognize the input as a valid value (i.e. Edge/Firefox), this simply
     * listens for comma keydown and ignores them
     * @param {!KeyboardEvent} evt
     */
    onKeydown_(evt) {
        if (evt.code === 'Comma') {
            evt.preventDefault();
        }
    }
}
export { styles as jhaFormCurrencyInputStyles };
