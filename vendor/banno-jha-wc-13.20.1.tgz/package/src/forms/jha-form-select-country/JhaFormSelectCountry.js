import JhaFormSelect from '../jha-form-select/jha-form-select.js';
import { countriesAsSelectArrayWithSelection } from '../../js/utils/country-abbreviations.js';
/** @element jha-form-select-country */
export default class JhaFormSelectCountry extends JhaFormSelect {
    constructor() {
        super();
        this.options = countriesAsSelectArrayWithSelection('USA');
        this.label = 'Country';
    }
}
