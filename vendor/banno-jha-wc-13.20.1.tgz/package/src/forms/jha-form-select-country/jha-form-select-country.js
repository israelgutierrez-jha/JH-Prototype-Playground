import JhaFormSelectCountry from './JhaFormSelectCountry.js';
customElements.define('jha-form-select-country', JhaFormSelectCountry);
/** @customElement jha-form-select-country */
export default JhaFormSelectCountry;
