// @ts-nocheck
import { LitElement, html, css } from 'lit';
import { ifDefined } from 'lit/directives/if-defined.js';
import { jhaStyles } from '../../styles/jha-styles.js';
import '../jha-form-floating-group/jha-form-floating-group.js';
/** @typedef {"hidden" | "text" | "search" | "tel" | "url" | "email" | "password" | "datetime" | "date" | "month" | "week" | "time" | "datetime-local" | "number" | "range" | "color" | "checkbox" | "radio" | "file" | "submit" | "image" | "reset" | "button"} InputType */
const styles = css `
  :host {
    display: block;
    color: var(--jha-text-neutral, #8d99a0);
  }
  :host([disabled]) {
    opacity: var(--jha-input-opacity-disabled, 0.7);
    cursor: default;
  }
  jha-form-floating-group {
    --jha-input-margin-bottom: var(--jha-text-input-margin-bottom, 4px);
    --jha-input-content-flex-direction: column;
    align-content: center;
    align-items: center;
    align-self: center;
  }

  .input-mask {
    display: flex;
  }

  .input-mask i {
    visibility: hidden;
    font-style: normal;
  }

  .input-mask span {
    display: inline-block;
  }

  input {
    color-scheme: var(--jha-input-color-scheme, initial);
  }
  .helper-text {
    word-break: normal;
    overflow-wrap: anywhere;
    color: var(--jh-input-helper-color-text, var(--jh-color-content-secondary-enabled));
    margin: 0;
    font: var(--jh-font-helper-regular);
  }
  .required-indicator {
    color: var(
      --jh-input-required-color-text,
      var(--jh-color-content-negative-enabled, var(--jha-color-danger, #db2012))
    );
  }
  .input-container {
    position: relative;
  }
  :host([has-left-slot-content]) input {
    padding-left: var(--jh-dimension-1300, 56px);
  }
  .label-container {
    display: flex;
    justify-content: space-between;
  }
  .label-container > span {
    display: flex;
    justify-content: flex-start;
    gap: 8px;
    white-space: nowrap;
    align-items: center;
  }
`;
/**
 * JHA Base Input component that others extend
 *
 * @element jha-form-input
 *
 * @prop {number} min - min value for number input
 * @prop {number} max - Max value for a number input
 * @prop {string} caption -  Title text of the input, also displayed in the character limit caption
 * @prop {number} step - Change the inputs step amount for incrementing up and down
 * @prop {regex} allowedCharacters - Regex pattern checked on keydown that prevents unallowed characters
 * @prop {regex} pattern - Regex pattern that must be matched or a warning is shown
 * @prop {number} maxlength - Maximum number of allowable characters
 * @prop {number} minlength - Minimum number of allowable characters
 * @prop {string} label - Label for the input
 * @prop {string} warning - Text displayed when the inputs validity check does not pass table  defaultValue    summary:     category: Properties
 * @prop {boolean} showWarning - Rather than setting a pattern, which is validated by the native input, you can manually set display the warning message when the value doesn\t match desired format
 * @prop {string} assistiveText - Aria assistive text
 * @prop {string} placeholder - Input placeholder text
 * @prop {string} value - The value of the input, transmitted on the change event
 * @prop {boolean} noLabel - Hides the inputs label
 * @prop {boolean} small - reduces component size
 * @prop {boolean} outline - adds border around the input and changes styling
 * @prop {boolean} required - Adds error and styling when the input is left blank or only whitespace is entered
 * @prop {boolean} disabled - Disables the input
 * @prop {boolean} autocomplete - Enables the inputs autocomplete functionality
 * @prop {boolean} readonly - Readonly input
 * @prop {boolean} hideRequiredIndicator - removes the required asterisk from the input label.  Please only use if marking optional fields with '(optional)'.
 */
export default class JhaFormInput extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    /** @type {import('lit').PropertyDeclarations} */
    static get properties() {
        return {
            min: {
                type: Number,
            },
            max: {
                type: Number,
            },
            id: {
                type: String,
                reflect: true,
            },
            disabled: {
                type: Boolean,
                reflect: true,
            },
            warning: {
                type: String,
                reflect: true,
            },
            type: {
                type: String,
                reflect: true,
            },
            label: {
                type: String,
            },
            pattern: {
                type: RegExp,
            },
            maxlength: {
                type: Number,
                reflect: true,
            },
            minlength: {
                type: Number,
                reflect: true,
            },
            required: {
                type: Boolean,
                reflect: true,
            },
            value_: {
                type: String,
            },
            caption: {
                // used as 'title' for input
                type: String,
            },
            small: {
                type: Boolean,
                reflect: true,
            },
            filled: {
                type: Boolean,
                reflect: true,
            },
            assistiveText: {
                type: String,
            },
            autocomplete: {
                type: String,
            },
            autocapitalize: {
                type: String,
            },
            name: {
                type: String,
            },
            outline: {
                type: Boolean,
                reflect: true,
            },
            noLabel: {
                type: Boolean,
            },
            hasInteraction_: {
                type: Boolean,
            },
            readonly: {
                type: Boolean,
            },
            placeholder: {
                type: String,
            },
            step: {
                type: String,
            },
            alwaysFloat: {
                type: Boolean,
            },
            allowedCharacters: {
                type: String,
            },
            showWarning: {
                type: Boolean,
            },
            mask: {
                type: String,
            },
            inputMode: {
                type: String,
            },
            hideRequiredIndicator: {
                type: Boolean,
            },
            ariaLabel: {
                type: String,
                attribute: 'aria-label',
            },
            helpText: {
                type: String,
            },
        };
    }
    constructor() {
        super();
        // eslint-disable-next-line wc/no-constructor-attributes
        this.id = '';
        this.disabled = false;
        this.warning = '';
        this.filled = false;
        /** @type {InputType} */
        this.type = 'text';
        this.pattern = undefined;
        this.required = false;
        this.label = '';
        this.small = false;
        /** @type {number|string} */
        this.min = 0;
        /** @type {number|string} */
        this.max = Infinity;
        this.minlength = 0;
        this.maxlength = Infinity;
        this.value = '';
        this.caption = '';
        this.assistiveText = '';
        this._modified = false;
        this.autocomplete = 'off';
        // eslint-disable-next-line wc/no-constructor-attributes
        this.autocapitalize = undefined;
        this.name = '';
        this.input_ = null;
        this.noLabel = false;
        this.outline = false;
        this.hasInteraction_ = false;
        this.readonly = false;
        this.value_ = '';
        this.placeholder = '';
        this.step = 'any';
        this.alwaysFloat = false;
        this.allowedCharacters = undefined;
        this.showWarning = false;
        this.mask = undefined;
        this.inputMode = 'text';
        this.hideRequiredIndicator = false;
        this.helpText = '';
    }
    checkValidity() {
        if (!this.input_) {
            return true;
        }
        if (!this.input_.required && this.input_.value.length <= 0) {
            return true;
        }
        if (this.mask && !this.maskedInputValid) {
            return false;
        }
        return (this.matchesAllowedCharacters &&
            this.input_.checkValidity() &&
            this.checkLength(this.value, this.minlength, this.maxlength) &&
            this.ifRequiredHasValue);
    }
    checkLength(value, min, max) {
        // Don't check character length on a number
        if (this.type === 'number') {
            return true;
        }
        return value !== null && min !== undefined && max !== undefined ? value.length >= min && value.length <= max : true;
    }
    // If input is required, should have at least one non whitespace
    get ifRequiredHasValue() {
        return !this.required || (this.value || '').trim().length > 0;
    }
    get valid() {
        return this.checkValidity() && this.ifRequiredHasValue;
    }
    get value() {
        // Input values should always be strings regardless of the input type
        return [null, undefined].includes(this.value_) ? '' : `${this.value_}`;
    }
    get matchesAllowedCharacters() {
        if (!this.allowedCharacters) {
            return true;
        }
        // Ensure the regex matches the entire string
        const regex = new RegExp(`^${this.allowedCharacters}$`);
        return regex.test(this.value);
    }
    set value(newVal) {
        const oldVal = this.value_;
        this.value_ = this.getMaskFormattedValue(newVal);
        // mark input as modified if value has changed
        if (oldVal !== newVal) {
            this._modified = true;
        }
        this.updateComplete.then(() => {
            const floatingGroup = this.shadowRoot && this.shadowRoot.querySelector('jha-form-floating-group');
            if (floatingGroup && floatingGroup.error) {
                this.requestUpdate();
            }
        });
    }
    firstUpdated() {
        this.setAttribute('role', 'textbox');
        this.input_ = this.shadowRoot.querySelector('input') || this.shadowRoot.querySelector('textarea');
    }
    focus() {
        if (this.input_) {
            this.input_.focus();
        }
    }
    updated() {
        // since pattern has to either exist or not (cannot be null or undefined),
        // set it manually.
        if (this.input_) {
            if (this.pattern) {
                this.input_.setAttribute('pattern', this.pattern);
            }
            else {
                this.input_.removeAttribute('pattern');
            }
            if (this._modified) {
                this._modified = false;
                // if modified, our value was changed (externally). dispatch a change event on our input
                /** @type {import('../../js/utils/types.js').InputChangeEvent} */
                const changeEvent = new CustomEvent('change', {
                    bubbles: true,
                    cancelable: true,
                    detail: this.value_,
                });
                this.input_.dispatchEvent(changeEvent);
            }
        }
    }
    formatValue(value) {
        // no-op by default
        this.value_ = value;
    }
    onKeydown_(evt) {
        // no-op by default
        return evt;
    }
    onKeypress_(evt) {
        // If there is an allowedCharacters regex, prevent the input of characters that do not match
        if (this.allowedCharacters && !new RegExp(this.allowedCharacters).test(evt.key)) {
            evt.preventDefault();
        }
    }
    onInput_(event) {
        const { target, code } = event;
        const cursorPosition = target.selectionStart;
        const isModifyingMaskedValue = this.mask && cursorPosition + 1 < target.value.length;
        // Safari has issue with number inputs where when a decimal point is entered the value becomes an empty string, so need to accounts for that here
        const isBlankDecimal = target.type === 'number' && target.value === '' && ['NumpadDecimal', 'Period'].includes(code);
        // Input events change our `value_` property directly instead of our 'public' `value` property, to prevent
        // formatting fighting the user while they type.  Do not update this.value_ if a decimal was entered and the target
        // value is blank -- because some browsers set the input value to a blank string for <input type="number"> input fields.
        this.value_ = isBlankDecimal ? this.value_ : this.getMaskFormattedValue(event.target.value);
        // relay an input event
        this.dispatchEvent(new CustomEvent('input', {
            detail: this.value_,
        }));
        // and a change event
        this.dispatchChange();
        // If the user is modifying in a masked value, the cursor needs to be set to not jump to the end of the value
        if (isModifyingMaskedValue) {
            this.setInputSelection(cursorPosition);
        }
    }
    async setInputSelection(selectionStart) {
        await this.updateComplete;
        this.input_.setSelectionRange(selectionStart, selectionStart);
    }
    onChange_() {
        // The number increment buttons on the input element don't fire an input event,
        // so the value needs to be updated here if it has not been
        if (this.input_.value !== this.value_) {
            this.value_ = this.getMaskFormattedValue(this.input_.value);
        }
        // relay a change event
        if (this.checkValidity()) {
            this.formatValue(this.value_);
        }
        this.dispatchChange();
        this.maybeDispatchInvalid_();
    }
    onBlur_() {
        this.hasInteraction_ = true;
        if (this.checkValidity()) {
            this.formatValue(this.value_);
        }
        else {
            // dispatch change so that our parent element can detect whether erorrs are displayed.
            // this occurs when the field is invalid, focused and then blurred, without making changes.
            this.dispatchChange();
        }
        if (this.input_.value !== this.value_) {
            this.input_.value = this.value_;
        }
    }
    maybeDispatchInvalid_() {
        if (!this.checkValidity()) {
            this.dispatchEvent(new CustomEvent('invalid', {
                bubbles: true,
                composed: true,
                detail: false,
            }));
        }
    }
    dispatchChange() {
        /** @type {import('../../js/utils/types.js').InputChangeEvent} */
        const changeEvent = new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: this.value_,
        });
        this.dispatchEvent(changeEvent);
        // backward compatibility for jha-form-currency-input
        this.dispatchEvent(new CustomEvent('changed', {
            detail: this.value_,
        }));
    }
    /**
     * @description suppress warnings until the user has interacted (blurred) the input
     * because of this a pattern is needed to trigger warning if input is too short.
     * UNLESS - the showWarning property is set to true
     */
    showWarning_() {
        return this.showWarning || (this.hasInteraction_ ? !this.checkValidity() : false);
    }
    get remainingMask() {
        if (!this.value || !this.value.length)
            return this.mask || '';
        return this.mask.slice(this.value.length);
    }
    get maskedInputValid() {
        if (!this.mask)
            return true;
        if (this.remainingMask.length)
            return false;
        return true;
    }
    getMaskFormattedValue(valueString) {
        if (!this.mask)
            return valueString;
        let charIndex = 0;
        const baseValue = this.removeMaskFormatting(valueString);
        return [...this.mask].reduce((acc, cur) => {
            const valChar = baseValue[charIndex];
            if (!valChar) {
                return acc;
            }
            const useMaskCharacter = !['_', valChar].includes(cur);
            charIndex += useMaskCharacter ? 0 : 1;
            if (charIndex === baseValue.length && valChar === cur) {
                return acc;
            }
            return `${acc}${useMaskCharacter ? cur : valChar}`;
        }, '');
    }
    removeMaskFormatting(valueString) {
        if (!this.mask)
            return valueString;
        const maskCharacters = [...this.mask].reduce((acc, cur) => {
            if (acc.includes(cur))
                return acc;
            return [...acc, ...[cur]];
        }, []);
        let newValue = valueString;
        maskCharacters.forEach((char) => {
            newValue = newValue.replaceAll(char, '');
        });
        return newValue;
    }
    renderLabel() {
        return html `
      <div class="label-container">
        <span>
          <label
            for=${this.id}
            class="label">
            ${this.label}${this.required && !this.hideRequiredIndicator
            ? html `
                  <span
                    class="required-indicator"
                    style="color: var(--jh-input-required-color-text, var(--jh-color-content-negative-enabled, var(--jha-color-danger, #DB2012)))">
                    *
                  </span>
                `
            : ''}
          </label>
          <slot
            slot="input-label-icon"
            name="input-label-icon"></slot>
        </span>

        <slot
          slot="input-top-right"
          name="input-top-right"></slot>
      </div>
    `;
    }
    renderHelperText() {
        return html ` <p class="helper-text">${this.helpText}</p> `;
    }
    render() {
        return html `
      <div>
        <jha-form-floating-group
          ?outline=${this.outline}
          ?small=${this.small}
          ?filled=${this.filled}
          ?no-label=${this.noLabel}
          .hasValue=${Boolean(this.value)}
          .error=${ifDefined(this.showWarning_() && this.warning ? this.warning : undefined)}
          .assistiveText=${this.assistiveText}
          ?always-float=${this.alwaysFloat}>
          ${this.label ? this.renderLabel() : ''}
          <slot
            name="input-left"
            slot="input-left"></slot>
          <input
            id=${this.id}
            ?required=${this.required}
            ?readonly=${this.readonly}
            ?disabled=${this.disabled}
            type=${this.type}
            minlength=${this.minlength}
            maxlength=${this.maxlength}
            min=${this.min}
            max=${this.max}
            step=${ /** @type {number} This appeases TSC, but step can be a string ("any") */(this.step)}
            name=${this.name}
            .value=${this.value}
            value=${this.value}
            aria-label=${this.ariaLabel || this.label}
            .title=${this.caption}
            @input=${this.onInput_}
            @change=${this.onChange_}
            @blur=${this.onBlur_}
            @keydown=${this.onKeydown_}
            @keypress=${this.onKeypress_}
            autocomplete=${this.autocomplete}
            autocapitalize=${this.autocapitalize}
            placeholder=${this.placeholder}
            inputmode=${this.inputMode} />
          ${this.helpText ? this.renderHelperText() : ''}
          <slot
            slot="input-right"
            name="input-right"></slot>
          ${!this.error
            ? html `<slot
                name="assistive-text"
                slot="assistive-text"></slot>`
            : ''}
          ${this.mask
            ? html `
                <span class="input-mask">
                  <i>${this.value}</i>
                  <span>${this.remainingMask}</span>
                </span>
              `
            : ''}
        </jha-form-floating-group>
      </div>
    `;
    }
}
