import JhaFormInput from './JhaFormInput.js';
customElements.define('jha-form-input', JhaFormInput);
/** @customElement jha-form-input */
export default JhaFormInput;
