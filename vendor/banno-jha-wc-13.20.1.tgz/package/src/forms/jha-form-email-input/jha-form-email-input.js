import JhaFormEmailInput from './JhaFormEmailInput.js';
customElements.define('jha-form-email-input', JhaFormEmailInput);
/** @customElement jha-form-email-input */
export default JhaFormEmailInput;
