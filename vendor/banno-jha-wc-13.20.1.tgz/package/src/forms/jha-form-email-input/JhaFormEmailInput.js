import JhaFormInput from '../jha-form-input-base/JhaFormInput.js';
/**
 * @element jha-form-email-input
 *
 * Extends Jha-form-input see: forms/jha-form-input-base/jhaFormInput.js for list of properties
 */
export default class JhaFormEmailInput extends JhaFormInput {
    static get properties() {
        return {
            matchValue: {
                type: String,
            },
            matchValueWarning: {
                type: String,
            },
        };
    }
    constructor() {
        super();
        /** @type {"email"} */
        this.type = 'email';
        this.label = 'Email address';
        this.warning = 'Please provide a valid email address.';
        // need to set hasInteraction_ to true if wanting to validate a prepopulated value;
        this.hasInteraction_ = false;
        // Provide a matchValue if using as a confirmation input to validate that the input values match.
        this.matchValue = null;
        // Unique text string to display when the value does not match the matchValue
        this.matchValueWarning = 'Emails must match';
    }
}
