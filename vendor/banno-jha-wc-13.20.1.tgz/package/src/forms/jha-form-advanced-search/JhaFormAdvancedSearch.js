import { css } from 'lit';
import JhaFormChipInput from '../jha-form-chip-input/JhaFormChipInput.js';
import { jhaStyles } from '../../styles/jha-styles.js';
import { getSearchableData, splitSearchString } from '../../js/utils/search-util.js';
const styles = css `
  :host {
    display: block;
  }
  :host([disabled]) {
    opacity: var(--jha-input-opacity-disabled, 0.7);
    cursor: default;
  }
  .tagLimit {
    display: none;
  }
  .chip {
    max-width: 90%;
  }
  .chip span {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    max-width: calc(100% - 12px);
  }
  .input {
    flex-wrap: nowrap;
  }

  :host([small]) jha-icon-search {
    height: 18px;
    width: 18px;
  }

  :host([small]) input {
    --jha-input-padding: 10px 36px;
  }

  :host([outline][small]) {
    --jha-form-floating-group-label-top: 18px;
    --jha-input-font-size: 14px;
  }

  :host([outline]:not([small])) {
    --jha-slotted-input-top: 26px;
  }

  :host([outline][small][show-search-icon]) {
    --jha-form-floating-group-label-left: 32px;
    --jha-slotted-input-top: 22px;
    --jha-form-floating-group-label-max-width: calc(100% - 32px);
  }
`;
/**
 * @element jha-form-advanced-search
 *
 * Extends Jha-form-chip-input see: forms/jha-form-chip-input/JhaFormChipInput.js for list of properties
 */
export default class JhaFormAdvancedSearch extends JhaFormChipInput {
    static get styles() {
        return [...super.styles, jhaStyles, styles];
    }
    static get properties() {
        return {
            searchFields: {
                type: Array,
            },
            data: {
                type: Array,
            },
            outline: {
                type: Boolean,
                reflect: true,
            },
            filled: {
                type: Boolean,
                reflect: true,
            },
            options: { type: Array },
            chipLimit: { type: Number },
            selectedOptions: { type: Array },
            selectedChipIndex: { type: Number },
            inputValue: { type: String },
            helperText: { type: String },
            label: { type: String },
            small: {
                type: Boolean,
                reflect: true,
            },
            required: {
                type: Boolean,
                reflect: true,
            },
            hideRequiredIndicator: {
                type: Boolean,
            },
            warning: {
                type: String,
                reflect: true,
            },
            focused: {
                type: String,
                reflect: true,
            },
            disabled: {
                type: Boolean,
                reflect: true,
            },
            showWarning: {
                type: Boolean,
            },
            allowUnknownValue: {
                type: Boolean,
            },
            showSearchIcon: {
                type: Boolean,
                reflect: true,
                attribute: 'show-search-icon',
            },
            showClearInputButton: {
                type: Boolean,
                reflect: true,
                attribute: 'show-clear-button',
            },
        };
    }
    constructor() {
        super();
        /** @type {!Array<string>} */
        this.searchFields = [];
        /** @type {!Array<*>} */
        this.data = [];
        /** @type {!Array<string>} */
        this.options = [];
        /** @type {number} */
        this.chipLimit = 1;
        /** @type {string} */
        this.inputValue = '';
        /** @type {!Array<string>} */
        this.selectedOptions = [];
        /** @type {?number} */
        this.selectedChipIndex = null;
        /** @type {?string} */
        this.helperText = null;
        /** @type {string} */
        this.placeholder = '';
        /** @type {string} */
        this.label = '';
        /** @type {boolean} */
        this.outline = false;
        /** @type {boolean} */
        this.filled = false;
        /** @type {boolean} */
        this.small = false;
        /** @type {boolean} */
        this.required = false;
        /** @type {boolean} */
        this.hideRequiredIndicator = false;
        /** @type {boolean} */
        this.hasInteraction_ = false;
        /** @type {string} */
        this.warning = '';
        /** @type {boolean} */
        this.focused = false;
        /** @type {boolean} */
        this.disabled = false;
        /** @type {boolean} */
        this.showWarning = false;
        /** @type {boolean} */
        this.allowUnknownValue = true;
        this.showSearchIcon = true;
        this.showClearInputButton = true;
        // eslint-disable-next-line @jkhy/ux/prefer-arrow-event-handler
        this.addEventListener('click', () => {
            this.focusInput();
        });
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (!(changedProperties.has('searchFields') || changedProperties.has('data')))
            return;
        this.options = getSearchableData(this.data, this.searchFields);
    }
    dispatchChangeEvent() {
        /** @type {import('../../js/utils/types.js').InputMultipleStringsEvent} */
        const changeEvent = new CustomEvent('change', {
            detail: splitSearchString(this.selectedOptions[0]),
        });
        this.dispatchEvent(changeEvent);
    }
}
export { styles as JhaFormAdvancedSearchStyles };
