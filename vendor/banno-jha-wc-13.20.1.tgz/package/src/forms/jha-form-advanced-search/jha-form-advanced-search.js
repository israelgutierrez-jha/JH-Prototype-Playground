import JhaFormAdvancedSearch from './JhaFormAdvancedSearch.js';
customElements.define('jha-form-advanced-search', JhaFormAdvancedSearch);
/** @customElement jha-form-advanced-search */
export default JhaFormAdvancedSearch;
