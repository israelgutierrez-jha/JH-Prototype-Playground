import JhaFormSelectYear from './JhaFormSelectYear.js';
customElements.define('jha-form-select-year', JhaFormSelectYear);
/** @customElement jha-form-select-year */
export default JhaFormSelectYear;
