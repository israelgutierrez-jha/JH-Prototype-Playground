import JhaFormSelect from '../jha-form-select/jha-form-select.js';
const startYear = new Date().getFullYear();
const DEFAULT_YEARS = Array.from({ length: 50 }, (_, i) => {
    const value = String(startYear + i);
    return { name: value, value };
});
/**@element jha-form-select-year */
export default class JhaFormSelectYear extends JhaFormSelect {
    constructor() {
        super();
        this.options = DEFAULT_YEARS;
        this.label = 'Select year';
        this.emptyOptionLabel = 'Choose one *';
    }
}
