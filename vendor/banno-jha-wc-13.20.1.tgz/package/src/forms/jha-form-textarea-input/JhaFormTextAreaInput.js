import { html, css } from 'lit';
import { ifDefined } from 'lit/directives/if-defined.js';
import { jhaStyles } from '../../styles/jha-styles.js';
import JhaFormInput from '../jha-form-input-base/JhaFormInput.js';
import '../jha-form-floating-group/jha-form-floating-group.js';
import '../../icons/jha-icon-switch.js';
import '../../icons/jha-icon-warning-filled.js';
const styles = css `
  :host([disabled]) {
    opacity: var(--jha-input-opacity-disabled, 0.7);
    cursor: default;
  }
  .details {
    text-align: var(--jha-form-textarea-input-details-text-align, inherit);
  }
  .helper-text {
    word-break: normal;
    overflow-wrap: anywhere;
    color: var(--jh-input-helper-color-text, var(--jh-color-content-secondary-enabled));
    margin: 0;
    font: var(--jh-font-helper-regular);
  }
  .required-indicator {
    color: var(--jh-input-required-color-text, var(--jh-color-content-negative-enabled));
  }
  .character-limit {
    float: right;
  }
  textarea {
    min-height: 72px;
  }
  textarea[rows] {
    height: auto !important;
  }
  jha-form-floating-group {
    --jha-input-margin-bottom: var(--jha-text-input-margin-bottom, 4px);
    --jha-input-content-flex-direction: column;
  }
  slot[name='input-right']::slotted(*) {
    background-color: var(--jh-input-color-background, var(--jh-color-container-primary-enabled));
    backdrop-filter: var(--jh-input-slot-right-backgdrop-filter, blur(5px));
    border-radius: var(--jh-input-slot-right-border-radius, 12px);
  }
  .label-container {
    display: flex;
    justify-content: space-between;
  }
  .label-container > span {
    display: flex;
    justify-content: flex-start;
    gap: 8px;
    white-space: nowrap;
    align-items: center;
  }
`;
/**
 * A souped-up text input element with added functionality of displaying a caption and character
 * count/limit below it.
 *
 * @cssprop --jha-form-textarea-input-details-text-align - sets the text-align style for the 'details' section
 *
 * @element jha-form-textarea-input
 *
 * Extends Jha-form-input see: forms/jha-form-input-base/jhaFormInput.js for list of properties
 */
export default class JhaFormTextAreaInput extends JhaFormInput {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            characterLimit: {
                type: Number,
            },
            error: {
                type: String,
            },
            min: {
                type: Number,
            },
            max: {
                type: Number,
            },
            readonly: {
                type: Boolean,
            },
            placeholder: {
                type: String,
            },
            rows: {
                type: Number,
            },
        };
    }
    constructor() {
        super();
        this.caption = '';
        this.minlength = 0;
        this.maxlength = Infinity;
        this.error = '';
        this.characterLimit = null;
        this.placeholder = '';
        this.rows = undefined;
    }
    renderLabel() {
        return html `
      <div class="label-container">
        <span>
          <label
            for=${this.id}
            class="label">
            ${this.label}${this.required && !this.hideRequiredIndicator
            ? html `
                  <span
                    class="required-indicator"
                    style="color: var(--jh-input-required-color-text, var(--jh-color-content-negative-enabled, var(--jha-color-danger, #DB2012)))">
                    *
                  </span>
                `
            : ''}
          </label>
          <slot name="input-label-icon"></slot>
        </span>

        <slot name="input-top-right"></slot>
      </div>
    `;
    }
    render() {
        return html `
      <div>
        <jha-form-floating-group
          outline
          ?small=${this.small}
          ?filled=${this.filled}
          ?no-label=${this.noLabel}
          .hasValue=${Boolean(this.value)}
          .error=${this.showWarning_() ? this.warning : null}
          .assistiveText=${this.assistiveText}>
          ${this.label ? this.renderLabel() : ''}
          <textarea
            id=${this.id}
            ?required=${this.required}
            ?readonly=${this.readonly}
            ?disabled=${this.disabled}
            rows=${ifDefined(this.rows)}
            type="text"
            minlength=${this.minlength}
            maxlength=${this.characterLimit ? this.characterLimit : this.maxlength}
            .value=${this.value}
            aria-label=${this.label}
            .placeholder=${this.placeholder}
            .title=${this.caption}
            @input=${this.onInput_}
            @change=${this.onChange_}
            @blur=${this.onBlur_}></textarea>
          ${this.helpText ? this.renderHelperText() : ''}
          <slot
            slot="input-right"
            name="input-right"></slot>

          <slot
            name="assistive-text"
            slot="assistive-text"></slot>
        </jha-form-floating-group>

        ${!this.error
            ? html `
              <div class="details">
                <span>${this.caption}</span>
                ${this.characterLimit
                ? html ` <span class="character-limit"> ${this.value.length}/${this.characterLimit} </span> `
                : ''}
              </div>
            `
            : ''}
      </div>
    `;
    }
}
export { styles as JhaFormTextAreaInputStyles };
