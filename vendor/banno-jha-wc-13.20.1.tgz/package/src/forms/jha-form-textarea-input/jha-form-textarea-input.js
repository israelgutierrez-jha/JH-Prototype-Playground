import JhaFormTextAreaInput from './JhaFormTextAreaInput.js';
customElements.define('jha-form-textarea-input', JhaFormTextAreaInput);
/** @customElement jha-form-textarea-input */
export default JhaFormTextAreaInput;
