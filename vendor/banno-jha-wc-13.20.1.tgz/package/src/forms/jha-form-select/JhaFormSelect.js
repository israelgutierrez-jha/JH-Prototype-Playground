import { css, html, LitElement } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
import '../jha-form-floating-group/jha-form-floating-group.js';
import '@jack-henry/jh-icons/icons-wc/icon-circle-xmark.js';
/** @typedef {import('lit').TemplateResult} TemplateResult */
/**
 * @typedef {Object} SelectOption
 * @property {string} name
 * @property {string} value
 * @property {boolean=} disabled
 * @property {boolean=} selected
 */
/**
 * @typedef {Object} OptionsGroup
 * @property {string} label
 * @property {Array<SelectOption>} group
 */
const styles = css `
  * {
    --jh-icon-size-small: 20px;
    --jh-icon-color-fill: var(--jha-color-neutral);
  }
  :host {
    display: block;
    position: relative;
  }
  :host([disabled]) {
    opacity: var(--jha-input-opacity-disabled, 0.7);
    cursor: default;
  }
  jha-form-floating-group {
    --jha-input-margin-bottom: var(--jha-text-input-margin-bottom, 4px);
    --jha-input-content-flex-direction: column;
    --jha-slotted-icon-right-position: 34px;
  }
  :host([icon-left]) jha-form-floating-group:not([always-float]):not([has-value]):not([has-focus]) {
    --jha-form-floating-group-label-left: 46px;
  }
  :host([filled]:not([outline])) jha-form-floating-group[filled][always-float],
  :host([filled]:not([outline])) jha-form-floating-group[filled][has-value],
  :host([filled]:not([outline])) jha-form-floating-group[filled][has-focus] {
    --jha-form-floating-group-label-left: 5px;
    --jha-form-floating-group-label-top: 14px;
  }
  select {
    --jha-select-text: var(--jha-text-base);
    font-family: inherit;
    display: block;
    width: 100%;
    line-height: var(--jha-select-line-height, 18px);
    color: var(--jha-select-text);
    outline: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    cursor: pointer;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  select[placeholder] {
    --jha-select-text: var(--jha-text-light);
  }
  select[disabled] {
    cursor: default;
  }
  select::-ms-expand {
    display: none;
  }

  ::slotted([slot='icon-left']) {
    position: absolute;
    top: 38px;
    left: 15px;
    width: 20px;
    height: 20px;
  }

  :host([filled]) ::slotted([slot='icon-left']),
  :host([outline]) ::slotted([slot='icon-left']) {
    top: 38px;
  }

  :host([icon-left][filled]:not([outline])) select,
  :host([icon-left]) select {
    padding-left: 48px;
  }

  jha-icon-chevron-down {
    position: absolute;
    top: var(--jha-form-select-icon-top, 28px);
    bottom: var(--jha-form-select-icon-bottom, auto);
    right: 8px;
    width: 24px;
    height: 24px;
    fill: var(--jha-color-neutral);
    z-index: 0;
  }
  jh-icon-circle-xmark:hover {
    --jh-icon-color-fill: var(--jh-input-clear-icon-color-fill-hover, var(--jh-color-content-brand-hover));
  }

  jh-icon-circle-xmark:focus {
    --jh-icon-color-fill: var(--jh-input-clear-icon-color-fill-focus, var(--jh-color-content-brand-active));
  }

  jh-icon-circle-xmark:active {
    --jh-icon-color-fill: var(--jh-input-clear-icon-color-fill-active, var(--jh-color-content-brand-active));
  }
  jh-icon-circle-xmark:hover {
    --jh-icon-color-fill: var(--jh-input-clear-icon-color-fill-hover, var(--jh-color-content-brand-hover));
  }

  jh-icon-circle-xmark:focus {
    --jh-icon-color-fill: var(--jh-input-clear-icon-color-fill-focus, var(--jh-color-content-brand-active));
  }

  jh-icon-circle-xmark:active {
    --jh-icon-color-fill: var(--jh-input-clear-icon-color-fill-active, var(--jh-color-content-brand-active));
  }

  jh-icon-circle-xmark[disabled] {
    --jh-icon-color-fill: var(--jh-input-clear-icon-color-fill-disabled, var(--jh-color-content-secondary-disabled));
    opacity: var(--jh-input-clear-opacity-disabled, 0.5);
    cursor: not-allowed;
  }
  :host([small]) jha-icon-chevron-down,
  :host([small]) ::slotted([slot='icon-left']) {
    bottom: var(--jha-form-select-small-icon-bottom, var(--jha-form-select-icon-bottom, auto));
  }

  label {
    max-width: calc(100% - 32px);
  }

  .required-indicator {
    color: var(
      --jh-input-required-color-text,
      var(--jh-color-content-negative-enabled, var(--jha-color-danger, #db2012))
    );
  }

  :host([filled]) label,
  :host([outline]) label {
    max-width: calc(100% - 48px);
  }

  :host([outline][small]) select {
    --jha-input-padding: 10px;
  }

  :host([filled]:not([outline])) select {
    border-radius: 0;
    box-sizing: border-box;
    background: var(--jha-form-select-background, var(--secondary-content-background-color, var(--jha-color-light)));
    border: none;
    border-bottom: 1px solid var(--jha-border-color, #e4e7ea);
    font-size: 14px;
    padding: 12px 24px 4px 8px;
  }
  :host([filled]:not([outline])) jha-icon-chevron-down {
    top: 24px;
  }

  :host([filled]:not([outline])) ::slotted([slot='icon-left']) {
    top: 30px;
  }

  :host([outline][small]) jha-icon-chevron-down {
    top: var(--jha-form-select-small-chevron-position-top, 20px);
  }
  :host([outline][small]) ::slotted([slot='icon-left']) {
    top: 22px;
  }
  div[slot='input-right'] {
    display: flex;
    align-items: center;
    gap: 4px;
    top: var(--jh-form-select-input-right-top, auto);
  }
  slot[name='input-right']::slotted(*) {
    position: unset;
    right: unset;
    bottom: unset;
    background-color: var(--jh-input-color-background, var(--jh-color-container-primary-enabled));
    backdrop-filter: var(--jh-input-slot-right-backgdrop-filter, blur(5px));
    border-radius: var(--jh-input-slot-right-border-radius, 12px);
  }
  slot[name='input-label-icon']::slotted(*) {
    margin-left: var(--jh-dimension-200, 6px);
  }
  /** prevent clicks on the icon slot from not opening the select */
  slot[name='icon'],
  slot[name='icon-left'] {
    pointer-events: none;
  }
  @media all and (-ms-high-contrast: none) {
    select::-ms-expand {
      display: none;
    }
  }

  label {
    width: calc(100% - 24px);
  }
  .label-container {
    display: flex;
    justify-content: space-between;
  }
  .label-container > span {
    display: flex;
    justify-content: flex-start;
    gap: 8px;
    white-space: nowrap;
    align-items: center;
  }

  :host([filled]) label,
  :host([outline]) label {
    width: calc(100% - 42px);
  }
`;
/** @element jha-form-select */
export default class JhaFormSelect extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            options: {
                type: Array,
            },
            value: {
                type: String,
            },
            focused: {
                type: Boolean,
                reflect: true,
            },
            emptyOptionLabel: {
                type: String,
            },
            enabledOptionLabel: {
                type: Boolean,
            },
            showClearButton: {
                type: Boolean,
            },
            id: {
                type: String,
                reflect: true,
            },
            required: {
                type: Boolean,
                reflect: true,
            },
            hideRequiredIndicator: {
                type: Boolean,
            },
            disabled: {
                type: Boolean,
                reflect: true,
            },
            error: {
                type: String,
            },
            warning: {
                type: String,
            },
            showWarning: {
                type: Boolean,
            },
            filled: {
                type: Boolean,
                reflect: true,
            },
            outline: {
                type: Boolean,
                reflect: true,
            },
            small: {
                type: Boolean,
                reflect: true,
            },
            label: {
                type: String,
                reflect: true,
            },
            isValid: {
                type: Boolean,
            },
            hasInteraction_: {
                type: Boolean,
            },
            assistiveText: {
                type: String,
            },
            labelKey: {
                type: String,
            },
            valueKey: {
                type: String,
            },
        };
    }
    constructor() {
        super();
        import('../../icons/jha-icon-chevron-down.js');
        this.focused = false;
        this.disabled = false;
        /** @type {Array<SelectOption|OptionsGroup>} */
        this.options = [];
        this.value = '';
        this.label = '';
        this.isValid = true;
        this.warning = 'Required';
        this.showWarning = false;
        this.hasInteraction_ = false;
        this.required = false;
        this.assistiveText = '';
        this.emptyOptionLabel = null;
        this.enabledOptionLabel = false;
        this.showClearButton = false;
        // eslint-disable-next-line wc/no-constructor-attributes
        this.id = '';
        this.labelKey = 'name';
        this.valueKey = 'value';
        this.filled = false;
        this.outline = false;
        this.small = false;
        this.hideRequiredIndicator = false;
    }
    connectedCallback() {
        super.connectedCallback();
        this.value = this.getInitialValue();
    }
    updated(changedProperties) {
        if (changedProperties.has('value')) {
            // Trigger change if value updated programmatically
            this.requestUpdate();
        }
    }
    /**
     * determine selected value based on `selected` property on option
     * @returns {string}
     */
    getInitialValue() {
        if (this.value && this.value !== '') {
            return this.value;
        }
        if (this.emptyOptionLabel) {
            return '';
        }
        const flatOptions = this.options
            .map((o) => {
            const maybeGroup = /** @type {OptionsGroup} */ (o);
            const maybeOption = /** @type {SelectOption} */ (o);
            if (maybeGroup.group) {
                return maybeGroup.group;
            }
            return maybeOption;
        })
            .flat();
        const selectedOption = flatOptions.find((o) => o.selected);
        const selectedValue = selectedOption ? selectedOption[this.valueKey] : null;
        const firstValue = flatOptions.length ? flatOptions[0][this.valueKey] : '';
        return selectedValue || firstValue;
    }
    onChange(event) {
        this.value = event.target.value;
        /** @type {import('../../js/utils/types.js').InputChangeEvent} */
        const changeEvent = new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: event.target.value,
        });
        this.dispatchEvent(changeEvent);
    }
    onFocus() {
        this.focused = true;
        this.dispatchEvent(new CustomEvent('focus'));
    }
    onBlur() {
        this.focused = false;
        this.hasInteraction_ = true;
        this.dispatchEvent(new CustomEvent('blur'));
    }
    checkValidity() {
        const el = this.shadowRoot.querySelector('select');
        if (el) {
            return el.checkValidity();
        }
        return true;
    }
    /**
     * @description suppress warnings until the user has interacted (blurred) the input
     * because of this a pattern is needed to trigger warning if input is too short.
     * UNLESS - the showWarning property is set to true
     */
    showWarning_() {
        return this.showWarning || (this.hasInteraction_ ? !this.checkValidity() : false);
    }
    get valid() {
        return !this.required || Boolean(this.value);
    }
    /**
     *
     * Render the individual option tag.  The Options can be disabled based on the data object containing a disabled property set to true.
     *
     * @param {SelectOption} option
     * @return {TemplateResult}
     */
    renderOption(option) {
        return html `
      <option
        .value=${option[this.valueKey]}
        .disabled=${option.disabled}
        ?selected=${option[this.valueKey] === this.value || option.selected}
        ?has-value=${Boolean(this.value)}>
        ${option[this.labelKey]}
      </option>
    `;
    }
    clearInput() {
        this.value = '';
        const changeEvent = new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: this.value,
        });
        this.dispatchEvent(changeEvent);
    }
    #getClearBtn() {
        let displayClearBtn = this.showClearButton && !this.disabled && this.value && this.value !== '' && this.value !== undefined;
        return displayClearBtn
            ? html `
          <button
            button-reset
            ?disabled=${this.disabled}
            @click=${this.clearInput}>
            <jh-icon-circle-xmark
              aria-hidden="true"
              size="small"></jh-icon-circle-xmark>
          </button>
        `
            : '';
    }
    render() {
        return html `
      <form>
        <jha-form-floating-group
          ?filled=${this.filled}
          ?outline=${this.outline}
          ?small=${this.small}
          .hasValue=${Boolean(this.value)}
          ?always-float=${this.emptyOptionLabel && this.emptyOptionLabel.trim().length > 0}
          .error=${this.showWarning_() ? this.warning : null}
          .assistiveText=${this.assistiveText}>
          ${this.label
            ? html `
                <div class="label-container">
                  <span>
                    <label
                      for=${this.id}
                      class="label">
                      ${this.required
                ? html `
                            ${this.label}
                            ${this.hideRequiredIndicator ? '' : html ` <span class="required-indicator">*</span> `}
                          `
                : this.label}
                    </label>
                    <slot name="input-label-icon"></slot>
                  </span>

                  <slot name="input-top-right"></slot>
                </div>
              `
            : ''}
          <slot name="icon-left"></slot>
          <select
            autocomplete="off"
            aria-label=${this.label}
            @focus=${this.onFocus}
            @blur=${this.onBlur}
            ?required=${this.required}
            ?disabled=${this.disabled}
            ?placeholder=${!this.value}
            .value=${this.value}
            @change=${(event) => this.onChange(event)}>
            ${this.emptyOptionLabel
            ? html `
                  <option
                    ?disabled=${!this.enabledOptionLabel}
                    selected
                    value="">
                    ${this.emptyOptionLabel}
                  </option>
                `
            : ''}
            ${this.options.map((o) => {
            const maybeGroup = /** @type {OptionsGroup} */ (o);
            const maybeOption = /** @type {SelectOption} */ (o);
            return html `
                ${maybeGroup.group
                ? html `
                      <optgroup .label=${maybeGroup.label}>
                        ${maybeGroup.group.map((item) => this.renderOption(item))}
                      </optgroup>
                    `
                : this.renderOption(maybeOption)}
              `;
        })}
          </select>
          <slot
            name="assistive-text"
            slot="assistive-text"></slot>
          <div slot="input-right">
            ${this.#getClearBtn()}
            <slot name="input-right"> </slot>
          </div>
          <slot name="icon">
            <jha-icon-chevron-down></jha-icon-chevron-down>
          </slot>
        </jha-form-floating-group>
      </form>
    `;
    }
}
export { styles as JhaFormSelectStyles };
