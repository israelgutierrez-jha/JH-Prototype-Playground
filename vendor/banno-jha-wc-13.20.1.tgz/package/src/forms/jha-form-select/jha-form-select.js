import JhaFormSelect from './JhaFormSelect.js';
customElements.define('jha-form-select', JhaFormSelect);
/** @customElement jha-form-select */
export default JhaFormSelect;
