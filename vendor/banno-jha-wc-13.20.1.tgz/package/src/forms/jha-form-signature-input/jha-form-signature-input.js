import JhaFormSignatureInput from './JhaFormSignatureInput.js';
customElements.define('jha-form-signature-input', JhaFormSignatureInput);
/** @customElement jha-form-signature-input */
export default JhaFormSignatureInput;
