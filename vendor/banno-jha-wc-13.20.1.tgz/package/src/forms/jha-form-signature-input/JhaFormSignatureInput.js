import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
const styles = css `
  :host {
    display: block;
    padding-top: var(--jha-input-padding-top, 0);
    margin-bottom: var(--jha-input-margin-bottom, 16px);
    border-radius: var(--jha-form-signature-border-radius, 8px);
    --jha-signature-fill-color: var(--jha-text-base, #000);
  }
  div.content {
    position: relative;
  }
  canvas {
    display: block;
    position: relative;
    border: 1px solid var(--jha-color-gray-medium, var(--body-text-secondary-color));
    border-radius: var(--jha-form-signature-border-radius, 8px);
    height: var(--jha-form-signature-height, 300px);
    width: 100%;
    z-index: 1;
  }
  .signature-line {
    position: absolute;
    bottom: 0;
    right: 24px;
    left: 24px;
    z-index: 2;
    color: var(--jha-color-gray-medium, #8c989f);
    padding: 8px 0 16px;
    box-sizing: border-box;
    display: flex;
    justify-content: center;
    font-size: var(--jha-form-signature-input-font-size, 12px);
    border-top: 1px solid var(--jha-color-gray-light, var(--jha-form-floating-group-filled-border-color, #e6e6e6));
  }
  button[button-reset] {
    color: var(--jha-color-primary, #3aaeda);
    position: absolute;
    top: 12px;
    right: 16px;
    padding: 8px;
    z-index: 2;
    width: auto;
    cursor: pointer;
  }
`;
const TRANSPARENT_ALPHA = 0;
const RED_OFFSET = 0;
const GREEN_OFFSET = 1;
const BLUE_OFFSET = 2;
const ALPHA_OFFSET = 3;
/**@element jha-form-signature-input */
export default class JhaFormSignatureInput extends LitElement {
    _getStrokeThemeHex() {
        return getComputedStyle(this).getPropertyValue('--jha-signature-fill-color');
    }
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            shouldDraw: {
                type: Boolean,
            },
            text: {
                type: String,
            },
            dataURL: {
                type: String,
            },
            totalStrokeLength: {
                type: Number,
            },
        };
    }
    constructor() {
        super();
        this.dataURL = null;
        this._context = null;
        this.shouldDraw = false;
        this.totalStrokeLength = 0;
        this.text = 'Draw your signature above';
        this._points = null;
    }
    firstUpdated() {
        const SIZE_DEFAULTS = {
            width: 700,
            height: 250,
        };
        const rect = this._canvas && this._canvas.getBoundingClientRect();
        if (!rect || !rect.width)
            return;
        this._canvas.width = SIZE_DEFAULTS.width;
        this._canvas.height = SIZE_DEFAULTS.height;
        const context = this._canvas.getContext('2d');
        const scale = this.getScale(rect, SIZE_DEFAULTS);
        context.scale(scale.x, scale.y);
        this._context = context;
    }
    set points(pointsObj) {
        if (this._points) {
            this.totalStrokeLength +=
                Math.hypot(Math.floor(pointsObj.x) - Math.floor(this._points.x), Math.floor(pointsObj.y) - Math.floor(this._points.y)) || 0;
        }
        this._points = pointsObj;
    }
    get points() {
        return this._points;
    }
    get _canvas() {
        return this.shadowRoot.querySelector('canvas');
    }
    updated(changedProperties) {
        if (changedProperties.has('dataURL')) {
            /** @type {import('../../js/utils/types.js').InputSignatureEvent} */
            const changeEvent = new CustomEvent('change', {
                bubbles: true,
                composed: true,
                detail: { image: this.dataURL, strokeLength: this.totalStrokeLength },
            });
            this.dispatchEvent(changeEvent);
        }
    }
    getScale(rect, SIZE_DEFAULTS) {
        return {
            x: SIZE_DEFAULTS.width / rect.width,
            y: SIZE_DEFAULTS.height / rect.height,
        };
    }
    _handleMouseDown(event) {
        if (event.buttons === 1) {
            this.startDrawing(event);
        }
    }
    _handleMouseUp(event) {
        if (event.button === 0) {
            this._finishDrawing();
        }
    }
    _finishDrawing() {
        if (!this.shouldDraw)
            return;
        this.shouldDraw = false;
        this._points = null;
        this.saveSignature();
    }
    /**
     *   Save signature should always return an image where the stroke color is black
     *   and the background is transparent. Any styling / theming should not be taken
     *   into account when saving the image. This is important as we can always be sure
     *   what the stroke / background are when loading a previously saved image.
     *   This allows the signature to be portable / agnostic of environment theming.
     */
    saveSignature() {
        if (!this._canvas || this.totalStrokeLength === 0)
            return;
        const sourceCanvas = this._canvas;
        const sourceContext = sourceCanvas.getContext('2d');
        const targetCanvas = document.createElement('canvas');
        const targetContext = targetCanvas.getContext('2d');
        targetCanvas.width = this._canvas.width;
        targetCanvas.height = this._canvas.height;
        const { width, height } = sourceCanvas;
        const sourceImageData = sourceContext.getImageData(0, 0, width, height);
        const sourcePixels = sourceImageData.data;
        const targetImageData = targetContext.getImageData(0, 0, width, height);
        const targetPixels = targetImageData.data;
        // Image data is a linear array of rgba --> [r,g,b,a,r,g,b,a], so we increment
        // by 4 and access each rgba value by its offset.
        for (let i = 0; i < sourcePixels.length; i += 4) {
            const sourcePixelAlpha = sourcePixels[i + 3];
            // Setting all pixels containing a stroke value to fully opaque black / RGBA(0,0,0,255)
            if (sourcePixelAlpha !== TRANSPARENT_ALPHA) {
                targetPixels[i + RED_OFFSET] = 0;
                targetPixels[i + BLUE_OFFSET] = 0;
                targetPixels[i + GREEN_OFFSET] = 0;
                targetPixels[i + ALPHA_OFFSET] = 255;
            }
        }
        targetContext.putImageData(targetImageData, 0, 0);
        this.dataURL = targetCanvas.toDataURL('image/png');
    }
    _handleMouseMove(event) {
        this.drawPath(event);
    }
    _handleTouchStart(event) {
        if (event.targetTouches.length === 1) {
            this.startDrawing(event);
        }
    }
    _handleTouchMove(event) {
        event.preventDefault();
        this.drawPath(event);
    }
    _handleTouchEnd(event) {
        event.preventDefault();
        this._finishDrawing();
    }
    startDrawing(event) {
        const strokeThemeColor = this._getStrokeThemeHex();
        this.shouldDraw = true;
        this._context.fillStyle = strokeThemeColor;
        this._context.strokeStyle = strokeThemeColor;
        this._context.lineWidth = 2;
        this._context.lineJoin = 'round';
        this._context.lineCap = 'round';
        this._context.beginPath();
        const elementRect = event.target.getBoundingClientRect();
        this.points = {
            x: event.clientX - elementRect.left,
            y: event.clientY - elementRect.top,
        };
        this._context.moveTo(this.points.x, this.points.y);
    }
    drawPath(event) {
        if (!this.shouldDraw)
            return;
        const elementRect = event.target.getBoundingClientRect();
        const points = event.targetTouches ? event.targetTouches[0] : event;
        this.points = {
            x: points.clientX - elementRect.left,
            y: points.clientY - elementRect.top,
        };
        this._context.lineTo(points.clientX - elementRect.left, points.clientY - elementRect.top);
        this._context.stroke();
    }
    clearCanvas() {
        this._context.clearRect(0, 0, this._canvas.width, this._canvas.height);
        this.dataURL = null;
        this.totalStrokeLength = 0;
    }
    render() {
        return html `
      <div class="content">
        ${this.dataURL
            ? html `
              <button
                button-reset
                type="button"
                @click=${() => this.clearCanvas()}>
                Clear
              </button>
            `
            : ''}

        <div class="signature-line">
          <span>${this.text}</span>
        </div>
        <canvas
          @mousedown=${this._handleMouseDown}
          @mousemove=${this._handleMouseMove}
          @mouseup=${this._handleMouseUp}
          @mouseleave=${this._handleMouseUp}
          @mouseenter=${this._handleMouseDown}
          @touchstart=${this._handleTouchStart}
          @touchmove=${this._handleTouchMove}
          @touchend=${this._handleTouchEnd}></canvas>
      </div>
    `;
    }
}
export { styles as JhaFormSignatureInputStyles };
