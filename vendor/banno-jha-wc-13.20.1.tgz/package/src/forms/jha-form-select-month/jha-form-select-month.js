import JhaFormSelectMonth from './JhaFormSelectMonth.js';
customElements.define('jha-form-select-month', JhaFormSelectMonth);
/** @customElement jha-form-select-month */
export default JhaFormSelectMonth;
