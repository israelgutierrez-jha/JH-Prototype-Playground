import JhaFormSelect from '../jha-form-select/jha-form-select.js';
const MONTHS = [
    { name: 'January', value: 'January' },
    { name: 'February', value: 'February' },
    { name: 'March', value: 'March' },
    { name: 'April', value: 'April' },
    { name: 'May', value: 'May' },
    { name: 'June', value: 'June' },
    { name: 'July', value: 'July' },
    { name: 'August', value: 'August' },
    { name: 'September', value: 'September' },
    { name: 'October', value: 'October' },
    { name: 'November', value: 'November' },
    { name: 'December', value: 'December' },
];
/**@element jha-form-select-month */
export default class JhaFormSelectMonth extends JhaFormSelect {
    constructor() {
        super();
        // JR: TODO: provide mechanism to override values?
        this.options = MONTHS;
        this.label = 'Select month';
        this.emptyOptionLabel = 'Choose one *';
    }
}
