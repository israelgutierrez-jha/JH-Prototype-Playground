import { LitElement, html, css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
const styles = css `
  :host {
    display: block;
  }
  input {
    display: none;
  }
`;
/** @element jha-form-file-input */
export default class JhaFormFileInput extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            name: {
                type: String,
            },
            multiple: {
                type: Boolean,
            },
            accept: {
                type: String,
            },
        };
    }
    constructor() {
        super();
        this.name = 'file';
        this.multiple = false;
        this.accept = '';
    }
    /** @return {!HTMLInputElement} */
    get fileInput() {
        return this.shadowRoot.querySelector('input#file-input');
    }
    _handleButtonClick() {
        const clickEvent = new MouseEvent('click', {
            bubbles: true,
            cancelable: false,
            view: window,
        });
        this.fileInput.dispatchEvent(clickEvent);
    }
    _onFileInputChange(evt) {
        /** @type {import('../../js/utils/types.js').InputFileListEvent} */
        const changeEvent = new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: evt.target.files,
        });
        this.dispatchEvent(changeEvent);
    }
    render() {
        return html `
      <slot @click=${this._handleButtonClick}></slot>
      <input
        id="file-input"
        type="file"
        ?multiple=${this.multiple}
        name=${this.name}
        accept=${this.accept}
        @change=${this._onFileInputChange} />
    `;
    }
}
export { styles as JhaFormFileInputStyles };
