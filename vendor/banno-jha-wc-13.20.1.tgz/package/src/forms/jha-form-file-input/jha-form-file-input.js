import JhaFormFileInput from './JhaFormFileInput.js';
customElements.define('jha-form-file-input', JhaFormFileInput);
/** @customElement jha-form-file-input */
export default JhaFormFileInput;
