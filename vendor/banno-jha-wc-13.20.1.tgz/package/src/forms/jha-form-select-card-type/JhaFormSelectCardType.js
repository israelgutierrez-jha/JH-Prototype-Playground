import JhaFormSelect from '../jha-form-select/jha-form-select.js';
/** @element jha-form-select-card-type */
export default class JhaFormSelectCardType extends JhaFormSelect {
    constructor() {
        super();
        this.options = [
            { name: 'Mastercard', value: 'Mastercard' },
            { name: 'Visa', value: 'Visa' },
            { name: 'Discover', value: 'Discover' },
            { name: 'American Express', value: 'American Express' },
        ];
        this.label = 'Card type';
        this.emptyOptionLabel = 'Choose one *';
    }
}
