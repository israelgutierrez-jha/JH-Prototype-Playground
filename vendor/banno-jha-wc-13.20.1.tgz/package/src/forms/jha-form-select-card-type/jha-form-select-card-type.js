import JhaFormSelectCardType from './JhaFormSelectCardType.js';
customElements.define('jha-form-select-card-type', JhaFormSelectCardType);
/** @customElement jha-form-select-card-type */
export default JhaFormSelectCardType;
