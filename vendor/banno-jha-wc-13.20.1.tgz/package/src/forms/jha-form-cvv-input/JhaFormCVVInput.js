import JhaFormInput from '../jha-form-input-base/JhaFormInput.js';
import '../jha-form-floating-group/jha-form-floating-group.js';
/**
 * @element jha-form-cvv-input
 *
 * Extends Jha-form-input see: forms/jha-form-input-base/jhaFormInput.js for list of properties
 */
export default class JhaFormCVVInput extends JhaFormInput {
    constructor() {
        super();
        this.maxlength = 4;
        this.minlength = 3;
        this.label = 'CVV';
        this.allowedCharacters = '[0-9]+'; // Allow only numbers
        this.warning = 'Enter the security code found on the back of your card.';
    }
}
