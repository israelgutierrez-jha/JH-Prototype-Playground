import JhaFormCVVInput from './JhaFormCVVInput.js';
customElements.define('jha-form-cvv-input', JhaFormCVVInput);
/** @customElement jha-form-cvv-input */
export default JhaFormCVVInput;
