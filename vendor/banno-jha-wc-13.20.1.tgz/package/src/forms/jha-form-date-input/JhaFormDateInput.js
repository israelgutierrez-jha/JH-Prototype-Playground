// @ts-nocheck
import JhaFormInput from '../jha-form-input-base/JhaFormInput.js';
/**
 * @element jha-form-date-input
 *
 * Extends Jha-form-input see: forms/jha-form-input-base/jhaFormInput.js for list of properties
 */
export default class JhaFormDateInput extends JhaFormInput {
    static get properties() {
        return {
            max: { type: String },
            min: { type: String },
            warning: { type: String },
            value_: { type: String },
        };
    }
    constructor() {
        super();
        this.min = `${new Date().getFullYear() - 120}-01-01`;
        this.max = this.getMaxDate();
        /** @type {import('../jha-form-input-base/JhaFormInput.js').InputType} */
        this.type = 'date';
        this.warning = 'Invalid date';
        this.alwaysFloat = true;
        this.value_ = '';
    }
    getMaxDate() {
        const date = new Date();
        const year = date.getFullYear();
        const month = (1 + date.getMonth()).toString().padStart(2, '0');
        const day = date.getDate().toString().padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
}
