import JhaFormDateInput from './JhaFormDateInput.js';
customElements.define('jha-form-date-input', JhaFormDateInput);
/** @customElement jha-form-date-input */
export default JhaFormDateInput;
