import JhaFormDateInputIcon from './JhaFormDateInputIcon.js';
customElements.define('jha-form-date-input-icon', JhaFormDateInputIcon);
/** @customElement jha-form-date-input-icon */
export default JhaFormDateInputIcon;
