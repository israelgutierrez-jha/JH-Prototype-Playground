import { html, css } from 'lit';
import JhaFormInput from '../jha-form-input-base/JhaFormInput.js';
import { jhaStyles } from '../../styles/jha-styles.js';
import '../../forms/jha-form-floating-group/jha-form-floating-group.js';
const styles = css `
  :host {
    display: block;
    margin-bottom: 16px;
  }
  :host([disabled]) {
    opacity: var(--jha-input-opacity-disabled, 0.7);
    cursor: default;
  }
  :host([outline]) jha-form-floating-group {
    --jha-input-padding: 17px 10px;
  }
  jha-form-floating-group {
    --jha-input-margin-bottom: var(--jha-text-input-margin-bottom, 4px);
    --jha-input-content-flex-direction: column;
  }
  :host([outline][small]) jha-icon-date,
  jha-icon-date {
    position: absolute;
    top: var(--jha-form-date-input-icon-top, 20px);
    bottom: var(--jha-form-date-input-icon-bottom, auto);
    right: 10px;
    fill: var(--jha-text-light, var(--body-text-secondary-color));
    pointer-events: none;
    z-index: 1;
  }
  :host([small]) jha-icon-date {
    bottom: var(--jha-form-date-input-small-icon-bottom, var(--jha-form-date-input-icon-bottom, auto));
  }
  :host([outline]) jha-icon-date {
    top: var(--jha-form-date-input-icon-top, 28px);
  }

  :host([outline]:not[small]) input {
    height: 56px;
  }
  jha-form-floating-group[has-focus] jha-icon-date-outline {
    fill: var(--jha-text-theme, #3aaeda);
  }
  [type='date']::-webkit-calendar-picker-indicator {
    opacity: 0;
    margin-right: 12px;
  }
  :host([outline]) [type='date']::-webkit-calendar-picker-indicator {
    margin: 0;
  }
  label {
    background-color: var(--jha-input-label-background, var(--jha-component-background-color, #fff));
    overflow: hidden;
    width: 100%;
  }
  :host([outline]) jha-form-floating-group[has-focus] label,
  :host([outline]) jha-form-floating-group[has-value] label {
    width: auto;
  }
  :host([filled]:not([outline])) label {
    background-color: var(--jha-color-light, var(--secondary-content-background-color));
  }
  :host([filled]:not([outline])) jha-form-floating-group:not([has-value]):not([has-focus]) label {
    --jha-form-floating-group-label-top: 32px;
    --jha-form-floating-group-label-left: 9px;
  }
  :host([filled]:not([outline])) {
    --jha-form-date-input-icon-top: 24px;
  }
  :host([filled]:not([outline])) [type='date']::-webkit-calendar-picker-indicator {
    opacity: 0;
    margin-right: 6px;
  }
  input[type='date']::-webkit-calendar-picker-indicator {
    opacity: 0;
    margin-right: 6px;
  }
  slot[name='input-right']::slotted(*) {
    position: absolute;
    right: var(--jha-text-input-right-slot-right-position, 34px);
    background-color: var(--jh-input-color-background, var(--jh-color-container-primary-enabled));
    backdrop-filter: var(--jh-input-slot-right-backgdrop-filter, blur(5px));
    border-radius: var(--jh-input-slot-right-border-radius, 12px);
  }
  jha-form-floating-group {
    --jha-input-padding: 1px 5px 1px 16px;
    margin-bottom: var(--jha-text-input-margin-bottom, 0);
  }
  .label-container {
    display: flex;
    justify-content: space-between;
  }
  .label-container > span {
    display: flex;
    justify-content: flex-start;
    gap: 8px;
    white-space: nowrap;
    align-items: center;
  }
  /** The native calendar icon cannot be styled in FF so we hide the jha icon */
  @-moz-document url-prefix() {
    jha-icon-date {
      display: none;
    }
  }
`;
/**
 * @element jha-form-date-input-icon
 *
 * Extends Jha-form-input see: forms/jha-form-input-base/jhaFormInput.js for list of properties
 */
export default class JhaFormDateInputIcon extends JhaFormInput {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            ...super.properties,
            ...{
                min: {
                    type: String,
                },
                max: {
                    type: String,
                },
                value_: {
                    type: String,
                },
            },
        };
    }
    constructor() {
        super();
        import('../../icons/jha-icon-date.js');
        this.min = `${new Date().getFullYear() - 120}-01-01`;
        this.max = this.getMaxDate();
        /** @type {import('../jha-form-input-base/JhaFormInput.js').InputType} */
        this.type = 'date';
        this.warning = 'Invalid date';
        this.value_ = '';
    }
    getMaxDate() {
        const date = new Date();
        const year = date.getFullYear();
        const month = (1 + date.getMonth()).toString().padStart(2, '0');
        const day = date.getDate().toString().padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    updated(changedProperties) {
        if (changedProperties.has('value_') && this.value !== this.input_.value) {
            this.input_.value = this.value;
        }
    }
    renderLabel() {
        return html `
      <div class="label-container">
        <span>
          <label
            for=${this.id}
            class="label">
            ${this.label}${this.required && !this.hideRequiredIndicator
            ? html `
                  <span
                    class="required-indicator"
                    style="color: var(--jh-input-required-color-text, var(--jh-color-content-negative-enabled, var(--jha-color-danger, #DB2012)))">
                    *
                  </span>
                `
            : ''}
          </label>
          <slot name="input-label-icon"></slot>
        </span>

        <slot name="input-top-right"></slot>
      </div>
    `;
    }
    render() {
        return html `
      <div>
        <jha-form-floating-group
          ?outline=${this.outline}
          ?small=${this.small}
          ?filled=${this.filled}
          ?no-label=${this.noLabel}
          .hasValue=${Boolean(this.value)}
          .error=${this.showWarning_() ? this.warning : null}
          .assistiveText=${this.assistiveText}>
          ${this.label ? this.renderLabel() : ''}
          <input
            id=${this.id}
            ?required=${this.required}
            ?readonly=${this.readonly}
            ?disabled=${this.disabled}
            type=${this.type}
            minlength=${this.minlength}
            maxlength=${this.maxlength}
            min=${this.min}
            max=${this.max}
            value=${this.value}
            aria-label=${this.label}
            .title=${this.caption}
            @input=${this.onInput_}
            @change=${this.onChange_}
            @blur=${this.onBlur_}
            @keydown=${this.onKeydown_}
            autocomplete=${this.autocomplete}
            placeholder=${this.placeholder} />
          <slot
            slot="input-right"
            name="input-right"></slot>
          <slot
            name="assistive-text"
            slot="assistive-text"></slot>
          <jha-icon-date></jha-icon-date>
        </jha-form-floating-group>
      </div>
    `;
    }
}
