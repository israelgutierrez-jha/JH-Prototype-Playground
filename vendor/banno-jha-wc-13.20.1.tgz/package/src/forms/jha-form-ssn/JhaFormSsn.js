import { css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
import JhaFormInput from '../jha-form-input-base/JhaFormInput.js';
const styles = css `
  :host {
    display: block;
    color: var(--jha-text-neutral, #8d99a0);
    margin-bottom: 16px;
  }
  :host([disabled]) {
    opacity: var(--jha-input-opacity-disabled, 0.7);
    cursor: default;
  }
  jha-form-floating-group {
    margin-bottom: var(--jha-text-input-margin-bottom, 0);
  }
`;
/**
 * @element jha-form-ssn
 *
 * Extends Jha-form-input see: forms/jha-form-input-base/jhaFormInput.js for list of properties
 */
export default class JhaFormSsn extends JhaFormInput {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            lastFour: {
                type: Boolean,
            },
        };
    }
    constructor() {
        super();
        this.maxlength = 9;
        this.minlength = 9;
        this.allowedCharacters = '[0-9-]+';
    }
    set lastFour(value) {
        if (value) {
            this.maxlength = 4;
            this.minlength = 4;
        }
        else {
            this.maxlength = 9;
            this.minlength = 9;
        }
    }
    get lastFour() {
        return this.maxlength === 4;
    }
    // formats input to match SSN format (AAA-GG-SSSS)
    formatValue(value) {
        // No need to reformat if only entering last four
        if (this.lastFour) {
            this.value_ = value;
            return;
        }
        this.maxlength = 11;
        let ssn = `${value}`;
        const ssnPattern = new RegExp('d{3}[-]d{2}[-]d{4}');
        const res = ssnPattern.test(value);
        if (!res) {
            ssn = ssn
                .match(/\d*/g)
                .join('')
                .match(/(\d{0,3})(\d{0,2})(\d{0,4})/)
                .slice(1)
                .filter((v) => v !== '')
                .join('-');
        }
        this.value_ = ssn;
    }
    checkValidity() {
        const { lastFour, required, value } = this;
        if (!value || !`${value}`.trim()) {
            return !required;
        }
        if (lastFour) {
            const lastFourRegEpx = new RegExp(/^\d{4}$/);
            return lastFourRegEpx.test(value);
        }
        const fullRegEpx = new RegExp('[0-9]{9}|[0-9]{3}[-][0-9]{2}[-][0-9]{4}');
        return fullRegEpx.test(value);
    }
    onInput_(event) {
        // No need to reformat if only entering last four
        if (this.maxlength === 4) {
            this.value_ = event.target.value;
        }
        else {
            this.maxlength = 9;
            this.value_ = event.target.value.replace(/-/g, '');
        }
        this.dispatchEvent(new CustomEvent('input', {
            detail: this.value_,
        }));
        this.dispatchChange();
    }
}
