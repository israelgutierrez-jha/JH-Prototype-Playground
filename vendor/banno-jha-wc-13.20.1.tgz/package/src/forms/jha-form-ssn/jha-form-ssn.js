import JhaFormSsn from './JhaFormSsn.js';
customElements.define('jha-form-ssn', JhaFormSsn);
/** @customElement jha-form-ssn */
export default JhaFormSsn;
