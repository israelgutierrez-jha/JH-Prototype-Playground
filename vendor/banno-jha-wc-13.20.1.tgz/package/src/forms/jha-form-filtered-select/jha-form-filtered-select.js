import JhaFormFilteredSelect from './JhaFormFilteredSelect.js';
customElements.define('jha-form-filtered-select', JhaFormFilteredSelect);
/** @customElement jha-form-select */
export default JhaFormFilteredSelect;
