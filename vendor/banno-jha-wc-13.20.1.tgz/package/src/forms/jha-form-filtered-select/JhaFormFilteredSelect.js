import { css, html, LitElement } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
import '../jha-form-input-base/jha-form-input.js';
import '@jack-henry/jh-icons/icons-wc/icon-circle-xmark.js';
const styles = css `
  * {
    --jh-icon-size-small: 20px;
    --jh-icon-color-fill: var(--jha-color-neutral);
  }
  :host {
    display: block;
    position: relative;
    --jh-size-1400: 56px;
    --jh-size-1200: 48px;
    --jh-size-1000: 40px;
    --jh-dimension-400: 16px;
    --jh-dimension-200: 8px;
    --jh-size-500: 20px;
    --jh-size-800: 32px;
  }
  button[button-reset] {
    display: flex;
    width: auto;
  }
  .icon {
    position: relative;
    top: 0;
    bottom: 0;
    right: 0;
    display: flex;
    align-items: center;
    z-index: 0;
    padding: 0 8px;
    background-color: var(--jha-component-background-color, #ffffff);
  }
  button {
    font: inherit;
    color: inherit;
  }
  .no-results {
    padding: 12px;
    color: var(--body-text-secondary-color);
  }
  .options-dropdown {
    display: none;
    z-index: 99;
    box-shadow: var(--jh-shadow-high, var(--card-shadow));
    max-height: 200px;
    overflow-y: auto;
    position: absolute;
    left: 0;
    right: 0;
    top: auto;
    background: var(--jh-color-container-primary-enabled, var(--primary-content-background-color));
  }
  :host([size='small']) .options-dropdown {
    top: 68px;
  }
  :host([size='large']) .options-dropdown {
    top: 84px;
  }
  ul {
    list-style-type: none;
    padding: 0;
    margin: 0;
  }
  .option[has-focus] {
    background-color: var(--jh-list-item-color-background-selected, var(--jh-color-container-primary-selected));
    border-left-width: 8px;
    border-left-color: var(--jh-list-item-color-border-selected, var(--jh-color-content-brand-enabled));
    border-left-style: solid;
  }
  li button {
    border: none;
    background: none;
    padding: 12px;
    margin: 0;
    cursor: pointer;
    font-size: 14px;
    display: flex;
    align-items: center;
    width: 100%;
    text-align: left;
  }
  li button:focus {
    outline: none;
  }
  li:hover,
  li:focus-within {
    background: var(--jh-color-container-primary-hover, var(--jha-focus-highlight-color));
  }
  .options-dropdown[show] {
    display: block;
  }
  jha-icon-chevron-down[open] {
    transform: rotate(180deg);
  }
  div[slot='input-right'] {
    display: flex;
  }
  slot[name='input-right']::slotted(*) {
    right: var(--jha-select-right-slot-right-position, 24px);
    background-color: var(--jh-input-color-background, var(--jh-color-container-primary-enabled));
    backdrop-filter: var(--jh-input-slot-right-backgdrop-filter, blur(5px));
    border-radius: var(--jh-input-slot-right-border-radius, 12px);
  }

  .input-left {
    padding-left: var(--padding-no-slotted-content, 36px);
  }

  .label-container {
    display: flex;
    justify-content: space-between;
  }
  .label-container > span {
    display: flex;
    justify-content: flex-start;
    gap: 8px;
    white-space: nowrap;
    align-items: center;
  }

  jh-icon-circle-xmark {
    top: var(--jha-form-select-icon-top, 25px);
    bottom: var(--jha-form-select-icon-bottom, auto);
    right: 41px;
    width: 24px;
    height: 24px;
    z-index: 0;
    cursor: pointer;
  }

  ::slotted([slot='clear-button']) {
    position: absolute;
    top: var(--jha-form-select-icon-top, 25px);
    bottom: var(--jha-form-select-icon-bottom, auto);
    right: 28px;
    width: 24px;
    height: 24px;
    z-index: 0;
  }
  jh-icon-circle-xmark:hover {
    --jh-icon-color-fill: var(--jh-input-clear-icon-color-fill-hover, var(--jh-color-content-brand-hover));
  }

  jh-icon-circle-xmark:focus {
    --jh-icon-color-fill: var(--jh-input-clear-icon-color-fill-focus, var(--jh-color-content-brand-active));
  }

  jh-icon-circle-xmark:active {
    --jh-icon-color-fill: var(--jh-input-clear-icon-color-fill-active, var(--jh-color-content-brand-active));
  }

  jh-icon-circle-xmark[disabled] {
    --jh-icon-color-fill: var(--jh-input-clear-icon-color-fill-disabled, var(--jh-color-content-secondary-disabled));
    opacity: var(--jh-input-clear-opacity-disabled, 0.5);
    cursor: not-allowed;
  }

  .hide-clear-button {
    display: none;
  }
`;
/**
 * @typedef {Object} SelectOption
 * @property {string} name
 * @property {string} value
 */
/**
 * JHA select input that allows you to choose multiple options
 *
 * @element jha-form-multi-select
 *
 * @prop {Array<string|SelectOption>} options - array of string values
 * @prop {string} value - The value, set by the input itself when an option is selected
 * @prop {Boolean} focused - Adds focused attribute to component
 * @prop {string} placeholder - Input placeholder text
 * @prop {Boolean} menuOpen - if the options menu is open
 * @prop {String} helperText - help text below the input
 * @prop {String} inputValue - text typed in the input field that filters options shown
 * @prop {String} label = inputs label
 * @prop {Boolean} required - adds error if component is focused and then nothing is selected
 * @prop {boolean=} disabled - disables the input
 * @prop {String} warning - message to show when there is an error *
 * @prop {boolean} hideRequiredIndicator - Removes the required asterisk from the input label.  Please only use if marking optional fields with '(optional)'.
 * @prop {boolean} hideClearButton - Removes the clear button in the input.
 *
 * @fires change - fires when user selects or removes an item.
 */
export default class JhaFormFilteredSelect extends LitElement {
    static get styles() {
        return [jhaStyles, styles];
    }
    static get properties() {
        return {
            options: {
                type: Array,
            },
            value: {
                type: String,
            },
            inputValue: {
                type: String,
            },
            focused: {
                type: Boolean,
                reflect: true,
            },
            placeholder: {
                type: String,
            },
            menuOpen: {
                type: Boolean,
            },
            initialMenuOpen: {
                type: Boolean,
            },
            id: {
                type: String,
                reflect: true,
            },
            size: {
                type: String,
                reflect: true,
            },
            required: {
                type: Boolean,
                reflect: true,
            },
            hideRequiredIndicator: {
                type: Boolean,
            },
            showClearButton: {
                type: Boolean,
            },
            disabled: {
                type: Boolean,
                reflect: true,
            },
            warning: {
                type: String,
            },
            label: {
                type: String,
                reflect: true,
            },
            isValid: {
                type: Boolean,
            },
            hasInteraction_: {
                type: Boolean,
            },
            labelKey: {
                type: String,
            },
            valueKey: {
                type: String,
            },
            isClearEvent_: {
                type: Boolean,
            },
            hasLeftSlotContent_: {
                type: Boolean,
            },
        };
    }
    constructor() {
        super();
        import('../../icons/jha-icon-chevron-down.js');
        this.focused = false;
        this.isValid = true;
        this.disabled = false;
        /** @type {Array<SelectOption|string>} */
        this.options = [];
        this.value = '';
        this.label = '';
        this.menuOpen = false;
        this.initialMenuOpen = false;
        this.warning = 'Required';
        this.required = false;
        this.placeholder = '';
        // eslint-disable-next-line wc/no-constructor-attributes
        this.id = '';
        this.size = 'medium';
        this.labelKey = 'name';
        this.valueKey = 'value';
        this.boundCloseMenu_ = this.closeMenu.bind(this);
        this.hasInteraction_ = false;
        this.isClearEvent_ = false;
        this.hideRequiredIndicator = false;
        this.showClearButton = false;
        this.hasLeftSlotContent_ = false;
        // eslint-disable-next-line @jkhy/ux/prefer-arrow-event-handler
        this.addEventListener('click', () => {
            this.focusInput();
        });
    }
    connectedCallback() {
        super.connectedCallback();
        this.setInitialValue();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        window.removeEventListener('click', this.boundCloseMenu_);
    }
    updated(changedProperties) {
        if (changedProperties.has('value') || changedProperties.has('inputValue') || changedProperties.has('options')) {
            // Trigger change if value updated programmatically
            this.requestUpdate();
        }
    }
    willUpdate(changedProperties) {
        if (changedProperties.has('value')) {
            // Trigger setInitialValue if value updated programmatically or if the value was changed on the property
            this.setInitialValue();
        }
    }
    get _slottedLeftContent() {
        const slot = /** @type HTMLSlotElement*/ (this.shadowRoot.querySelector('slot[name=input-left]'));
        return slot.assignedElements({ flatten: true });
    }
    /**
     * determine selected value
     * @returns {string | SelectOption | null}
     */
    getInitialValue() {
        const selectedOption = this.options.find((o) => typeof o === 'string' ? o === this.value : o[this.valueKey] === this.value);
        return selectedOption ?? null;
    }
    /**Set the initial value of the input */
    setInitialValue() {
        const selectedOption = this.getInitialValue() ?? '';
        let newValue = '';
        let newInputValue = '';
        if (typeof selectedOption === 'string') {
            newValue = selectedOption;
            newInputValue = selectedOption;
        }
        else {
            newValue = selectedOption[this.valueKey];
            newInputValue = selectedOption[this.labelKey];
        }
        // Only update properties if they have actually changed.
        if (this.value !== newValue) {
            this.value = newValue;
        }
        if (this.inputValue !== newInputValue) {
            this.inputValue = newInputValue;
        }
    }
    focusListItemButton(index) {
        const list = this.shadowRoot.querySelectorAll('li.option');
        if (list && list[index]) {
            const button = list[index].querySelector('button');
            if (button) {
                button.focus();
            }
        }
    }
    getOption(item) {
        return typeof item === 'string' ? item : item[this.labelKey];
    }
    getOptionValue(item) {
        return typeof item === 'string' ? item : item[this.valueKey];
    }
    onInputKeyup(e) {
        e.preventDefault();
        this.initialMenuOpen = false;
        if (['ArrowDown', 'ArrowUp'].includes(e.code)) {
            e.preventDefault();
            const li = e.target.parentNode;
            if (li) {
                const list = Array.from(this.shadowRoot.querySelectorAll('li.option') || []);
                const index = list.findIndex((item) => item === li);
                const sibling = e.code === 'ArrowUp' ? index - 1 : index + 1;
                if (sibling > -1 && sibling <= list.length) {
                    this.focusListItemButton(sibling);
                }
            }
        }
        else if (e.key === 'Escape') {
            this.closeMenu();
            if (!this.menuOpen) {
                this.blurInput();
            }
            return;
        }
        else if (e.key === 'Enter' || e.key === 'NumEnter') {
            if (!this.menuOpen) {
                this.closeMenu();
                this.blurInput();
            }
        }
        else if (!this.menuOpen) {
            this.showMenu();
        }
        this.selectedChipIndex = null;
        this.inputValue = e.target.value;
    }
    filterDropDown(item) {
        const itemValue = this.getOption(item);
        return itemValue.toLowerCase().includes(this.inputValue.trim().toLowerCase());
    }
    checkValidity() {
        /** @type {import('../jha-form-input-base/jha-form-input.js').default} */
        const el = this.shadowRoot.querySelector('jha-form-input');
        if (this.required && el) {
            const showWarning = this.value === '';
            if (this.hasInteraction_) {
                el.showWarning = showWarning;
            }
            return showWarning === false;
        }
        return true;
    }
    selectOption(option) {
        this.hasInteraction_ = true;
        this.inputValue = this.getOption(option);
        this.value = this.getOptionValue(option);
        this.closeMenu();
        this.dispatchChangeEvent();
    }
    onOptionKeydown_(event, option) {
        if (event.code === 'Enter') {
            this.selectOption(option);
        }
        else if (['ArrowDown', 'ArrowUp'].includes(event.code)) {
            event.preventDefault();
            const li = event.target.parentNode;
            if (li) {
                const list = Array.from(this.shadowRoot.querySelectorAll('li.option') || []);
                const index = list.findIndex((item) => item === li);
                const sibling = event.code === 'ArrowUp' ? index - 1 : index + 1;
                if (sibling > -1 && sibling <= list.length) {
                    this.focusListItemButton(sibling);
                }
            }
        }
        else if (event.code === 'Escape') {
            this.closeMenu();
        }
    }
    dispatchChangeEvent() {
        this.dispatchEvent(new CustomEvent('change', {
            detail: this.value,
        }));
    }
    focusInput() {
        this.shadowRoot.getElementById('input').focus();
    }
    blurInput() {
        this.shadowRoot.getElementById('input').blur();
    }
    onFocus() {
        setTimeout(() => {
            if (this.isClearEvent_) {
                // Ignore focus event if clear button was clicked
                this.isClearEvent_ = false; // Reset the flag
                return;
            }
            this.focused = true;
            this.showMenu();
            this.dispatchEvent(new CustomEvent('focus'));
        }, 200); // Timeout to allow for button or dro
    }
    showMenu() {
        if (this.menuOpen)
            return;
        this.menuOpen = true;
        this.initialMenuOpen = true;
        setTimeout(() => {
            const focusedItem = this.shadowRoot.querySelector('li.option[has-focus]');
            if (focusedItem) {
                focusedItem.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
        }, 0);
        setTimeout(() => {
            window.addEventListener('click', this.boundCloseMenu_);
        }, 500);
    }
    closeMenu() {
        this.menuOpen = false;
        window.removeEventListener('click', this.boundCloseMenu_);
    }
    handleToggleArrow(evt) {
        evt.stopPropagation();
        if (this.menuOpen) {
            this.blurInput();
            this.closeMenu();
            return;
        }
        this.showMenu();
    }
    onBlur() {
        setTimeout(() => {
            if (!this.hasInteraction_) {
                // Handle the blur event
                this.focused = false;
                this.hasInteraction_ = true;
            }
            this.isValid = this.checkValidity();
        }, 200); // Timeout to allow dropdown option click
    }
    /**@description suppress warnings until the user has interacted (focused) the input */
    showWarning() {
        return this.hasInteraction_ && !this.focused ? !this.checkValidity() : false;
    }
    clearInput() {
        this.inputValue = '';
        this.value = '';
        this.isClearEvent_ = true;
        this.blurInput();
        this.closeMenu();
        this.dispatchChangeEvent();
    }
    #getClearBtn() {
        let displayClearBtn = this.showClearButton && !this.disabled && this.value && this.value !== '' && this.value !== undefined;
        return displayClearBtn
            ? html `
          <button
            button-reset
            ?disabled=${this.disabled}
            @click=${this.clearInput}>
            <jh-icon-circle-xmark
              aria-hidden="true"
              size="small"></jh-icon-circle-xmark>
          </button>
        `
            : '';
    }
    async handleLeftSlotChange() {
        await this.updateComplete;
        this.hasLeftSlotContent_ = this._slottedLeftContent?.length > 0;
    }
    /**
     *
     * Render the individual option.
     *
     * @param {SelectOption | string} option
     * @return {import('lit').TemplateResult}
     */
    renderOption(option) {
        return html `
      <li
        class="option"
        ?has-focus=${this.inputValue.trim().toLowerCase() === this.getOption(option).trim().toLowerCase()}
        tabindex="-1">
        <button
          @click=${() => this.selectOption(option)}
          @keydown=${(evt) => this.onOptionKeydown_(evt, option)}>
          <span>${this.getOption(option)}</span>
        </button>
      </li>
    `;
    }
    render() {
        return html `
      <jha-form-input
        id="input"
        type="text"
        label=${this.label}
        .size=${this.size}
        ?disabled=${this.disabled}
        .value=${this.inputValue}
        ?required=${this.required}
        ?show-indicator=${!this.hideRequiredIndicator}
        ?showWarning=${this.showWarning()}
        .warning=${this.warning}
        placeholder=${this.placeholder}
        @keyup=${this.onInputKeyup}
        @blur=${this.onBlur}
        @focus=${this.onFocus}
        @input=${this.onInputKeyup}
        @change=${(evt) => evt.stopPropagation()}
        autocomplete="off"
        ?has-left-slot-content=${this.hasLeftSlotContent_}
        ?hide-left-slot=${!this.hasLeftSlotContent_}>
        <slot
          slot="input-label-icon"
          name="input-label-icon"></slot>
        <slot
          slot="input-top-right"
          name="input-top-right"></slot>
        <slot
          slot="input-left"
          name="input-left"
          @slotchange=${this.handleLeftSlotChange}></slot>
        <div slot="input-right">
          ${this.#getClearBtn()}
          <slot name="input-right"></slot>
          <button
            button-reset
            type="button"
            @click=${this.handleToggleArrow}>
            <jha-icon-chevron-down ?open=${this.menuOpen}></jha-icon-chevron-down>
          </button>
        </div>
        <slot
          name="assistive-text"
          slot="assistive-text"></slot>
      </jha-form-input>
      <div
        tabindex="-1"
        class="options-dropdown"
        ?show=${this.menuOpen}
        @click=${(evt) => {
            evt.stopPropagation();
        }}>
        ${this.initialMenuOpen || this.options.some((o) => this.filterDropDown(this.getOption(o)))
            ? html `
              <ul tabindex="0">
                ${this.initialMenuOpen
                ? this.options.map((o) => this.renderOption(o))
                : this.options.filter((o) => this.filterDropDown(this.getOption(o))).map((o) => this.renderOption(o))}
              </ul>
            `
            : html ` <div class="no-results">No results found</div> `}
      </div>
    `;
    }
}
export { styles as JhaFormFilteredSelectStyles };
