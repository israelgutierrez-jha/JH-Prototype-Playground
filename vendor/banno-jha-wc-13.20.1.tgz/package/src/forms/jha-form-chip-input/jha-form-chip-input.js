import JhaFormChipInput from './JhaFormChipInput.js';
customElements.define('jha-form-chip-input', JhaFormChipInput);
/** @customElement jha-form-chip-input */
export default JhaFormChipInput;
