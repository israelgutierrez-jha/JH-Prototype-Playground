import { LitElement, css, html } from 'lit';
import '../jha-form-floating-group/jha-form-floating-group.js';
import { jhaStyles } from '../../styles/jha-styles.js';
const styles = css `
  :host {
    display: block;
    position: relative;
  }
  :host([disabled]) {
    opacity: var(--jha-input-opacity-disabled, 0.7);
    cursor: default;
  }
  :host([show-search-icon]) {
    --jha-input-symbol-left-width: 24px;
  }
  :host([show-clear-button]) {
    --jha-input-symbol-right-width: 24px;
  }
  jha-form-floating-group {
    --jha-input-content-flex-direction: column;
    --jha-slotted-input-bottom: 12px;
  }
  label {
    z-index: 1;
  }
  .input {
    position: relative;
    line-height: 18px;
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    max-height: 86px;
    --jha-input-box-sizing: border-box;
  }
  :host([small]) .input {
    --jha-input-padding: 8px;
    --jha-input-font-size: 14px;
  }
  input {
    flex: 1;
    border: none;
    background: transparent;
    font: inherit;
    color: var(--jha-text-dark);
  }
  input:focus {
    outline: none;
  }
  .chip {
    color: var(--jha-text-dark);
    background: var(--jha-input-chip-color, #f0f5f9);
    padding: var(--jha-multiselect-chip-padding, 3px 8px);
    font-size: var(--jha-input-font-size, 14px);
    border-radius: 2px;
    line-height: 1.2;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    gap: 2px;
  }
  :host([filled]) .input {
    padding-top: 22px;
  }
  :host([filled]) .chip {
    --jha-input-chip-color: var(--jha-component-background-color, #f0f5f9);
  }
  jha-icon-close {
    width: 12px;
    height: 12px;
    fill: currentColor;
  }
  .chip[selected] {
    background: var(--jha-text-theme, var(--body-text-theme-color));
    color: var(--jha-component-background-color, var(--primary-content-background-color));
  }
  button {
    font: inherit;
    color: inherit;
  }
  button.clear-input {
    display: inline-block;
    width: auto;
  }
  .chip button {
    background: none;
    border: none;
    padding: 0;
    margin: 0;
    cursor: pointer;
    font-size: 10px;
    top: 2px;
    position: relative;
  }
  .options-dropdown {
    display: none;
    z-index: 1000;
    box-shadow: var(--jha-card-box-shadow, var(--card-shadow));
    max-height: 200px;
    overflow-y: auto;
    position: absolute;
    left: 0;
    right: 0;
    margin-top: -6px;
    background: var(--jha-component-background-color, var(--primary-content-background-color));
    top: var(--jh-chip-input-options-top, auto);
  }
  :host([outline][small]) .options-dropdown {
    margin-top: 0px;
  }
  ul {
    list-style-type: none;
    padding: 0;
    margin: 0;
  }
  li button {
    border: none;
    background: none;
    padding: 6px 12px;
    margin: 0;
    cursor: pointer;
    font-size: 14px;
    display: block;
    border-radius: none;
    width: 100%;
    text-align: left;
  }
  li button:focus {
    outline: none;
  }
  li:hover,
  li:focus-within {
    background: var(--jha-focus-highlight-color, var(--link-button-pressed-color));
  }
  .options-dropdown[show] {
    display: block;
  }
  .tagLimit {
    text-align: right;
    font-size: 12px;
    color: var(--jha-color-gray-medium, var(--body-text-secondary-color));
  }
  .info-area {
    display: flex;
    justify-content: space-between;
    margin: var(--jha-chip-info-margin-top, 10px) 0 0 0;
    box-sizing: border-box;
    width: 100%;
  }
  .no-results {
    padding: 12px;
    color: var(--jha-color-gray-medium, var(--body-text-secondary-color));
  }
  .helperText {
    font-size: 12px;
    color: var(--jha-color-gray-medium, var(--body-text-secondary-color));
    margin-left: var(--jha-chip-helper-margin-left, 0);
  }
  input[disabled] {
    color: var(--jha-form-floating-group-input-disabled-text-color, var(--jha-text-light));
  }

  .required-indicator {
    color: var(
      --jh-input-required-color-text,
      var(--jh-color-content-negative-enabled, var(--jha-color-danger, #db2012))
    );
  }
`;
/**
 * An input that allows users to select multiple options from a dropdown.
 *
 * @element jha-form-chip-input
 *
 * @prop {Array<string>} options - the list of options users can select from
 * @prop {Number} chipLimit - the max number of options users can select
 * @prop {String} helperText - text that shows under the input
 * @prop {String} label - text that shows in the 'placeholder' position and floats above input
 * @prop {string} warning - Text displayed when the inputs validity check does not passtable  defaultValue    summary:     category: Properties
 * @prop {boolean} showWarning - Rather than setting a pattern, which is validated by the native input, you can manually set display the warning message when the value doesn\t match desired format
 * @prop {boolean} small - reduces component size
 * @prop {boolean} outline - adds border around the input and changes styling
 * @prop {boolean} required - Adds error and styling when the input is left blank or only whitespace is entered
 * @prop {boolean} disabled - Disables the input
 * @prop {boolean} hideRequiredIndicator - Removes the required asterisk from the input label.  Please only use if marking optional fields with '(optional)'.
 *
 * @cssprop --jha-input-chip-color - Background color for a chip item in the input
 *
 * @fires change - fires when user selects or removes an item. detail is an array of selectedOptions
 */
export default class JhaFormChipInput extends LitElement {
    static get properties() {
        return {
            outline: {
                type: Boolean,
                reflect: true,
            },
            filled: {
                type: Boolean,
                reflect: true,
            },
            options: { type: Array },
            chipLimit: { type: Number },
            selectedOptions: { type: Array },
            selectedChipIndex: { type: Number },
            inputValue: { type: String },
            helperText: { type: String },
            label: { type: String },
            small: {
                type: Boolean,
                reflect: true,
            },
            required: {
                type: Boolean,
                reflect: true,
            },
            hideRequiredIndicator: {
                type: Boolean,
            },
            warning: {
                type: String,
                reflect: true,
            },
            focused: {
                type: String,
                reflect: true,
            },
            disabled: {
                type: Boolean,
                reflect: true,
            },
            showWarning: {
                type: Boolean,
            },
            allowUnknownValue: {
                type: Boolean,
            },
            showSearchIcon: {
                type: Boolean,
                reflect: true,
                attribute: 'show-search-icon',
            },
            showClearInputButton: {
                type: Boolean,
                reflect: true,
                attribute: 'show-clear-button',
            },
        };
    }
    constructor() {
        super();
        import('../../icons/jha-icon-close.js');
        import('../../icons/jha-icon-search.js');
        import('../../icons/jha-icon-circle-close.js');
        this.chipLimit = null;
        this.inputValue = '';
        this.selectedOptions = [];
        this.selectedChipIndex = null;
        this.helperText = null;
        this.placeholder = '';
        this.options = [];
        this.label = '';
        this.outline = false;
        this.filled = false;
        this.small = false;
        this.required = false;
        this.hasInteraction_ = false;
        this.warning = '';
        this.focused = false;
        this.disabled = false;
        this.showWarning = false;
        this.hideRequiredIndicator = false;
        this.allowUnknownValue = false;
        this.showSearchIcon = false;
        this.showClearInputButton = false;
        // eslint-disable-next-line @jkhy/ux/prefer-arrow-event-handler
        this.addEventListener('click', () => {
            this.focusInput();
        });
    }
    updated(changedProperties) {
        if (changedProperties.has('inputValue')) {
            this.dispatchEvent(new CustomEvent('input-value-change', {
                detail: this.inputValue,
                bubbles: true,
                composed: true,
            }));
        }
    }
    onInputKeyup(e) {
        e.preventDefault();
        if (e.key === 'ArrowLeft') {
            this.selectPreviousChip();
        }
        else if (e.key === 'ArrowRight') {
            this.selectNextChip();
        }
        else if (e.key === 'Enter' && this.allowUnknownValue) {
            this.selectOption(this.inputValue);
            return;
        }
        else if ((e.key === 'Backspace' || e.key === 'Delete') && !this.inputValue) {
            if (this.selectedChipIndex !== null) {
                this.removeItemAtIndex(this.selectedChipIndex);
                this.selectedChipIndex = null;
            }
            else {
                this.selectedChipIndex = this.selectedOptions.length - 1;
            }
        }
        else {
            this.selectedChipIndex = null;
        }
        const { value } = e.target;
        this.inputValue = value;
    }
    filterDropDown(item) {
        return item.toLowerCase().includes(this.inputValue.toLowerCase()) && !this.selectedOptions.includes(item);
    }
    selectPreviousChip() {
        if (!this.selectedOptions.length)
            return;
        this.selectedChipIndex = this.selectedChipIndex
            ? (this.selectedChipIndex - 1) % this.selectedOptions.length
            : this.selectedOptions.length - 1;
    }
    selectNextChip() {
        if (!this.selectedOptions.length)
            return;
        this.selectedChipIndex =
            this.selectedChipIndex !== null ? (this.selectedChipIndex + 1) % this.selectedOptions.length : 0;
    }
    selectOption(option) {
        if (this.selectedOptions.includes(option))
            return;
        this.selectedOptions = [...this.selectedOptions, option];
        this.inputValue = '';
        this.focusInput();
        this.dispatchChangeEvent();
    }
    clearInput() {
        this.inputValue = '';
    }
    onKeydown_(event, option) {
        if (event.code === 'Enter') {
            this.selectOption(option);
        }
    }
    floatLabel(inputValue, options) {
        return inputValue || options.length;
    }
    removeItemAtIndex(selectedIndex) {
        this.selectedOptions = this.selectedOptions.filter((option, index) => index !== selectedIndex);
        this.dispatchChangeEvent();
    }
    removeItem(option) {
        this.selectedOptions = this.selectedOptions.filter((o) => o !== option);
        this.focusInput();
        this.dispatchChangeEvent();
    }
    dispatchChangeEvent() {
        /** @type {import('../../js/utils/types.js').InputMultipleStringsEvent} */
        const changeEvent = new CustomEvent('change', {
            detail: this.selectedOptions,
        });
        this.dispatchEvent(changeEvent);
    }
    focusInput() {
        this.shadowRoot.getElementById('input').focus();
    }
    isInputDisabled(options) {
        return this.chipLimit && options.length >= this.chipLimit;
    }
    onFocus() {
        this.focused = true;
        this.dispatchEvent(new CustomEvent('focus'));
    }
    onBlur() {
        this.focused = false;
        this.hasInteraction_ = true;
    }
    checkValidity() {
        if (this.required) {
            return this.selectedOptions.length > 0;
        }
        return true;
    }
    /**
     * @description suppress warnings until the user has interacted (blurred) the input
     * because of this a pattern is needed to trigger warning if input is too short.
     * UNLESS - the showWarning property is set to true
     */
    showWarning_() {
        return this.showWarning || (this.hasInteraction_ ? !this.checkValidity() : false);
    }
    static get styles() {
        return [jhaStyles, styles];
    }
    render() {
        return html `
      <jha-form-floating-group
        ?outline=${this.outline}
        ?always-float=${Boolean(this.placeholder)}
        ?small=${this.small}
        ?filled=${this.filled}
        .hasValue=${Boolean((this.selectedOptions || []).length > 0 || this.inputValue)}
        .error=${this.showWarning_() ? this.warning : null}>
        ${this.showSearchIcon ? html ` <jha-icon-search slot="input-left"></jha-icon-search> ` : ''}
        ${this.showClearInputButton && Boolean(this.inputValue)
            ? html `
              <button
                button-reset
                type="button"
                slot="input-right"
                class="clear-input"
                @click=${() => this.clearInput()}>
                <jha-icon-circle-close></jha-icon-circle-close>
              </button>
            `
            : ''}
        ${this.label
            ? html `
              <label
                for=${this.id}
                class="label">
                ${this.required
                ? html `
                      ${this.label}
                      ${this.hideRequiredIndicator ? '' : html ` <span class="required-indicator">*</span> `}
                    `
                : this.label}
              </label>
            `
            : ''}
        <div class="input">
          ${this.selectedOptions.map((o, i) => html `
              <div
                class="chip"
                ?selected=${i === this.selectedChipIndex}>
                <span>${o}</span>
                <button @click=${() => this.removeItem(o)}>
                  <jha-icon-close></jha-icon-close>
                </button>
              </div>
            `)}
          <input
            id="input"
            type="text"
            ?disabled=${this.disabled || this.isInputDisabled(this.selectedOptions)}
            @keyup=${this.onInputKeyup}
            .value=${this.inputValue}
            @blur=${this.onBlur}
            @focus=${this.onFocus}
            ?required=${this.required}
            placeholder=${this.placeholder} />
        </div>
        ${this.showWarning_() && this.warning
            ? ''
            : html `
              ${this.helperText || this.chipLimit
                ? html `
                    <div
                      class="info-area"
                      slot="assistive-text">
                      <div class="helperText">${this.helperText}</div>
                      ${this.chipLimit
                    ? html ` <div class="tagLimit">${this.selectedOptions.length}/${this.chipLimit}</div> `
                    : ''}
                    </div>
                  `
                : ''}
            `}
        <div
          class="options-dropdown"
          ?show=${this.inputValue}>
          ${this.options.some((o) => this.filterDropDown(o))
            ? html `
                <ul tabindex="0">
                  ${this.options
                .filter((o) => this.filterDropDown(o))
                .map((o) => html `
                        <li>
                          <button
                            @click=${() => this.selectOption(o)}
                            @keydown=${(evt) => this.onKeydown_(evt, o)}>
                            ${o}
                          </button>
                        </li>
                      `)}
                </ul>
              `
            : html `
                <div class="no-results">
                  ${this.allowUnknownValue
                ? html `
                        <ul tabindex="0">
                          <li>
                            <button
                              @click=${() => this.selectOption(this.inputValue)}
                              @keydown=${(evt) => this.onKeydown_(evt, this.inputValue)}>
                              ${this.inputValue}
                            </button>
                          </li>
                        </ul>
                      `
                : 'No results found'}
                </div>
              `}
        </div>
      </jha-form-floating-group>
    `;
    }
}
