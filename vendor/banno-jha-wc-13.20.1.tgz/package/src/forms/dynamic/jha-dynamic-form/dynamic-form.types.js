export const FULL_ROW_INPUTS = ['checkbox', 'radio', 'switch', 'textarea'];
export const inputTypes = [
    'checkbox',
    'currency',
    'date',
    'email',
    'phone',
    'url',
    'number',
    'radio',
    'select',
    'switch',
    'text',
    'textarea',
    'file',
    'percentage',
];
