import JhaDynamicForm from './JhaDynamicForm';
customElements.define('jha-dynamic-form', JhaDynamicForm);
/** @customElement jha-dynamic-form */
export default JhaDynamicForm;
