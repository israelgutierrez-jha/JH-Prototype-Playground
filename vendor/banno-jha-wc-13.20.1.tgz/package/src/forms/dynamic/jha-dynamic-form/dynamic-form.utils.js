import { getNestedValue } from '../../../js/utils/form-util.js';
import { deepMerge } from '@jkhy/frontend-utils/functions/object.helpers.js';
const setFormDataValue = ({ id, value, inputType, }) => {
    const propArray = id.split('.');
    return propArray.reverse().reduce((acc, key, index) => {
        if (index === 0) {
            acc[key] = inputType === 'number' && value ? parseFloat(value) : (value ?? '');
            return acc;
        }
        return { [key]: acc };
    }, {});
};
export const convertConfigToFormData = (config) => {
    let formData = {};
    config.blocks.forEach((block) => {
        block.rows.forEach((row) => {
            row.forEach((field) => {
                if (!field.id)
                    return;
                const fieldObject = setFormDataValue(field);
                formData = deepMerge(formData, fieldObject);
            });
        });
    });
    return formData;
};
export const valuesMatch = (value1, value2) => {
    if (value1 === value2)
        return true;
    if (typeof value1 === 'string' && typeof value2 === 'string') {
        return value1.toLowerCase() === value2.toLowerCase();
    }
    if (typeof value1 === 'number' || typeof value2 === 'number') {
        const value1Number = typeof value1 === 'number' ? value1 : parseFloat(value1);
        const value2Number = typeof value2 === 'number' ? value2 : parseFloat(value2);
        return value1Number === value2Number;
    }
    if (Array.isArray(value1) && Array.isArray(value2)) {
        return value1.every((val) => value2.includes(val));
    }
    return false;
};
export const valueIncludes = (value, searchValue) => {
    if (Array.isArray(value)) {
        return value.some((val) => valuesMatch(val, searchValue));
    }
    return value.toLowerCase().includes(searchValue.toLowerCase());
};
export const conditionMet = (inputCondition, formData) => {
    const { propertyName, value, condition } = inputCondition;
    const actualValue = getNestedValue(formData, propertyName);
    if (!['hasValue', 'noValue'].includes(condition) && [undefined, null, ''].includes(actualValue)) {
        return false;
    }
    switch (condition) {
        case 'hasValue':
            return ![undefined, null, ''].includes(actualValue);
        case 'noValue':
            return [undefined, null, ''].includes(actualValue);
        case 'equalTo':
            return valuesMatch(actualValue, value);
        case 'notEqualTo':
            return !valuesMatch(actualValue, value);
        case 'lessThan':
            return actualValue < value;
        case 'greaterThan':
            return actualValue > value;
        case 'includes':
            return valueIncludes(actualValue, value);
        case 'excludes':
            return !valueIncludes(actualValue, value);
        case 'oneOf':
            return value.includes(actualValue);
        case 'notOneOf':
            return !value.includes(actualValue);
        case 'lengthEqualTo':
            return actualValue.length === value;
        case 'lengthNotEqualTo':
            return actualValue.length !== value;
        case 'lengthLessThan':
            return actualValue.length < value;
        case 'lengthGreaterThan':
            return actualValue.length > value;
        default:
            return false;
    }
};
export const blockConditionsMet = (inputConditions, formData) => {
    return inputConditions.every((condition) => conditionMet(condition, formData));
};
