var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { LitElement, html, css } from 'lit';
import { property, state } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import { jhaStyles } from '../../../styles/jha-styles.js';
import { FULL_ROW_INPUTS } from './dynamic-form.types';
import formElementMixin from '../../../js/mixins/form-element-mixin';
import { convertConfigToFormData, blockConditionsMet } from './dynamic-form.utils';
import { getNestedValue } from '../../../js/utils/form-util.js';
import '../../jha-form-row/jha-form-row.js';
import '../jha-dynamic-input/jha-dynamic-input.js';
import '@jack-henry/jh-elements/components/button/button.js';
const styles = css `
  :host {
    display: block;
    height: 100%;
  }

  jha-form-row {
    align-items: flex-end;
    flex-wrap: wrap;
    content-visibility: auto;
    contain-intrinsic-size: var(--jha-form-row-intrinsic-size, auto 100px);
  }

  .content {
    padding: 0 3px; /* prevents focus border cut off */
    height: 100%;
    overflow: auto;
  }

  :host([scroll-navigation]) .section:last-of-type {
    min-height: var(--form-height, 0);
    margin-bottom: 0;
  }

  .section {
    border-top: 1px solid var(--jha-form-section-border, var(--jh-color-divider-primary));
    margin: var(--jha-form-section-margin, 0 0 24px 0);
    padding: var(--jha-form-section-padding, 16px 0 0 0);
    content-visibility: auto;
    contain-intrinsic-size: var(--jha-form-section-intrinsic-size, auto 100px);
  }

  .section:first-of-type {
    border-top: none;
    margin-top: 0;
    padding-top: 0;
  }

  .content-section {
    margin: var(--jha-form-section-margin, 24px 0 0 0);
    padding: var(--jha-form-section-padding, 0);
  }

  .content-section:first-of-type {
    border-top: none;
    margin-top: 0;
    padding-top: 0;
  }

  .section-header {
    margin: var(--jha-form-section-description-margin, 0);
  }

  .section-header h3 {
    margin: 0;
  }

  .layout-grid {
    column-width: var(--jha-form-grid-column-min-width, 300px);
    column-gap: var(--jha-form-grid-column-gap, 40px);
    column-rule: var(--jha-dimension-25, 1px) solid var(--jh-color-divider-primary, var(--jha-border-color));
  }

  .layout-grid .block-header h4 {
    --jha-form-block-title-border-bottom: var(--jha-dimension-25, 1px) solid
      var(--jh-color-divider-secondary, var(--jha-border-color));
    padding-bottom: var(--jha-form-grid-block-title-padding-bottom, 4px);
    margin-bottom: var(--jha-form-grid-block-title-margin-bottom, 4px);
  }

  .block {
    break-inside: avoid;
    margin: var(--jha-form-block-margin, 24px 0 0 0);
    padding: var(--jha-form-block-padding, 24px 0 0 0);
    border-top: 1px solid var(--jha-form-block-border, var(--jh-color-divider-secondary, --jha-border-color));
    content-visibility: auto;
    contain-intrinsic-size: var(--jha-form-block-intrinsic-size, auto 100px);
  }

  .block:first-of-type {
    border-top: none;
    margin-top: 0;
    padding-top: 0;
  }

  .layout-grid .block {
    border-top: none;
    margin-top: 0;
    padding-top: 0;
    margin-bottom: var(--jha-form-grid-block-margin-bottom, 24px);
    padding-bottom: var(--jha-form-grid-block-padding-bottom, 0);
  }

  .content-block {
    break-inside: avoid;
  }

  .layout-grid .content-block {
    border-top: none;
    margin-top: 0;
    padding-top: 0;
  }

  .block-header {
    margin: var(--jha-form-block-description-margin, 0);
  }

  h4 {
    margin: 0;
  }

  .block-header h4 {
    color: var(--jha-form-block-title-color, inherit);
    font-size: var(--jha-form-block-title-font-size, inherit);
    border-bottom: var(--jha-form-block-title-border-bottom, none);
  }

  p {
    margin: var(--jha-form-block-description-margin, 0 0 8px 0);
  }

  footer {
    display: flex;
    justify-content: var(--jha-form-footer-justify, flex-start);
    gap: 8px;
    margin: var(--jha-form-footer-margin, 0 0 16px 0);
  }
`;
/**
 * @element jha-dynamic-form
 * @cssprop --jha-form-row-intrinsic-size - Controls `contain-intrinsic-size` on form rows. Default: `auto 200px`.
 * @cssprop --jha-form-section-intrinsic-size - Controls `contain-intrinsic-size` on form sections. Default: `auto 200px`.
 * @cssprop --jha-form-block-intrinsic-size - Controls `contain-intrinsic-size` on form blocks. Default: `auto 200px`.
 */
export default class JhaDynamicForm extends formElementMixin(LitElement) {
    constructor() {
        super(...arguments);
        this.formData = {};
        this.cacheData = false;
        this.cacheId = '';
        this.scrollNavigation = false;
        /**
         * Fraction of the viewport height (0–1) used as the reference line for
         * scroll-spy detection. A section becomes "active" when its top edge
         * scrolls above this point. Useful for accommodating sticky headers.
         * @attr scroll-threshold
         * @prop {Number} scrollThreshold - Default: 0.33 (top third of viewport)
         */
        this.scrollThreshold = 0.33;
        this.hideFooter = false;
        this.readOnlyLayout = null;
        this.inputSize = 'medium';
        this.visibleSectionId = null;
        /** ResizeObserver for detecting layout size changes (if constrained ancestor exists) */
        this._resizeObserver = null;
        /** Cached constrained ancestor container to observe instead of `this` (prevents height feedback loops) */
        this._resizeContainer = null;
        /** When true, suppresses IO-driven section change during programmatic scroll */
        this._programmaticScroll = false;
        this._programmaticScrollTimer = null;
        this._scrollDebounceTimer = null;
        /** Fallback listener for viewport resize when no constrained ancestor exists */
        this.onWindowResize_ = () => this.updateFormHeight();
        this._defaultFormData = {};
        this._intersectionObserver = null;
        this.handleScroll = () => {
            if (this._programmaticScroll)
                return;
            if (!(this.scrollNavigation || this.hasAttribute('scroll-navigation'))) {
                return;
            }
            this.debouncedUpdateVisibleSection_();
        };
        /**
         * IntersectionObserver callback — triggers visible section recalculation
         * when sections enter or leave the viewport.
         */
        this._onIntersections = (entries) => {
            if (this._programmaticScroll)
                return;
            if (!(this.scrollNavigation || this.hasAttribute('scroll-navigation'))) {
                return;
            }
            this.updateVisibleSection_();
        };
        this.inputValueChange = (evt) => {
            super.inputValueChange(evt);
            this.dispatchEvent(new CustomEvent('jh-form-data-change', {
                detail: {
                    formData: this.formData,
                    config: this.config,
                },
                bubbles: true,
                composed: true,
            }));
        };
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        if (this._resizeObserver) {
            this._resizeObserver.disconnect();
            this._resizeObserver = null;
        }
        if (this._scrollDebounceTimer !== null) {
            clearTimeout(this._scrollDebounceTimer);
            this._scrollDebounceTimer = null;
        }
        if (this._programmaticScrollTimer !== null) {
            clearTimeout(this._programmaticScrollTimer);
            this._programmaticScrollTimer = null;
        }
        if (this._intersectionObserver) {
            this._intersectionObserver.disconnect();
            this._intersectionObserver = null;
        }
        this._resizeContainer = null;
        window.removeEventListener('resize', this.onWindowResize_);
    }
    handleFormSubmit(evt) {
        this.dispatchEvent(new CustomEvent('jh-form-submit', {
            detail: {
                formData: this.formData,
                config: this.config,
            },
            bubbles: true,
            composed: true,
        }));
    }
    handleFormCancel() {
        this.dispatchEvent(new CustomEvent('jh-form-cancel', {
            bubbles: true,
            composed: true,
        }));
    }
    handleCancelKeydown(event) {
        if (event.key === 'Enter') {
            this.handleFormCancel();
        }
    }
    /**
     * Walk up the DOM tree to find a constrained ancestor container.
     *
     * This prevents a resize runaway loop where:
     * 1. Component measures its own height (self-referential)
     * 2. Sets --form-height CSS variable (used as min-height on form sections)
     * 3. The host grows to accommodate that height
     * 4. ResizeObserver fires again, triggering step 1, causing unbounded growth
     *
     * By observing a constrained ancestor instead, we measure external layout
     * changes (parent window resize, layout shift) without feedback from our own
     * CSS mutations.
     *
     * @returns First ancestor with scrollable overflow or max-height constraint, or null
     */
    getResizeContainer() {
        let currentContainer = this.parentElement;
        while (currentContainer) {
            const { overflowY, overflow, maxHeight, position } = getComputedStyle(currentContainer);
            const scrollOverflowValues = ['auto', 'scroll', 'overlay'];
            const isScrollableContainer = scrollOverflowValues.includes(overflowY) || scrollOverflowValues.includes(overflow);
            const hasConstrainedHeight = maxHeight !== 'none' || position === 'fixed';
            if (isScrollableContainer || hasConstrainedHeight) {
                return currentContainer;
            }
            currentContainer = currentContainer.parentElement;
        }
        return null;
    }
    /**
     * Calculate and update the available height for the form's scrollable content area.
     *
     * Height strategy prioritizes stability and prevents growth loops:
     * 1. If a constrained ancestor exists (from getResizeContainer), use its height.
     *    This ensures the form caps at a known, external constraint.
     * 2. Otherwise, calculate available viewport height below the form's top position.
     *    This avoids self-referential measurement of an auto-sized host.
     * 3. Subtract footer height to leave space for form actions.
     * 4. Use strict equality guard when writing --form-height to prevent redundant
     *    DOM mutations that could re-trigger ResizeObserver in edge cases.
     *
     * The --form-height CSS variable is used by :host([scroll-navigation]) .section:last-of-type
     * as a min-height constraint for smooth scroll navigation behavior.
     */
    updateFormHeight() {
        // Support boolean property or presence-based attribute binding from consumers.
        if (!(this.scrollNavigation || this.hasAttribute('scroll-navigation'))) {
            return;
        }
        const footer = this.renderRoot.querySelector('footer');
        const containerHeight = this._resizeContainer?.clientHeight;
        const { top } = this.getBoundingClientRect();
        const viewportHeight = Math.max(window.innerHeight - Math.max(top, 0), 0);
        const baseHeight = containerHeight ?? viewportHeight;
        const height = Math.max(baseHeight - (footer?.clientHeight || 0), 0);
        const newValue = `${height}px`;
        // Guard against re-entrancy: only write the property when the value
        // actually changes, preventing the ResizeObserver feedback loop where
        // setting --form-height (used as min-height on the last section) causes
        // the host to resize and re-trigger this callback.
        if (this.style.getPropertyValue('--form-height') !== newValue) {
            this.style.setProperty('--form-height', newValue);
        }
    }
    debouncedUpdateVisibleSection_() {
        if (this._scrollDebounceTimer !== null) {
            clearTimeout(this._scrollDebounceTimer);
        }
        this._scrollDebounceTimer = window.setTimeout(() => {
            this.updateVisibleSection_();
        }, 100);
    }
    /**
     * Determine visible section by finding the last section whose top edge
     * has scrolled past a reference line near the top of the viewport.
     * Works regardless of which ancestor is scrolling.
     */
    updateVisibleSection_() {
        let visibleSectionId = null;
        const headers = this.sectionHeaders;
        // Reference line: fraction of viewport height (configurable via scrollThreshold)
        const referenceLine = Math.round(window.innerHeight * this.scrollThreshold);
        headers.forEach((header) => {
            if (header.getBoundingClientRect().top <= referenceLine) {
                visibleSectionId = header?.id || null;
            }
        });
        if (this.visibleSectionId !== visibleSectionId) {
            this.visibleSectionId = visibleSectionId;
            this.dispatchEvent(new CustomEvent('jh-form-visible-section-change', {
                detail: this.visibleSectionId,
                bubbles: true,
                composed: true,
            }));
        }
    }
    firstUpdated(changedProperties) {
        if (changedProperties.has('config')) {
            this.initializeFormData();
        }
        this._resizeContainer = this.getResizeContainer();
        this.updateFormHeight();
        if (this._resizeContainer) {
            this._resizeObserver = new ResizeObserver(this.updateFormHeight.bind(this));
            this._resizeObserver.observe(this._resizeContainer);
        }
        else {
            window.addEventListener('resize', this.onWindowResize_);
        }
        // IntersectionObserver is the primary mechanism for detecting which section
        // is visible. Uses viewport (root: null) so it works regardless of which
        // ancestor element is scrolling — even across shadow DOM boundaries.
        this._intersectionObserver = new IntersectionObserver(this._onIntersections, {
            root: null,
            threshold: Array.from({ length: 20 }, (_, i) => i / 19),
        });
        const sections = this.sectionHeaders;
        sections.forEach((h) => this._intersectionObserver?.observe(h));
        super.firstUpdated(changedProperties);
    }
    initializeFormData() {
        if (Object.keys(this.formData).length === 0) {
            this.formData = convertConfigToFormData(this.config);
        }
    }
    static get styles() {
        return [jhaStyles, styles];
    }
    get sectionHeaders() {
        return this.renderRoot.querySelectorAll('.section');
    }
    scrollToSection(sectionId) {
        const activeSectionHeaderElement = sectionId && this.renderRoot.querySelector(`#${sectionId}.section`);
        if (!activeSectionHeaderElement)
            return;
        // Suppress IO-driven updates while programmatic scroll animates
        this._programmaticScroll = true;
        if (this._programmaticScrollTimer !== null) {
            clearTimeout(this._programmaticScrollTimer);
        }
        // Re-enable after scroll animation settles (smooth scroll ~300-800ms)
        this._programmaticScrollTimer = window.setTimeout(() => {
            this._programmaticScroll = false;
            this._programmaticScrollTimer = null;
        }, 1000);
        this.visibleSectionId = sectionId;
        activeSectionHeaderElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    renderRow(row, disableInputs) {
        if (row.length === 0) {
            return html ``;
        }
        return html `
      <jha-form-row>
        ${row.map((field) => {
            const { size, inputType } = field;
            let fieldSize = size;
            if (FULL_ROW_INPUTS.includes(inputType)) {
                fieldSize = 4;
            }
            if (!fieldSize) {
                fieldSize = Math.floor(4 / row.length);
            }
            return html `
            <jha-dynamic-input
              input-size=${this.inputSize}
              data-id=${field.id}
              .fieldConfig=${field}
              .disabled=${disableInputs}
              .size=${fieldSize}
              .rowLength=${row.length}
              .readOnly=${field.readOnly || false}
              .readOnlyLayout=${this.readOnlyLayout}
              .value=${getNestedValue(this.formData, field.id) || field.value || ''}
              @jh-input-change=${this.inputValueChange}></jha-dynamic-input>
          `;
        })}
      </jha-form-row>
    `;
    }
    renderBlock(block) {
        const { label, description, id, rows, conditions } = block;
        const conditionMet = conditions ? blockConditionsMet(conditions.inputs, this.formData) : true;
        if (!conditionMet && conditions?.conditionType === 'hidden') {
            return '';
        }
        return html `
      <div
        class=${classMap({
            block: !conditions,
            'content-block': true,
        })}
        id="${id}">
        ${label || description
            ? html `
              <div
                class="block-header"
                ?active=${this.visibleSectionId === id}>
                ${label ? html ` <h4>${label}</h4> ` : ''} ${description ? html ` <p>${description}</p> ` : ''}
              </div>
            `
            : ''}
        ${rows.map((row) => this.renderRow(row, !conditionMet))}
      </div>
    `;
    }
    renderFooter() {
        const { submitButtonLabel, cancelButtonLabel, showCancelButton } = this.config;
        if (this.hideFooter) {
            return '';
        }
        return html `
      <footer>
        ${showCancelButton
            ? html `
              <jh-button
                appearance="secondary"
                type="button"
                size="small"
                @click="${this.handleFormCancel}"
                @keydown="${this.handleCancelKeydown}"
                label="${cancelButtonLabel || 'Cancel'}"></jh-button>
            `
            : ''}
        <jh-button
          appearance="primary"
          size="small"
          @click="${this.handleFormSubmit}"
          ?disabled=${!this.formValid || !this.formDirty}
          label="${submitButtonLabel || 'Submit'}"></jh-button>
      </footer>
    `;
    }
    renderFormContent() {
        const { sections, blocks } = this.config;
        if (sections && sections.length > 0) {
            return sections.map((section) => {
                const { label, description, id, layout, blocks } = section;
                return html `
          <div
            class="section"
            id="${id}">
            ${label || description
                    ? html `
                  <div
                    class="section-header"
                    ?active=${this.visibleSectionId === id}>
                    ${label ? html ` <h3>${label}</h3> ` : ''} ${description ? html ` <p>${description}</p> ` : ''}
                  </div>
                `
                    : ''}
            <div
              class=${classMap({
                    'content-section': true,
                    'layout-grid': layout === 'grid',
                })}>
              ${blocks.map((block) => this.renderBlock(block))}
            </div>
          </div>
        `;
            });
        }
        else if (blocks && blocks.length > 0) {
            return blocks.map((block) => this.renderBlock(block));
        }
        else {
            return html ``;
        }
    }
    renderForm() {
        const { title, id } = this.config;
        return html `
      <div
        class="content"
        @scroll=${this.handleScroll}>
        <header>
          <h3>${title}</h3>
        </header>
        <form
          id="${id}"
          tabindex="-1">
          ${this.renderFormContent()} ${this.renderFooter()}
        </form>
      </div>
    `;
    }
    render() {
        if (!this.config) {
            return html ``;
        }
        return this.renderForm();
    }
}
__decorate([
    property({ type: Object }),
    __metadata("design:type", Object)
], JhaDynamicForm.prototype, "config", void 0);
__decorate([
    property({ type: Object }),
    __metadata("design:type", Object)
], JhaDynamicForm.prototype, "formData", void 0);
__decorate([
    property({ type: Boolean }),
    __metadata("design:type", Boolean)
], JhaDynamicForm.prototype, "cacheData", void 0);
__decorate([
    property({ type: String }),
    __metadata("design:type", String)
], JhaDynamicForm.prototype, "cacheId", void 0);
__decorate([
    property({ type: Boolean, reflect: true, attribute: 'scroll-navigation' }),
    __metadata("design:type", Boolean)
], JhaDynamicForm.prototype, "scrollNavigation", void 0);
__decorate([
    property({ type: Number, attribute: 'scroll-threshold' }),
    __metadata("design:type", Number)
], JhaDynamicForm.prototype, "scrollThreshold", void 0);
__decorate([
    property({ type: Boolean, reflect: true, attribute: 'hide-footer' }),
    __metadata("design:type", Boolean)
], JhaDynamicForm.prototype, "hideFooter", void 0);
__decorate([
    property({ type: String }),
    __metadata("design:type", String)
], JhaDynamicForm.prototype, "readOnlyLayout", void 0);
__decorate([
    property({ type: String, attribute: 'input-size' }),
    __metadata("design:type", String)
], JhaDynamicForm.prototype, "inputSize", void 0);
__decorate([
    state(),
    __metadata("design:type", String)
], JhaDynamicForm.prototype, "visibleSectionId", void 0);
export { styles as JhaDynamicFormStyles };
