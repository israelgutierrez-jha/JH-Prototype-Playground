var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { LitElement, html, css, nothing } from 'lit';
import { property, state } from 'lit/decorators.js';
import { jhaStyles } from '../../../../styles/jha-styles.js';
import './BlockEditor';
const styles = css `
  :host {
    border: 1px solid var(--jha-border-color, #e4e7ea);
    display: block;
    padding: 24px 0 16px 0;
    position: relative;
    margin: 16px 0;
  }

  :host([minimized]) {
    padding: 16px 0;
  }

  :host([show-warning])::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    border-left: 4px solid var(--jha-color-warning, #c98702);
  }

  :host(.dragged-over) {
    background-color: var(--jha-color-light, var(--secondary-content-background-color)) !important;
  }

  :host > div {
    display: flex;
    justify-content: space-between;
    position: relative;
    position: relative;
    width: calc(100% - 36px);
    margin-left: 36px;
    height: 100%;
  }
  :host span.icon-wrapper {
    display: flex;
    /*cursor: -webkit-grab;*/
    /*cursor: -moz-grab;*/
    /*cursor: grab;*/
    width: 24px;
    flex: 0 1 24px;
    align-self: stretch;
    align-items: center;
    justify-content: flex-end;
    margin-left: -30px;
    cursor: move;
    background: transparent;
  }
  svg {
    fill: var(--jha-list-organizer-handle-color, var(--jha-text-theme));
  }
  :host([drag='true']) {
    background-color: var(--jha-color-light, var(--secondary-content-background-color)) !important;
    border-bottom: none !important;
  }
  :host([clone='true']) {
    box-shadow:
      0 1px 1px 0 rgba(0, 0, 0, 0.24),
      0 1px 4px rgba(0, 0, 0, 0.12);
  }
  :host ::slotted(*) {
    width: 100%;
  }
  :host([draggable='false']) > div {
    display: block;
    margin: 0;
  }
  :host([draggable='false']) span.icon-wrapper {
    display: none;
  }

  .content {
    flex: 2;
    border-left: 1px solid var(--jha-color-light, #f0f5f9);
    padding: 0 8px;
  }
  .content[minimized] {
    display: none;
  }

  .label {
    position: absolute;
    --jha-input-label-font-size: 16px;
    color: var(--jha-text-light, #8c989f);
    background-color: var(--jha-component-background-color, #fff);
    font-weight: 400;
    padding: 3px 4px;
    font-size: 14;
    top: -12px;
    left: 16px;
    width: auto;
  }

  .minimized {
    display: flex;
    border-left: 1px solid var(--jha-border-color, #e4e7ea);
    margin-left: 8px;
    padding: 8px 16px;
    font-size: 16px;
    align-items: center;
  }

  .label jha-icon-chevron-down {
    vertical-align: middle;
    transform: rotate(180deg);
    margin-left: -8px;
  }

  .minimized:hover,
  .label:hover {
    color: var(--jha-color-primary);
    text-decoration: underline;
  }

  .minimized:hover jha-icon-chevron-down,
  .label:hover jha-icon-chevron-down {
    fill: var(--jha-color-primary);
  }

  .remove-block {
    flex: 0;
    padding: 0 12px;
  }
  .remove-block:hover jha-icon-delete {
    fill: var(--jha-color-primary);
  }
`;
/**
 * @element jha-dynamic-block
 */
export default class JhaDynamicBlock extends LitElement {
    constructor() {
        super(...arguments);
        this.minimized = true;
        this.showWarning = false;
    }
    static get styles() {
        return [jhaStyles, styles];
    }
    dispatchEditBlock() {
        this.dispatchEvent(new CustomEvent('edit-block', {
            detail: this.block.id,
            bubbles: true,
            composed: true,
        }));
    }
    handleUpdatedBlock(event) {
        this.block = { ...event.detail.block };
    }
    handleRemoveBlock() {
        this.dispatchEvent(new CustomEvent('remove-block', {
            detail: this,
            bubbles: true,
            composed: true,
        }));
    }
    renderMinimizedView() {
        return html `
      <button
        button-reset
        type="button"
        class="minimized"
        @click=${this.dispatchEditBlock}>
        <span>${this.block.label}</span>
        <jha-icon-chevron-down></jha-icon-chevron-down>
      </button>
      <button
        button-reset
        type="button"
        class="remove-block"
        @click=${this.handleRemoveBlock}>
        <jha-icon-delete></jha-icon-delete>
      </button>
    `;
    }
    renderOpenView() {
        return html `
      <div
        class="content"
        ?minimized=${this.minimized}>
        <block-editor
          id="main"
          .block=${this.block}></block-editor>
      </div>
    `;
    }
    render() {
        return html `
      ${!this.minimized
            ? html `
            <button
              class="label"
              button-reset
              type="button"
              @click=${this.dispatchEditBlock}>
              ${this.block.label}
              <jha-icon-chevron-down></jha-icon-chevron-down>
            </button>
          `
            : nothing}
      <div>
        <!-- We can't use a custom element here. Event re-targeting kills drag events on Safari -->
        <span
          class="icon-wrapper"
          drag-item>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            aria-label="Drag to move account">
            <path d="M8,18h2v-2H8V18z M8,13h2v-2H8V13z M8,6v2h2V6H8z"></path>
            <path d="M13,18h2v-2h-2V18z M13,13h2v-2h-2V13z M13,6v2h2V6H13z"></path>
          </svg>
        </span>
        ${this.minimized ? this.renderMinimizedView() : nothing} ${this.renderOpenView()}
      </div>
    `;
    }
}
__decorate([
    property({ type: Object }),
    __metadata("design:type", Object)
], JhaDynamicBlock.prototype, "block", void 0);
__decorate([
    property({ type: Boolean }),
    __metadata("design:type", Object)
], JhaDynamicBlock.prototype, "minimized", void 0);
__decorate([
    state(),
    __metadata("design:type", Object)
], JhaDynamicBlock.prototype, "showWarning", void 0);
export { styles as JhaDynamicBlockStyles };
