import JhaDynamicBlock from './JhaDynamicBlock';
customElements.define('jha-dynamic-block', JhaDynamicBlock);
/** @customElement jha-dynamic-block */
export default JhaDynamicBlock;
