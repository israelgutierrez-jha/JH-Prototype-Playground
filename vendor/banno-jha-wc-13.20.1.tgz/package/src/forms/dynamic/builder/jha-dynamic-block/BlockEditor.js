var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { LitElement, html, css, nothing } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { customElement, property, state } from 'lit/decorators.js';
import { jhaStyles } from '../../../../styles/jha-styles.js';
import { FULL_ROW_INPUTS } from '../../jha-dynamic-form/dynamic-form.types.js';
import { inputFields, getUniqueInput } from '../jha-dynamic-field/dynamic-field.utils.js';
import '@jack-henry/jh-elements/components/checkbox/checkbox.js';
import '../../../../jha-flex-wrapper/jha-flex-wrapper.js';
import '../jha-dynamic-field/FieldMenu';
import '../jha-dynamic-field/jha-dynamic-field.js';
const styles = css `
  section {
    display: block;
    padding: 0 8px;
    margin: 16px 0;
  }
  jha-form-row {
    padding: 16px 0 0 0;
    --jha-form-row-gap-horizontal: 0;
    position: relative;
  }
  .remove-block {
    flex: 0 1 0%;
    margin-right: 4px;
    margin-top: 7px;
  }
  .remove-block:hover jha-icon-delete {
    fill: var(--jha-color-primary);
  }
  jh-input {
    --jh-input-color-background: transparent;
  }
  #left,
  #right {
    position: absolute;
    height: 50px;
    width: 50%;
    top: 16px;
  }
  #left {
    left: 0;
  }
  #right {
    right: 0;
  }
`;
let BlockEditor = class BlockEditor extends LitElement {
    constructor() {
        super(...arguments);
        this.editingField = '';
    }
    static get styles() {
        return [jhaStyles, styles];
    }
    get dynamicFields() {
        return Array.from(this.shadowRoot.querySelectorAll('jha-form-row jha-dynamic-field'));
    }
    get rows() {
        return Array.from(this.shadowRoot.querySelectorAll('jha-form-row'));
    }
    handleRemoveBlock() {
        this.dispatchEvent(new CustomEvent('remove-block', {
            detail: this,
            bubbles: true,
            composed: true,
        }));
    }
    extendBlock(blockObject) {
        return { ...this.block, ...blockObject };
    }
    dispatchUpdatedBlock(block) {
        this.dispatchEvent(new CustomEvent('updated-block', {
            detail: this.extendBlock(block),
            bubbles: true,
            composed: true,
        }));
    }
    rowChildFields(row) {
        const childArray = Array.from(row.children);
        return childArray.filter((childEl) => childEl.tagName === 'JHA-DYNAMIC-FIELD');
    }
    rowContainsChild(row, fieldId) {
        return this.rowChildFields(row).some(({ field: { id } }) => id === fieldId);
    }
    async dragStart_(event) {
        event.stopImmediatePropagation();
        let isDragItem = false;
        let element = event.target.shadowRoot.elementFromPoint(event.clientX, event.clientY);
        while (element) {
            isDragItem = element.hasAttribute('drag-item');
            element = !isDragItem ? element.parentElement : undefined;
        }
        if (isDragItem) {
            this.dragField_ = event.currentTarget;
            const { dataTransfer } = event;
            dataTransfer.effectAllowed = 'move';
            window.requestAnimationFrame(() => {
                document.body.style.userSelect = 'none';
                this.dragField_.setAttribute('drag', 'true');
            });
        }
        else {
            event.preventDefault();
        }
    }
    async dragEnd_() {
        if (!this.dragField_)
            return;
        await this.updateComplete;
        this.dynamicFields.forEach((block) => block.removeAttribute('drag'));
        this.dragField_ = undefined;
        document.body.style.removeProperty('user-select');
    }
    drop_(event) {
        event.stopPropagation();
        event.preventDefault();
    }
    dragEnterField_(draggingOverField, draggingOver) {
        const targetIndex = this.rows.indexOf(draggingOverField.parentElement);
        if (this.rowContainsChild(draggingOverField.parentElement, this.dragField_.field.id)) {
            this.dispatchUpdatedBlock({
                rows: this.block.rows.toSpliced(targetIndex, 1, [
                    this.block.rows[targetIndex][1],
                    this.block.rows[targetIndex][0],
                ]),
            });
        }
        else {
            this.dispatchUpdatedBlock({
                rows: this.block.rows.reduce((rows, row, index) => {
                    if (index === targetIndex) {
                        const updatedRow = draggingOver.some((el) => el.id === 'left')
                            ? [this.dragField_.field, ...row]
                            : [...row, this.dragField_.field];
                        return [...rows, updatedRow];
                    }
                    const filteredRow = row.filter((field) => field.id !== this.dragField_.field.id);
                    const filteredRows = [...rows, filteredRow.length ? filteredRow : undefined].filter(Boolean);
                    return filteredRows;
                }, []),
            });
        }
    }
    dragEnterRow_(draggingOverRow) {
        const toRowIndex = this.rows.indexOf(draggingOverRow);
        this.dispatchUpdatedBlock({
            rows: this.block.rows.reduce((rows, row, index) => {
                const filteredRow = row.filter((field) => field.id !== this.dragField_.field.id);
                if (index === toRowIndex)
                    return [...rows, [this.dragField_.field], filteredRow.length ? filteredRow : undefined].filter(Boolean);
                const filteredRows = [...rows, filteredRow.length ? filteredRow : undefined].filter(Boolean);
                if (index === this.block.rows.length - 1 && index < toRowIndex)
                    return [...filteredRows, [this.dragField_.field]];
                return filteredRows;
            }, []),
        });
    }
    async dragEnter_(event) {
        event.stopImmediatePropagation();
        event.preventDefault();
        if (!this.dragField_)
            return;
        const targetEl = event.currentTarget;
        if (this.debounceDragEnter) {
            clearTimeout(this.debounceDragEnter);
            this.debounceDragEnter = null;
        }
        this.debounceDragEnter = setTimeout(() => {
            const draggingOver = targetEl.shadowRoot.elementsFromPoint(event.clientX, event.clientY);
            if (targetEl.tagName === 'JHA-DYNAMIC-FIELD' && targetEl.field.id !== this.dragField_.field.id) {
                if (FULL_ROW_INPUTS.includes(targetEl.field.inputType) ||
                    FULL_ROW_INPUTS.includes(this.dragField_.field.inputType) ||
                    (!this.rowContainsChild(targetEl.parentElement, this.dragField_.field.id) &&
                        this.rowChildFields(targetEl.parentElement).length === 2)) {
                    this.dragEnterRow_(targetEl.parentElement);
                }
                else {
                    this.dragEnterField_(targetEl, draggingOver);
                }
            }
            else if (targetEl.tagName === 'JHA-FORM-ROW' &&
                !(draggingOver.some((el) => el.tagName === 'JHA-DYNAMIC-FIELD') && this.rowChildFields(targetEl).length === 1)) {
                this.dragEnterRow_(targetEl);
            }
        }, 50);
    }
    dragOver_(event) {
        event.stopImmediatePropagation();
        event.preventDefault();
        const { dataTransfer } = event;
        dataTransfer.dropEffect = 'move';
    }
    renderBlockSettingsContent() {
        if (!this.showBlockSettings())
            return '';
        return html `
      <jh-input
        outline
        label="Label (optional)"
        .value=${this.block.label}
        @jh-change=${(event) => {
            this.dispatchUpdatedBlock({
                label: event.target.value,
            });
        }}></jh-input>

      <jh-input
        type="textarea"
        .value=${this.block.description}
        label="Description text (optional)"
        @jh-change=${(event) => {
            this.dispatchUpdatedBlock({
                description: event.target.value,
            });
        }}></jh-input>
    `;
    }
    showBlockSettings() {
        return this.block.description !== null && this.block.label !== null;
    }
    handleAddInput({ detail: input }) {
        this.dispatchUpdatedBlock({
            rows: [
                ...this.block.rows,
                [
                    getUniqueInput(input, this.dynamicFields.map((dynamicField) => dynamicField.field)),
                ],
            ],
        });
    }
    handleRemoveField({ currentTarget: row, srcElement: dynamicField }) {
        const updatedRow = Array.from(this.shadowRoot.querySelectorAll('jha-form-row'));
        const updatedRowIndex = updatedRow.indexOf(row);
        const updatedFieldIndex = Array.from(row.querySelectorAll('jha-dynamic-field')).indexOf(dynamicField);
        const newRow = this.block.rows[updatedRowIndex].toSpliced(updatedFieldIndex, 1);
        this.dispatchUpdatedBlock({
            rows: newRow.length > 0
                ? this.block.rows.toSpliced(updatedRowIndex, 1, newRow)
                : this.block.rows.toSpliced(updatedRowIndex, 1),
        });
    }
    handleUpdatedField({ currentTarget: row, srcElement: dynamicField, detail: field }) {
        const updatedRow = Array.from(this.shadowRoot.querySelectorAll('jha-form-row'));
        const updatedRowIndex = updatedRow.indexOf(row);
        const updatedFieldIndex = Array.from(row.querySelectorAll('jha-dynamic-field')).indexOf(dynamicField);
        this.dispatchUpdatedBlock({
            rows: this.block.rows.toSpliced(updatedRowIndex, 1, this.block.rows[updatedRowIndex].toSpliced(updatedFieldIndex, 1, field)),
        });
    }
    renderBlockSettings() {
        return html `
      <div class="settings">
        <jha-flex-wrapper space-between>
          <jh-checkbox
            @jh-change=${({ target: { checked } }) => {
            this.dispatchUpdatedBlock({
                description: checked ? this.block.description || '' : null,
                label: checked ? this.block.label || '' : 'Default block',
            });
        }}
            .checked=${this.showBlockSettings()}
            name="Add label/description"
            label="Add a label and description for the block."></jh-checkbox>
          <button
            button-reset
            type="button"
            class="remove-block"
            @click=${this.handleRemoveBlock}>
            <jha-icon-delete></jha-icon-delete>
          </button>
        </jha-flex-wrapper>

        ${this.renderBlockSettingsContent()}
      </div>
    `;
    }
    render() {
        return html `
      ${this.renderBlockSettings()}
      ${this.block.rows.map((row) => html `
          <jha-form-row
            @dragenter=${this.dragEnter_}
            @dragover=${this.dragOver_}
            @updated-field=${this.handleUpdatedField}
            @remove-field=${this.handleRemoveField}>
            ${repeat(row, (field) => field.id, (field) => html `
                ${!FULL_ROW_INPUTS.includes(field.inputType) && row.length === 1
            ? html `
                      <div id="left"></div>
                      <div id="right"></div>
                    `
            : nothing}
                <jha-dynamic-field
                  .field=${field}
                  draggable="true"
                  @dragstart=${this.dragStart_}
                  @dragend=${this.dragEnd_}
                  @drop=${this.drop_}
                  @dragover=${this.dragOver_}
                  @dragenter=${this.dragEnter_}
                  drag=${this.dragField_ && this.dragField_.field.id === field.id ? 'true' : 'false'}
                  .editing=${field.id === this.editingField}
                  @updated-field=${({ detail: { id } }) => {
            this.editingField = this.editingField ? id : this.editingField;
            setTimeout(() => {
                this.requestUpdate();
            });
        }}
                  @edit-field=${({ detail: id }) => {
            this.editingField = this.editingField === id ? '' : id;
        }}></jha-dynamic-field>
              `)}
          </jha-form-row>
        `)}
      <jha-form-row
        placeholder
        @dragenter=${this.dragEnter_}>
        <field-menu
          label="Add an input field"
          .fields=${inputFields}
          @field-selected=${this.handleAddInput}></field-menu>
      </jha-form-row>
    `;
    }
};
__decorate([
    property({ type: Object }),
    __metadata("design:type", Object)
], BlockEditor.prototype, "block", void 0);
__decorate([
    property({ attribute: false, hasChanged: () => false }),
    __metadata("design:type", Object)
], BlockEditor.prototype, "dragField_", void 0);
__decorate([
    property({ type: String }),
    __metadata("design:type", Object)
], BlockEditor.prototype, "editingField", void 0);
__decorate([
    state(),
    __metadata("design:type", void 0)
], BlockEditor.prototype, "debounceDragEnter", void 0);
BlockEditor = __decorate([
    customElement('block-editor')
], BlockEditor);
export default BlockEditor;
export { styles as BlockEditor };
