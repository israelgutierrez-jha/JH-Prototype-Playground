var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { LitElement, html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { query } from 'lit/decorators/query.js';
import { jhaStyles } from '../../../../styles/jha-styles.js';
import '@jack-henry/jh-elements/components/button/button.js';
import '@jack-henry/jh-elements/components/checkbox/checkbox.js';
import '@jack-henry/jh-elements/components/input/input.js';
import '@jack-henry/jh-elements/components/list-item/list-item.js';
import '@jack-henry/jh-elements/components/menu/menu.js';
import '../../../../jha-flex-wrapper/jha-flex-wrapper.js';
import '../../../../jha-popover/jha-popover.js';
import '../../../../icons/jha-icons.js';
const styles = css `
  jha-popover {
    display: block;
    width: 100%;
    font-size: 16px;
    font-weight: 500;
    margin: 0 auto;
  }
  jh-button {
    width: 100%;
  }
  h4 {
    color: var(--jha-text-theme, --jha-color-primary);
    margin: 0;
    font-weight: 16px;
  }
  jh-input,
  span {
    color: var(--jha-text-base);
  }
  .field-search {
    padding: 0px 16px;
  }
`;
let FieldMenu = class FieldMenu extends LitElement {
    constructor() {
        super(...arguments);
        this.fields = [];
        this.label = '';
        this.search = '';
    }
    static get styles() {
        return [jhaStyles, styles];
    }
    get filteredFields() {
        return this.fields.filter(({ label, description }) => label.toLowerCase().includes(this.search) || description.toLowerCase().includes(this.search));
    }
    dispatchFieldSelected({ icon, description, ...field }) {
        this.dispatchEvent(new CustomEvent('field-selected', {
            detail: field,
            bubbles: true,
            composed: true,
        }));
    }
    handleSearchInput(e) {
        this.search = (e.target?.value || '').toLowerCase().trim();
    }
    handleSelectField(field) {
        this.search = '';
        this._popover.closePopover();
        this.dispatchFieldSelected(field);
    }
    render() {
        return html `
      <jha-popover>
        <jh-button
          block
          label=${this.label}
          slot="button"
          appearance="secondary">
          <jh-icon-pencil slot="jh-button-icon-left"></jh-icon-pencil>
        </jh-button>
        <jh-menu>
          <jh-input
            placeholder="Search the list"
            show-clear-button
            type="search"
            size="small"
            class="field-search"
            @jh-clear=${this.handleSearchInput}
            @input=${this.handleSearchInput}></jh-input>
          ${this.filteredFields.map((field) => html `
              <jh-list-item
                @click=${() => this.handleSelectField(field)}
                tabindex="0">
                <jha-icons
                  medium
                  slot="jh-list-item-left"
                  .icon=${field.icon}></jha-icons>
                <div slot="jh-list-item-content">
                  <h4>${field.label}</h4>
                  <span>${field.description}</span>
                </div>
              </jh-list-item>
            `)}
        </jh-menu>
      </jha-popover>
    `;
    }
};
__decorate([
    property({ type: Array }),
    __metadata("design:type", Array)
], FieldMenu.prototype, "fields", void 0);
__decorate([
    property({ type: String }),
    __metadata("design:type", Object)
], FieldMenu.prototype, "label", void 0);
__decorate([
    property({ type: String }),
    __metadata("design:type", Object)
], FieldMenu.prototype, "search", void 0);
__decorate([
    query('jha-popover'),
    __metadata("design:type", Object)
], FieldMenu.prototype, "_popover", void 0);
FieldMenu = __decorate([
    customElement('field-menu')
], FieldMenu);
export default FieldMenu;
export { styles as FieldMenuStyles };
