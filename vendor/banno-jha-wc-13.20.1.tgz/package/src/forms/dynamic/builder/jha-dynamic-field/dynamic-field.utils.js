import { inputTypes } from '../../jha-dynamic-form/dynamic-form.types';
const inputs = {
    text: {
        description: 'Collect text from the user.',
        icon: 'user',
        label: 'Text input',
        id: 'textInput',
        characterLimit: undefined,
    },
    textarea: {
        description: 'Text area input.',
        icon: 'text',
        label: 'Text area',
        id: 'textarea',
        characterLimit: undefined,
    },
    checkbox: {
        description: 'Display a single or multiple checkboxes for the user to select from.',
        icon: 'square-checkmark',
        label: 'Checkbox',
        id: 'checkbox',
        options: [],
        value: [],
    },
    currency: {
        description: 'Text input for currency.',
        icon: 'receipt',
        label: 'Currency',
        id: 'currency',
    },
    date: {
        description: 'Display a date picker for the user to select a date from.',
        icon: 'date',
        label: 'Date',
        id: 'date',
    },
    email: {
        description: 'Text input formatter to accept an email address.',
        icon: 'mention',
        label: 'Email',
        id: 'email',
    },
    phone: {
        description: 'Text input formatter to accept a phone number.',
        icon: 'phone',
        label: 'Phone',
        id: 'phone',
        mask: '(___) ___-____',
    },
    url: {
        description: 'Text input for a URL.',
        icon: 'globe',
        label: 'URL',
        id: 'url',
    },
    number: {
        description: 'Collect a number from the user.',
        icon: 'hash',
        label: 'Number',
        id: 'number',
    },
    radio: {
        description: 'Display a single or multiple radio buttons for the user to select.',
        icon: 'circle-radio-selected',
        label: 'Radio',
        id: 'radio',
        options: [],
    },
    select: {
        description: 'Display a dropdown with options for the user to select from.',
        icon: 'chevron-down',
        label: 'Dropdown',
        id: 'dropdown',
        options: [],
        emptyOptionLabel: '',
    },
    switch: {
        description: 'Display a switch',
        icon: 'switch',
        label: 'Switch',
        id: 'switch',
    },
    file: {
        description: 'Collect files from the user',
        icon: 'upload',
        label: 'File',
        id: 'file',
        multiple: false,
        max: undefined,
        accept: '.pdf, .doc, .docx, .xls, .xlsx, .csv, .txt, .rtf, .html, .zip, .gz, .rar, .z, .tgz, .tar, .mp3, .mp4, .aac, .wma, .wmv, .avi, .mpg, .mpeg, .flv, .avi, .jpg, .jpeg, .png, .gif, .tif',
    },
};
const defaultField = {
    id: '',
    label: '',
    placeholder: '',
    value: '',
    required: false,
};
const createOptions = (field) => {
    return [
        [
            {
                editor: 'label',
                label: 'Name',
            },
            {
                editor: 'label',
                label: 'Value',
            },
            {
                editor: 'label',
                label: 'Default',
            },
        ],
        ...Array.from({
            length: field.options[field.options.length - 1]?.value && field.options[field.options.length - 1].name
                ? field.options.length + 1
                : Math.max(1, field.options.length),
        })
            .map((_, index) => {
            const option = field.options[index];
            const nextOption = field.options[index + 1];
            if (option && nextOption && !option.value && !option.name)
                return undefined;
            return [
                {
                    label: '',
                    placeholder: '',
                    propertyName: 'name',
                    editor: 'input',
                    type: 'text',
                    index,
                },
                {
                    label: '',
                    placeholder: '',
                    propertyName: 'value',
                    editor: 'input',
                    type: 'text',
                    index,
                },
                {
                    label: '',
                    placeholder: '',
                    propertyName: 'value',
                    editor: Array.isArray(field.value) ? 'checkbox' : 'radio',
                    index,
                    tooltipText: 'Select this option by default',
                    tooltipPosition: 'left',
                },
            ];
        })
            .filter(Boolean),
    ];
};
const CAPTION = {
    label: 'Caption',
    placeholder: '',
    propertyName: 'caption',
    editor: 'input',
    type: 'text',
};
const PLACEHOLDER = {
    label: 'Placeholder',
    placeholder: '',
    propertyName: 'placeholder',
    editor: 'input',
    type: 'text',
};
const INPUT_PROPERTIES = {
    text: () => [
        [PLACEHOLDER, CAPTION],
        [
            {
                label: 'Character limit',
                placeholder: '',
                propertyName: 'characterLimit',
                editor: 'input',
                type: 'number',
            },
            {
                label: 'Min length',
                placeholder: '',
                propertyName: 'minLength',
                editor: 'input',
                type: 'number',
            },
            {
                label: 'Max length',
                placeholder: '',
                propertyName: 'maxLength',
                editor: 'input',
                type: 'number',
            },
        ],
    ],
    textarea: () => [
        [
            {
                label: 'Character limit',
                placeholder: '',
                propertyName: 'characterLimit',
                editor: 'input',
                type: 'number',
            },
        ],
    ],
    radio: (field) => [...createOptions(field)],
    checkbox: (field) => [
        [
            ...(field.required
                ? [
                    {
                        label: 'Min choices',
                        placeholder: '',
                        propertyName: 'minLength',
                        editor: 'input',
                        type: 'number',
                    },
                ]
                : []),
            {
                label: 'Max choices',
                placeholder: '',
                propertyName: 'maxLength',
                editor: 'input',
                type: 'number',
            },
        ],
        ...createOptions(field),
    ],
    select: (field) => [
        [
            {
                label: 'Empty option label',
                placeholder: '',
                propertyName: 'emptyOptionLabel',
                editor: 'input',
            },
        ],
        ...createOptions(field),
    ],
    switch: () => [[CAPTION]],
    date: (field) => [
        [CAPTION],
        [
            {
                editor: 'switch',
                label: 'Prevent past dates',
                propertyName: 'preventPast',
                _change: (_field, value) => {
                    const today = new Date();
                    today.setMinutes(today.getMinutes() - today.getTimezoneOffset());
                    const todayLocal = today.toISOString().slice(0, 10);
                    return {
                        preventPast: value,
                        minDate: value ? todayLocal : undefined,
                    };
                },
            },
        ],
        [
            {
                editor: 'input',
                type: 'date',
                label: 'Min date',
                propertyName: 'minDate',
                disabled: Boolean(field.preventPast),
            },
        ],
        [
            {
                editor: 'switch',
                label: 'Prevent future dates',
                propertyName: 'preventFuture',
                _change: (_field, value) => {
                    const today = new Date();
                    today.setMinutes(today.getMinutes() - today.getTimezoneOffset());
                    const todayLocal = today.toISOString().slice(0, 10);
                    return {
                        preventFuture: value,
                        maxDate: value ? todayLocal : undefined,
                    };
                },
            },
        ],
        [
            {
                editor: 'input',
                type: 'date',
                label: 'Max date',
                propertyName: 'maxDate',
                disabled: Boolean(field.preventFuture),
            },
        ],
    ].filter(Boolean),
    number: () => [
        [{ ...PLACEHOLDER, type: 'number' }, CAPTION],
        [
            {
                label: 'Step',
                placeholder: '',
                propertyName: 'step',
                editor: 'input',
                type: 'number',
            },
            {
                label: 'Min',
                placeholder: '',
                propertyName: 'min',
                editor: 'input',
                type: 'number',
            },
            {
                label: 'Max',
                placeholder: '',
                propertyName: 'max',
                editor: 'input',
                type: 'number',
            },
        ],
    ],
    phone: (field) => [
        [CAPTION],
        [
            {
                editor: 'switch',
                label: 'Use a mask to format number',
                propertyName: 'mask',
                _change: ({ mask }, value) => {
                    if (!value)
                        return { mask: '' };
                    return {
                        mask: mask || '(___) ___-____',
                        minLength: undefined,
                        maxLength: undefined,
                    };
                },
            },
        ],
        !field.mask
            ? [
                PLACEHOLDER,
                {
                    label: 'Min length',
                    placeholder: '',
                    propertyName: 'minLength',
                    editor: 'input',
                    type: 'number',
                },
                {
                    label: 'Max length',
                    placeholder: '',
                    propertyName: 'maxLength',
                    editor: 'input',
                    type: 'number',
                },
            ]
            : [
                {
                    editor: 'input',
                    type: 'text',
                    label: 'Mask',
                    propertyName: 'mask',
                    caption: 'Underscores will be replaced by numbers as the user types',
                },
            ],
    ].filter(Boolean),
    file: () => [
        [CAPTION],
        [
            {
                label: 'Accepted file types',
                caption: 'File extensions must be separated by commas and start with a period',
                editor: 'textarea',
                propertyName: 'accept',
            },
        ],
        [
            {
                label: 'Max file size',
                caption: 'In bytes',
                editor: 'input',
                type: 'number',
                propertyName: 'max',
            },
        ],
        [
            {
                label: 'Allow multiple files',
                editor: 'switch',
                propertyName: 'multiple',
            },
        ],
    ],
};
export const editableFields = (field) => {
    return INPUT_PROPERTIES[field.inputType]?.(field) || [];
};
export const inputFields = inputTypes.map((inputType) => ({
    ...defaultField,
    ...inputs[inputType],
    inputType,
}));
export const getUniqueInput = ({ description, icon, ...input }, fields) => {
    let index = 1;
    if (fields && fields.length) {
        const likeFields = fields.filter((field) => field.id.replace(/[^a-zA-Z]/g, '') === input.id);
        let uniqueIndex;
        do {
            const currentIndex = index;
            const foundIndex = likeFields.some((field) => Number(field.id.replace(/[^0-9]/g, '')) === currentIndex);
            if (!foundIndex) {
                uniqueIndex = index;
            }
            else {
                index += 1;
            }
        } while (!uniqueIndex);
    }
    return { ...{}, ...input, id: `${input.id}${index}` };
};
