import JhaDynamicField from './JhaDynamicField';
customElements.define('jha-dynamic-field', JhaDynamicField);
/** @customElement jha-dynamic-field */
export default JhaDynamicField;
