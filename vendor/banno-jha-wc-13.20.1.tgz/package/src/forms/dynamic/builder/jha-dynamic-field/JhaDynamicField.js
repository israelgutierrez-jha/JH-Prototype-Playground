var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { LitElement, html, css } from 'lit';
import { property } from 'lit/decorators.js';
import { jhaStyles } from '../../../../styles/jha-styles.js';
import './FieldEditor.js';
const styles = css `
  :host {
    border: 1px solid var(--jha-border-color, #8c989f);
    padding: 0;
    position: relative;
    display: flex;
    background-color: var(--jha-component-background-color, var(--primary-content-background-color));
    align-items: center;
    border-radius: var(--jha-list-organizer-card-border-radius, 0px);
  }
  :host([editing]),
  .edit-form {
    box-shadow:
      0 4px 4px 0 rgba(37, 49, 62, 0.24),
      0 1px 3px rgba(37, 49, 62, 0.12);
  }
  :host([editing]) .header {
    z-index: 11;
  }
  .header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: relative;
    position: relative;
    width: 100%;
    padding-left: 4px;
    box-sizing: border-box;
    height: 100%;
    background-color: var(--jha-component-background-color, var(--primary-content-background-color));
  }
  :host(:not([valid])[show-warning])::before,
  :host(:not([valid])[show-warning]) .edit-form::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    border-left: 4px solid var(--jha-color-warning, #c98702);
  }
  :host span.icon-wrapper {
    display: flex;
    width: 24px;
    flex: 0 1 24px;
    align-self: stretch;
    align-items: center;
    justify-content: flex-end;
    cursor: move;
    background: transparent;
  }
  :host([drag='true']) {
    border-bottom: none !important;
  }

  :host([drag='true']) .header {
    background-color: var(--jha-color-light, var(--secondary-content-background-color)) !important;
  }

  :host([clone='true']) {
    box-shadow:
      0 1px 1px 0 rgba(0, 0, 0, 0.24),
      0 1px 4px rgba(0, 0, 0, 0.12);
  }
  svg {
    fill: var(--jha-list-organizer-handle-color, var(--jha-text-theme));
  }
  section {
    flex: 2;
    margin-top: 8px;
    position: relative;
  }
  jha-icon-collapse {
    transform: rotate(90deg);
    fill: var(--jha-color-primary);
  }
  jha-icon-edit {
    vertical-align: middle;
    margin-right: 8px;
  }
  button.edit-input {
    padding: 8px;
    margin: 4px;
    text-align: left;
    justify-content: flex-start;
    display: flex;
    align-items: center;
  }
  button.edit-input span {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  button.edit-input:hover {
    color: var(--jha-color-primary);
    text-decoration: underline;
  }
  button[delete-button]:hover jha-icon-delete,
  button[button-reset]:hover jha-icon-chevron-down {
    fill: var(--jha-color-primary);
  }
  button[delete-button] {
    flex: 1;
    padding-right: 8px;
  }
  button.resize {
    flex: 1;
  }
  button.resize[disabled] jha-icon-chevron-right {
    fill: var(--jha-color-neutral);
  }
  jha-icon-chevron-right {
    fill: var(--jha-color-primary);
  }
  button[last] jha-icon-chevron-right {
    transform: rotate(180deg);
  }
  .edit-form {
    position: absolute;
    left: -1px;
    right: -1px;
    top: 48px;
    background-color: var(--jha-component-background-color, var(--primary-content-background-color));
    border-color: var(--jha-border-color, #8c989f);
    border-style: solid;
    border-width: 0 1px 1px 1px;
    z-index: 10;
    display: none;
    min-width: 400px;
    padding: 0px 8px 8px 16px;
  }
  .edit-form[visible] {
    display: flex;
    flex-direction: column;
  }
  .edit-form[last] {
    left: auto;
  }
  :host([editing]) jha-icon-chevron-down {
    transform: rotate(180deg);
  }
  form {
    padding: 0 8px 8px 16px;
  }
  .fieldset-id {
    display: inline-block;
    font-size: 16px;
    top: 29px;
  }
  jha-form-row:not(:last-of-type) {
    margin-bottom: 16px;
  }
  jh-input {
    --jh-input-color-background: transparent;
  }
`;
/**
 * @element jha-dynamic-field
 */
export default class JhaDynamicField extends LitElement {
    constructor() {
        super(...arguments);
        this.editing = false;
    }
    static get styles() {
        return [jhaStyles, styles];
    }
    extendField(fieldObject) {
        return { ...this.field, ...fieldObject };
    }
    handleRemoveField() {
        this.dispatchEvent(new CustomEvent('remove-field', {
            bubbles: true,
            composed: true,
        }));
    }
    dispatchEditField() {
        this.dispatchEvent(new CustomEvent('edit-field', {
            detail: this.field.id,
            bubbles: true,
            composed: true,
        }));
    }
    dispatchUpdatedField(field) {
        this.dispatchEvent(new CustomEvent('updated-field', {
            detail: this.extendField(field),
            bubbles: true,
            composed: true,
        }));
    }
    renderFieldHeader() {
        return html `
      <div class="header">
        <!-- We can't use a custom element here. Event re-targeting kills drag events on Safari -->
        <span
          class="icon-wrapper"
          drag-item>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            aria-label="Drag to move field">
            <path d="M8,18h2v-2H8V18z M8,13h2v-2H8V13z M8,6v2h2V6H8z"></path>
            <path d="M13,18h2v-2h-2V18z M13,13h2v-2h-2V13z M13,6v2h2V6H13z"></path>
          </svg>
        </span>
        <button
          button-reset
          class="edit-input"
          type="button"
          @click=${this.dispatchEditField}>
          <span> ${this.field.label || 'Edit input'}${this.field.required ? '*' : ''} </span>
          <jha-icon-chevron-down></jha-icon-chevron-down>
        </button>

        <button
          delete-button
          button-reset
          title="delete input"
          type="button"
          @click=${this.handleRemoveField}>
          <jha-icon-delete></jha-icon-delete>
        </button>
      </div>
      ${this.renderEditMenu()}
    `;
    }
    renderEditMenu() {
        return html `
      <div
        class="edit-form"
        ?visible=${this.editing}>
        ${this.field.inputType
            ? html `
              <jha-form-row>
                <jh-checkbox
                  label="Required"
                  .checked=${this.field.required}
                  @jh-change=${({ target: { checked: required } }) => {
                this.dispatchUpdatedField({
                    required,
                });
            }}></jh-checkbox>
              </jha-form-row>
              <jha-form-row>
                <jh-input
                  outline
                  label="Input label"
                  data-id="label"
                  .value=${this.field.label}
                  required
                  show-indicator
                  @jh-change=${({ target: { value: label } }) => {
                this.dispatchUpdatedField({
                    label,
                });
            }}></jh-input>
                <jha-form-text-input
                  outline
                  data-id="id"
                  required
                  label="ID"
                  .value=${this.field.id}
                  allowedCharacters="[a-zA-Z0-9]"
                  .pattern=${this.invalidIds}
                  @blur=${({ target: { value: id } }) => {
                this.dispatchUpdatedField({
                    id,
                });
            }}></jha-form-text-input>
              </jha-form-row>
            `
            : ''}
        <field-editor .field=${this.field}></field-editor>
      </div>
    `;
    }
    render() {
        return html ` ${this.renderFieldHeader()} `;
    }
}
__decorate([
    property({ type: Object }),
    __metadata("design:type", Object)
], JhaDynamicField.prototype, "field", void 0);
__decorate([
    property({ type: RegExp }),
    __metadata("design:type", Object)
], JhaDynamicField.prototype, "invalidIds", void 0);
__decorate([
    property({ type: Boolean, reflect: true }),
    __metadata("design:type", Object)
], JhaDynamicField.prototype, "editing", void 0);
export { styles as JhaDynamicFieldStyles };
