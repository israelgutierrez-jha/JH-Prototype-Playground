var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { LitElement, html, css, nothing } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { jhaStyles } from '../../../../styles/jha-styles.js';
import '@jack-henry/jh-elements/components/checkbox/checkbox.js';
import '@jack-henry/jh-elements/components/radio/radio.js';
import '@jack-henry/jh-elements/components/switch/switch.js';
import '../../../../jha-flex-wrapper/jha-flex-wrapper.js';
import { editableFields } from './dynamic-field.utils.js';
import '../../../jha-form-input-base/jha-form-input.js';
import '../../../jha-form-textarea-input/jha-form-textarea-input.js';
import '../../../../jha-tooltip/jha-tooltip.js';
const styles = css `
  jha-form-row {
    align-items: center;
  }
  jha-tooltip {
    --jha-tooltip-text-color: var(--jha-button-text);
    --jha-tooltip-color-background: var(--jha-toast-background);
  }
  jha-form-row > label {
    margin-bottom: -4px;
    font-size: var(--jha-input-label-font-size, 16px);
    color: var(--jha-input-label-color, var(--jha-text-light, #8c989f));
  }
  jha-form-row > label:last-child {
    max-width: 50px;
  }
  jha-form-row > jha-tooltip:last-child {
    max-width: 50px;
    padding-left: 12px;
  }
  jh-switch {
    margin-top: 4px;
    margin-bottom: 12px;
  }
`;
let FieldEditor = class FieldEditor extends LitElement {
    extendField(fieldObject) {
        return { ...this.field, ...fieldObject };
    }
    dispatchUpdatedField(field) {
        this.dispatchEvent(new CustomEvent('updated-field', {
            detail: this.extendField(field),
            bubbles: true,
            composed: true,
        }));
    }
    updateOption(propertyName, value, index) {
        let { value: fieldValue } = this.field;
        const nameInput = this.shadowRoot.querySelector(`#name-${index}`);
        const valueInput = this.shadowRoot.querySelector(`#value-${index}`);
        const option = this.field.options[index];
        const updatedOption = {
            name: nameInput.value,
            value: valueInput.value,
        };
        if (updatedOption[propertyName] === (option?.[propertyName] || ''))
            return;
        const nextOption = this.field.options[index + 1];
        const emptyOptionWithSibling = option && nextOption && !updatedOption.value && !updatedOption.name;
        const shouldUpdateOptions = !updatedOption.name === !updatedOption.value || (!option?.name && !option?.value);
        const options = emptyOptionWithSibling
            ? this.field.options.toSpliced(index, 1)
            : this.field.options.toSpliced(index, 1, updatedOption);
        if (propertyName === 'value' &&
            option &&
            ((fieldValue && fieldValue === option.value) || (Array.isArray(fieldValue) && fieldValue.includes(option.value)))) {
            fieldValue = Array.isArray(fieldValue) ? fieldValue.toSpliced(1, fieldValue.indexOf(option.value), value) : value;
        }
        this.dispatchUpdatedField({
            options: shouldUpdateOptions
                ? options.filter((fieldOption) => fieldOption.name && fieldOption.value)
                : this.field.options,
            value: fieldValue,
        });
    }
    renderRadio({ propertyName, label, index = undefined }) {
        return html `
      <jh-radio
        label=${label}
        .value=${this.field.options[index]?.[propertyName] || ''}
        .checked=${this.field.value && this.field.value === this.field.options[index]?.[propertyName]}
        @jh-change=${({ currentTarget: { value } }) => {
            this.dispatchUpdatedField({ value });
        }}
        ?disabled=${!(this.field.options[index]?.name && this.field.options[index]?.value)}></jh-radio>
    `;
    }
    renderCheckbox({ propertyName, label, index = undefined }) {
        return html `
      <jh-checkbox
        label=${label}
        .value=${this.field.options[index]?.[propertyName] || ''}
        .checked=${this.field.value && this.field.value.includes(this.field.options[index]?.[propertyName])}
        @jh-change=${({ currentTarget: { checked, value } }) => {
            this.dispatchUpdatedField({
                value: checked
                    ? [...this.field.value, value]
                    : this.field.value.filter((fieldValue) => fieldValue !== value),
            });
        }}
        ?disabled=${!(this.field.options[index]?.name && this.field.options[index]?.value)}></jh-checkbox>
    `;
    }
    renderInput({ propertyName, label, type = undefined, placeholder = undefined, index = undefined, caption = undefined, disabled = undefined, _change, }) {
        return html `
      <jha-form-input
        outline
        label=${label}
        type=${type}
        id=${[propertyName, index].filter((elem) => elem !== undefined).join('-')}
        placeholder=${ifDefined(placeholder)}
        .helpText=${caption || ''}
        .value=${index >= 0 ? this.field.options[index]?.[propertyName] : this.field[propertyName] || ''}
        ?disabled=${disabled}
        @change=${({ target: { value } }) => {
            if (_change) {
                this.dispatchUpdatedField(_change(this.field, value));
            }
            else if (index === undefined) {
                if (type === 'number' && parseFloat(value) !== parseFloat(this.field[propertyName])) {
                    this.dispatchUpdatedField({ [propertyName]: parseFloat(value) });
                }
                else if (type !== 'number' && value !== this.field[propertyName]) {
                    this.dispatchUpdatedField({ [propertyName]: value });
                }
            }
            else {
                this.updateOption(propertyName, value, index);
            }
        }}></jha-form-input>
    `;
    }
    renderSwitch({ propertyName, label, _change }) {
        return html `
      <jh-switch
        .checked=${Boolean(this.field[propertyName])}
        label=${label}
        @jh-change=${({ target: { checked } }) => {
            if (_change) {
                this.dispatchUpdatedField(_change(this.field, checked));
            }
            else {
                this.dispatchUpdatedField({ [propertyName]: checked });
            }
        }}></jh-switch>
    `;
    }
    renderTextarea({ propertyName, label, type = undefined, placeholder = undefined, index = undefined, caption = undefined, }) {
        return html `
      <jha-form-textarea-input
        outline
        label=${label}
        type=${type}
        id=${[propertyName, index].filter((elem) => elem !== undefined).join('-')}
        placeholder=${ifDefined(placeholder)}
        .value=${index >= 0 ? this.field.options[index]?.[propertyName] : this.field[propertyName] || ''}
        .helpText=${caption || ''}
        @change=${({ target: { value } }) => {
            if (value !== this.field[propertyName]) {
                this.dispatchUpdatedField({ [propertyName]: value });
            }
        }}></jha-form-textarea-input>
    `;
    }
    renderPropertyEditor(inputProperty) {
        if (inputProperty.editor === 'label')
            return html ` <label>${inputProperty.label}</label> `;
        if (inputProperty.editor === 'input')
            return this.renderInput(inputProperty);
        if (inputProperty.editor === 'radio')
            return this.renderRadio(inputProperty);
        if (inputProperty.editor === 'checkbox')
            return this.renderCheckbox(inputProperty);
        if (inputProperty.editor === 'switch')
            return this.renderSwitch(inputProperty);
        if (inputProperty.editor === 'textarea')
            return this.renderTextarea(inputProperty);
        return nothing;
    }
    renderRow(row) {
        return html `
      <jha-form-row>
        ${row.map((inputProperty) => {
            if (inputProperty.tooltipText) {
                return html `
              <jha-tooltip
                text=${inputProperty.tooltipText}
                ?top=${inputProperty.tooltipPosition === 'top'}
                ?bottom=${inputProperty.tooltipPosition === 'bottom'}
                ?left=${inputProperty.tooltipPosition === 'left'}
                ?right=${inputProperty.tooltipPosition === 'right'}>
                ${this.renderPropertyEditor(inputProperty)}
              </jha-tooltip>
            `;
            }
            return this.renderPropertyEditor(inputProperty);
        })}
      </jha-form-row>
    `;
    }
    static get styles() {
        return [jhaStyles, styles];
    }
    render() {
        return html ` ${editableFields(this.field).map(this.renderRow.bind(this))} `;
    }
};
__decorate([
    property({ type: Object }),
    __metadata("design:type", Object)
], FieldEditor.prototype, "field", void 0);
FieldEditor = __decorate([
    customElement('field-editor')
], FieldEditor);
export default FieldEditor;
export { styles as FieldEditor };
