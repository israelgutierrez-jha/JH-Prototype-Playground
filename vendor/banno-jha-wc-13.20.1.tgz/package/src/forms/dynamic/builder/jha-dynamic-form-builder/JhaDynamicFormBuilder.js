var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { LitElement, html, css, nothing } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { property, state } from 'lit/decorators.js';
import { jhaStyles } from '../../../../styles/jha-styles.js';
import formElementMixin from '../../../../js/mixins/form-element-mixin.js';
import { getForm, getBlock } from './dynamic-form-builder.utils.js';
import '../../../../cards/jha-card/jha-card.js';
import '../../../jha-form-row/jha-form-row.js';
import '../../../jha-form-text-input/jha-form-text-input.js';
import '@jack-henry/jh-elements/components/button/button.js';
import '@jack-henry/jh-elements/components/input/input.js';
import '../jha-dynamic-block/jha-dynamic-block.js';
const styles = css `
  :host {
    overflow: auto;
  }
  jha-card {
    max-width: 800px;
    margin: 0 auto;
    display: block;
  }
  section {
    min-height: 400px;
  }
  footer {
    margin-top: 32px;
    padding-top: 32px;
    border-top: var(--jha-file-uploader-border, 2px dashed var(--jha-border-color, #e4e7ea));
    position: relative;
  }
  footer label {
    background-color: var(--jha-component-background-color, #ffffff);
    position: absolute;
    top: -16px;
    left: 50%;
    transform: translate(-50%, 0px);
    padding: 4px;
    font-size: 16px;
  }
  jha-form-row.buttons {
    justify-content: center;
    align-items: flex-end;
    gap: 44px;
  }
  jha-form-row.buttons > div {
    flex: 1;
    --jha-input-text-align: center;
    display: flex;
    max-width: 200px;
  }
  jh-input {
    --jh-input-color-background: transparent;
  }
  jh-input.submit {
    --jha-form-input-label-background-color: transparent;
    --jh-input-color-background: var(--jha-color-primary, #006ee4);
    --jh-input-color-text: var(--jha-text-white, #ffffff);
  }
  jha-form-row.buttons jh-input {
    --jha-form-floating-group-label-top: 15px;
  }
  button.add-cancel-button,
  button.add-block-button {
    border: var(--jha-file-uploader-border, 2px dashed var(--jha-border-color, #e4e7ea));
    color: var(--jha-text-base, #707070);
    border-radius: 4px;
    padding: 10px 8px;
    font-size: 14px;
    font-weight: 500;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
  }
  button.delete-cancel {
    flex: 1;
    padding: 8px;
    margin-top: 18px;
    margin-right: -40px;
  }
  .add-block {
    width: var(--block-menu-width, 100%);
    max-width: var(--block-menu-max-width, 400px);
    font-size: 16px;
    font-weight: 500;
    margin: var(--block-menu-margin, 16px auto);
  }
  button.add-block-button {
    width: 100%;
    text-transform: uppercase;
  }
  jha-icon-plus {
    margin-right: 8px;
  }
`;
/**
 * @element jha-dynamic-form-builder
 */
export default class JhaDynamicFormBuilder extends formElementMixin(LitElement) {
    static get styles() {
        return [jhaStyles, styles];
    }
    constructor() {
        super();
        this.form = getForm();
        this.title = 'Build a form';
        this.saveLabel = 'SAVE';
        this.showFormDetails = true;
        this.editingBlock = '';
        this.dragBlock_ = undefined;
        import('../../../../icons/jha-icon-delete.js');
        import('../../../../icons/jha-icon-plus.js');
        import('../../../../icons/jha-icon-refresh.js');
    }
    get dynamicBlocks() {
        return Array.from(this.shadowRoot.querySelectorAll('jha-dynamic-block'));
    }
    updated(changedProperties) {
        if (changedProperties.has('form')) {
            this.dispatchFormChange();
        }
    }
    extendForm(formObject) {
        this.form = { ...this.form, ...formObject };
    }
    dispatchFormChange() {
        this.dispatchEvent(new CustomEvent('jh-form-builder-change', {
            bubbles: true,
            composed: true,
            detail: this.form,
        }));
    }
    dragStart_(event) {
        let isDragItem = false;
        let element = event.target.shadowRoot.elementFromPoint(event.clientX, event.clientY);
        while (element) {
            isDragItem = element.hasAttribute('drag-item');
            element = !isDragItem ? element.parentElement : undefined;
        }
        if (isDragItem) {
            this.dragBlock_ = event.currentTarget;
            const { dataTransfer } = event;
            dataTransfer.dropEffect = 'move';
            window.requestAnimationFrame(() => {
                document.body.style.userSelect = 'none';
                this.dragBlock_.setAttribute('drag', 'true');
            });
        }
        else {
            event.preventDefault();
        }
    }
    async dragEnd_() {
        if (!this.dragBlock_)
            return;
        await this.updateComplete;
        this.dynamicBlocks.forEach((block) => block.removeAttribute('drag'));
        this.dragBlock_ = undefined;
        document.body.style.removeProperty('user-select');
    }
    drop_(event) {
        event.stopPropagation();
        event.preventDefault();
    }
    dragEnter_(event) {
        event.stopPropagation();
        const targetEl = event.currentTarget;
        if (!this.dragBlock_ || this.dragBlock_ === targetEl || targetEl.tagName !== 'JHA-DYNAMIC-BLOCK') {
            return;
        }
        const targetIndex = this.dynamicBlocks.indexOf(targetEl);
        const toIndex = targetEl.nextElementSibling && targetEl.nextElementSibling.block.id === this.dragBlock_.block.id
            ? targetIndex
            : targetIndex + 1;
        const fromIndex = this.dynamicBlocks.findIndex((dynamicBlock) => dynamicBlock.hasAttribute('drag'));
        this.extendForm({
            blocks: this.form.blocks.toSpliced(toIndex, 0, ...this.form.blocks.splice(fromIndex, 1)),
        });
    }
    dragOver_(event) {
        event.preventDefault();
        const { dataTransfer } = event;
        dataTransfer.dropEffect = 'move';
    }
    handleAddBlock() {
        this.extendForm({ blocks: [...this.form.blocks, getBlock()] });
    }
    handleFormSave() {
        this.dispatchEvent(new CustomEvent('jh-form-builder-save', {
            bubbles: true,
            composed: true,
            detail: this.form,
        }));
    }
    handleFormSaveKeydown(event) {
        if (event.key === 'Enter') {
            this.handleFormSave();
        }
    }
    async handleRemoveBlock({ currentTarget: block }) {
        const removedBlockIndex = this.dynamicBlocks.indexOf(block);
        this.extendForm({
            blocks: this.form.blocks.toSpliced(removedBlockIndex, 1),
        });
    }
    handleUpdatedBlock(event) {
        const blockIndex = this.dynamicBlocks.indexOf(event.currentTarget);
        this.extendForm({
            blocks: this.form.blocks.toSpliced(blockIndex, 1, event.detail),
        });
    }
    render() {
        return html `
      <jha-card>
        ${this.title ? html ` <h1 slot="header-left">${this.title}</h1> ` : nothing}
        ${this.saveLabel
            ? html `
              <jh-button
                appearance="secondary"
                type="button"
                size="small"
                slot="header-right"
                @click=${this.handleFormSave}
                @keydown=${this.handleFormSaveKeydown}
                label=${this.saveLabel}>
                SAVE
              </jh-button>
            `
            : nothing}
        <article>
          ${this.showFormDetails
            ? html `
                <jha-form-row>
                  <jh-input
                    label="Form name"
                    .value=${this.form.title}
                    @jh-change=${({ target: { value: title } }) => {
                this.extendForm({
                    title,
                });
            }}></jh-input>
                  <jh-input
                    formId
                    label="Form id"
                    .value=${this.form.id}
                    @jh-change=${({ target: { value: id } }) => {
                this.extendForm({
                    id,
                });
            }}></jh-input>
                </jha-form-row>
              `
            : nothing}
          <div id="blocks">
            ${repeat(this.form.blocks, (block) => block.id, (block) => html `
                <jha-dynamic-block
                  .block=${block}
                  @remove-block=${this.handleRemoveBlock}
                  @dragstart=${this.dragStart_}
                  @dragend=${this.dragEnd_}
                  @drop=${this.drop_}
                  @dragenter=${this.dragEnter_}
                  @dragover=${this.dragOver_}
                  draggable="true"
                  @updated-block=${this.handleUpdatedBlock}
                  .minimized=${block.id !== this.editingBlock}
                  @edit-block=${({ detail: id }) => {
            this.editingBlock = this.editingBlock === id ? '' : id;
        }}></jha-dynamic-block>
              `)}
          </div>
          <div class="add-block">
            <button
              button-reset
              type="button"
              class="add-block-button"
              @click=${this.handleAddBlock}>
              <jha-icon-plus></jha-icon-plus>
              Add a block
            </button>
          </div>

          <footer>
            <label>Footer</label>
            <jha-form-row class="buttons">
              <div>
                ${this.form.showCancelButton
            ? html `
                      <jh-input
                        label="Cancel button"
                        .value=${this.form.cancelButtonLabel}
                        @jh-change=${({ target: { value: cancelButtonLabel } }) => {
                this.extendForm({
                    cancelButtonLabel,
                });
            }}></jh-input>
                      <button
                        button-reset
                        type="button"
                        title="remove cancel button"
                        class="delete-cancel"
                        @click=${() => {
                this.extendForm({
                    cancelButtonLabel: !this.form.showCancelButton ? 'Cancel' : '',
                    showCancelButton: !this.form.showCancelButton,
                });
            }}>
                        <jha-icon-delete></jha-icon-delete>
                      </button>
                    `
            : html `
                      <button
                        button-reset
                        type="button"
                        title="add cancel button"
                        class="add-cancel-button"
                        @click=${() => {
                this.extendForm({
                    cancelButtonLabel: !this.form.showCancelButton ? 'Cancel' : '',
                    showCancelButton: !this.form.showCancelButton,
                });
            }}>
                        <jha-icon-plus></jha-icon-plus>
                        Add a cancel button
                      </button>
                    `}
              </div>
              <div>
                <jh-input
                  class="submit"
                  label="Submit button"
                  .value=${this.form.submitButtonLabel}
                  @jh-change=${({ target: { value: submitButtonLabel } }) => {
            this.extendForm({
                submitButtonLabel,
            });
        }}></jh-input>
              </div>
            </jha-form-row>
          </footer>
        </article>
      </jha-card>
    `;
    }
}
__decorate([
    property({ type: Object }),
    __metadata("design:type", Object)
], JhaDynamicFormBuilder.prototype, "form", void 0);
__decorate([
    property({ type: String }),
    __metadata("design:type", Object)
], JhaDynamicFormBuilder.prototype, "title", void 0);
__decorate([
    property({ type: String }),
    __metadata("design:type", Object)
], JhaDynamicFormBuilder.prototype, "saveLabel", void 0);
__decorate([
    property({ type: Boolean }),
    __metadata("design:type", Object)
], JhaDynamicFormBuilder.prototype, "showFormDetails", void 0);
__decorate([
    property({ type: String }),
    __metadata("design:type", Object)
], JhaDynamicFormBuilder.prototype, "editingBlock", void 0);
__decorate([
    state(),
    __metadata("design:type", Object)
], JhaDynamicFormBuilder.prototype, "dragBlock_", void 0);
export { styles as JhaDynamicFormStyles };
