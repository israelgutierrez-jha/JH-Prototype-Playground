import randomGuid from '../../../../js/utils/random-guid.js';
const defaultForm = {
    id: '',
    title: 'New Form',
    blocks: [],
    submitButtonLabel: 'Send',
    showCancelButton: false,
    cancelButtonLabel: '',
};
const defaultBlock = {
    description: null,
    id: '',
    rows: [],
    label: 'Default block',
};
export const getForm = () => ({ ...{}, ...defaultForm });
export const getBlock = () => ({ ...defaultBlock, id: randomGuid() });
