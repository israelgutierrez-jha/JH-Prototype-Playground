import JhaDynamicFormBuilder from './JhaDynamicFormBuilder';
customElements.define('jha-dynamic-form-builder', JhaDynamicFormBuilder);
/** @customElement jha-dynamic-form-builder */
export default JhaDynamicFormBuilder;
