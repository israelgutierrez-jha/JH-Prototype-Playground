var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { LitElement, html, css } from 'lit';
import { property, state } from 'lit/decorators.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { jhaStyles } from '../../../styles/jha-styles.js';
import { formatCurrency } from '../../../js/utils/format-currency.js';
import '@jack-henry/jh-elements/components/input/input.js';
import '@jack-henry/jh-elements/components/checkbox/checkbox.js';
import '@jack-henry/jh-elements/components/checkbox-group/checkbox-group.js';
import '@jack-henry/jh-elements/components/radio-group/radio-group.js';
import '@jack-henry/jh-elements/components/radio/radio.js';
import '@jack-henry/jh-elements/components/switch/switch.js';
import '../../jha-form-select/jha-form-select.js';
import '../../jha-form-input-base/jha-form-input.js';
import '../../../jha-file-uploader/jha-file-uploader.js';
const styles = css `
  :host {
    display: block;
    --jha-form-floating-group-required-indicator-color: var(--jha-color-danger);
  }

  :host([size='1']:not([row-length='3'])) {
    --jha-form-row-item-flex: 0 2 calc(25% - var(--jha-form-row-gap-horizontal));
    width: calc(25% - var(--jha-form-row-gap-horizontal));
  }
  :host([size='1'][row-length='3']) {
    --jha-form-row-item-flex: 1 2 calc(25% - var(--jha-form-row-gap-horizontal));
    width: calc(25% - var(--jha-form-row-gap-horizontal));
  }

  :host([size='2']) {
    --jha-form-row-item-flex: 0 0 calc(50% - var(--jha-form-row-gap-horizontal));
    width: calc(50% - var(--jha-form-row-gap-horizontal));
  }

  :host([size='3']) {
    --jha-form-row-item-flex: 0 2 calc(75% - var(--jha-form-row-gap-horizontal));
    width: calc(75% - var(--jha-form-row-gap-horizontal));
  }

  :host([size='4']) {
    --jha-form-row-item-flex: 1 2 100%;
    width: 100%;
  }

  :host([read-only]) {
    overflow: hidden;
  }

  jh-checkbox-group,
  jh-radio-group,
  jh-input,
  jha-file-uploader {
    margin-bottom: var(--jh-input-margin-bottom, 16px);
  }

  jha-form-select {
    display: inline-block;
    width: 100%;
  }

  jha-form-select[disabled],
  jh-checkbox-group[disabled],
  jh-radio-group[disabled] {
    opacity: var(--jh-input-opacity-disabled, var(--jh-opacity-300));
  }

  jh-input.other {
    margin: 16px 0 16px 28px;
    width: auto;
  }

  jha-form-select[invalid] {
    --jha-input-border: 1px solid var(--jh-color-content-negative-enabled);
  }

  jh-switch {
    margin: var(--jh-switch-margin, 16px 0 24px);
  }

  jha-form-currency-input,
  jha-form-percent-input {
    --jha-input-margin-bottom: 16px;
  }

  .character-limit {
    margin-top: -12px;
  }

  .read-only-container {
    container-type: inline-size;
    display: block;
  }

  .read-only-field {
    overflow: hidden;
    width: 100%;
    display: flex;
    flex-direction: var(--jha-dynamic-form-read-only-flex-direction, column);
    gap: var(--jha-dynamic-form-read-only-gap, 8px);
    justify-content: var(--jha-dynamic-form-read-only-justify-content, space-between);
    margin-bottom: var(--jha-dynamic-form-read-only-margin-bottom, 16px);
    border-bottom: var(--jha-dynamic-form-read-only-border-bottom, none);
    padding-bottom: var(--jha-dynamic-form-read-only-padding-bottom, 8px);
    padding-left: var(--jha-dynamic-form-read-only-padding-left, 0);
    padding-right: var(--jha-dynamic-form-read-only-padding-right, 8px);
  }

  .read-only-field[read-only-layout='flex'] {
    flex-direction: row;
    --jha-dynamic-form-read-only-flex-direction: row;
    --jha-dynamic-form-read-only-justify-content: space-between;
    --jha-dynamic-form-read-only-label-font-size: 14px;
    --jha-dynamic-form-read-only-value-font-weight: 500;
    --jha-dynamic-form-read-only-label-flex: 0 0 calc(40% - var(--jha-dynamic-form-read-only-gap, 4px));
    --jha-dynamic-form-read-only-value-flex: 0 1 calc(60% - var(--jha-dynamic-form-read-only-gap, 4px));
    --jha-dynamic-form-read-only-value-text-align: right;
  }

  .read-only-field label {
    flex: var(--jha-dynamic-form-read-only-label-flex, 1);
    font-size: var(--jha-dynamic-form-read-only-label-font-size, 12px);
    font-weight: var(--jha-dynamic-form-read-only-label-font-weight, 500);
    color: var(--jha-dynamic-form-read-only-label-color, var(--jh-color-content-primary-enabled));
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .read-only-field .value {
    flex: var(--jha-dynamic-form-read-only-value-flex, 1);
    font-size: var(--jha-dynamic-form-read-only-value-font-size, 14px);
    color: var(--jha-dynamic-form-read-only-value-color, var(--jh-color-content-primary-enabled));
    font-weight: var(--jha-dynamic-form-read-only-value-font-weight, 400);
    text-align: var(--jha-dynamic-form-read-only-value-text-align, left);
    max-width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .read-only-field[read-only-layout='inline'] {
    flex-direction: row;
    gap: var(--jha-dynamic-form-read-only-inline-gap, 8px);
    align-items: center;
    justify-content: flex-start;
  }

  .read-only-field[read-only-layout='inline'] label,
  .read-only-field[read-only-layout='inline'] .value {
    width: auto;
    flex: none;
    font-size: var(--jha-dynamic-form-read-only-value-font-size, 14px);
  }

  .read-only-field[read-only-layout='flex'] {
    border-bottom: var(--jha-dynamic-form-read-only-border-bottom, 1px solid var(--jh-color-divider-primary));
  }

  .read-only-field[input-type='textarea'] .value {
    white-space: normal;
  }

  .flex-container {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }
  .flex-container .item {
    width: calc(50% - 4px);
  }
`;
/**
 * @element jha-dynamic-input
 */
export default class JhaDynamicInput extends LitElement {
    constructor() {
        super(...arguments);
        this.value = '';
        this.dataId = '';
        this.isValid = true;
        this.disabled = false;
        this.size = null;
        this.rowLength = null;
        this.readOnly = false;
        this.readOnlyLayout = null;
        this.inputSize = 'medium';
        this.otherOptionInvalid = false;
    }
    static get styles() {
        return [jhaStyles, styles];
    }
    get displayValue() {
        const { inputType } = this.fieldConfig;
        switch (inputType) {
            case 'switch':
                return this.value ? 'Yes' : 'No';
            case 'select':
                const selectedOption = this.fieldConfig.options?.find((option) => option.value === this.value);
                return selectedOption ? selectedOption.name : this.value;
            case 'radio':
                const radioOption = this.fieldConfig.options?.find((option) => option.value === this.value);
                if (radioOption) {
                    return radioOption.name;
                }
                else if (this.value?.startsWith('other:')) {
                    return this.value.replace('other: ', '');
                }
                return this.value;
            case 'checkbox':
                return this.value.join(', ');
            case 'currency':
                return formatCurrency(this.value);
            default:
                return this.value;
        }
    }
    get inputElement() {
        switch (this.fieldConfig.inputType) {
            case 'select':
                return this.shadowRoot?.querySelector('jha-form-select');
            case 'number':
                return this.shadowRoot?.querySelector('jha-form-input');
            case 'date':
                return this.shadowRoot?.querySelector('jha-form-input');
            case 'file':
                return this.shadowRoot?.querySelector('jha-file-uploader');
            case 'currency':
                return this.shadowRoot?.querySelector('jha-form-currency-input')?.shadowRoot?.querySelector('input');
            case 'text':
            default:
                return this.shadowRoot?.querySelector('jh-input')?.shadowRoot?.querySelector('input, textarea');
        }
    }
    get checkboxErrorText() {
        const { inputType, required, minLength } = this.fieldConfig;
        if (inputType !== 'checkbox') {
            return '';
        }
        if (required && !this.value?.length) {
            return 'Required';
        }
        if (required && minLength && this.value?.length < minLength) {
            return `Please select at least ${minLength} option${minLength > 1 ? 's' : ''}`;
        }
        if (this.value?.includes('other')) {
            return 'Please enter a value for other';
        }
        return '';
    }
    isCheckboxValid() {
        const { required, minLength } = this.fieldConfig;
        const value = (this.value || []);
        if (required && value.length === 0) {
            return false;
        }
        if (required && minLength && value.length < minLength) {
            return false;
        }
        if (value.includes('other')) {
            return false;
        }
        return true;
    }
    checkValidity() {
        const { minLength, inputType, required } = this.fieldConfig;
        if (this.readOnly) {
            return true;
        }
        if (inputType === 'checkbox') {
            return this.isCheckboxValid();
        }
        if (minLength && required && minLength > this.value.length) {
            return false;
        }
        if (inputType === 'radio') {
            return this.value !== 'other' && (!required || Boolean(this.value));
        }
        if (this.inputElement && typeof this.inputElement?.checkValidity === 'function') {
            return this.inputElement?.checkValidity();
        }
        return true;
    }
    valueIsChecked(value) {
        return (this.value || []).some((item) => item === value || (value === 'other' && item.startsWith('other')));
    }
    updateValue(value) {
        this.value = value;
        this.isValid = this.checkValidity();
        this.dispatchEvent(new CustomEvent('jh-input-change', {
            detail: value,
            bubbles: true,
            composed: true,
        }));
    }
    inputValueChange(event) {
        const { inputType } = this.fieldConfig;
        const { target, detail } = event;
        const value = inputType === 'switch' ? target?.checked : target?.value || detail || '';
        this.updateValue(value);
    }
    handleRadioChange(event) {
        this.inputValueChange(event);
        this.otherOptionInvalid = false;
    }
    handleCheckboxGroupChange(event) {
        const { value, checked } = event.target;
        let newValue = (this.value || []);
        if (checked) {
            newValue = [...newValue, value];
        }
        else if (value === 'other') {
            newValue = newValue.filter((item) => !item.startsWith('other'));
            this.otherOptionInvalid = false;
        }
        else {
            newValue = newValue.filter((item) => item !== value);
        }
        this.updateValue(newValue);
    }
    handleOtherOptionChange(event) {
        const { inputType } = this.fieldConfig;
        const { value } = event.target;
        const otherValue = value ? `other: ${value}` : 'other';
        const newValue = inputType === 'radio'
            ? otherValue
            : (this.value || []).map((item) => (item.startsWith('other') ? otherValue : item));
        this.updateValue(newValue);
        this.checkOtherInputValidity();
    }
    handleBlur() {
        this.isValid = this.checkValidity();
    }
    checkOtherInputValidity() {
        const { inputType } = this.fieldConfig;
        const { value } = this;
        if (inputType === 'checkbox') {
            this.otherOptionInvalid = value?.includes('other');
        }
        else if (inputType === 'radio') {
            this.otherOptionInvalid = value === 'other';
        }
    }
    renderOtherInput() {
        return html `
      <jh-input
        required
        show-indicator
        class="other"
        size=${this.inputSize || 'medium'}
        placeholder="Enter other option"
        @input=${this.handleOtherOptionChange}
        ?invalid=${this.otherOptionInvalid}
        @blur=${this.checkOtherInputValidity}></jh-input>
    `;
    }
    renderCheckbox() {
        import('@jack-henry/jh-elements/components/checkbox/checkbox.js');
        import('@jack-henry/jh-elements/components/checkbox-group/checkbox-group.js');
        const { label, caption, maxLength, options, required } = this.fieldConfig;
        const { value } = this;
        return html `
      <jh-checkbox-group
        label=${label || ''}
        .helperText=${caption}
        .required=${required}
        .showIndicator=${required}
        ?invalid=${this.isValid === false}
        ?disabled=${this.disabled}
        error-text=${this.checkboxErrorText}>
        <div class="flex-container">
          ${options?.map((option) => html `
              <div class="item">
                <jh-checkbox
                  label=${option.name}
                  .value=${option.value}
                  .checked=${this.valueIsChecked(option.value)}
                  .disabled=${this.disabled ||
            Boolean(maxLength && !this.valueIsChecked(option.value) && value?.length === maxLength)}
                  @jh-change=${this.handleCheckboxGroupChange}></jh-checkbox>
                ${option.value === 'other' && this.valueIsChecked(option.value) ? this.renderOtherInput() : ''}
              </div>
            `)}
        </div>
      </jh-checkbox-group>
    `;
    }
    renderRadio() {
        import('@jack-henry/jh-elements/components/radio/radio.js');
        import('@jack-henry/jh-elements/components/radio-group/radio-group.js');
        const { label, caption, options, required, id } = this.fieldConfig;
        const { value } = this;
        return html `
      ${options.length > 0
            ? html `
            <jh-radio-group
              label=${label || ''}
              .helperText=${caption || ''}
              .required=${required}
              .showIndicator=${required}
              ?invalid=${this.otherOptionInvalid}
              ?disabled=${this.disabled}
              error-text="Please enter a value for other"
              name=${id}>
              ${options?.map((option) => html `
                  <jh-radio
                    label=${option.name}
                    .value=${option.value}
                    .disabled=${this.disabled}
                    .checked=${value === option.value ||
                (option.value === 'other' && value?.startsWith('other:'))}
                    @jh-change=${this.handleRadioChange}></jh-radio>
                  ${option.value === 'other' && this.value?.startsWith('other')
                ? this.renderOtherInput()
                : ''}
                `)}
            </jh-radio-group>
          `
            : ''}
    `;
    }
    renderTextInput() {
        import('@jack-henry/jh-elements/components/input/input.js');
        const { caption, characterLimit, inputType, label, maxLength, minLength, max, min, placeholder, required } = this.fieldConfig;
        return html `
      <jh-input
        .value=${this.value}
        .helperText=${caption || ''}
        label=${label || ''}
        .placeholder=${placeholder || ''}
        .required=${required}
        .showIndicator=${required}
        .type=${inputType}
        .maxlength=${maxLength || characterLimit ? `${maxLength || characterLimit}` : ''}
        .minlength=${minLength ? `${minLength}` : ''}
        .max=${max ? `${max}` : ''}
        .min=${min ? `${min}` : ''}
        error-text=${minLength && !this.isValid && this.value ? `Value must be at least ${minLength} characters` : ''}
        .disabled=${this.disabled}
        @input=${this.inputValueChange}
        size=${this.inputSize || 'medium'}
        @blur=${this.handleBlur}
        ?invalid=${this.isValid === false}></jh-input>
      ${characterLimit ? html ` <p class="character-limit">${this.value?.length || 0}/${characterLimit}</p> ` : ''}
    `;
    }
    renderSelect() {
        import('../../jha-form-select/jha-form-select.js');
        const { label, options, emptyOptionLabel, required } = this.fieldConfig;
        return html `
      <jha-form-select
        .options=${options}
        .value=${this.value}
        label=${label || ''}
        .emptyOptionLabel=${emptyOptionLabel || ' '}
        .required=${required}
        @change=${this.inputValueChange}
        @blur=${this.handleBlur}
        .disabled=${this.disabled}
        ?small=${this.inputSize === 'small'}
        ?invalid=${this.isValid === false}
        warning=" "></jha-form-select>
    `;
    }
    renderSwitch() {
        import('@jack-henry/jh-elements/components/switch/switch.js');
        const { label, caption } = this.fieldConfig;
        return html `
      <jh-switch
        .checked=${this.value}
        label=${label || ''}
        .disabled=${this.disabled}
        .helperText=${caption || ''}
        @jh-change=${this.inputValueChange}></jh-switch>
    `;
    }
    renderNumber() {
        import('../../jha-form-input-base/jha-form-input.js');
        const { caption, label, max, min, step, placeholder, required } = this.fieldConfig;
        return html `
      <jha-form-input
        type="number"
        .value=${this.value}
        label=${label || ''}
        .disabled=${this.disabled}
        .helpText=${caption || ''}
        .placeholder=${placeholder || ''}
        .required=${required}
        .max=${max}
        .min=${min}
        .step=${step}
        ?small=${this.inputSize === 'small'}
        @change=${this.inputValueChange}></jha-form-input>
    `;
    }
    renderDate() {
        import('../../jha-form-input-base/jha-form-input.js');
        const { caption, label, placeholder, required, preventFuture, preventPast } = this.fieldConfig;
        const today = new Date();
        today.setMinutes(today.getMinutes() - today.getTimezoneOffset());
        const todayLocal = today.toISOString().slice(0, 10);
        const minDate = preventPast ? todayLocal : this.fieldConfig.minDate;
        const maxDate = preventFuture ? todayLocal : this.fieldConfig.maxDate;
        return html `
      <jha-form-input
        type="date"
        .value=${this.value}
        label=${label || ''}
        .disabled=${this.disabled}
        .helpText=${caption || ''}
        .placeholder=${placeholder || ''}
        .required=${required}
        .max=${maxDate ?? ''}
        .min=${minDate ?? ''}
        ?small=${this.inputSize === 'small'}
        @change=${this.inputValueChange}></jha-form-input>
    `;
    }
    renderPhone() {
        import('@jack-henry/jh-elements/components/input-telephone/input-telephone.js');
        const { caption, label, placeholder, required, mask, maxLength, minLength } = this.fieldConfig;
        return html `
      <jh-input-telephone
        .value=${this.value}
        label=${label || ''}
        .disabled=${this.disabled}
        .helpText=${caption || ''}
        .placeholder=${placeholder || ''}
        .required=${required}
        input-mask=${mask?.replace(/[_9]/g, (char) => (char === '_' ? '9' : '\\\\9'))}
        .maxlength=${maxLength ? `${maxLength}` : mask.length}
        .minlength=${minLength ? `${minLength}` : ''}
        error-text="Please provide a valid phone number."
        @jh-change=${this.inputValueChange}></jh-input-telephone>
    `;
    }
    renderUpload() {
        import('../../../jha-file-uploader/jha-file-uploader.js');
        const { caption, label, max, required, accept, multiple } = this.fieldConfig;
        return html `
      <jha-file-uploader
        label=${label || ''}
        .disabled=${this.disabled}
        .helpText=${caption || ''}
        .required=${required}
        .max=${ifDefined(max)}
        .accept=${accept}
        .multiple=${multiple}
        @change=${({ detail: files }) => {
            this.updateValue(files.map(({ file }) => file));
        }}></jha-file-uploader>
    `;
    }
    renderReadOnly() {
        const { inputType, label, readOnlyLayout } = this.fieldConfig;
        const calculatedFieldLayout = readOnlyLayout || this.readOnlyLayout || 'stacked';
        return html `
      <div class="read-only-container">
        <div
          read-only-layout=${calculatedFieldLayout}
          class="read-only-field"
          input-type=${inputType}>
          ${label ? html `<label>${label}${calculatedFieldLayout === 'stacked' ? '' : ':'}</label>` : ''}
          <div
            class="value"
            title=${this.displayValue}>
            ${this.displayValue || '--'}
          </div>
        </div>
      </div>
    `;
    }
    renderCurrency() {
        const { caption, label, placeholder, required, max, min, step } = this.fieldConfig;
        import('../../jha-form-currency-input/jha-form-currency-input.js');
        return html `
      <jha-form-currency-input
        .value=${this.value}
        label=${label || ''}
        .disabled=${this.disabled}
        .helpText=${caption || ''}
        .placeholder=${placeholder || ''}
        .required=${required}
        .max=${max}
        .min=${min}
        .step=${step}
        ?small=${this.inputSize === 'small'}
        useCommas
        @change=${this.inputValueChange}></jha-form-currency-input>
    `;
    }
    renderPercentage() {
        import('../../jha-form-percent-input/jha-form-percent-input.js');
        const { caption, label, placeholder, required, min, max, step } = this.fieldConfig;
        return html `
      <jha-form-percent-input
        .value=${this.value}
        label=${label || ''}
        .disabled=${this.disabled}
        .helpText=${caption || ''}
        .placeholder=${placeholder || ''}
        .required=${required}
        .min=${min || 0}
        .max=${max || 100}
        .step=${step}
        ?small=${this.inputSize === 'small'}
        @change=${this.inputValueChange}></jha-form-percent-input>
    `;
    }
    render() {
        if (this.readOnly) {
            return this.renderReadOnly();
        }
        switch (this.fieldConfig.inputType) {
            case 'checkbox':
                return this.renderCheckbox();
            case 'radio':
                return this.renderRadio();
            case 'select':
                return this.renderSelect();
            case 'switch':
                return this.renderSwitch();
            case 'number':
                return this.renderNumber();
            case 'phone':
                return this.renderPhone();
            case 'file':
                return this.renderUpload();
            case 'currency':
                return this.renderCurrency();
            case 'percentage':
                return this.renderPercentage();
            case 'date':
                return this.renderDate();
            case 'text':
            default:
                return this.renderTextInput();
        }
    }
}
__decorate([
    property({ type: Object, attribute: 'field-config' }),
    __metadata("design:type", Object)
], JhaDynamicInput.prototype, "fieldConfig", void 0);
__decorate([
    property({}),
    __metadata("design:type", Object)
], JhaDynamicInput.prototype, "value", void 0);
__decorate([
    property({ type: String, attribute: 'data-id' }),
    __metadata("design:type", String)
], JhaDynamicInput.prototype, "dataId", void 0);
__decorate([
    property({ type: Boolean }),
    __metadata("design:type", Boolean)
], JhaDynamicInput.prototype, "isValid", void 0);
__decorate([
    property({ type: Boolean }),
    __metadata("design:type", Boolean)
], JhaDynamicInput.prototype, "disabled", void 0);
__decorate([
    property({ type: Number, reflect: true }),
    __metadata("design:type", Number)
], JhaDynamicInput.prototype, "size", void 0);
__decorate([
    property({ type: Number, reflect: true, attribute: 'row-length' }),
    __metadata("design:type", Number)
], JhaDynamicInput.prototype, "rowLength", void 0);
__decorate([
    property({ type: Boolean, reflect: true, attribute: 'read-only' }),
    __metadata("design:type", Boolean)
], JhaDynamicInput.prototype, "readOnly", void 0);
__decorate([
    property({ type: String, attribute: 'read-only-layout' }),
    __metadata("design:type", String)
], JhaDynamicInput.prototype, "readOnlyLayout", void 0);
__decorate([
    property({ type: String, attribute: 'input-size' }),
    __metadata("design:type", String)
], JhaDynamicInput.prototype, "inputSize", void 0);
__decorate([
    state(),
    __metadata("design:type", Boolean)
], JhaDynamicInput.prototype, "otherOptionInvalid", void 0);
export { styles as JhaDynamicInputStyles };
