import JhaDynamicInput from './JhaDynamicInput';
customElements.define('jha-dynamic-input', JhaDynamicInput);
/** @customElement jha-dynamic-input */
export default JhaDynamicInput;
