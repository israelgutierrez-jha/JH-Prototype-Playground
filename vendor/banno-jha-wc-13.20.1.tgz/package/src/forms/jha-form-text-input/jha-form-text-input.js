import JhaFormTextInput from './JhaFormTextInput.js';
customElements.define('jha-form-text-input', JhaFormTextInput);
/** @customElement jha-form-text-input */
export default JhaFormTextInput;
