import { html, css } from 'lit';
import { jhaStyles } from '../../styles/jha-styles.js';
import JhaFormInput from '../jha-form-input-base/JhaFormInput.js';
import '../jha-form-floating-group/jha-form-floating-group.js';
/**
 * A souped-up text input element with added functionality of displaying a caption and character
 * count/limit below it.
 * @element jha-form-text-input
 *
 * Extends Jha-form-input see: forms/jha-form-input-base/jhaFormInput.js for list of properties
 */
export default class JhaFormTextInput extends JhaFormInput {
    static get styles() {
        return [
            jhaStyles,
            css `
        :host {
          display: block;
          margin-bottom: 16px;
        }
        :host([disabled]) {
          opacity: var(--jha-input-opacity-disabled, 0.7);
          cursor: default;
        }
        jha-form-floating-group {
          --jha-input-margin-bottom: var(--jha-text-input-margin-bottom, 4px);
          --jha-input-content-flex-direction: column;
        }
        .character-limit {
          float: right;
        }
        .details {
          color: var(--jha-color-gray-medium, var(--body-text-secondary-color));
          font-size: 0.9em;
        }
        datalist {
          margin-top: -12px;
        }
        .required-indicator {
          color: var(--jh-input-required-color-text, var(--jh-color-content-negative-enabled));
        }
        .label-container {
          display: flex;
          justify-content: space-between;
        }
        .label-container > span {
          display: flex;
          justify-content: flex-start;
          gap: 8px;
          white-space: nowrap;
          align-items: center;
        }
      `,
        ];
    }
    static get properties() {
        return {
            characterLimit: {
                type: Number,
            },
            name: {
                type: String,
            },
            error: {
                type: String,
            },
            min: {
                type: Number,
            },
            max: {
                type: Number,
            },
            readonly: {
                type: Boolean,
            },
            maxlength: {
                type: Number,
            },
            minlength: {
                type: Number,
            },
            outline: {
                type: Boolean,
                reflect: true,
            },
            list: {
                type: String,
            },
            listOptions: {
                type: Array,
            },
        };
    }
    constructor() {
        super();
        this.caption = '';
        this.minlength = 0;
        this.maxlength = Infinity;
        this.error = '';
        this.characterLimit = null;
        this.readonly = false;
        this.outline = false;
        this.list = '';
        this.listOptions = [];
        this.name = '';
    }
    renderLabel() {
        return html `
      <div class="label-container">
        <span>
          <label
            for=${this.id}
            class="label">
            ${this.label}${this.required && !this.hideRequiredIndicator
            ? html `
                  <span
                    class="required-indicator"
                    style="color: var(--jh-input-required-color-text, var(--jh-color-content-negative-enabled, var(--jha-color-danger, #DB2012)))">
                    *
                  </span>
                `
            : ''}
          </label>
          <slot name="input-label-icon"></slot>
        </span>

        <slot name="input-top-right"></slot>
      </div>
    `;
    }
    render() {
        return html `
      <div>
        <jha-form-floating-group
          ?outline=${this.outline}
          ?small=${this.small}
          ?filled=${this.filled}
          ?always-float=${Boolean(this.placeholder)}
          ?no-label=${this.noLabel}
          .hasValue=${Boolean(this.value)}
          .error=${this.showWarning_() ? this.warning : null}
          .assistiveText=${this.assistiveText}>
          ${this.label ? this.renderLabel() : ''}
          <slot
            name="input-left"
            slot="input-left"></slot>
          <input
            id=${this.id}
            name=${this.id === null || this.id === undefined ? this.name : this.id}
            placeholder=${this.placeholder}
            ?required=${this.required}
            ?readonly=${this.readonly}
            ?disabled=${this.disabled}
            type="text"
            minlength=${this.minlength}
            maxlength=${this.characterLimit ? this.characterLimit : this.maxlength}
            .value=${this.value}
            aria-label=${this.label}
            .title=${this.caption}
            @input=${this.onInput_}
            @change=${this.onChange_}
            @blur=${this.onBlur_}
            autocomplete=${this.autocomplete}
            @keydown=${this.onKeydown_}
            @keypress=${this.onKeypress_}
            list=${this.list} />
          <slot
            slot="input-right"
            name="input-right"></slot>
          <slot
            name="assistive-text"
            slot="assistive-text"></slot>
        </jha-form-floating-group>
        ${this.list
            ? html `
              <datalist id=${this.list}>
                ${this.listOptions.map((o) => html ` <option value=${o.value}></option> `)}
              </datalist>
            `
            : html ``}
        ${!this.error
            ? html `
              <div class="details">
                <span>${this.caption}</span>
                ${this.characterLimit
                ? html ` <span class="character-limit"> ${this.value.length}/${this.characterLimit} </span> `
                : ''}
              </div>
            `
            : ''}
      </div>
    `;
    }
}
