import JhaChartLegendElement from './JhaChartLegend';
customElements.define('jha-chart-legend', JhaChartLegendElement);
/** @customElement jha-chart-legend */
export default JhaChartLegendElement;
