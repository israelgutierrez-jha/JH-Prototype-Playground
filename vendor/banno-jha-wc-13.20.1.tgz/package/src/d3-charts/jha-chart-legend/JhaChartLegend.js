var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { LitElement, html, css, nothing } from 'lit';
import { property } from 'lit/decorators.js';
import * as d3 from 'd3';
import JhaDropdown from '../../dropdowns/jha-dropdown/jha-dropdown.js';
import '../../dropdowns/jha-dropdown-toggle/jha-dropdown-toggle.js';
import '../../dropdowns/jha-dropdown-menu/jha-dropdown-menu.js';
import '../../dropdowns/jha-dropdown-menu-item/jha-dropdown-menu-item.js';
import { UNKNOWN_COLOR } from '../shared/chart-util';
const styles = css `
  :host {
    display: flex;
    width: 100%;
    font-size: 12px;
    align-items: flex-start;
    align-self: center;
  }
  #legend-container {
    overflow: hidden;
    width: 100%;
    margin-bottom: 16px;
  }
  ul#legend {
    list-style: none;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    height: 24px;
    overflow: hidden;
    margin: 0;
    padding-inline-start: 0;
  }
  rect {
    rx: 4px;
    ry: 4px;
  }
  span {
    white-space: nowrap;
  }
  jha-dropdown {
    margin-left: 8px;
    margin-right: 48px;
    padding: 4px 0;
  }
  jha-dropdown-toggle {
    color: var(--jh-color-content-secondary-enabled);
  }
  jha-dropdown-menu {
    min-width: 100px;
    box-shadow:
      0 1px 1px 0 rgba(0, 0, 0, 0.24),
      0 1px 4px rgba(0, 0, 0, 0.12);
    max-height: var(--jha-chart-legend-overflow-max-height, 800px);
  }
  jha-dropdown-menu-item {
    font-size: 12px;
    background: transparent;
    font-weight: 400;
    cursor: default;
    white-space: nowrap;
  }
  ul > jha-dropdown-menu-item {
    margin-bottom: 16px;
  }
  jha-dropdown-menu-item > * {
    padding-top: 0;
    padding-bottom: 0;
  }
  jha-dropdown-menu#overflow jha-dropdown-menu-item {
    padding: 8px 8px 0 8px;
  }
  jha-dropdown-menu#overflow jha-dropdown-menu-item:last-of-type {
    padding: 8px;
  }
`;
export default class JhaChartLegendElement extends LitElement {
    constructor() {
        super(...arguments);
        this.colorScale = d3.scaleOrdinal().unknown(UNKNOWN_COLOR);
        this.dotSize = 8;
        this.hiddenKeyCount = 0;
        this.keys = [];
        this.showHidden = true;
    }
    static get styles() {
        return [styles];
    }
    async onUpdateComplete() {
        await this.updateComplete;
        const legendEl = this.shadowRoot?.querySelector('ul#legend');
        if (!legendEl)
            return;
        const legendTop = legendEl.offsetTop;
        const keys = Array.from(legendEl.querySelectorAll('.series-key'));
        const hiddenKeys = keys.filter((k) => k.offsetTop - legendTop > 0);
        this.hiddenKeyCount = hiddenKeys.length;
        if (!this.showHidden) {
            return;
        }
        const overflow = this.shadowRoot?.querySelector('jha-dropdown-menu#overflow');
        const onHover = this.onHover.bind(this);
        const onUnhover = this.onUnhover.bind(this);
        if (overflow) {
            overflow.replaceChildren(...hiddenKeys.map((k) => {
                const clone = k.cloneNode(true);
                clone.addEventListener('mouseover', onHover);
                clone.addEventListener('mouseleave', onUnhover);
                return clone;
            }));
        }
    }
    onHover(evt) {
        const key = evt.currentTarget?.dataset?.key;
        if (key) {
            this.dispatchEvent(new CustomEvent('highlight', { bubbles: false, detail: { key } }));
        }
    }
    onUnhover(evt) {
        const key = evt.currentTarget?.dataset?.key;
        if (key) {
            this.dispatchEvent(new CustomEvent('unhighlight', { bubbles: false, detail: { key } }));
        }
    }
    onHoverToggle() {
        const dropdown = this.shadowRoot?.querySelector('jha-dropdown');
        if (!(dropdown instanceof JhaDropdown)) {
            return;
        }
        if (!dropdown?.open) {
            dropdown.openMenu();
        }
    }
    render() {
        if (this.keys.length === 0 || !this.colorScale || this.keys.every((k) => !k)) {
            return nothing;
        }
        this.onUpdateComplete();
        return html `
      <div id="legend-container">
        <ul id="legend">
          ${this.keys.map((key) => {
            const svg = d3.create('svg').attr('width', 16).attr('height', 16).attr('viewBox', [0, 0, 16, 16]);
            svg
                .selectAll('dots')
                .data([key])
                .enter()
                .append('rect')
                .attr('x', 0)
                .attr('y', 7)
                .attr('width', this.dotSize)
                .attr('height', this.dotSize)
                .style('fill', (d) => this.colorScale?.(d?.toString()))
                .append('title')
                .text((d) => d);
            return html `
              <jha-dropdown-menu-item
                class="series-key"
                data-key="${key}"
                @mouseover=${this.onHover}
                @mouseleave=${this.onUnhover}>
                <div>${svg.node()}${key}</div>
              </jha-dropdown-menu-item>
            `;
        })}
        </ul>
      </div>
      ${this.maybeRenderOverflow()}
    `;
    }
    maybeRenderOverflow() {
        if (!this.hiddenKeyCount) {
            return '';
        }
        return html `
      <jha-dropdown
        @mouseover=${this.onHoverToggle}
        @mouseleave=${this.onHoverToggle}>
        <jha-dropdown-toggle slot="toggle">
          <span>${this.hiddenKeyCount} more...</span>
        </jha-dropdown-toggle>
        <jha-dropdown-menu id="overflow"></jha-dropdown-menu>
      </jha-dropdown>
    `;
    }
}
__decorate([
    property({ attribute: false }),
    __metadata("design:type", Function)
], JhaChartLegendElement.prototype, "colorScale", void 0);
__decorate([
    property({ type: Number }),
    __metadata("design:type", Object)
], JhaChartLegendElement.prototype, "dotSize", void 0);
__decorate([
    property({ type: Number }),
    __metadata("design:type", Object)
], JhaChartLegendElement.prototype, "hiddenKeyCount", void 0);
__decorate([
    property({ type: Array }),
    __metadata("design:type", Object)
], JhaChartLegendElement.prototype, "keys", void 0);
__decorate([
    property({ type: Boolean }),
    __metadata("design:type", Object)
], JhaChartLegendElement.prototype, "showHidden", void 0);
