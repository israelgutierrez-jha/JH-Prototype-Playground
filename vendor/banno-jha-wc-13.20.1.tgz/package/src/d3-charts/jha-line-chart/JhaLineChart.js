var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { LitElement, css } from 'lit';
import { property } from 'lit/decorators.js';
import * as d3 from 'd3';
import { jhaChartMixin, sharedChartStyles, NO_SEGMENT_KEY, } from '../shared/jha-chart-mixin';
import { parseAsNumber, UNKNOWN_COLOR } from '../shared/chart-util';
import { colorPalette18 } from '../shared/color-palette';
const styles = css `
  rect.dot {
    rx: 3px;
    ry: 3px;
    transition:
      transform 0.15s ease,
      opacity 0.2s ease;
  }
  rect.dot:not([highlighted]) {
    fill: transparent !important;
    stroke: transparent !important;
  }
  .hover-line {
    stroke: var(--jha-color-neutral);
    stroke-dasharray: 4;
    transition: opacity 0.2s ease;
  }
  /* hover effects */
  svg:has(g[highlight]) g[data-key]:not([highlight]) path {
    stroke-width: 4;
    opacity: 0.3;
    filter: grayscale(40%);
  }
  svg g[data-key] path {
    transition:
      stroke-width 0.2s ease,
      filter 0.25s ease;
  }
  svg g[data-key][highlight] path {
    stroke-width: 4;
    filter: drop-shadow(0 0 1px currentColor);
  }
`;
const minStepWidth = 80;
const marginTop = 10;
const marginRight = 0;
const marginBottom = 36;
const minMarginLeft = 24;
const zeroValue = 0;
const ANIMATION_DURATION = window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 100 : 800;
export default class JhaLineChartElement extends jhaChartMixin(LitElement) {
    constructor() {
        super(...arguments);
        this._series = null;
        this.dotSize = 6;
        this.highlightedDate = null;
        this.getYValue = (valueConfigs, key, p) => {
            let yValue;
            if (this.useValuesAsKeys) {
                // multiple value configurations, use the one that matches the series key
                const vc = valueConfigs.find((vc) => vc.label === key);
                yValue = parseAsNumber(p[vc?.name]);
            }
            else {
                // single value configuration
                yValue = parseAsNumber(p[valueConfigs[0]?.name]);
            }
            return yValue;
        };
        this.updateSeries = async () => {
            if (!this.data?.length || !this.configuration) {
                this._series = null;
                this._keys = [];
                return;
            }
            const data = this.data;
            const config = this.configuration;
            const valueConfigs = this.valueConfigs;
            const useValuesAsKeys = this.useValuesAsKeys;
            const allKeys = useValuesAsKeys
                ? valueConfigs.map((vc) => vc.label) // use values as keys if there are multiple
                : Array.from(new Set(data?.map((d) => d[config.ySegment?.name]?.toString() || NO_SEGMENT_KEY))); // otherwise use ySegment
            this._keys = useValuesAsKeys
                ? valueConfigs.filter((vc) => this.filter(vc.label)).map((vc) => vc.label) // use values as keys if there are multiple
                : Array.from(new Set(this.filteredData?.map((d) => d[config.ySegment?.name]?.toString() || NO_SEGMENT_KEY))); // otherwise use ySegment
            // sort all keys alphanumerically to ensure consistent color mapping and legend order
            allKeys.sort((a, b) => a.localeCompare(b));
            this._keys.sort((a, b) => a.localeCompare(b));
            const dates = Array.from(new Set(data.map((d) => d[config.xSegment?.name])));
            this._series = this._keys.map((ySegment, i) => [
                ySegment,
                dates.map((xSegment) => data.find((d) => d[config.xSegment?.name] === xSegment && (!config.ySegment || d[config.ySegment?.name] === ySegment)) || {
                    // missing data point, use 0 as default value
                    [config.xSegment?.name]: xSegment,
                    [config.ySegment?.name]: ySegment,
                    [(useValuesAsKeys ? valueConfigs[i] : valueConfigs[0])?.name]: zeroValue,
                }),
            ]);
            this.colorScale = d3
                .scaleOrdinal()
                // should be all possible keys rather than just filtered keys; otherwise, colors may shift when filtering
                .domain(allKeys)
                .range(colorPalette18)
                .unknown(UNKNOWN_COLOR);
        };
        this.updateChart = () => {
            if (!this.configuration || !this._series?.length) {
                return;
            }
            const series = this._series;
            const config = this.configuration;
            const valueConfigs = this.useValuesAsKeys
                ? this.valueConfigs.filter((vc) => this.filter(vc.label))
                : this.valueConfigs;
            const xFormatter = this.getFormatter(config.xSegment?.type);
            const yFormatter = this.getFormatter(valueConfigs.length === 1 ? valueConfigs[0]?.type : 'number'); // TODO: support multiple value types/axes, but for now just use 'number' if multiple
            this._yScale = d3
                .scaleLinear()
                .domain([
                Math.min(d3.min(series, (d) => d3.min(valueConfigs, (vc) => d3.min(d[1], (d2) => parseAsNumber(d2[vc?.name])))), 0),
                d3.max(series, (d) => d3.max(valueConfigs, (vc) => d3.max(d[1], (d2) => parseAsNumber(d2[vc?.name])))),
            ])
                .range([this.availableHeight - marginBottom, marginTop]);
            // determine margin based on the longest y-axis label
            const yAxisWidth = Math.max(minMarginLeft, d3.max(this._yScale.ticks(), (d) => yFormatter(d)?.length || 0) * 7);
            this._xScale = d3
                .scaleBand()
                .domain(this._series[0][1].map((d) => d[config.xSegment?.name]))
                .range([minStepWidth / 2, this.width - marginRight - minStepWidth / 2])
                .paddingOuter(0.1)
                .paddingInner(1);
            // A function to format the value in the tooltip.
            const formatValue = (v) => (Number.isNaN(v) ? 'N/A' : v.toLocaleString('en'));
            // Create the SVG container.
            const svg = d3
                .create('svg')
                .attr('width', this.width - yAxisWidth - 8) // account for the width of the axis and the container's `gap`
                .attr('height', this.availableHeight)
                .attr('viewBox', [0, 0, this.width, this.availableHeight]);
            const yAxisSvg = d3
                .create('svg')
                .attr('id', 'y-axis')
                .attr('width', yAxisWidth)
                .attr('height', this.availableHeight)
                .attr('viewBox', [0, 0, yAxisWidth, this.availableHeight]);
            // Append the horizontal axis.
            svg
                .append('g')
                .attr('id', 'x-axis')
                .attr('transform', `translate(0,${this.availableHeight - 20})`) // account for text height
                .call(d3.axisBottom(this._xScale).tickSize(0).tickFormat(xFormatter))
                .call((g) => g.selectAll('.domain').remove());
            const yAxis = (svg) => svg
                .append('g')
                .attr('class', 'y-axis')
                .call(d3.axisLeft(this._yScale).tickSize(0).tickFormat(yFormatter))
                .call((g) => g.selectAll('.domain').remove());
            // Append the vertical axis ticks.
            yAxis(svg)
                .call((g) => g
                .selectAll('.tick line')
                .clone()
                .attr('x1', 0)
                .attr('x2', this.width - marginRight)
                .attr('stroke-opacity', 0.1))
                .call((g) => g.selectAll('.tick text').remove());
            yAxis(yAxisSvg).call((g) => g
                .selectAll('.tick text')
                .attr('x', this.yAxisLeftAlign ? 0 : yAxisWidth)
                .attr('text-anchor', this.yAxisLeftAlign ? 'start' : 'end'));
            // Add hover line before series (whether or not it's visible) so it's displayed behind the dots
            svg.append('line').attr('class', 'hover-line');
            // Append a group for each series, and a path for each element in the series.
            // d[0] = key
            // d[1] = data
            const groups = svg
                .append('g')
                .selectAll()
                .data(this._series)
                .join('g')
                .attr('data-key', (d) => d[0])
                .attr('stroke', (d) => this.colorScale?.(d[0]) || UNKNOWN_COLOR)
                .attr('stroke-width', '3')
                .attr('stroke-linejoin', 'round')
                .attr('stroke-linecap', 'round')
                .on('mouseenter', (event, d) => {
                this.highlight(d[0]);
            })
                .on('mouseleave', (event, d) => {
                this.unhighlight(d[0]);
            });
            const line = d3.line().curve(d3.curveMonotoneX);
            // Add paths (lines) with draw animation
            groups
                .append('path')
                .attr('fill', 'none')
                .attr('d', (d) => line(d[1].map((p) => {
                const key = d[0];
                const yValue = this.getYValue(valueConfigs, key, p);
                return [this._xScale(p[config.xSegment?.name]), this._yScale(yValue)];
            })))
                .each(function () {
                const path = this;
                const totalLength = path.getTotalLength();
                d3.select(path)
                    .attr('stroke-dasharray', `${totalLength} ${totalLength}`)
                    .attr('stroke-dashoffset', totalLength)
                    .transition()
                    .duration(ANIMATION_DURATION)
                    .ease(d3.easeQuadOut)
                    .attr('stroke-dashoffset', 0);
            });
            // Add transparent dots with title (details) - fade in after line draws
            groups
                .selectAll('rect.dot')
                .data((D) => D[1].map((d) => ({ ...d, key: D[0] })))
                .join('rect')
                .attr('class', 'dot')
                .attr('x', (d) => (this._xScale(d[config.xSegment?.name]) ?? 0) - this.dotSize / 2)
                .attr('y', (d) => {
                const yValue = this.getYValue(valueConfigs, d.key, d);
                return this._yScale(yValue) - this.dotSize / 2;
            })
                .attr('width', this.dotSize)
                .attr('height', this.dotSize)
                .attr('value', (d) => {
                const yValue = this.getYValue(valueConfigs, d.key, d);
                return yValue;
            })
                .attr('title', (d) => {
                const yValue = this.getYValue(valueConfigs, d.key, d);
                return `${xFormatter(d[config.xSegment?.name])} - ${d.key} - ${formatValue(yFormatter(yValue))}`;
            })
                .attr('stroke', (d) => this.colorScale?.(d.key) || UNKNOWN_COLOR)
                .style('fill', (d) => this.colorScale?.(d.key) || UNKNOWN_COLOR)
                .style('opacity', 0)
                .on('mouseenter', (event, d) => {
                const highlightedData = d;
                this.maybeShowHoverDetails(event.target, highlightedData);
            })
                .on('mouseleave', () => {
                this.onUnhoverData();
            })
                .transition()
                .delay(ANIMATION_DURATION * 0.6)
                .duration(ANIMATION_DURATION * 0.4)
                .style('opacity', 1);
            this.chart = svg.node();
            this.yAxis = yAxisSvg.node();
            this.addHoverLine(svg, this._xScale);
            if (this.highlightedDate) {
                this.updateHoverLine(svg);
            }
        };
        /**
         * Show vertical dotted line for the closest date, highlighting each value on the line
         * @param {d3.ScaleBand<string>} x - x scale
         */
        this.addHoverLine = (svg, x) => {
            const savedDate = this.highlightedDate;
            svg.on('mousemove touchmove', (event) => {
                const [xPos] = d3.pointer(event);
                const closestDate = x.domain().reduce((a, b) => (Math.abs(xPos - x(a)) < Math.abs(xPos - x(b)) ? a : b));
                if (this.highlightedDate === closestDate) {
                    return;
                }
                this.highlightedDate = closestDate;
                this.updateHoverLine(svg);
            });
            svg.on('mouseleave', () => {
                svg.select('line.hover-line').attr('x1', null).attr('x2', null).attr('y1', null).attr('y2', null);
                this.shadowRoot.querySelectorAll('.tooltip').forEach((t) => t.remove());
                this.highlightedDate = savedDate;
                this.updateHoverLine(svg);
            });
        };
    }
    static { this.styles = [sharedChartStyles, styles]; }
    get width() {
        if (!this._series?.length) {
            return 0;
        }
        const maxSeriesLength = this._series.length === 1
            ? this._series[0][1].length
            : this._series.reduce((max, cur) => (Number.isNaN(max) ? cur[1].length : Math.max(cur[1].length, max)), 0);
        return Math.max(maxSeriesLength * minStepWidth, this.containerWidth);
    }
    /**
     * Reset highlighted dots and place hover line at the correct position
     * @param {SVGElement} svg
     */
    updateHoverLine(svg) {
        // reset highlighted dots
        svg.selectAll('rect.dot[highlighted]').each((d, i, nodes) => {
            nodes[i].removeAttribute('highlighted');
        });
        // highlight dots
        svg
            .selectAll('rect.dot')
            .filter((d) => this._xScale(d[this.configuration.xSegment?.name]) === this._xScale(this.highlightedDate))
            .each((d, i, nodes) => {
            nodes[i].setAttribute('highlighted', '');
        });
        const x = this._xScale(this.highlightedDate);
        if (x && this.configuration?.features?.hoverDate) {
            // place hover line
            svg
                .select('line.hover-line')
                .attr('x1', x)
                .attr('x2', x)
                .attr('y1', this._yScale(d3.max(this._yScale.domain()) || 0))
                .attr('y2', this._yScale(d3.min(this._yScale.domain()) || 0));
        }
        else {
            // hide hover line
            svg.select('line.hover-line').attr('x1', null).attr('x2', null).attr('y1', null).attr('y2', null);
        }
        this.showHighlightedValueTooltips();
    }
    async showHighlightedValueTooltips() {
        if (!this.configuration?.features?.tooltips) {
            return;
        }
        // remove any existing tooltips
        this.shadowRoot.querySelectorAll('.tooltip').forEach((t) => t.remove());
        // wait for the chart to be updated
        await this.updateComplete;
        await this.updateComplete;
        const thisBounds = this.chart?.getBoundingClientRect() || this.getBoundingClientRect();
        const tooltips = Array.from(this.shadowRoot.querySelectorAll('rect.dot[highlighted]')).map((node) => {
            const bounds = node.getBoundingClientRect();
            const scrollLeft = this.chartContainer?.scrollLeft || 0;
            // show formatted values
            const tooltip = document.createElement('div');
            this.tooltipContainer.appendChild(tooltip);
            tooltip.setAttribute('class', 'tooltip');
            window.setTimeout(() => {
                const tooltipWidth = tooltip.getBoundingClientRect().width;
                const newTop = bounds.y - thisBounds.top - 32;
                tooltip.style.top = `${newTop < 0 ? 0 : newTop}px`;
                if (bounds.x + tooltipWidth <= document.body.clientWidth) {
                    // show on right side of target (preferred)
                    tooltip.style.left = `${bounds.x - thisBounds.left + scrollLeft + 8}px`;
                }
                else {
                    // show on left side of the target if it would flow off the screen
                    tooltip.style.left = `${bounds.x + thisBounds.left + scrollLeft - tooltipWidth - 8}px`;
                }
            });
            const value = parseInt(node.getAttribute('value'), 10);
            const valueConfigs = Array.isArray(this.configuration?.value)
                ? this.configuration?.value
                : [this.configuration?.value];
            const formatter = this.getFormatter(valueConfigs.length === 1 ? valueConfigs[0].type : 'number'); // TODO: support multiple value types/axes, but for now just use 'number' if multiple
            tooltip.innerText = formatter(value);
            return tooltip;
        });
        window.setTimeout(() => {
            // check for overlapping tooltips and adjust positions if necessary
            tooltips
                .sort((a, b) => a.offsetTop - b.offsetTop) // it's important that the tooltips are sorted by top position (ascending)
                .forEach((t1, i) => {
                const tooltip = t1;
                const bounds = tooltip.getBoundingClientRect();
                tooltips.slice(i + 1).forEach((t) => {
                    const otherTooltip = t;
                    const otherBounds = otherTooltip.getBoundingClientRect();
                    if (bounds.bottom > otherBounds.top) {
                        // move other tooltip below this one, with a small gap
                        otherTooltip.style.top = `${tooltip.offsetTop + otherBounds.height + 4}px`;
                    }
                });
            });
        });
    }
}
__decorate([
    property({ type: Number }),
    __metadata("design:type", Object)
], JhaLineChartElement.prototype, "dotSize", void 0);
__decorate([
    property({ type: String }),
    __metadata("design:type", String)
], JhaLineChartElement.prototype, "highlightedDate", void 0);
