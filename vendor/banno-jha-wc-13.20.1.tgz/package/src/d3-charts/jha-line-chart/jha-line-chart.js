import JhaLineChartElement from './JhaLineChart';
customElements.define('jha-line-chart', JhaLineChartElement);
/** @customElement jha-line-chart */
export default JhaLineChartElement;
