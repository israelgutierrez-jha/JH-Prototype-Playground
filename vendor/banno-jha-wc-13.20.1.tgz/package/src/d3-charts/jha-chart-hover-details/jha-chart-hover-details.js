import JhaChartHoverDetailsElement from './JhaChartHoverDetails';
customElements.define('jha-chart-hover-details', JhaChartHoverDetailsElement);
/** @customElement jha-chart-hover-details */
export default JhaChartHoverDetailsElement;
