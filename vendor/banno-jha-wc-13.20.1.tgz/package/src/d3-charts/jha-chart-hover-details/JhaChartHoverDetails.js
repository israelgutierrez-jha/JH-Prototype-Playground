var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { LitElement, html, css, nothing } from 'lit';
import { property } from 'lit/decorators.js';
import { numberFormatter } from '../shared/chart-util';
const styles = css `
  :host {
    display: flex;
    border-radius: var(--4, 4px);
    border: 1px solid var(--jh-color-divider-primary);
    background: var(--jh-color-container-secondary-enabled);
    box-shadow: 0px 4px 24px -8px rgba(0, 0, 0, 0.25);
    backdrop-filter: blur(10px);
    padding: 7px;
    gap: 9px;
    line-height: 14px;
    color: var(--jh-color-content-secondary-enabled);
  }
  #color {
    border-radius: 5px;
    width: 3px;
  }
  h3 {
    color: var(--jh-color-content-primary-enabled);
    font-size: var(--jh-font-size-350);
    font-weight: 700;
    margin: 4px 0;
  }
  p {
    padding: 3px 0;
    margin: 0;
  }
  p span {
    color: var(--jh-color-content-primary-enabled);
    font-size: var(--jh-font-size-300);
    font-weight: var(--jh-font-weight-500);
    font-family: monospace;
  }
`;
export default class JhaChartHoverDetailsElement extends LitElement {
    constructor() {
        super(...arguments);
        this.color = null;
        this.chartTitle = '';
        this.details = null;
    }
    static { this.styles = [styles]; }
    static get properties() {
        return {
            details: {
                type: Object,
                attribute: false,
            },
            color: {
                type: String,
            },
        };
    }
    get percentOfTotal() {
        if (!this.details) {
            return 0;
        }
        return (Math.abs(this.details.value / this.details.total) * 100).toFixed(1);
    }
    render() {
        if (!this.details) {
            return nothing;
        }
        return html `
      <div
        id="color"
        style="background-color: ${this.color}"></div>
      <div>
        <h3>${this.chartTitle}</h3>
        <p>${this.details.ySegment}</p>
        <p>${this.details.xSegment}</p>
        <p>
          <span>${numberFormatter(this.details.value)}</span>
          ${this.details.valueDescription || 'total'}
        </p>
        ${this.maybeRenderTotal()}
      </div>
    `;
    }
    maybeRenderTotal() {
        if (!this.details.ySegment || isNaN(this.percentOfTotal)) {
            return nothing;
        }
        return html `
      <p>
        <span>${this.percentOfTotal}%</span>
        of total (${numberFormatter(this.details?.total || 0)})
      </p>
    `;
    }
}
__decorate([
    property({ type: String }),
    __metadata("design:type", String)
], JhaChartHoverDetailsElement.prototype, "color", void 0);
__decorate([
    property({ type: String }),
    __metadata("design:type", String)
], JhaChartHoverDetailsElement.prototype, "chartTitle", void 0);
__decorate([
    property({ type: Object, attribute: false }),
    __metadata("design:type", Object)
], JhaChartHoverDetailsElement.prototype, "details", void 0);
