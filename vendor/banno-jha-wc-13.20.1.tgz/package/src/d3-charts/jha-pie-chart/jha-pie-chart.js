import JhaPieChartElement from './JhaPieChart';
customElements.define('jha-pie-chart', JhaPieChartElement);
/** @customElement jha-pie-chart */
export default JhaPieChartElement;
