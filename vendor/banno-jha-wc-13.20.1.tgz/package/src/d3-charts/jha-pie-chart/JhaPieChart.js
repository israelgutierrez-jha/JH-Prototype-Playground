import { LitElement, css, html } from 'lit';
import * as d3 from 'd3';
import { jhaChartMixin, sharedChartStyles, } from '../shared/jha-chart-mixin';
import { UNKNOWN_COLOR } from '../shared/chart-util';
import { colorPalette18 } from '../shared/color-palette';
const zeroValue = 0;
const ANIMATION_DURATION = window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 800;
const styles = css `
  .pie-chart {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }
  slot[name='details'],
  ::slotted(*) {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    position: absolute;
  }
  /* Pie slice hover/highlight effects */
  svg path[data-key] {
    transition:
      opacity 0.25s ease,
      filter 0.25s ease,
      transform 0.2s ease;
    transform-origin: center;
  }
  svg:has(path[highlight]) path[data-key]:not([highlight]) {
    opacity: 0.4;
    filter: grayscale(30%);
  }
  svg path[data-key][highlight] {
    filter: drop-shadow(0 2px 8px rgba(0, 0, 0, 0.3));
  }
  svg path[data-key]:hover:not([highlight]) {
    filter: brightness(1.15);
  }
`;
export default class JhaPieChartElement extends jhaChartMixin(LitElement) {
    constructor() {
        super(...arguments);
        this.onHighlightedKeyChanged = (event) => {
            this.unhighlightedSections.forEach((section) => {
                const arcDatum = section['__data__'];
                section.setAttribute('d', this.arc(arcDatum));
            });
            if (!this.highlightedSection) {
                return;
            }
            const arcDatum = this.highlightedSection['__data__'];
            this.highlightedSection.setAttribute('d', this.highlightArc(arcDatum));
        };
        this.updateSeries = async () => {
            if (!this.data?.length || !this.configuration) {
                this._series = null;
                this._keys = [];
                return;
            }
            const data = this.data;
            const config = this.configuration;
            const allKeys = data.map((d) => d[config.ySegment?.name]?.toString()).sort((a, b) => a.localeCompare(b));
            this._keys = Array.from(new Set(this.filteredData?.map((d) => d[config.ySegment?.name])));
            // sort all keys alphanumerically to ensure consistent color mapping and legend order
            allKeys.sort((a, b) => a.localeCompare(b));
            this._keys.sort((a, b) => a.localeCompare(b));
            this._series = this.filteredData;
            this.colorScale = d3
                .scaleOrdinal()
                // should be all possible keys rather than just filtered keys; otherwise, colors may shift when filtering
                .domain(allKeys)
                .range(colorPalette18)
                .unknown(UNKNOWN_COLOR);
        };
        this.updateChart = () => {
            if (!this.configuration || !this.data?.length) {
                return;
            }
            const series = this._series;
            const config = this.configuration;
            const valueConfigs = this.valueConfigs;
            const { width } = this;
            const xFormatter = this.getFormatter(config.xSegment?.type);
            const yFormatter = this.getFormatter(valueConfigs[0].type);
            // A function to format the value in the tooltip.
            const formatValue = (v) => (Number.isNaN(v) ? 'N/A' : v.toLocaleString('en'));
            // Create the SVG container.
            const svg = d3
                .create('svg')
                .attr('width', width)
                .attr('height', this.availableHeight)
                .attr('viewBox', [0, 0, width, this.availableHeight]);
            const outerRadius = Math.min(width, this.availableHeight) / 2;
            // Create a pie generator
            const pie = d3
                .pie()
                .value((d) => Number(d[valueConfigs[0].name]) || 0)
                .sort(null)
                .padAngle(1 / outerRadius); // small gap between slices
            // Create a group to hold the pie chart
            const g = svg.append('g').attr('transform', `translate(${width / 2}, ${this.availableHeight / 2})`);
            // Store arc generator reference for the transition
            const arcGen = this.arc;
            const highlightArcGen = this.highlightArc;
            const highlightedKey = this.highlightedKey;
            // Add the pie slices with fan-out animation
            g.selectAll('path')
                .data(pie(series))
                .enter()
                .append('path')
                .attr('data-key', (d) => d.data[config.ySegment?.name]?.toString())
                .attr('fill', (d) => this.colorScale(d.data[config.ySegment?.name]?.toString()) || UNKNOWN_COLOR)
                .attr('title', (d) => {
                const value = d.data[valueConfigs[0].name];
                return `${xFormatter(d.data[config.xSegment?.name])} - ${d.data[config.ySegment?.name]} - ${formatValue(yFormatter(value || zeroValue))}`;
            })
                .on('click', (event, d) => {
                const key = d.data[config.ySegment?.name]?.toString();
                if (this.highlightedKey === key) {
                    this.unhighlight(key);
                }
                else {
                    this.highlight(key);
                    // Rotate the pie chart so the highlighted section is at the top
                    const angle = (d.startAngle + d.endAngle) / 2; // Get the middle angle of the section
                    const rotateDegrees = (-angle * 180) / Math.PI; // Convert to degrees and offset to put at top
                    // Apply rotation to the chart group
                    d3.select(this.chart)
                        .select('g')
                        .transition()
                        .duration(750)
                        .attr('transform', `translate(${this.width / 2}, ${this.availableHeight / 2}) rotate(${rotateDegrees})`);
                }
            })
                .on('mouseenter', (event, d) => {
                const key = d.data[config.ySegment?.name]?.toString();
                const highlightedData = d.data;
                this.maybeShowHoverDetails(event.target, highlightedData);
            })
                .on('mouseleave', () => {
                this.onUnhoverData();
            })
                .transition()
                .duration(ANIMATION_DURATION)
                .ease(d3.easeQuadOut)
                .attrTween('d', function (d) {
                const isHighlighted = d.data[config.ySegment?.name] === highlightedKey;
                const arc = isHighlighted ? highlightArcGen : arcGen;
                const interpolate = d3.interpolate({ startAngle: 0, endAngle: 0 }, d);
                return (t) => arc(interpolate(t));
            });
            this.chart = svg.node();
        };
        this.renderChartContainer = () => {
            return html ` <div class="pie-chart">
      ${this.chart} ${this.maybeRenderHoverDetails()}
      <slot> </slot>
    </div>`;
        };
    }
    static { this.styles = [sharedChartStyles, styles]; }
    get width() {
        return this.containerWidth;
    }
    get donutWidth() {
        return Math.min(this.width, this.availableHeight) / 10;
    }
    /** Pie chart arc generator for non-highlighted section */
    get arc() {
        return d3
            .arc()
            .innerRadius(Math.min(this.width, this.availableHeight) / 2 - this.donutWidth)
            .outerRadius(Math.min(this.width, this.availableHeight) / 2)
            .cornerRadius(2);
    }
    /** Pie chart arc generator for highlighted section */
    get highlightArc() {
        return d3
            .arc()
            .innerRadius(Math.min(this.width, this.availableHeight) / 2 - this.donutWidth - 8)
            .outerRadius(Math.min(this.width, this.availableHeight) / 2)
            .cornerRadius(4);
    }
    get highlightedSection() {
        return this.chart.querySelector('path[highlight]');
    }
    get unhighlightedSections() {
        return this.chart.querySelectorAll('path:not([highlight])');
    }
    connectedCallback() {
        super.connectedCallback();
        this.addEventListener('highlighted-key-changed', this.onHighlightedKeyChanged);
    }
    disconnectedCallback() {
        this.removeEventListener('highlighted-key-changed', this.onHighlightedKeyChanged);
        super.disconnectedCallback();
    }
}
