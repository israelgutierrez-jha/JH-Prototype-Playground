import { format as dateFormat, differenceInMonths, differenceInYears } from 'date-fns';
const today = new Date();
export const shortMonthYearFormatter = (rawValue) => {
    if (Number.isNaN(Date.parse(rawValue))) {
        return rawValue;
    }
    const d = new Date(rawValue);
    d.setUTCHours(12, 0, 0, 0);
    return `${dateFormat(d, 'MMM')} ${dateFormat(d, 'yyyy')}`;
};
export const longMonthYearFormatter = (rawValue) => {
    const d = new Date(rawValue);
    d.setUTCHours(12, 0, 0, 0);
    if (Number.isNaN(Date.parse(rawValue))) {
        return rawValue;
    }
    return `${dateFormat(d, 'MMMM')} ${dateFormat(d, 'yyyy')}`;
};
/**
 * @param {number} value
 * @returns {string}
 */
export const numberFormatter = (value) => {
    if (Number.isNaN(value)) {
        return value;
    }
    return value?.toLocaleString() || '0';
};
/**
 * Formats a number as a currency string in USD.
 *
 * @param {number} value - The number to format.
 * @returns {string} The formatted currency string.
 */
export const currencyFormatter = (value) => {
    if (Number.isNaN(value)) {
        return value;
    }
    return value.toLocaleString('en-US', {
        style: 'currency',
        currency: 'USD',
    });
};
/**
 * @param {number} value
 * @returns {string}
 */
export const inExactNumberFormatter = (value) => {
    if (Number.isNaN(value)) {
        return value;
    }
    if (Math.abs(value) < 1000) {
        return value.toLocaleString();
    }
    if (Math.abs(value) < 1000000) {
        return `${(value / 1000).toFixed(1)}K`;
    }
    return `${(value / 1000000).toFixed(1)}M`;
};
export const rawValueFormatter = (rawValue) => rawValue?.toLocaleString();
export const dateRangeDescription = (startDate, endDate = new Date()) => {
    if (!startDate) {
        return '';
    }
    const monthDiff = differenceInMonths(endDate, startDate);
    if (monthDiff < 23) {
        return `Past ${monthDiff} months`;
    }
    const yearDiff = differenceInYears(endDate, startDate);
    return `Past ${yearDiff} years`;
};
export const TODAY_ISO = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 12, 0, 0, 0)
    .toISOString()
    .substring(0, 10);
export const UNKNOWN_COLOR = '#ccc';
/** Take a value and attempt to parse it as a number. If the value is not a number or cannot be parsed, return 0. */
export const parseAsNumber = (value) => {
    if (typeof value === 'number') {
        if (isNaN(value)) {
            return 0;
        }
        return value;
    }
    if (typeof value === 'string') {
        const parsed = parseFloat(value);
        return Number.isNaN(parsed) ? 0 : parsed;
    }
    return 0; // treat non-string, non-number values as 0 for charting purposes
};
