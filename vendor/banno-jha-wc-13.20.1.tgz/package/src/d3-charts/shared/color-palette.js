export const colorPalette18 = [
    'var(--jh-chart-graphic-0)',
    'var(--jh-chart-graphic-1)',
    'var(--jh-chart-graphic-2)',
    'var(--jh-chart-graphic-3)',
    'var(--jh-chart-graphic-4)',
    'var(--jh-chart-graphic-5)',
    'var(--jh-chart-graphic-6)',
    'var(--jh-chart-graphic-7)',
    'var(--jh-chart-graphic-8)',
    'var(--jh-chart-graphic-9)',
    'var(--jh-chart-graphic-10)',
    'var(--jh-chart-graphic-11)',
    'var(--jh-chart-graphic-12)',
    'var(--jh-chart-graphic-13)',
    'var(--jh-chart-graphic-14)',
    'var(--jh-chart-graphic-15)',
    'var(--jh-chart-graphic-16)',
    'var(--jh-chart-graphic-17)',
];
export default {
    colorPalette18,
};
