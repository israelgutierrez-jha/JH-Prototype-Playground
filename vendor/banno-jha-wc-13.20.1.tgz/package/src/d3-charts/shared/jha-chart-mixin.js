var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/* eslint max-classes-per-file: ["warn", 2] */
import { html, css } from 'lit';
import { property, state } from 'lit/decorators.js';
import { scaleOrdinal } from 'd3';
import '../../progress/jha-progress/jha-progress.js';
import '../../buttons/jha-button/jha-button.js';
import '../jha-chart-legend/jha-chart-legend.js';
import { inExactNumberFormatter, currencyFormatter, rawValueFormatter, shortMonthYearFormatter, UNKNOWN_COLOR, parseAsNumber, } from './chart-util';
export const MIN_HEIGHT = 200;
/** Key to use when no segment is defined—should not be `undefined`; if truthy, value will be displayed on certain charts (legend, x axis) */
export const NO_SEGMENT_KEY = null;
export const jhaChartMixin = (superClass) => {
    class Chart extends superClass {
        set configuration(config) {
            this._configuration = config;
        }
        get configuration() {
            // allow deprecated dateSegment/segment
            const xSegment = this._configuration?.xSegment || this._configuration?.dateSegment;
            const ySegment = this._configuration?.ySegment || this._configuration?.segment;
            return {
                ...this._configuration,
                xSegment,
                ySegment,
            };
        }
        /** @returns {HTMLElement} */
        get chartContainer() {
            return this.shadowRoot?.querySelector('#chart-container');
        }
        get containerWidth() {
            return this.chartContainer?.clientWidth || this.clientWidth;
        }
        get availableHeight() {
            return Math.max(MIN_HEIGHT, (this.chartContainer?.clientHeight || this.clientHeight) - 48);
        }
        get highlightedKey() {
            return this.highlightedKey_;
        }
        /** Should the values be used as the x-axis segments? True only if there is no xSegment defined. */
        get useValuesAsXSegment() {
            return !this.configuration?.xSegment;
        }
        /** Should the values be used as keys for the chart? True only if there is an xSegment defined, but no ySegment. */
        get useValuesAsKeys() {
            return !this.useValuesAsXSegment && !this.configuration?.ySegment && Array.isArray(this.configuration?.value);
        }
        /** Returns an array of the value configurations—whether one or multiple. */
        get valueConfigs() {
            return Array.isArray(this.configuration?.value) ? this.configuration.value : [this.configuration?.value];
        }
        set highlightedKey(key) {
            if (key === this.highlightedKey_ || !this.shadowRoot) {
                return;
            }
            this.highlightedKey_ = key;
            Array.from(this.shadowRoot.querySelectorAll('*[highlight]')).forEach((g) => {
                g.removeAttribute('highlight');
            });
            this.shadowRoot.querySelectorAll(`*[data-key="${key}"]`).forEach((g) => g.setAttribute('highlight', ''));
            const highlightedData = this.filteredData.find((data) => data[this.configuration.ySegment?.name] === key);
            this.dispatchEvent(new CustomEvent('highlighted-key-changed', {
                bubbles: false,
                detail: {
                    key,
                    data: highlightedData,
                },
            }));
        }
        /** @returns {HTMLElement} */
        get tooltipContainer() {
            return this.shadowRoot?.querySelector('#tooltip-container');
        }
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        constructor(...args) {
            super();
            this.colorScale = scaleOrdinal().unknown(UNKNOWN_COLOR);
            this._configuration = null;
            this.data = null;
            this.filter = (key) => true;
            this.hoverDetailsData = null;
            this.yAxisLeftAlign = false;
            this.yAxis = null;
            this.loading = false;
            this.chartTitle = '';
            this.chart = null;
            this._keys = [];
            this._series = null;
            this._xScale = null;
            this._yScale = null;
            this.previousWidth_ = 0;
            this.previousHeight_ = this.clientHeight;
            this.highlightedKey_ = null;
            this.highlightTimeout_ = null;
            this._oldSeries = null;
            this.resizeHandler_ = (entries) => {
                for (const entry of entries) {
                    const { width, height } = entry.contentRect;
                    if (!this.loading && typeof width === 'number' && Math.abs(width - this.previousWidth_) > 20) {
                        // resize chart if the width changes by more than 20px
                        this.previousWidth_ = width;
                        this.resizeChart_();
                    }
                    if (!this.loading && typeof height === 'number' && Math.abs(height - this.previousHeight_) > 20) {
                        // resize chart if the height changes by more than 20px
                        this.previousHeight_ = height;
                        this.resizeChart_();
                    }
                }
            };
            /** @type {!function(*):boolean} */
            this.filter = (_key) => true;
        }
        get filteredData() {
            const data = this.data ?? [];
            if (!this.configuration?.ySegment) {
                // return all data if there's no ySegment to filter by
                return data;
            }
            return data?.filter((d) => Object.prototype.hasOwnProperty.call(d, this.configuration?.ySegment?.name)
                ? this.filter(d[this.configuration?.ySegment?.name])
                : true);
        }
        /** @param {import('lit').PropertyValues} changedProperties */
        updated(changedProperties) {
            if (['data', 'filter', 'loading'].some((prop) => changedProperties.has(prop))) {
                this.updateSeries().then(() => this.updateChart());
            }
        }
        connectedCallback() {
            super.connectedCallback();
            this.initializeChart();
        }
        async updateSeries() {
            if (!this.data?.length || !this.configuration) {
                this._series = null;
                this._keys = [];
                this._xScale = null;
                this._yScale = null;
            }
        }
        updateChart() { }
        async initializeChart() {
            await this.updateComplete;
            this.resizeObserver_ = new ResizeObserver(this.resizeHandler_);
            this.resizeObserver_.observe(this);
        }
        resizeChart_() {
            if (this.debounceRefresh_) {
                clearTimeout(this.debounceRefresh_);
                this.debounceRefresh_ = null;
            }
            this.loading = true;
            this.debounceRefresh_ = window.setTimeout(() => {
                this.loading = false;
            }, 250);
        }
        getFormatter(propType) {
            switch (propType) {
                case 'date':
                    return shortMonthYearFormatter;
                case 'number':
                    return inExactNumberFormatter;
                case 'currency':
                    return currencyFormatter;
                case 'object':
                    return JSON.stringify;
                default:
                    return rawValueFormatter; // return raw value
            }
        }
        /**
         * Get the total (absolute) value for a given x-axis segment.
         * @param {string} xSegment
         * @param {boolean} [applyFilter=false] When true, applies the current filter: uses filteredData as the data
         *   source (for non-values-as-x/keys modes) and excludes filtered-out value configs (for values-as-keys mode).
         * @returns {number}
         */
        getTotalValueForXSegment(xSegment, applyFilter = false) {
            const data = (applyFilter && !this.useValuesAsXSegment && !this.useValuesAsKeys ? this.filteredData : this.data);
            const valueConfigs = (Array.isArray(this.configuration.value) ? this.configuration.value : [this.configuration.value]).filter((vc) => (applyFilter && this.useValuesAsKeys ? this.filter(vc.label) : true)); // filter value configs if using values as keys
            const total = this.useValuesAsXSegment
                ? data.reduce((sum, d) => {
                    const vc = valueConfigs.find((vc) => vc.label === xSegment);
                    const valueKey = vc?.name || valueConfigs[0].name;
                    return sum + parseAsNumber(d[valueKey]);
                }, 0)
                : this.useValuesAsKeys
                    ? data
                        .filter((dd) => dd[this.configuration.xSegment?.name] === xSegment)
                        .reduce((sum, d) => {
                        const values = valueConfigs.map((vc) => parseAsNumber(d[vc.name]));
                        return sum + values.reduce((s, v) => s + v, 0);
                    }, 0)
                    : data
                        .filter((dd) => dd[this.configuration.xSegment?.name] === xSegment)
                        .reduce((sum, d) => {
                        const valueKey = valueConfigs[0].name;
                        return sum + parseAsNumber(d[valueKey]);
                    }, 0);
            return total;
        }
        highlight(key) {
            if (this.highlightTimeout_) {
                clearTimeout(this.highlightTimeout_);
                this.highlightTimeout_ = null;
            }
            this.highlightTimeout_ = window.setTimeout(() => {
                this.highlightedKey = key;
            }, 100);
        }
        unhighlight(key) {
            if (this.highlightTimeout_) {
                clearTimeout(this.highlightTimeout_);
                this.highlightTimeout_ = null;
            }
            if (this.highlightedKey === key) {
                this.highlightedKey = null;
            }
        }
        /**
         * Get the total (absolute) value for all x-axis segments
         * @returns {number}
         */
        getTotalValueForAllSegments() {
            const data = this.data;
            const valueConfigs = (Array.isArray(this.configuration.value) ? this.configuration.value : [this.configuration.value]).filter((vc) => (this.useValuesAsKeys ? this.filter(vc.label) : true)); // filter value configs if using values as keys
            const total = this.useValuesAsXSegment
                ? data.reduce((sum, d) => {
                    // if using values as xSegment, only the first value config is relevant for the total (for now—until support is added for multiple y segments and multiple values)
                    return sum + parseAsNumber(d[valueConfigs[0].name]);
                }, 0)
                : data.reduce((sum, d) => {
                    const values = valueConfigs.map((vc) => parseAsNumber(d[vc.name]));
                    return sum + values.reduce((s, v) => s + v, 0);
                }, 0);
            return total;
        }
        /**
         * @param {?Element} targetEl
         * @param {!object} highlightedData
         * @param {string=} valueKey Optional key to specify which value to show in the tooltip for charts using values-as-keys mode
         */
        maybeShowHoverDetails(targetEl, highlightedData, valueKey) {
            if (!this.configuration?.features?.hoverDetails) {
                return;
            }
            import('../jha-chart-hover-details/jha-chart-hover-details.js');
            if (this.hoverTimeout_) {
                clearTimeout(this.hoverTimeout_);
            }
            const config = this.configuration;
            if (targetEl && targetEl instanceof Element) {
                this.hoverTimeout_ = window.setTimeout(async () => {
                    const total = this.useValuesAsXSegment && valueKey !== undefined
                        ? this.getTotalValueForXSegment(valueKey)
                        : config.xSegment
                            ? this.getTotalValueForXSegment(highlightedData[config.xSegment.name])
                            : // total sum of all values
                                this.getTotalValueForAllSegments();
                    const valueConfigs = this.valueConfigs;
                    const valueConfig = valueConfigs.find((vc) => vc.label === (valueKey || this.highlightedKey)) || valueConfigs[0];
                    const xFormatter = this.getFormatter(config.xSegment?.type);
                    const yFormatter = this.getFormatter(config.ySegment?.type || valueConfig.type);
                    this.hoverDetailsData = {
                        xKey: highlightedData[config.xSegment?.name],
                        xSegment: config.xSegment ? xFormatter(highlightedData[config.xSegment?.name]) : undefined,
                        yKey: highlightedData[config.ySegment?.name],
                        ySegment: config.ySegment ? yFormatter(highlightedData[config.ySegment?.name]) : undefined,
                        value: highlightedData[valueConfig?.name],
                        valueDescription: valueConfig?.label,
                        total,
                    };
                    const popover = /** @type {HTMLElement} */ this.shadowRoot?.querySelector('#hover-details');
                    const hoverDetails = this.shadowRoot?.querySelector('jha-chart-hover-details');
                    if (popover && popover instanceof HTMLElement) {
                        // show popover at left: 0 so the detail width can be computed correctly; then, compute the correct value for `left`
                        const bounds = targetEl.getBoundingClientRect();
                        popover.style.left = '0';
                        popover.showPopover();
                        // determine the width and left position of the details element
                        const detailsWidth = hoverDetails?.getBoundingClientRect().width || 260; // fall back to average width for the first hover
                        if (bounds.right + detailsWidth <= document.body.clientWidth) {
                            // show on right side of target (preferred)
                            popover.style.left = `${bounds.x + bounds.width + 4}px`;
                        }
                        else if (bounds.left - detailsWidth >= 0) {
                            // show on left side of the target if it would flow off the screen to the right
                            popover.style.left = `${bounds.x - 4 - detailsWidth}px`;
                        }
                        else {
                            // show aligned to right edge of bounds if it would flow off the screen on both sides
                            popover.style.left = `${bounds.x + bounds.width - detailsWidth}px`;
                        }
                        // determine the height and top position of the details element
                        const detailsHeight = hoverDetails?.getBoundingClientRect().height || 120; // fall back to average height for the first hover
                        if (bounds.y + detailsHeight <= document.body.clientHeight) {
                            // show on bottom side of target (preferred)
                            popover.style.top = `${bounds.y + bounds.height / 3}px`;
                        }
                        else {
                            // show on top side of the target if it would flow off the screen
                            popover.style.top = `${bounds.y - detailsHeight}px`;
                        }
                    }
                }, 200);
            }
        }
        onUnhoverData() {
            if (this.hoverTimeout_) {
                clearTimeout(this.hoverTimeout_);
            }
            if (!this.unhoverTimeout_) {
                this.unhoverTimeout_ = window.setTimeout(() => {
                    const popover = this.shadowRoot?.querySelector('#hover-details');
                    popover?.hidePopover();
                    this.unhoverTimeout_ = null;
                }, 200);
            }
        }
        /** Handler for `mouseenter` event on hover-details container—cancels unhover timeout */
        onmouseenterHoverDetails(event) {
            if (this.unhoverTimeout_) {
                clearTimeout(this.unhoverTimeout_);
                this.unhoverTimeout_ = null;
            }
        }
        /** Handler for `mouseleave` event on hover-details container—starts unhover timeout */
        onmouseleaveHoverDetails(event) {
            this.onUnhoverData();
        }
        renderLoading() {
            return html ` <jha-progress></jha-progress> `;
        }
        renderDataLoadErrorRetry() {
            return html `
        <div class="error">
          <p><slot name="data-load-error">Oops. Something went wrong loading data.</slot></p>
          <jha-button
            @click=${(evt) => {
                evt.preventDefault();
                this.dispatchEvent(new CustomEvent('reload-data'));
            }}>
            Try again
          </jha-button>
        </div>
      `;
        }
        renderLoadedNoData() {
            return html ` <div id="no-data"><slot name="no-data">No data</slot></div> `;
        }
        renderChartError() {
            return html ` <p class="error"><slot name="chart-render-error">Oops. Something went wrong.</slot></p> `;
        }
        renderLegend() {
            return html `
        <jha-chart-legend
          .keys=${Array.from(this._keys)}
          .colorScale=${this.colorScale}
          @click=${(evt) => evt.preventDefault()}
          @highlight=${(evt) => this.highlight(evt.detail.key)}
          @unhighlight=${(evt) => this.unhighlight(evt.detail.key)}></jha-chart-legend>
      `;
        }
        renderChart() {
            if (this.data?.length !== 0 && !this._series) {
                // data was supplied but series could not be generated
                return this.renderChartError();
            }
            if (this.data && !this._series?.length) {
                // data was supplied but no data points after filtering
                return this.renderLoadedNoData();
            }
            try {
                return html `
          ${this.renderLegend()}
          <div id="chart-container">${this.renderChartContainer()}</div>
        `;
            }
            catch {
                return this.renderChartError();
            }
        }
        renderChartContainer() {
            return html `
        ${this.yAxis}
        <div class="scrollable">
          <div id="tooltip-container"></div>
          ${this.chart} ${this.maybeRenderHoverDetails()}
        </div>
      `;
        }
        render() {
            if (this.loading) {
                return this.renderLoading();
            }
            if (this.data instanceof Error) {
                return this.renderDataLoadErrorRetry();
            }
            return this.renderChart();
        }
        maybeRenderHoverDetails() {
            if (!this.configuration?.features?.hoverDetails) {
                return '';
            }
            let maybeHoverDetails = '';
            if (this.hoverDetailsData) {
                const keys = this._keys || [];
                const colorKey = keys.includes(this.hoverDetailsData.yKey)
                    ? this.hoverDetailsData.yKey
                    : keys.includes(this.hoverDetailsData.xKey)
                        ? this.hoverDetailsData.xKey
                        : keys.includes(this.hoverDetailsData.valueDescription)
                            ? this.hoverDetailsData.valueDescription
                            : NO_SEGMENT_KEY;
                maybeHoverDetails = html `
          <jha-chart-hover-details
            .chartTitle=${this.chartTitle}
            .details=${this.hoverDetailsData}
            .color=${this.colorScale(colorKey)}>
          </jha-chart-hover-details>
        `;
            }
            return html `
        <div
          id="hover-details"
          @mouseenter=${this.onmouseenterHoverDetails}
          @mouseleave=${this.onmouseleaveHoverDetails}
          popover>
          ${maybeHoverDetails}
        </div>
      `;
        }
    }
    __decorate([
        property({ type: Object, attribute: false }),
        __metadata("design:type", Function)
    ], Chart.prototype, "colorScale", void 0);
    __decorate([
        property({ type: Object, attribute: false }),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [Object])
    ], Chart.prototype, "configuration", null);
    __decorate([
        property({ type: Array }),
        __metadata("design:type", Array)
    ], Chart.prototype, "data", void 0);
    __decorate([
        property({ attribute: false }),
        __metadata("design:type", Object)
    ], Chart.prototype, "filter", void 0);
    __decorate([
        property({ type: Object, attribute: false }),
        __metadata("design:type", Object)
    ], Chart.prototype, "hoverDetailsData", void 0);
    __decorate([
        property({ type: Boolean }),
        __metadata("design:type", Object)
    ], Chart.prototype, "yAxisLeftAlign", void 0);
    __decorate([
        state(),
        __metadata("design:type", SVGElement)
    ], Chart.prototype, "yAxis", void 0);
    __decorate([
        state(),
        __metadata("design:type", Object)
    ], Chart.prototype, "loading", void 0);
    __decorate([
        property({ type: String, attribute: 'chart-title' }),
        __metadata("design:type", Object)
    ], Chart.prototype, "chartTitle", void 0);
    __decorate([
        state(),
        __metadata("design:type", SVGElement)
    ], Chart.prototype, "chart", void 0);
    __decorate([
        state(),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], Chart.prototype, "highlightedKey", null);
    return Chart;
};
export default jhaChartMixin;
export const sharedChartStyles = css `
  :host {
    display: flex;
    flex-direction: column;
    width: 100%;
    align-content: center;
    justify-content: center;
    height: 100%;
    position: relative;
    justify-self: center;
  }
  #no-data {
    display: flex;
    justify-content: center;
  }
  #chart-container {
    height: 100%;
    min-height: ${MIN_HEIGHT + 4}px;
    display: flex;
    gap: 8px;
    align-items: center;
  }
  #chart-container .scrollable {
    overflow-x: auto;
    overflow-y: visible;
  }
  svg#y-axis {
    flex-shrink: 0;
    flex-grow: 0;
    transform: scaleY(0.98);
  }
  g.tick text {
    font-size: 12px;
  }
  jha-progress {
    align-self: center;
  }
  jha-chart-legend {
    width: 70%;
    min-width: 100%;
  }
  .error {
    display: flex;
    justify-content: center;
    flex-direction: column;
    align-items: center;
  }
  #tooltip-container {
    position: relative;
    top: 0;
    left: 0;
    height: 0;
  }
  .tooltip {
    position: absolute;
    width: max-content;
    padding: 4px;
    background-color: var(--jha-component-background-color);
    color: var(--jha-text-base);
    border-radius: 4px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    pointer-events: none;
    opacity: 0;
    transition: opacity 0.3s;
  }
  .tooltip[style] {
    opacity: 1;
  }

  *[popover] {
    background: transparent;
    border: none;
    margin: 0;
    padding: 0;
    overflow: visible;
  }

  [popover] {
    opacity: 0;
    transition: opacity 0.3s;
  }

  [popover]:popover-open {
    opacity: 1;
  }

  @starting-style {
    [popover]:popover-open {
      opacity: 0;
    }
  }

  /* Shared highlight transition styles */
  svg *[data-key] {
    transition:
      opacity 0.25s ease,
      filter 0.25s ease;
  }
`;
