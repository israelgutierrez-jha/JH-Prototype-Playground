import JhaStackedColumnChartElement from './JhaStackedColumnChart';
customElements.define('jha-stacked-column-chart', JhaStackedColumnChartElement);
/** @customElement jha-stacked-column-chart */
export default JhaStackedColumnChartElement;
