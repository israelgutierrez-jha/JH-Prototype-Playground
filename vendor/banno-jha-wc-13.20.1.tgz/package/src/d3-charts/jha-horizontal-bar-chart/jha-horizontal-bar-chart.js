import JhaHorizontalBarChartElement from './JhaHorizontalBarChart';
customElements.define('jha-horizontal-bar-chart', JhaHorizontalBarChartElement);
/** @customElement jha-horizontal-bar-chart */
export default JhaHorizontalBarChartElement;
