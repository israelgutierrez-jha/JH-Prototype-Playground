import { LitElement, css } from 'lit';
import * as d3 from 'd3';
import { jhaChartMixin, sharedChartStyles, NO_SEGMENT_KEY } from '../shared/jha-chart-mixin';
import { UNKNOWN_COLOR } from '../shared/chart-util';
import { colorPalette18 } from '../shared/color-palette';
const stepWidth = 26;
const barWidth = 15;
const marginTop = 0;
const marginRight = 0;
const marginBottom = 0;
const minMarginLeft = 0;
const zeroValue = 0;
const ANIMATION_DURATION = window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 100 : 500;
// A function to format the value in the tooltip.
const formatValue = (v) => (Number.isNaN(v) ? 'N/A' : v.toLocaleString('en'));
const styles = css `
  :host {
    align-self: center;
  }
  rect {
    rx: 1px;
    ry: 1px;
    transition:
      filter 0.15s ease,
      opacity 0.25s ease;
  }
  g.series {
    clip-path: inset(0 0 0 0 round 8px 8px 8px 8px);
    transition:
      opacity 0.25s ease,
      filter 0.25s ease;
  }
  /* hover effects */
  svg:has(rect[highlight]) rect[data-key]:not([highlight]) {
    opacity: 0.3;
    filter: grayscale(40%);
  }
  svg rect[data-key][highlight] {
    filter: drop-shadow(0 0 4px currentColor);
  }
  svg rect[data-key] {
    transition:
      filter 0.15s ease,
      opacity 0.25s ease;
  }
  svg rect[data-key]:hover {
    filter: brightness(1.15);
  }
  g.tick text,
  text.total-label {
    font-weight: 500;
  }
`;
export default class JhaHorizontalBarChartElement extends jhaChartMixin(LitElement) {
    constructor() {
        super(...arguments);
        this._series = null;
        this.verticalAxisWidth = 0;
        this.updateSeries = async () => {
            if (!this.data?.length || !this.configuration) {
                this._series = null;
                this._keys = [];
                return;
            }
            const data = this.data;
            const config = this.configuration;
            const valueConfigs = this.valueConfigs;
            const useValuesAsXSegment = this.useValuesAsXSegment;
            const useValuesAsKeys = this.useValuesAsKeys;
            const allKeys = useValuesAsKeys
                ? valueConfigs.map((vc) => vc.label) // use values as keys if there are multiple
                : Array.from(new Set(data.map((d) => d[config.ySegment?.name || config.xSegment?.name]?.toString() || NO_SEGMENT_KEY)));
            this._keys = useValuesAsKeys
                ? valueConfigs.filter((vc) => this.filter(vc.label)).map((vc) => vc.label) // use values as keys if there are multiple
                : this.useValuesAsXSegment
                    ? allKeys // if using values as xSegment, the filter is applied to the values rather than the keys, so all keys should be included here
                    : Array.from(new Set(this.filteredData.map((d) => d[config.ySegment?.name || config.xSegment?.name]?.toString() || NO_SEGMENT_KEY)));
            // sort all keys alphanumerically to ensure consistent color mapping and legend order
            allKeys.sort((a, b) => a.localeCompare(b));
            this._keys.sort((a, b) => a.localeCompare(b));
            const keySet = this.hasTwoSegments || useValuesAsXSegment || useValuesAsKeys
                ? d3.union(this._keys)
                : new d3.InternSet([NO_SEGMENT_KEY]);
            const dataMap = useValuesAsXSegment
                ? // When using values as the x-axis segments, create a synthetic map keyed by value label
                    new Map(valueConfigs
                        .filter((vc) => this.filter(vc.label))
                        .map((vc) => [
                        vc.label,
                        new Map(data.map((d) => [d[config.ySegment?.name]?.toString() || NO_SEGMENT_KEY, d])),
                    ]))
                : this.hasTwoSegments
                    ? d3.index(data, (d) => d[config.xSegment?.name] || NO_SEGMENT_KEY, (d) => d[config.ySegment?.name] || NO_SEGMENT_KEY)
                    : useValuesAsKeys
                        ? // if there is only one segment and we are using values as keys, we need to index by the keys to get the correct stacking; otherwise, we can just index by the xSegment (or ySegment) and use the keys/values for stacking
                            d3.index(data, (d) => d[config.xSegment?.name] || NO_SEGMENT_KEY, (d) => d[config.ySegment?.name] || NO_SEGMENT_KEY)
                        : // if there is only one segment and we are not using values as keys, we can just index by the xSegment (or ySegment) and use the values for stacking
                            d3.index(data, (d) => d[config.xSegment?.name || config.ySegment?.name] || NO_SEGMENT_KEY, // primary key - x segment, or y segment if x segment is not defined
                            (d) => NO_SEGMENT_KEY);
            this._series = d3
                .stack()
                .offset(d3.stackOffsetDiverging)
                .order(d3.stackOrderDescending)
                .keys(keySet)
                .value((d, key) => {
                const vc = valueConfigs.find((vc) => vc.label === (useValuesAsKeys ? key : d[0]));
                const k = useValuesAsKeys ? NO_SEGMENT_KEY : key;
                const valueKey = vc?.name || valueConfigs[0].name;
                return d[1].get(k)?.[valueKey] || zeroValue;
            })(dataMap);
            this.colorScale = d3
                .scaleOrdinal()
                // should be all possible keys rather than just filtered keys; otherwise, colors may shift when filtering
                .domain(allKeys)
                .range(colorPalette18)
                .unknown(UNKNOWN_COLOR);
        };
        this.updateChart = () => {
            if (!this.configuration || !this._series?.length) {
                return;
            }
            const series = this._series;
            const config = this.configuration;
            const valueConfigs = this.valueConfigs;
            const { height } = this;
            const xFormatter = this.getFormatter(config.xSegment?.type);
            const yFormatter = this.getFormatter(valueConfigs[0].type);
            const xDomain = series[0].map((d) => d.data[0]?.toString());
            const yDomain = [d3.min(series, (d) => d3.min(d, (d2) => d2[0])), d3.max(series, (d) => d3.max(d, (d2) => d2[1]))];
            // this is the vertical scale
            this._xScale = d3
                .scaleBand()
                .domain(xDomain)
                .range([marginTop, height - marginTop - marginBottom])
                .padding(1);
            // determine margin based on the longest y-axis label
            this.verticalAxisWidth =
                Math.max(minMarginLeft, d3.max(this._xScale.domain(), (d) => xFormatter(d)?.length || 0) * 8) + 4 ||
                    minMarginLeft;
            // estimate the max width for the total labels based on the longest formatted total value
            let totalsWidth = 0;
            if (this.configuration?.features?.tooltips) {
                const largestTotal = yDomain[1];
                totalsWidth = formatValue(yFormatter(largestTotal)).length * 8 + 4;
            }
            // this is the horizontal scale for the bars
            this._yScale = d3
                .scaleLinear()
                .domain(yDomain)
                .range([
                0,
                this.containerWidth -
                    this.verticalAxisWidth -
                    8 - // account for 8px gap between axis and bars
                    marginRight -
                    series.length - // account for 1px gap between bars
                    totalsWidth, // add some space for "total" label width
            ]);
            // Create the SVG container.
            const svg = d3
                .create('svg')
                .attr('width', this.containerWidth)
                .attr('height', this.height)
                .attr('viewBox', [0, 0, this.containerWidth, this.height]);
            // Append the vertical axis
            svg
                .append('g')
                .call(d3
                .axisLeft(this._xScale)
                .tickSize(0)
                .tickFormat(xFormatter))
                .call((g) => g.select('.domain').remove())
                .call((g) => g.selectAll('.tick text').attr('x', this.verticalAxisWidth));
            // Append a group for each series, and a rect for each segment in the series.
            svg
                .append('g')
                .attr('transform', `translate(${this.verticalAxisWidth + 8})`)
                .selectAll('g.series')
                .data(this._xScale.domain())
                .join('g')
                .attr('class', 'series')
                .attr('data-key', (k) => k)
                .selectAll('rect')
                .data((x) => series.map((S) => {
                const item = Array.isArray(S) ? S.find((s) => s.data[0]?.toString() === x) : S;
                return item
                    ? { ...item, key: S.key, x }
                    : { 0: 0, 1: 0, data: [x, new Map()], key: S.key, x };
            }))
                .join('rect')
                .attr('y', (d) => this._xScale(d.x) - barWidth / 2)
                .attr('x', 0)
                .attr('data-key', (d) => d.key)
                .attr('height', barWidth)
                .attr('width', 0)
                .attr('fill', (d) => this.colorScale?.(this._keys.includes(d.key) ? d.key : d.x) || UNKNOWN_COLOR)
                .attr('title', (d) => {
                const dataKey = this.useValuesAsKeys ? NO_SEGMENT_KEY : d.key;
                const vc = this.useValuesAsKeys || this.useValuesAsXSegment
                    ? valueConfigs.find((vc) => vc.label === (this.useValuesAsKeys ? d.key : d.x))
                    : valueConfigs[0];
                const value = d.data[1]?.get(dataKey)?.[vc.name];
                return `${xFormatter(d.x)} - ${d.key} - ${formatValue(yFormatter(value || zeroValue))}`;
            })
                .on('mouseenter', (event, d) => {
                this.highlight(d.key);
                const highlightedData = d.data[1].get(this.useValuesAsKeys ? NO_SEGMENT_KEY : d.key);
                const valueKey = this.useValuesAsXSegment ? d.x : this.useValuesAsKeys ? d.key : NO_SEGMENT_KEY;
                this.maybeShowHoverDetails(event.target, highlightedData, valueKey);
            })
                .on('mouseleave', (event, d) => {
                this.unhighlight(d.key);
                this.onUnhoverData();
            })
                .transition()
                .duration(ANIMATION_DURATION)
                .ease(d3.easePoly)
                .attr('x', (d) => this._yScale(d[0]))
                .attr('width', (d) => {
                const size = Math.abs(this._yScale(d[0]) - this._yScale(d[1]));
                return size > 1 ? size - 1 : size; // leave 1px gap between bars
            });
            this.chart = svg.node();
            this.maybeShowTotalsTooltips();
        };
        this.renderLegend = () => {
            // don't render legend for horizontal bar chart
            return '';
        };
    }
    static { this.styles = [sharedChartStyles, styles]; }
    get height() {
        if (!this._series?.length) {
            return 0;
        }
        return this._series[0].length * stepWidth + marginTop + marginBottom + stepWidth * 2;
    }
    get hasTwoSegments() {
        return Boolean(this.configuration?.ySegment && this.configuration?.xSegment);
    }
    maybeShowTotalsTooltips() {
        if (!this.configuration?.features?.tooltips) {
            return;
        }
        const series = this._series;
        const config = this.configuration;
        const valueConfigs = this.valueConfigs;
        const yFormatter = this.getFormatter(valueConfigs[0].type);
        const svg = d3.select(this.chart);
        // Add total value labels at the end of each series
        const totals = this._xScale.domain().map((x) => {
            const total = this.getTotalValueForXSegment(x, true);
            // compute the rightmost end pixel for this x across all segments
            const endPx = series.reduce((maxPx, S) => {
                const item = S.find((s) => s.data[0]?.toString() === x);
                if (!item)
                    return maxPx;
                const p0 = this._yScale(item[0]);
                const p1 = this._yScale(item[1]);
                return Math.max(maxPx, Math.max(p0, p1));
            }, 0);
            return { x, total, endPx };
        });
        // Append total labels
        svg
            .append('g')
            .attr('transform', `translate(${this.verticalAxisWidth + 8})`)
            .selectAll('text.total-label')
            .data(totals)
            .join('text')
            .attr('class', 'total-label')
            .attr('x', 0) // small gap after the bar end
            .attr('y', (d) => this._xScale(d.x))
            .attr('dy', '0.32em') // vertically center in the band
            .attr('fill', 'currentColor')
            .attr('font-size', 12)
            .text((d) => formatValue(yFormatter(d.total || zeroValue)))
            .transition()
            .duration(ANIMATION_DURATION)
            .ease(d3.easePoly)
            .attr('x', (d) => d.endPx + 3); // small gap after the bar end) {
    }
}
