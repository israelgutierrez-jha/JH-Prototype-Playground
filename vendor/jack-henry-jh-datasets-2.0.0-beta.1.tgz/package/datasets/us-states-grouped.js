/**
* SPDX-FileCopyrightText: 2026 Jack Henry
*
* SPDX-License-Identifier: Apache-2.0
*/

export const US_STATES_GROUPED = [
  {
    groupLabel: "Northeast",
    groupValues: [
      { label: "Connecticut", value: "CT" },
      { label: "Maine", value: "ME" },
      { label: "Massachusetts", value: "MA" },
      { label: "New Hampshire", value: "NH" },
      { label: "New Jersey", value: "NJ" },
      { label: "New York", value: "NY" },
      { label: "Pennsylvania", value: "PA" },
      { label: "Rhode Island", value: "RI" },
      { label: "Vermont", value: "VT" }
    ]
  },
  {
    groupLabel: "Midwest",
    groupValues: [
      { label: "Illinois", value: "IL" },
      { label: "Indiana", value: "IN" },
      { label: "Iowa", value: "IA" },
      { label: "Kansas", value: "KS" },
      { label: "Michigan", value: "MI" },
      { label: "Minnesota", value: "MN" },
      { label: "Missouri", value: "MO" },
      { label: "Nebraska", value: "NE" },
      { label: "North Dakota", value: "ND" },
      { label: "Ohio", value: "OH" },
      { label: "South Dakota", value: "SD" },
      { label: "Wisconsin", value: "WI" }
    ]
  },
  {
    groupLabel: "South",
    groupValues: [
      { label: "Alabama", value: "AL" },
      { label: "Arkansas", value: "AR" },
      { label: "Delaware", value: "DE" },
      { label: "District of Columbia", value: "DC" },
      { label: "Florida", value: "FL" },
      { label: "Georgia", value: "GA" },
      { label: "Kentucky", value: "KY" },
      { label: "Louisiana", value: "LA" },
      { label: "Maryland", value: "MD" },
      { label: "Mississippi", value: "MS" },
      { label: "North Carolina", value: "NC" },
      { label: "Oklahoma", value: "OK" },
      { label: "South Carolina", value: "SC" },
      { label: "Tennessee", value: "TN" },
      { label: "Texas", value: "TX" },
      { label: "Virginia", value: "VA" },
      { label: "West Virginia", value: "WV" }
    ]
  },
  {
    groupLabel: "West",
    groupValues: [
      { label: "Alaska", value: "AK" },
      { label: "Arizona", value: "AZ" },
      { label: "California", value: "CA" },
      { label: "Colorado", value: "CO" },
      { label: "Hawaii", value: "HI" },
      { label: "Idaho", value: "ID" },
      { label: "Montana", value: "MT" },
      { label: "Nevada", value: "NV" },
      { label: "New Mexico", value: "NM" },
      { label: "Oregon", value: "OR" },
      { label: "Utah", value: "UT" },
      { label: "Washington", value: "WA" },
      { label: "Wyoming", value: "WY" }
    ]
  },
  {
    groupLabel: "Territories",
    groupValues: [
      { label: "American Samoa", value: "AS" },
      { label: "Guam", value: "GU" },
      { label: "Northern Mariana Islands", value: "MP" },
      { label: "Puerto Rico", value: "PR" },
      { label: "US Virgin Islands", value: "VI" }
    ]
  },
  {
    groupLabel: "Armed Forces",
    groupValues: [
      { label: "Armed Forces Americas", value: "AA" },
      { label: "Armed Forces Europe", value: "AE" },
      { label: "Armed Forces Pacific", value: "AP" }
    ]
  }
];