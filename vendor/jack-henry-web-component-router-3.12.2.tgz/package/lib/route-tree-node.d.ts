export default RouteTreeNode;
declare class RouteTreeNode {
    /** @param {!RouteData} data */
    constructor(data: RouteData);
    /**
     * The key.
     * @protected {string}
     */
    protected key_: string;
    /**
     * The value.
     * @private {!RouteData}
     */
    private value_;
    /**
     * Reference to the parent node or null if it has no parent.
     * @private {?RouteTreeNode}
     */
    private parent_;
    /**
     * Child nodes or null in case of leaf node.
     * @private {?Array<!RouteTreeNode>}
     */
    private children_;
    /**
     * Gets the key.
     * @return {string} The key.
     */
    getKey(): string;
    /**
     * Gets the value.
     * @return {!RouteData} The value.
     */
    getValue(): RouteData;
    /** @return {?RouteTreeNode} */
    getParent(): RouteTreeNode | null;
    /** @return {!Array<!RouteTreeNode>} Immutable child nodes. */
    getChildren(): Array<RouteTreeNode>;
    /**
     * @return {!Array<!RouteTreeNode>} All ancestor nodes in
     *     bottom-up order.
     */
    getAncestors(): Array<RouteTreeNode>;
    /**
     * @return {!RouteTreeNode} The root of the tree structure,
     *     i.e. the farthest ancestor of the node or the node itself if it has no
     *     parents.
     */
    getRoot(): RouteTreeNode;
    /**
     * Returns a node whose key matches the given one in the hierarchy rooted at
     * this node. The hierarchy is searched using an in-order traversal.
     * @param {string} key The key to search for.
     * @return {?RouteTreeNode} The node with the given key, or
     *     null if no node with the given key exists in the hierarchy.
     */
    getNodeByKey(key: string): RouteTreeNode | null;
    /**
     * Traverses the subtree with the possibility to skip branches. Starts with
     * this node, and visits the descendant nodes depth-first, in preorder.
     * @param {function(this:RouteTreeNode, !RouteTreeNode):
     *     (boolean|undefined|void)} f Callback function. It takes the node as argument.
     *     The children of this node will be visited if the callback returns true or
     *     undefined, and will be skipped if the callback returns false.
     */
    traverse(f: (this: RouteTreeNode, arg1: RouteTreeNode) => (boolean | undefined | void)): void;
    /**
     * Sets the parent node of this node. The callers must ensure that the parent
     * node and only that has this node among its children.
     * @param {RouteTreeNode} parent The parent to set. If
     *     null, the node will be detached from the tree.
     * @protected
     */
    protected setParent(parent: RouteTreeNode): void;
    /**
     * Appends a child node to this node.
     * @param {!RouteTreeNode} child Orphan child node.
     */
    addChild(child: RouteTreeNode): void;
    /**
     * Inserts a child node at the given index.
     * @param {!RouteTreeNode} child Orphan child node.
     * @param {number} index The position to insert at.
     */
    addChildAt(child: RouteTreeNode, index: number): void;
    /**
     * Removes the child node at the given index.
     * @param {number} index The position to remove from.
     * @return {RouteTreeNode} The removed node if any.
     */
    removeChildAt(index: number): RouteTreeNode;
    /**
     * Removes the given child node of this node.
     * @param {RouteTreeNode} child The node to remove.
     * @return {RouteTreeNode} The removed node if any.
     */
    removeChild(child: RouteTreeNode): RouteTreeNode;
    /** @return {boolean} */
    requiresAuthentication(): boolean;
    /**
     * Cause this route to become the active route. When a route is activated,
     * exitCallback functions from the routeData should be called up the tree in order
     * beginning with the previousNodeId until a common node is found with the
     * path from the root to this node.
     *
     * After exitCallback methods have all completed, entryCallbacks should
     * be called in order beginning with the root node down the tree through
     * this node.
     *
     *      _Root_
     *     /      \
     *    A       D
     *   / \       \
     *  B  C       E
     *
     * If the current route is "B" and the route for "E" is activated,
     * then the following callbacks should be invoked:
     *
     *     B.exitCallback, A.exitCallback, Root.entryCallback,
     *     D.entryCallback, E.entryCallback
     *
     * If the current route is "B" and the route for "C" is activated,
     * then the following callbacks should be invoked:
     *
     *     B.exitCallback, Root.entryCallback, A.entryCallback, C.entryCallback
     *
     * @param {!string|undefined} previousRouteId
     * @param {!Context} context
     */
    activate(previousRouteId: string | undefined, context: Context): Promise<void>;
}
import RouteData from './route-data.js';
import { Context } from './page.js';
