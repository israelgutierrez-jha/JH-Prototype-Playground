import { type Constructor, type RoutingMixinInterface } from './routing.mixin.js';
declare function animatedRoutingMixin<T extends Constructor<HTMLElement>>(Superclass: T, className: string): Constructor<RoutingMixinInterface> & T;
export default animatedRoutingMixin;
