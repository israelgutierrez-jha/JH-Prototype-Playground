import BasicRoutingInterface from './routing-interface.js';
import type { Context } from './page.js';
import type RouteTreeNode from './route-tree-node.js';
export type Constructor<T = {}> = new (...args: any[]) => T;
export declare class RoutingMixinInterface {
    routeEnter(currentNode: RouteTreeNode, nextNodeIfExists: RouteTreeNode | undefined, routeId: string, context: Context): Promise<boolean | void>;
    routeExit(currentNode: RouteTreeNode, nextNode: RouteTreeNode | undefined, routeId: string, context: Context): Promise<boolean | void>;
}
declare const RoutingMixin: <T extends Constructor<HTMLElement>>(superclass: T) => Constructor<RoutingMixinInterface> & T;
export { RoutingMixin, BasicRoutingInterface };
