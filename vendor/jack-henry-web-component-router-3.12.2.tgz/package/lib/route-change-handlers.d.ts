export function loadRouteNode(currentNode: RouteTreeNode, nextNodeIfExists: RouteTreeNode | undefined, routeId: string, context: Context): Promise<boolean | void>;
export function removeRouteNode(currentNode: RouteTreeNode): Promise<void>;
import RouteTreeNode from './route-tree-node.js';
import { Context } from './page.js';
