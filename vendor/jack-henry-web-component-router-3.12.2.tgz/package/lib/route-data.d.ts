export default RouteData;
export type BeforeEnter = (currentNode: RouteTreeNode, nextNodeIfExists: RouteTreeNode | undefined, routeId: string, context: Context) => Promise<boolean | void>;
/**
 * @callback BeforeEnter
 * @param {!RouteTreeNode} currentNode
 * @param {!RouteTreeNode|undefined} nextNodeIfExists
 * @param {string} routeId
 * @param {!Context} context
 * @return {!Promise<boolean|void>}
 */
/** @fileoverview Basic data for a route */
declare class RouteData {
    /**
     * @param {string} id of this route
     * @param {string} tagName of the element
     * @param {string} path of this route
     * @param {!Array<string>=} namedParameters list in camelCase. Will be
     *     converted to a map of camelCase and hyphenated.
     * @param {boolean=} requiresAuthentication
     * @param {BeforeEnter=} beforeEnter
     * @param {!Object<string, *>=} metaData optional metadata associated with this route
     */
    constructor(id: string, tagName: string, path: string, namedParameters?: Array<string> | undefined, requiresAuthentication?: boolean | undefined, beforeEnter?: BeforeEnter | undefined, metaData?: {
        [x: string]: any;
    } | undefined);
    id: string;
    tagName: string;
    path: string;
    attributes: {
        [x: string]: string;
    };
    metaData: {
        [x: string]: any;
    };
    /** @type {!Element|undefined} */
    element: Element | undefined;
    requiresAuthentication: boolean;
    /** @type {!BeforeEnter} */
    beforeEnter: BeforeEnter;
}
import RouteTreeNode from './route-tree-node.js';
import { Context } from './page.js';
