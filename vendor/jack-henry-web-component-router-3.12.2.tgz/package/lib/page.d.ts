/** The page instance */
export class Page {
    /** @type {!Array<!PageCallback>} */
    callbacks: Array<PageCallback>;
    /** @type {!Array<!PageCallback>} */
    exits: Array<PageCallback>;
    current: string;
    len: number;
    /** @type {!Context} */
    prevContext: Context;
    _decodeURLComponents: boolean;
    _base: string;
    _strict: boolean;
    _running: boolean;
    _hashbang: boolean;
    _popstate: boolean;
    _click: boolean;
    /** @type {!Window|undefined} */
    _window: Window | undefined;
    /**
     * Handle "click" events.
     * @param {!Event} evt
     */
    clickHandler(evt: Event): void;
    _onpopstate: any;
    /**
     * Configure the instance of page. This can be called multiple times.
     *
     * @param {PageOptions=} options
     */
    configure(options?: PageOptions | undefined): void;
    /**
     * Get or set basepath to `path`.
     *
     * @param {string} path
     */
    base(path: string, ...args: any[]): string;
    /**
     * Gets the `base`, which depends on whether we are using History or
     * hashbang routing.
     */
    _getBase(): string;
    /**
     * Get or set strict path matching to `enable`
     *
     * @param {boolean} enable
     */
    strict(enable: boolean, ...args: any[]): boolean;
    /**
     * Bind with the given `options`.
     *
     * Options:
     *
     *    - `click` bind to click events [true]
     *    - `popstate` bind to popstate [true]
     *    - `dispatch` perform initial dispatch [true]
     *
     * @param {PageOptions=} options
     * @return {!Promise<undefined>}
     */
    start(options?: PageOptions | undefined): Promise<undefined>;
    /** Unbind click and popstate event handlers. */
    stop(): void;
    /**
     * Show `path` with optional `state` object.
     *
     * @param {string} path
     * @param {Object=} state
     * @param {boolean=} dispatch
     * @param {boolean=} push
     * @return {!Promise<!Context>}
     */
    show(path: string, state?: any | undefined, dispatch?: boolean | undefined, push?: boolean | undefined): Promise<Context>;
    /**
     * Goes back in the history
     * Back should always let the current route push state and then go back.
     *
     * @param {string} path - fallback path to go back if no more history exists, if undefined defaults to page.base
     * @param {Object=} state
     */
    back(path: string, state?: any | undefined): void;
    /**
     * Register route to redirect from one path to other
     * or just redirect to another route
     *
     * @param {string} from - if param 'to' is undefined redirects to 'from'
     * @param {string=} to
     */
    redirect(from: string, to?: string | undefined): void;
    /**
     * Replace `path` with optional `state` object.
     *
     * @param {string|undefined} path
     * @param {*=} state
     * @param {boolean=} init
     * @param {boolean=} dispatch
     * @return {!Promise<!Context>}
     */
    replace(path: string | undefined, state?: any | undefined, init?: boolean | undefined, dispatch?: boolean | undefined): Promise<Context>;
    /**
     * Dispatch the given `ctx`.
     *
     * @param {!Context} ctx
     * @param {!Context} prev
     */
    dispatch(ctx: Context, prev: Context): Promise<void>;
    /**
     * Register an exit route on `path` with
     * callback `fn()`, which will be called
     * on the previous context when a new
     * page is visited.
     *
     * @param {!string|!PageCallback} path
     * @param {!PageCallback} fn
     * @param {...!PageCallback} fns
     */
    exit(path: string | PageCallback, fn: PageCallback, ...fns: PageCallback[]): any;
    /**
     * Event button.
     */
    _which(e: any): any;
    /**
     * Convert to a URL object
     */
    _toURL(href: any): URL | HTMLAnchorElement;
    /**
     * Check if `href` is the same origin.
     * @param {string} href
     */
    sameOrigin(href: string): boolean;
    _samePath(url: any): boolean;
    /**
     * Remove URL encoding from the given `str`.
     * Accommodates whitespace in both x-www-form-urlencoded
     * and regular percent-encoded form.
     *
     * @param {string} val - URL component to decode
     */
    _decodeURLEncodedURIComponent(val: string): string;
    /**
     * Register `path` with callback `fn()`
     *
     *   page.register('*', fn);
     *   page.register('/user/:id', load, user);
     *
     * @param {string} path
     * @param {!PageCallback} fn
     * @param {...!PageCallback} fns
     */
    register(path: string, fn: PageCallback, ...fns: PageCallback[]): void;
}
export class Context {
    /**
     * Initialize a new "request" `Context`
     * with the given `path` and optional initial `state`.
     *
     * @param {string|undefined} path
     * @param {*=} state
     * @param {!Page=} pageInstance
     * @param {boolean=} push Should state be pushed when handled?
     */
    constructor(path: string | undefined, state?: any | undefined, pageInstance?: Page | undefined, push?: boolean | undefined);
    page: Page;
    canonicalPath: string;
    path: string;
    title: string;
    state: any;
    querystring: string;
    pathname: string;
    /** @type {!Object<string, string>} */
    params: {
        [x: string]: string;
    };
    query: URLSearchParams;
    /**
     * @private
     * @type {boolean}
     */
    private pushState_;
    hash: string;
    /**
     * @private
     * @type {boolean}
     */
    private handled_;
    /** @type {boolean|undefined} */
    init: boolean | undefined;
    /** @type {string|undefined} */
    routePath: string | undefined;
    /** @param {boolean} value */
    set handled(value: boolean);
    /** @return {boolean} */
    get handled(): boolean;
    /** Push state. */
    pushState(): void;
    replaceState(): void;
    /** Save the context state. */
    save(): void;
}
export class Route {
    /**
     * Initialize `Route` with the given HTTP `path`,
     * and an array of `callbacks` and `options`.
     *
     * Options:
     *
     *   - `sensitive`    enable case-sensitive routes
     *   - `strict`       enable strict matching for trailing slashes
     *
     * @param {string} path
     * @param {Object=} options
     * @param {!Page=} page
     */
    constructor(path: string, options?: any | undefined, page?: Page | undefined);
    page: Page;
    path: string;
    method: string;
    regexp: RegExp;
    keys: any[];
    /**
     * Return route middleware with
     * the given callback `fn()`.
     *
     * @param {!PageCallback} fn
     * @return {!PageCallback}
     */
    middleware(fn: PageCallback): PageCallback;
    /**
     * Check if this route matches `path`, if so
     * populate `params`.
     *
     * @param {string} path
     * @param {Object} params
     * @return {boolean}
     */
    match(path: string, params: any): boolean;
}
type PageCallback = (arg0: Context, arg1: (...args: unknown[]) => unknown) => unknown;
/** @typedef {function(!Context, function(...?):?):?} */
declare let PageCallback: any;
type PageOptions = {
    window: (Window | undefined);
    decodeURLComponents: (boolean | undefined);
    popstate: (boolean | undefined);
    click: (boolean | undefined);
    hashbang: (boolean | undefined);
    dispatch: (boolean | undefined);
};
/**
 * @typedef {{
 *     window: (Window|undefined),
 *     decodeURLComponents: (boolean|undefined),
 *     popstate: (boolean|undefined),
 *     click: (boolean|undefined),
 *     hashbang: (boolean|undefined),
 *     dispatch: (boolean|undefined)
 * }}
 */
declare let PageOptions: any;
export {};
