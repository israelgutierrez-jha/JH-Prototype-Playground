export default Router;
export type RouteConfig = {
    id: string;
    tagName: string;
    path: string;
    params: (Array<string> | undefined);
    authenticated: (boolean | undefined);
    subRoutes: (Array<RouteConfig> | undefined);
    beforeEnter: (() => Promise<any>);
    metaData: ({
        [x: string]: any;
    } | undefined);
};
declare class Router {
    static instance_: any;
    /** @return {Router} */
    static get instance(): Router;
    /** @param {RouteConfig=} routeConfig */
    constructor(routeConfig?: RouteConfig | undefined);
    /** @type {string|undefined} */
    currentNodeId_: string | undefined;
    /** @type {string|undefined} */
    prevNodeId_: string | undefined;
    /** @type {!RouteTreeNode|undefined} */
    routeTree_: RouteTreeNode | undefined;
    nextStateWasPopped: boolean;
    /** @type {!Set<!function():?>} */
    routeChangeStartCallbacks_: Set<() => unknown>;
    /** @type {!Set<!function(!Error=):?>} */
    routeChangeCompleteCallbacks_: Set<(arg0: Error | undefined) => unknown>;
    page: Page;
    /** @param {!RouteTreeNode|undefined} root */
    set routeTree(root: RouteTreeNode | undefined);
    /** @return {!RouteTreeNode|undefined} */
    get routeTree(): RouteTreeNode | undefined;
    /** @return {string|undefined} */
    get currentNodeId(): string | undefined;
    /** @return {string|undefined} */
    get prevNodeId(): string | undefined;
    /** @param {!RouteConfig} routeConfig */
    buildRouteTree(routeConfig: RouteConfig): RouteTreeNode;
    /**
     * Build the routing tree and begin routing
     * @return {!Promise<undefined>}
     */
    start(): Promise<undefined>;
    /**
     * Navigate to the specified route
     * @param {string} path
     * @param {Object=} params Values to use for named & query parameters
     * @returns {!Promise<!Context>}
     */
    go(path: string, params?: any | undefined): Promise<Context>;
    /**
     * Navigate to the specified route, but replace the current history event with the new one
     * @param {string} path
     * @param {Object=} params Values to use for named & query parameters
     *   NOTE: You must quote the properties so that Closure Compiler does not rename them!
     * @return {!Promise<!Context>}
     */
    redirect(path: string, params?: any | undefined): Promise<Context>;
    /**
     * Return the path for the specified route
     * @param {string} path
     * @param {Object=} params Values to use for named & query parameters
     *   NOTE: You must quote the properties so that Closure Compiler does not rename them!
     * @return {string}
     */
    url(path: string, params?: any | undefined): string;
    /**
     * Register an exit callback to be invoked on every route change
     * @param {function(!Context, function(boolean=):?):?} callback
     */
    addGlobalExitHandler(callback: (arg0: Context, arg1: (arg0: boolean | undefined) => unknown) => unknown): void;
    /**
     * Register an exit callback for a particular route
     * @param {!string} route
     * @param {function(!Context, function(boolean=):?):?} callback
     */
    addExitHandler(route: string, callback: (arg0: Context, arg1: (arg0: boolean | undefined) => unknown) => unknown): void;
    /**
     * Register an entry callback for a particular route
     * @param {!string} route
     * @param {function(!Context, function(boolean=):?):?} callback
     */
    addRouteHandler(route: string, callback: (arg0: Context, arg1: (arg0: boolean | undefined) => unknown) => unknown): void;
    /** @param {!function():?} callback */
    addRouteChangeStartCallback(callback: () => unknown): void;
    /** @param {!function():?} callback */
    removeRouteChangeStartCallback(callback: () => unknown): void;
    /** @param {!function(!Error=):?} callback */
    addRouteChangeCompleteCallback(callback: (arg0: Error | undefined) => unknown): void;
    /** @param {!function(!Error=):?} callback */
    removeRouteChangeCompleteCallback(callback: (arg0: Error | undefined) => unknown): void;
    /**
     * Walk the route tree and register route nodes with
     * the Page.js router.
     *
     * @private
     */
    private registerRoutes_;
    /**
     * @param {!RouteTreeNode} routeTreeNode
     * @param {!Context} context
     * @param {function():?} next
     * @private
     */
    private routeChangeCallback_;
    /**
     * Replace route path param values with their param name
     * for analytics tracking
     *
     * @param {!Context} context route enter context
     * @return {!string}
     */
    getRouteUrlWithoutParams(context: Context): string;
}
import animatedRoutingMixin from './lib/animated-routing-mixin.js';
import BasicRoutingInterface from './lib/routing-interface.js';
import { Context } from './lib/page.js';
import RouteData from './lib/route-data.js';
import RouteTreeNode from './lib/route-tree-node.js';
import routingMixin from './lib/routing-mixin.js';
import { Page } from './lib/page.js';
export { animatedRoutingMixin, BasicRoutingInterface, Context, RouteData, RouteTreeNode, routingMixin };
