---
name: 'jh-platform-tools'
description: 'Library for building Jack Henry Platform applications with Lit web components, providing layout components, routing integration, authentication, context management, and development tools.'
---

# JH Platform Tools

> Comprehensive toolkit for building Jack Henry Platform applications with shared infrastructure, authentication, and UI patterns

## Overview

JH Platform Tools is a library that provides the foundation for building applications within the Jack Henry Platform ecosystem. It includes layout components, routing integration with `@jack-henry/web-component-router`, mixins for common functionality, services for authentication and API communication, Lit contexts for state management, and utilities for consistent platform experiences.

This package follows the Jack Henry Digital UX standards for Web Components built with Lit, ensuring consistency across platform applications.

## Key Concepts

### Mixins

Reusable class mixins that add common functionality to Lit components. These mixins provide access to platform services, contexts, and behaviors needed by platform applications.

**[Read the full Mixins guide →](resources/mixins.md)**

Key mixins include:

- **platform-app-mixin**: Core mixin for platform apps with routing and service initialization
- **admin-user-context-mixin**: Access to authenticated admin user data
- **app-routing-mixin**: Routing utilities and navigation helpers
- **color-scheme-mixin**: Color scheme (light/dark mode) management
- **entity-mixin**: Entity context for multi-institution applications
- **toast-mixin**: Toast notification functionality
- **saved-table-views-mixin**: Persistent table view configurations

### Components

Platform layout components provide the structure and navigation for Jack Henry Platform applications. These Web Components follow Lit best practices and integrate seamlessly with platform services.

**[View complete component documentation →](resources/custom-elements.json)**

The `custom-elements.json` file contains comprehensive API documentation for all components including:

- **jh-platform-layout**: Main layout wrapper with header, navigation, and content areas
- **jh-platform-header**: Application header with branding and user controls
- **jh-platform-nav**: Primary navigation menu
- **jh-platform-content**: Content area with panel and drawer support
- **jh-platform-admin-user**: User profile and institution switcher
- **jh-platform-search-bar**: Global search functionality
- **jh-platform-drawer**: Sliding drawer panel
- **jh-platform-overlay**: Modal overlay component
- **jh-platform-back-button**: Navigation back button
- **jh-platform-session-expiration-dialog**: Session timeout warning

Each component entry includes properties, attributes, slots, CSS custom properties, events, and detailed descriptions.

### Services

Services handle external communication, authentication, configuration, and platform state management. They extend `EventTarget` for reactive event dispatching and integrate with reactive controllers.

**[Read the full Services guide →](resources/services.md)**

Key services include:

- **AdminUserService**: Session management and user authentication
- **PlatformAppService**: App configuration and initialization
- **jha-fetch**: Authenticated HTTP client with token management
- **portfolio-permissions-service**: Permission checking for portfolio features
- **session-check**: Session expiration monitoring
- **ui-config-service**: UI configuration management

### Contexts

Lit contexts provide reactive state management across component boundaries using `@lit/context`. Platform contexts ensure consistent access to user data, routing, permissions, and entities throughout the application.

**[Read the full Contexts guide →](resources/contexts.md)**

Available contexts:

- **admin-user-context**: Current authenticated admin user
- **admin-user-permissions-context**: User permissions for AMS products
- **app-routing-context**: Current route and router instance
- **entity-context**: Institution/entity selection state

### Styles

Shared style modules for consistent theming and layouts across platform applications. These provide color palettes and page-level styling utilities.

**[Read the full Styles guide →](resources/styles.md)**

Available styles:

- **color-palette**: 18-color palette with light and dark variants
- **page-styles**: Common page layout and structure styles

### Utilities

Helper functions and utilities for common platform tasks including institution selection, toast notifications, phone number formatting, and 404 page handling.

**[Read the full Utilities guide →](resources/utils.md)**

Available utilities:

- **show-toast-util**: Display toast notifications with icons
- **institution-selector**: Institution picker functionality
- **phone**: Phone number formatting and validation
- **display-not-found-util**: Show 404 pages for missing routes

## Quick Reference

### Basic Platform App Setup

```typescript
import { LitElement, html } from 'lit';
import { customElement } from 'lit/decorators.js';
import platformAppMixin from '@jack-henry/platform-tools/mixins/platform-app-mixin.js';
import '@jack-henry/platform-tools/components/jh-platform-layout.js';
import { ROUTE_CONFIG } from './routing/route-config.js';

const AppElement = platformAppMixin(LitElement, ROUTE_CONFIG);

@customElement('my-platform-app')
class MyPlatformApp extends AppElement {
  render() {
    return html`<slot></slot>`;
  }
}
```

### Route Configuration

```typescript
import type { PTRouteConfig } from '@jack-henry/platform-tools';

const ROOT_PATH = 'my-app';

const ROUTE_IDS = {
  app: 'my-app',
  layout: 'jh-platform-layout',
  dashboard: 'my-app-dashboard',
};

const ROUTE_CONFIG: PTRouteConfig = {
  id: ROUTE_IDS.app,
  path: ROOT_PATH,
  tagName: ROUTE_IDS.app,
  subRoutes: [
    {
      id: ROUTE_IDS.layout,
      path: '',
      tagName: ROUTE_IDS.layout,
      subRoutes: [
        {
          id: ROUTE_IDS.dashboard,
          path: '/',
          tagName: ROUTE_IDS.dashboard,
        },
      ],
    },
  ],
};

export { ROUTE_IDS, ROUTE_CONFIG };
```

### Accessing Admin User Context

```typescript
import { LitElement, html } from 'lit';
import { customElement } from 'lit/decorators.js';
import adminUserContextMixin from '@jack-henry/platform-tools/mixins/admin-user-context-mixin.js';

@customElement('user-greeting')
class UserGreeting extends adminUserContextMixin(LitElement) {
  render() {
    return html`
      <h1>Welcome, ${this.user?.firstName} ${this.user?.lastName}!</h1>
      <p>Email: ${this.user?.email}</p>
    `;
  }
}
```

### Making Authenticated API Requests

```typescript
import { jhaFetch } from '@jack-henry/platform-tools/services/jha-fetch.js';

async function fetchUserData(userId: string) {
  const response = await jhaFetch(`/api/users/${userId}`);
  const data = await response.json();
  return data;
}
```

### Showing Toast Notifications

```typescript
import showToast from '@jack-henry/platform-tools/utils/show-toast-util.js';

// Success toast
showToast({
  role: 'success',
  text: 'Changes saved successfully',
});

// Error toast
showToast({
  role: 'danger',
  text: 'Failed to save changes',
  hideDismissButton: false,
});
```

## Best Practices

1. **Use platform-app-mixin as the base** for your main app component to get routing, services, and platform integration
2. **Apply context mixins selectively** - only include mixins in components that need the functionality
3. **Leverage Lit contexts** for state management across component boundaries rather than prop drilling
4. **Use jha-fetch for all API calls** to ensure proper authentication token handling
5. **Follow the routing pattern** with `jh-platform-layout` as a child route for consistent navigation
6. **Initialize services in platform-app-mixin** rather than in individual components
7. **Use TypeScript** for type safety with all platform APIs and contexts
8. **Keep components focused** - use mixins for cross-cutting concerns, services for data fetching
9. **Test with the provided Vite config** for local development against staging environment

## Installation

```bash
yarn add @jack-henry/platform-tools
```

## Package Exports

The package provides granular exports for all major feature areas:

- `.` - Main index with types
- `./configs/*` - Vite and other configuration files
- `./mixins/*` - All mixin modules
- `./components/*` - Platform layout components
- `./contexts/*` - Lit context definitions
- `./services/*` - Service modules
- `./session-storage/*` - Session storage utilities
- `./styles/*` - Shared style modules
- `./utils/*` - Utility functions

## Component Documentation

Detailed API documentation for all platform components is available in the [custom-elements.json](resources/custom-elements.json) file. This machine-readable format includes:

- Component properties and attributes with types
- CSS custom properties for theming
- Events dispatched by components
- Slots for content projection
- Method signatures
- Detailed descriptions and usage notes

Tools like `@custom-elements-manifest/analyzer` and IDEs that support custom elements manifests can use this file to provide IntelliSense, autocomplete, and inline documentation while working with platform components.

## Related Resources

- [Lit Documentation](https://lit.dev)
- [@lit/context](https://lit.dev/docs/data/context/)
- [@jack-henry/web-component-router](https://github.com/Banno/web-component-router)
- [JH Elements](https://elements.banno-platform.com) - Component library
- [JH Icons](https://icons.banno-platform.com) - Icon library
