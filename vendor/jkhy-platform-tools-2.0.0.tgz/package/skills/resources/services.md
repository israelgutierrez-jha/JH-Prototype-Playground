# Platform Services

Services in jh-platform-tools handle external communication, authentication, permissions, configuration management, and session monitoring. They follow event-driven patterns extending `EventTarget` for reactive integration with components.

## Admin User Service

Manages authenticated admin user sessions, institution selection, and permission loading for AMS products.

### Overview

`AdminUserService` is a singleton service that handles all aspects of user authentication state. It loads user data, manages institution selection, fetches AMS product permissions, and provides reactive observables for component subscriptions.

### Usage

The service is automatically initialized by `PlatformAppService`. Access it through contexts or the platform app:

```typescript
import { AdminUserService } from '@jack-henry/platform-tools/services/admin-user/admin-user.service.js';

// Get singleton instance (typically done by PlatformAppService)
const adminUserService = AdminUserService.getInstance(appConfig);

// Subscribe to user context changes
adminUserService.userContext$.subscribe((userContext) => {
  console.log('User state:', userContext.state);
  console.log('User:', userContext.user);
});

// Subscribe to permissions changes
adminUserService.adminUserPermissionsContext$.subscribe((permissions) => {
  console.log('Available products:', permissions.products);
  const product = permissions.getProduct('exception-processing');
  console.log('Product permissions:', product?.permissions);
});
```

### User Context States

```typescript
type UserContextState =
  | 'initial' // Not yet loaded
  | 'loading' // Fetching user data
  | 'authenticated' // User loaded and authenticated
  | 'error'; // Error loading user
```

### Methods

- `loadSession(): Promise<User>` - Load user session and data
- `checkAuth(): Promise<User>` - Verify authentication status
- `getInstitutions(): Promise<Institution[]>` - Fetch available institutions
- `selectInstitution(institutionId: string): Promise<void>` - Select institution
- `getUserProducts(): Promise<AmsProduct[]>` - Load user's AMS products
- `getProductPermissions(productCode: string): Promise<Permission[]>` - Get permissions for product

### User Type

```typescript
interface User {
  email: string;
  firstName: string;
  lastName: string;
  userId: string;
  phone: string | null;
  institution: Institution | null;
  canSwitchInstitutions: boolean;
}
```

### Permissions Context

```typescript
interface AdminUserPermissionsContext {
  state: 'initial' | 'loading' | 'loaded' | 'error';
  products: AmsProduct[];
  getProduct(productCode: string): AmsProduct | undefined;
  awaitProducts: Promise<AmsProduct[]>;
}

interface AmsProduct {
  code: string;
  name: string;
  permissions: Permission[];
  hasPermission(permissionName: string): boolean;
}
```

### Best Practices

- **Use contexts instead of direct service access** - Apply `adminUserContextMixin` to components
- **Subscribe at the app level** - Let contexts propagate state changes
- **Check state before accessing data** - User may still be loading
- **Handle institution selection** - Wait for `userContext.state === 'authenticated'`

---

## Platform App Service

Main service that coordinates application initialization, routing, authentication checks, and session monitoring.

### Overview

`PlatformAppService` is a singleton that brings together all platform concerns: user authentication, session monitoring, institution handling, and route protection. It's initialized automatically by `platformAppMixin`.

### Configuration

```typescript
interface AppConfig {
  basePath: string; // App's URL base path (e.g., '/my-app')
  requiresInstitutionId: boolean; // Whether routes need institution ID param
  unauthenticatedApp?: boolean; // Skip auth checks (for public apps)
  logoutPath?: string; // Custom logout redirect path
  amsProductCodes?: string[]; // AMS products to load permissions for
  bffName?: string; // Backend-for-frontend service name
  bffNagPrefix?: string; // NAG proxy prefix through BFF
}
```

### Usage

```typescript
import { PlatformAppService } from '@jack-henry/platform-tools/services/platform-app-service.js';

// Initialize (typically done by platformAppMixin)
const appConfig = {
  basePath: '/exception-processing',
  requiresInstitutionId: true,
  amsProductCodes: ['exception-processing'],
};

const platformAppService = PlatformAppService.getInstance(appConfig);

// Access user and permissions
console.log('Current user:', platformAppService.user);
console.log('Institution ID:', platformAppService.institutionId);
console.log('Is authenticated:', platformAppService.isAuthenticated);
console.log('Permissions:', platformAppService.userPermissions);

// Check route before navigation
await platformAppService.checkRoute('/my-app/dashboard');
```

### Properties

- `user: User` - Current authenticated user
- `institutionId: string | undefined` - Active institution ID
- `isAuthenticated: boolean` - Whether user is authenticated
- `userPermissions: AdminUserPermissionsContext` - User's product permissions
- `sessionCheckWorker: Worker` - Web worker monitoring session expiration

### Methods

- `checkRoute(path: string): Promise<void>` - Validate auth and institution for route
- `terminateSessionCheckWorker(): void` - Stop session monitoring
- `getInstance(config: AppConfig): PlatformAppService` - Get singleton instance

### Session Monitoring

The service automatically starts a Web Worker to monitor session expiration:

- Polls for session status at regular intervals
- Dispatches countdown events as expiration approaches
- Shows session expiration dialog when threshold is reached
- Redirects to login when session expires

### Authentication Flow

1. Route navigation attempted
2. `checkRoute()` called by `platformAppMixin`
3. Service checks authentication status
4. If unauthenticated, redirects to login with `redirect_to` param
5. After login, user returns to original route
6. If authenticated but wrong institution, redirects with institution ID

### Unauthorized Event

The service listens for `unauthorized` events from `eventDispatcher`:

```typescript
// Automatically triggered by jhaFetch on 401 responses
eventDispatcher.dispatchEvent(new CustomEvent('unauthorized'));

// PlatformAppService redirects to login with reauthentication reason
```

---

## JHA Fetch

Authenticated HTTP client for making API requests with automatic token handling, caching, and error management.

### Overview

`jhaFetch` wraps the Fetch API with platform-specific concerns like XSRF token injection, credential handling, response caching, and 401 error dispatching.

### Basic Usage

```typescript
import { jhaFetch } from '@jack-henry/platform-tools/services/jha-fetch.js';

// Simple GET request
const response = await jhaFetch('/a/api/backoffice/v0/users');
const users = await response.json();

// POST with body
const response = await jhaFetch('/a/api/backoffice/v0/users', {
  method: 'POST',
  body: JSON.stringify({ name: 'John Doe', email: 'john@example.com' }),
  headers: {
    'Content-Type': 'application/json',
  },
});

// Advanced configuration
const data = await JhaFetch.fetch<User[]>({
  api: USER_API_CONFIG,
  method: 'GET',
  urlArguments: { institutionId: '123' },
  urlParams: { limit: 50, offset: 0 },
  ignoreCache: true,
});
```

### API Configuration Pattern

Define reusable API configurations:

```typescript
import type { ApiConfig } from '@jack-henry/platform-tools/services/jha-fetch.js';

const API_ROUTES: Record<string, ApiConfig> = {
  USER_LIST: {
    url: (institutionId: string) => `/a/api/backoffice/v0/${institutionId}/users`,
    arguments: ['institutionId'],
    requestMethods: ['GET'],
  },
  USER_DETAIL: {
    url: (institutionId: string, userId: string) => `/a/api/backoffice/v0/${institutionId}/users/${userId}`,
    arguments: ['institutionId', 'userId'],
    requestMethods: ['GET', 'PUT', 'DELETE'],
  },
  USER_SEARCH: {
    url: (institutionId: string) => `/a/api/backoffice/v0/${institutionId}/users/search`,
    arguments: ['institutionId'],
    requestMethods: ['POST'],
  },
};

// Use with JhaFetch
const users = await JhaFetch.fetch<User[]>({
  api: API_ROUTES.USER_LIST,
  method: 'GET',
  urlArguments: { institutionId: '123' },
  urlParams: { active: true },
});

const user = await JhaFetch.fetch<User>({
  api: API_ROUTES.USER_DETAIL,
  method: 'GET',
  urlArguments: { institutionId: '123', userId: '456' },
});
```

### Configuration Options

```typescript
interface JhaFetchConfig {
  api?: ApiConfig; // Predefined API configuration
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  url?: string | ((...args) => string); // URL or URL builder function
  urlArguments?: Record<string, any>; // Arguments for URL builder
  urlParams?: Record<string, any>; // Query string parameters
  headers?: Record<string, any>; // Custom headers
  body?: any; // Request body (auto-stringified)
  sendBodyAsIs?: boolean; // Don't stringify body
  ignoreCache?: boolean; // Skip cache for this request
  includeSuccessStatus?: boolean; // Include status in response
  credentials?: RequestCredentials; // Credential mode
}
```

### Caching

GET requests are automatically cached for 10 seconds:

```typescript
// First call - hits network
const users1 = await jhaFetch('/api/users');

// Within 10 seconds - returns cached response
const users2 = await jhaFetch('/api/users');

// After 10 seconds - hits network again
const users3 = await jhaFetch('/api/users');

// Bypass cache
const users4 = await JhaFetch.fetch({
  api: { url: '/api/users' },
  method: 'GET',
  ignoreCache: true,
});
```

Cache is automatically invalidated for URLs when `PUT`, `POST`, or `DELETE` requests are made to them.

### XSRF Protection

The service automatically:

1. Reads `XSRF-TOKEN` cookie
2. Adds `x-xsrf-token` header to requests
3. Sets credentials mode to `include` when token present

### Error Handling

```typescript
try {
  const response = await jhaFetch('/api/users/123');
  const user = await response.json();
} catch (error) {
  // Error object structure
  console.error('Status:', error.status);
  console.error('Body:', error.body);
}
```

On 401 Unauthorized:

- Dispatches `unauthorized` event via `eventDispatcher`
- `PlatformAppService` listens and redirects to login

### Methods

- `jhaFetch(url: string, options?: RequestInit): Promise<Response>` - Simple fetch wrapper
- `JhaFetch.fetch<T>(config: JhaFetchConfig): Promise<T>` - Advanced fetch with error handling
- `JhaFetch.fetchNoCatch<T>(config: JhaFetchConfig): Promise<T>` - Fetch without catch block

---

## Event Dispatcher

Global event bus for cross-cutting concerns like authentication errors.

### Overview

Simple `EventTarget` singleton for dispatching and listening to application-wide events.

### Usage

```typescript
import { eventDispatcher } from '@jack-henry/platform-tools/services/event-dispatcher.js';

// Listen for events
eventDispatcher.addEventListener('unauthorized', (event: CustomEvent) => {
  console.log('Unauthorized access:', event.detail);
  // Handle unauthorized state
});

// Dispatch events
eventDispatcher.dispatchEvent(
  new CustomEvent('unauthorized', {
    detail: { path: '/restricted-resource' },
  }),
);

// Remove listeners
const handler = (event) => {
  /* ... */
};
eventDispatcher.addEventListener('my-event', handler);
eventDispatcher.removeEventListener('my-event', handler);
```

### Standard Events

- `unauthorized` - Dispatched by `jhaFetch` on 401 responses

### Custom Events

You can use the event dispatcher for application-specific events:

```typescript
// Define typed event
interface DataRefreshEvent extends CustomEvent {
  detail: {
    dataType: string;
    timestamp: number;
  };
}

// Dispatch
eventDispatcher.dispatchEvent(
  new CustomEvent<DataRefreshEvent['detail']>('data-refresh', { detail: { dataType: 'users', timestamp: Date.now() } }),
);

// Listen
eventDispatcher.addEventListener('data-refresh', (event: DataRefreshEvent) => {
  console.log('Data refreshed:', event.detail.dataType);
});
```

---

## UI Config Service

Manages persistent UI configuration like table views, filters, and column layouts at user and institution levels.

### Overview

`PlatformUIConfigService` provides storage and retrieval for UI configurations with support for multiple scoping levels (user, institution, application).

### Usage

```typescript
import { PlatformUIConfigService, CONFIG_LEVEL } from '@jack-henry/platform-tools/services/ui-config-service';

const uiConfigService = new PlatformUIConfigService('my-app', 'users-table');

// Save user-level configuration
await uiConfigService.save({
  level: CONFIG_LEVEL.USER,
  institutionId: '123',
  name: 'My Custom View',
  config: {
    filters: { status: 'active' },
    sort: { field: 'lastName', direction: 'asc' },
    columns: ['firstName', 'lastName', 'email'],
  },
});

// Load all configurations for this context
const configs = await uiConfigService.load('123');
console.log('User configs:', configs[CONFIG_LEVEL.USER]);
console.log('Institution configs:', configs[CONFIG_LEVEL.INSTITUTION]);

// Get specific configuration by ID
const config = await uiConfigService.getById('config-id-123', '123');

// Delete configuration
await uiConfigService.delete('config-id-123', '123');
```

### Configuration Levels

```typescript
const CONFIG_LEVEL = {
  USER: 'user', // Personal user configurations
  INSTITUTION: 'institution', // Shared institution configurations
} as const;
```

### Configuration Interface

```typescript
interface SavedConfig {
  id?: string; // Auto-generated if not provided
  level: 'user' | 'institution'; // Scope level
  institutionId: string; // Institution context
  name: string; // Display name
  config: any; // Arbitrary configuration object
}
```

### Integration with Tables

Used by `SavedTableViewsMixin` for persisting table state:

```typescript
interface TableConfig {
  filters: Record<string, FilterValue>;
  sort: { field: string; direction: 'asc' | 'desc' };
  columns: string[];
  pageSize: number;
}

const savedConfig: SavedConfig = {
  level: CONFIG_LEVEL.USER,
  institutionId,
  name: 'Active Users View',
  config: tableConfig,
};

await uiConfigService.save(savedConfig);
```

### Error Handling

```typescript
import { ApiResponseError } from '@jack-henry/platform-tools/services/ui-config-service';

try {
  await uiConfigService.save(config);
} catch (error) {
  if (error instanceof ApiResponseError) {
    console.error('API Error:', error.message);
    console.error('Status:', error.status);
    console.error('Details:', error.body);
  }
}
```

---

## Portfolio Permissions Service

Manages portfolio-level permissions for consumer accounts and roles.

### Overview

`PortFolioPermissionService` handles loading and checking permissions for portfolio operations based on consumer roles and account access.

### Usage

```typescript
import { PortFolioPermissionService } from '@jack-henry/platform-tools/services/portfolio-permissions-service';

const config = {
  institutionId: '123',
  consumerId: '456',
  accountId: '789',
};

const portfolioService = new PortFolioPermissionService(config);

// Load permissions
await portfolioService.loadPermissions();

// Check permissions
const canView = portfolioService.hasPermission('view-transactions');
const canEdit = portfolioService.hasPermission('edit-account');

console.log('Can view transactions:', canView);
console.log('Can edit account:', canEdit);

// Access role information
console.log('Consumer role ID:', portfolioService.consumerRoleId);
console.log('Portfolio role ID:', portfolioService.portfolioRoleId);
console.log('Role accounts:', portfolioService.roleAccounts);
```

### Configuration

```typescript
interface PortfolioServiceConfig {
  institutionId: string;
  consumerId: string;
  accountId?: string;
}
```

### Context Integration

Provides a Lit context for component consumption:

```typescript
import { consume } from '@lit/context';
import { rolePermissionsContext } from '@jack-henry/platform-tools/services/portfolio-permissions-service';

@customElement('account-actions')
class AccountActions extends LitElement {
  @consume({ context: rolePermissionsContext, subscribe: true })
  rolePermissions?: RolePermissionsContext;

  render() {
    if (!this.rolePermissions?.hasPermission('transfer-funds')) {
      return html`<p>Insufficient permissions</p>`;
    }

    return html` <button @click=${this.handleTransfer}>Transfer Funds</button> `;
  }
}
```

### Role Permissions Context

```typescript
interface RolePermissionsContext {
  consumerRoleId: string | undefined;
  portfolioRoleId: string | undefined;
  roleAccounts: RoleAccount[];
  hasPermission(operation: string): boolean;
}

interface RoleAccount {
  accountId: string;
  permissions: string[];
}
```

---

## Session Check Service

Web Worker-based service that monitors session expiration and displays countdown dialogs.

### Overview

Runs in a dedicated Web Worker to track session timeout without blocking the main thread. Starts automatically via `PlatformAppService`.

### How It Works

1. Worker initialized with session timeout duration
2. Polls session status at regular intervals
3. Calculates time remaining until expiration
4. Posts messages to main thread with countdown
5. Main thread shows session expiration dialog
6. User can extend session or will be logged out

### Worker Messages

```typescript
interface SessionCheckWorkerMessage<T> {
  type: 'initialize' | 'update-expiration';
  detail: T;
}

interface InitializeWorkerDetails {
  expiresAt: number; // Unix timestamp of expiration
  warningThreshold: number; // When to show warning (ms before expiration)
}

interface ExpirationUpdateDetails {
  secondsRemaining: number; // Time left in session
}
```

### Extending Session

The session expiration dialog component (`jh-platform-session-expiration-dialog`) handles session extension:

```typescript
// User clicks "Stay Logged In"
const response = await jhaFetch('/a/api/session/extend', {
  method: 'POST',
});

const { expiresAt } = await response.json();

// Update worker with new expiration
platformAppService.sessionCheckWorker.postMessage({
  type: 'update-expiration',
  detail: { expiresAt },
});
```

### Terminating Worker

```typescript
// Clean up when app disconnects
platformAppService.terminateSessionCheckWorker();
```

---

## Best Practices

### Service Access

**Prefer contexts over direct service instantiation:**

✅ **Good**: Use contexts and mixins

```typescript
class MyComponent extends adminUserContextMixin(LitElement) {
  render() {
    return html`<p>User: ${this.user?.firstName}</p>`;
  }
}
```

❌ **Bad**: Direct service access

```typescript
class MyComponent extends LitElement {
  connectedCallback() {
    super.connectedCallback();
    const service = AdminUserService.getInstance();
    // Polling or manual subscription
  }
}
```

### Error Handling

Always handle errors from async service calls:

```typescript
try {
  const user = await adminUserService.loadSession();
  console.log('User loaded:', user);
} catch (error) {
  console.error('Failed to load user:', error);
  // Show error UI
}
```

### Caching Strategy

- Use `jhaFetch` cache for frequently accessed, rarely changing data
- Set `ignoreCache: true` for real-time data
- Bust cache when data changes via POST/PUT/DELETE

### Observables

Subscribe to observables at the app level, not in every component:

```typescript
// In main app component
connectedCallback() {
  super.connectedCallback();

  this.userSubscription = adminUserService.userContext$.subscribe(
    (context) => this.handleUserContext(context)
  );
}

disconnectedCallback() {
  this.userSubscription?.unsubscribe();
  super.disconnectedCallback();
}
```

### API Configuration

Define API routes centrally for reusability:

```typescript
// apis/user-api.ts
export const USER_API = {
  LIST: { url: (instId) => `/api/${instId}/users`, arguments: ['institutionId'] },
  DETAIL: { url: (instId, userId) => `/api/${instId}/users/${userId}`, arguments: ['institutionId', 'userId'] },
};

// Use everywhere
await JhaFetch.fetch({ api: USER_API.LIST, method: 'GET', urlArguments: { institutionId } });
```
