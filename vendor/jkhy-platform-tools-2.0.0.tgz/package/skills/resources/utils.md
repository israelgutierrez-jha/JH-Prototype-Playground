# Platform Utilities

Helper functions and utilities for common platform tasks including toast notifications, phone number formatting, institution selection, and 404 page handling.

## Show Toast Utility

Display toast notifications at the application level with automatic icon handling and theming.

### Overview

`showToast` is a utility function that displays toast notifications anywhere in your application. It automatically creates and manages a `jh-toast-controller` element, handles icon imports for different notification types, and dispatches appropriate events.

### Usage

```typescript
import { showToast } from '@jack-henry/platform-tools/utils/show-toast-util.js';

// Success notification
showToast({
  role: 'success',
  text: 'Changes saved successfully',
});

// Error notification
showToast({
  role: 'danger',
  text: 'Failed to save changes. Please try again.',
});

// Delete confirmation
showToast({
  role: 'deleted',
  text: 'User account deleted',
});

// Custom notification
showToast({
  text: 'Processing your request...',
  appearance: 'neutral',
  timeout: 3000,
  hideDismissButton: false,
});
```

### Options Interface

```typescript
interface ToastOptions {
  text: string; // Required: Toast message text
  role?: 'success' | 'danger' | 'deleted' | 'default' | '';
  appearance?: 'positive' | 'negative' | 'neutral';
  timeout?: number; // Auto-dismiss timeout in milliseconds
  hideDismissButton?: boolean; // Hide/show dismiss button
  stacked?: boolean; // Stack multiple toasts
  dismissButtonAccessibleLabel?: string;
  toastDismissIcon?: string; // Custom dismiss icon HTML
  toastIcon?: string; // Custom toast icon HTML
  toastAction?: string; // Action button HTML
}
```

### Role Presets

The `role` option applies preset configurations:

**Success**:

- Icon: `jh-icon-checkmark`
- Appearance: `neutral`
- Auto-dismiss: yes (default)

```typescript
showToast({
  role: 'success',
  text: 'Profile updated',
});
```

**Danger**:

- Icon: `jh-icon-triangle-exclamation`
- Appearance: `negative`
- Auto-dismiss: yes (default)

```typescript
showToast({
  role: 'danger',
  text: 'Authentication failed',
});
```

**Deleted**:

- Icon: `jh-icon-trash-can`
- Appearance: `negative`
- Auto-dismiss: yes (default)

```typescript
showToast({
  role: 'deleted',
  text: 'Record deleted',
});
```

### Custom Configuration

Override defaults for more control:

```typescript
// Long-lived error with dismiss button
showToast({
  role: 'danger',
  text: 'Critical error occurred',
  timeout: 0, // No auto-dismiss
  hideDismissButton: false, // Show dismiss button
});

// Custom icon
showToast({
  text: 'New message received',
  appearance: 'positive',
  toastIcon: '<jh-icon-envelope slot="jh-toast-icon" size="large"></jh-icon-envelope>',
});

// With action button
showToast({
  text: 'Changes saved',
  toastAction: '<button slot="jh-toast-action">Undo</button>',
});
```

### How It Works

1. **Controller Creation**: Checks for existing `jh-toast-controller` in `document.body`
2. **Creates if Missing**: Instantiates and appends controller if not found
3. **Icon Import**: Dynamically imports appropriate icon based on `role`
4. **Event Dispatch**: Dispatches `jh-create-toast` custom event
5. **Toast Display**: Controller handles toast creation and lifecycle

### Best Practices

**Use semantic roles:**

```typescript
// ✅ Good - semantic roles
showToast({ role: 'success', text: 'Saved' });
showToast({ role: 'danger', text: 'Error occurred' });

// ❌ Avoid - unclear semantics
showToast({ appearance: 'neutral', text: 'Saved' });
```

**Keep messages concise:**

```typescript
// ✅ Good - brief and clear
showToast({ role: 'success', text: 'Profile updated' });

// ❌ Avoid - too verbose
showToast({
  role: 'success',
  text: 'Your user profile has been successfully updated and all changes have been saved to the database',
});
```

**Provide actionable error messages:**

```typescript
// ✅ Good - actionable
showToast({
  role: 'danger',
  text: 'Connection lost. Check your internet connection.',
});

// ❌ Avoid - vague
showToast({ role: 'danger', text: 'Error' });
```

**Set appropriate timeouts:**

```typescript
// Critical errors - no auto-dismiss
showToast({
  role: 'danger',
  text: 'Payment failed',
  timeout: 0,
  hideDismissButton: false,
});

// Success messages - quick dismiss
showToast({
  role: 'success',
  text: 'Copied to clipboard',
  timeout: 2000,
});
```

### Integration with Try-Catch

```typescript
async function saveData(data: FormData) {
  try {
    await api.save(data);
    showToast({
      role: 'success',
      text: 'Data saved successfully',
    });
  } catch (error) {
    console.error('Save failed:', error);
    showToast({
      role: 'danger',
      text: 'Failed to save data. Please try again.',
      hideDismissButton: false,
    });
  }
}
```

---

## Display Not Found Utility

Trigger and clear 404 "not found" displays in platform applications.

### Overview

`displayNotFound` and `clearNotFound` functions dispatch events to show or hide platform 404 pages. The `jh-platform-layout` component listens for these events and handles the UI.

### Usage

```typescript
import { displayNotFound, clearNotFound } from '@jack-henry/platform-tools/utils/display-not-found-util.js';

// Show 404 page
displayNotFound();

// Show 404 with custom return button
displayNotFound({
  label: 'Return to Dashboard',
  path: '/my-app/dashboard',
});

// Clear the 404 display
clearNotFound();
```

### Return Button Interface

```typescript
interface DisplayNotFoundReturnButton {
  label: string; // Button text
  path: string; // URL path to navigate to
}
```

### Integration with Routing

Display 404 when a route doesn't match:

```typescript
import { displayNotFound } from '@jack-henry/platform-tools/utils/display-not-found-util.js';

class MyApp extends platformAppMixin(LitElement, ROUTE_CONFIG) {
  async routeEnter(currentNode, nextNode, routeId, context) {
    await super.routeEnter(currentNode, nextNode, routeId, context);

    // Check if route is valid
    if (!this.isValidRoute(routeId)) {
      displayNotFound({
        label: 'Return to Home',
        path: this.getHomeUrl(),
      });
      return;
    }

    // Clear any previous 404 display
    clearNotFound();
  }
}
```

### Conditional Display

Show 404 when resource doesn't exist:

```typescript
async function loadUser(userId: string) {
  try {
    const user = await api.getUser(userId);
    clearNotFound();
    return user;
  } catch (error) {
    if (error.status === 404) {
      displayNotFound({
        label: 'View All Users',
        path: '/users',
      });
    }
    throw error;
  }
}
```

### Event Details

```typescript
interface DisplayNotFoundEventDetails {
  show: boolean;
  returnButton?: DisplayNotFoundReturnButton;
}

// Dispatched event type: 'not-found-change'
```

The event bubbles through the DOM and is caught by `jh-platform-layout`.

### Best Practices

**Always provide a return button:**

```typescript
// ✅ Good - helpful return path
displayNotFound({
  label: 'Return to Dashboard',
  path: '/app/dashboard',
});

// ❌ Avoid - no way to navigate away
displayNotFound();
```

**Clear 404 when navigating:**

```typescript
connectedCallback() {
  super.connectedCallback();
  clearNotFound(); // Clear when entering a new route
}
```

**Handle async load failures:**

```typescript
async loadResource() {
  this.loading = true;
  try {
    this.data = await fetchData();
    clearNotFound();
  } catch (error) {
    if (error.status === 404) {
      displayNotFound({ label: 'Go Back', path: this.previousUrl });
    }
  } finally {
    this.loading = false;
  }
}
```

---

## Phone Utility

Format, validate, and manipulate phone numbers for US/Canada and international formats.

### Overview

`PhoneUtil` provides comprehensive phone number handling including validation, formatting, masking, and E.164 conversion. Supports custom country codes with extensible patterns.

### Usage

```typescript
import PhoneUtil from '@jack-henry/platform-tools/utils/phone.js';

// Format US phone number
const formatted = PhoneUtil.formatPhone('5551234567');
// Result: "(555) 123-4567"

// Validate phone number
const isValid = PhoneUtil.isValidNumber('555-123-4567');
// Result: true

// Mask phone number for display
const masked = PhoneUtil.phoneMask('5551234567');
// Result: "•••-•••-••67"

// Convert to E.164 format
const e164 = PhoneUtil.toE164('(555) 123-4567');
// Result: "+15551234567"

// Clean phone number (remove formatting)
const clean = PhoneUtil.cleanPhoneNumber('(555) 123-4567');
// Result: "5551234567"
```

### Methods

#### formatPhone(phoneNumber: string, countryCode: string = '1'): string

Format a phone number using the pattern for the given country code:

```typescript
PhoneUtil.formatPhone('5551234567', '1');
// "(555) 123-4567"

PhoneUtil.formatPhone('44207XXXXXXX', '44');
// "44207XXXXXXX" (no format defined for UK)
```

#### isValidNumber(phoneNumber: string, countryCode: string = '1'): boolean

Validate phone number against country pattern:

```typescript
PhoneUtil.isValidNumber('(555) 123-4567'); // true
PhoneUtil.isValidNumber('555-123-4567'); // true
PhoneUtil.isValidNumber('123'); // false
PhoneUtil.isValidNumber('555-123-456X'); // false
```

#### maybeFormatPhone(newValue: string, oldValue: string = ''): string

Intelligently format phone numbers as user types:

```typescript
// Handles partial input gracefully
PhoneUtil.maybeFormatPhone('555'); // "555"
PhoneUtil.maybeFormatPhone('5551234567'); // "(555) 123-4567"
PhoneUtil.maybeFormatPhone('invalid'); // "invalid" (leaves as-is)
```

Use in input handlers:

```typescript
@customElement('phone-input')
class PhoneInput extends LitElement {
  @property() value = '';

  handleInput(e: InputEvent) {
    const target = e.target as HTMLInputElement;
    const oldValue = this.value;
    this.value = PhoneUtil.maybeFormatPhone(target.value, oldValue);
    target.value = this.value;
  }

  render() {
    return html`
      <input
        type="tel"
        .value=${this.value}
        @input=${this.handleInput}
        placeholder="(555) 123-4567" />
    `;
  }
}
```

#### phoneMask(phoneNumber: string, char: string = '•'): string

Mask phone number, showing only last 2 digits:

```typescript
PhoneUtil.phoneMask('5551234567');
// "•••-•••-••67"

PhoneUtil.phoneMask('+15551234567', '*');
// "***-***-**67"
```

Use for sensitive data display:

```typescript
render() {
  return html`
    <div class="phone-display">
      <span>${PhoneUtil.phoneMask(this.user.phone)}</span>
      <button @click=${this.reveal}>Reveal</button>
    </div>
  `;
}
```

#### cleanPhoneNumber(phoneNumber: string): string

Strip all formatting characters:

```typescript
PhoneUtil.cleanPhoneNumber('(555) 123-4567'); // "5551234567"
PhoneUtil.cleanPhoneNumber('+1-555-123-4567'); // "15551234567"
PhoneUtil.cleanPhoneNumber('555.123.4567'); // "5551234567"
```

#### toE164(phoneNumber: string, countryCode: string = '1'): string

Convert to E.164 international format:

```typescript
PhoneUtil.toE164('5551234567'); // "+15551234567"
PhoneUtil.toE164('(555) 123-4567'); // "+15551234567"
PhoneUtil.toE164('+1-555-123-4567'); // "+15551234567"
PhoneUtil.toE164('2071234567', '44'); // "+442071234567"
```

Use for API submissions:

```typescript
async function submitForm(formData: FormData) {
  const phoneNumber = formData.get('phone') as string;
  const e164Phone = PhoneUtil.toE164(phoneNumber);

  await api.createUser({
    name: formData.get('name'),
    phone: e164Phone, // Submit in standard format
  });
}
```

### Country Codes

Access supported country codes:

```typescript
const codes = PhoneUtil.countryCodes;
// Map of country code => { name, pattern?, format? }

const usCode = codes.get('1');
// { name: 'US/Canada', pattern: /regex/, format: '($1) $2-$3' }

const name = PhoneUtil.getCountryName('1');
// "US/Canada"

const pattern = PhoneUtil.getPattern('1');
// "^\+?1?[-\s]?\(?([\dX]{3})[)-]?\s?(\d{3})-?(\d{4})$"

const format = PhoneUtil.getFormat('1');
// "($1) $2-$3"
```

### Extending Country Support

Add new country codes by extending the Map:

```typescript
// In your app initialization
PhoneUtil.countryCodes.set('49', {
  name: 'Germany',
  pattern: /^\+?49[-\s]?(\d{3,4})[-\s]?(\d{7,9})$/,
  format: '$1 $2',
});
```

### Form Validation

Integrate with form validation:

```typescript
@customElement('user-form')
class UserForm extends LitElement {
  @property() phoneNumber = '';
  @property() phoneError = '';

  validatePhone() {
    if (!this.phoneNumber) {
      this.phoneError = 'Phone number is required';
      return false;
    }

    if (!PhoneUtil.isValidNumber(this.phoneNumber)) {
      this.phoneError = 'Invalid phone number format';
      return false;
    }

    this.phoneError = '';
    return true;
  }

  handleSubmit(e: Event) {
    e.preventDefault();

    if (!this.validatePhone()) {
      return;
    }

    const e164Phone = PhoneUtil.toE164(this.phoneNumber);
    this.submitToApi(e164Phone);
  }
}
```

---

## Institution Selector Utility

Present institution selection dialog for multi-institution users.

### Overview

`awaitInstitutionSelection` displays a dialog for users to choose from available institutions. Handles single-institution auto-selection and tracks recent institution selections.

### Usage

```typescript
import awaitInstitutionSelection from '@jack-henry/platform-tools/utils/institution-selector.js';
import type { JhInstitution } from '@jack-henry/platform-tools/utils/institution-selector.js';

// Get user's institutions from API
const institutions: JhInstitution[] = [
  {
    name: 'First National Bank',
    institutionId: 'abc-123',
    url: '/my-app/abc-123',
  },
  {
    name: 'Community Credit Union',
    institutionId: 'def-456',
    url: '/my-app/def-456',
  },
];

// Show selection dialog
const selected = await awaitInstitutionSelection(institutions);

if (selected) {
  console.log('User selected:', selected.name);
  window.location.href = selected.url;
}
```

### Institution Interface

```typescript
interface JhInstitution {
  name: string; // Display name
  institutionId: string; // Unique identifier
  url: string; // URL to navigate to
}
```

### Function Signature

```typescript
awaitInstitutionSelection(
  institutions: JhInstitution[],
  currentInstitutionId?: string
): Promise<JhInstitution>
```

### Single Institution Behavior

If only one institution is available, auto-selects without showing dialog:

```typescript
const institutions = [{ name: 'Only Bank', institutionId: '123', url: '/app/123' }];

const selected = await awaitInstitutionSelection(institutions);
// Returns immediately without dialog
```

### Recent Institutions

The utility tracks recently selected institutions in session storage:

```typescript
// First selection
await awaitInstitutionSelection(institutions);
// Stores institution ID in session storage

// Next selection
await awaitInstitutionSelection(institutions);
// Dialog shows recent selections at top
```

### Current Institution

Pass current institution ID to hide cancel button:

```typescript
// When user must select (no current institution)
const selected = await awaitInstitutionSelection(institutions);
// No cancel button - selection required

// When switching institutions
const selected = await awaitInstitutionSelection(institutions, currentInstitutionId);
// Cancel button available - can keep current
```

### Integration with Platform App

Use during app initialization:

```typescript
import { platformAppMixin } from '@jack-henry/platform-tools/mixins/platform-app-mixin.js';
import awaitInstitutionSelection from '@jack-henry/platform-tools/utils/institution-selector.js';

class MyApp extends platformAppMixin(LitElement, ROUTE_CONFIG) {
  async connectedCallback() {
    super.connectedCallback();

    // Wait for user to load
    await this.platformAppService.checkAuth();

    const user = this.platformAppService.user;

    if (user.canSwitchInstitutions && !this.institutionId) {
      // Show institution selector
      const institutions = await this.fetchInstitutions();
      const selected = await awaitInstitutionSelection(institutions);

      if (selected) {
        // Navigate to selected institution
        this.router.go(selected.url);
      }
    }
  }
}
```

### Error Handling

Dialog cancellation throws an error:

```typescript
try {
  const selected = await awaitInstitutionSelection(institutions, currentId);
  // User made selection
  navigateTo(selected.url);
} catch (error) {
  // User cancelled dialog
  console.log('Institution selection cancelled');
}
```

### Best Practices

**Fetch institutions from API:**

```typescript
async function getAvailableInstitutions(): Promise<JhInstitution[]> {
  const response = await jhaFetch('/api/institutions');
  const data = await response.json();

  return data.institutions.map((inst) => ({
    name: inst.name,
    institutionId: inst.id,
    url: `/app/${inst.id}`,
  }));
}
```

**Handle required selection:**

```typescript
async function requireInstitutionSelection() {
  const institutions = await getAvailableInstitutions();

  if (institutions.length === 0) {
    showToast({
      role: 'danger',
      text: 'No institutions available',
    });
    return null;
  }

  try {
    return await awaitInstitutionSelection(institutions);
  } catch (error) {
    // User cancelled - redirect or retry
    return requireInstitutionSelection();
  }
}
```

**Provide context for switching:**

```typescript
async function switchInstitution(currentId: string) {
  const institutions = await getAvailableInstitutions();

  try {
    const selected = await awaitInstitutionSelection(institutions, currentId);

    if (selected.institutionId !== currentId) {
      showToast({
        role: 'success',
        text: `Switched to ${selected.name}`,
      });
      window.location.href = selected.url;
    }
  } catch (error) {
    // User cancelled - stay on current institution
  }
}
```

---

## Best Practices

### Error Feedback

Always provide user feedback for operations:

```typescript
async function saveData(data: any) {
  try {
    await api.save(data);
    showToast({ role: 'success', text: 'Saved successfully' });
  } catch (error) {
    console.error(error);
    showToast({ role: 'danger', text: 'Save failed. Please try again.' });
  }
}
```

### Phone Number Storage

Store phone numbers in E.164 format:

```typescript
// User input: "(555) 123-4567"
const userInput = formData.get('phone');
const storedValue = PhoneUtil.toE164(userInput);
// Stored: "+15551234567"

// Display formatted
const displayValue = PhoneUtil.formatPhone(storedValue);
// Display: "(555) 123-4567"
```

### Utility Function Composition

Combine utilities for complete workflows:

```typescript
async function handlePhoneSubmit(phone: string) {
  // Validate
  if (!PhoneUtil.isValidNumber(phone)) {
    showToast({
      role: 'danger',
      text: 'Please enter a valid phone number',
    });
    return;
  }

  // Format for API
  const e164 = PhoneUtil.toE164(phone);

  try {
    await api.updatePhone(e164);
    showToast({
      role: 'success',
      text: 'Phone number updated',
    });
  } catch (error) {
    showToast({
      role: 'danger',
      text: 'Failed to update phone number',
    });
  }
}
```

### Consistent Error Handling

Create helper functions for common patterns:

```typescript
async function withErrorToast<T>(operation: () => Promise<T>, errorMessage: string): Promise<T | null> {
  try {
    return await operation();
  } catch (error) {
    console.error(error);
    showToast({ role: 'danger', text: errorMessage });
    return null;
  }
}

// Usage
await withErrorToast(() => api.deleteUser(userId), 'Failed to delete user');
```
