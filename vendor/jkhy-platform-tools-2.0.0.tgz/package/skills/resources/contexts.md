# Platform Contexts

Lit contexts provide reactive state sharing across component boundaries without prop drilling. Platform contexts deliver authenticated user data, routing information, entity state, and permissions throughout the application tree.

## Overview

Contexts in jh-platform-tools use `@lit/context` for type-safe, reactive state management. Components provide contexts at high levels (app root, routes) and consume them anywhere in the tree with automatic re-rendering on updates.

## Admin User Context

Provides the authenticated admin user's session state and information.

### Usage

**Consuming with Mixin** (Recommended):

```typescript
import { LitElement, html } from 'lit';
import { customElement } from 'lit/decorators.js';
import adminUserContextMixin from '@jack-henry/platform-tools/mixins/admin-user-context-mixin.js';

@customElement('user-info')
class UserInfo extends adminUserContextMixin(LitElement) {
  render() {
    if (this.userState === 'loading') {
      return html`<p>Loading user...</p>`;
    }

    if (this.userState === 'error') {
      return html`<p>Error loading user</p>`;
    }

    return html`
      <div>
        <h2>${this.user?.firstName} ${this.user?.lastName}</h2>
        <p>Email: ${this.user?.email}</p>
        <p>User ID: ${this.user?.userId}</p>
        ${this.user?.phone ? html`<p>Phone: ${this.user.phone}</p>` : ''}
        ${this.user?.institution ? html`<p>Institution: ${this.user.institution.name}</p>` : ''}
        ${this.user?.canSwitchInstitutions ? html`<button>Switch Institution</button>` : ''}
      </div>
    `;
  }
}
```

**Consuming Directly**:

```typescript
import { LitElement, html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { consume } from '@lit/context';
import { adminUserContext, type AdminUserContext } from '@jack-henry/platform-tools/contexts/admin-user-context.js';

@customElement('user-greeting')
class UserGreeting extends LitElement {
  @consume({ context: adminUserContext, subscribe: true })
  @state()
  userContext?: AdminUserContext;

  render() {
    const user = this.userContext?.user;
    return html`<h1>Welcome, ${user?.firstName}!</h1>`;
  }
}
```

### Type Definition

```typescript
interface AdminUserContext {
  state: 'initial' | 'loading' | 'authenticated' | 'error';
  user: User;
  error?: string;
}

interface User {
  email: string;
  firstName: string;
  lastName: string;
  userId: string;
  phone: string | null;
  institution: Institution | null;
  canSwitchInstitutions: boolean;
}

interface Institution {
  id: string;
  name: string;
  routingNumber: string;
}
```

### Context States

- `initial` - Not yet fetched
- `loading` - Currently loading user data
- `authenticated` - User loaded and authenticated
- `error` - Error occurred during load

### Provider

Automatically provided by `AdminUserService` through `PlatformAppService`. No manual provision needed.

### Best Practices

- **Always check state** before using user data
- **Use optional chaining** for user properties: `user?.firstName`
- **Apply mixin selectively** - only to components that need user data
- **Avoid accessing in constructor** - context not available until `connectedCallback`

---

## Admin User Permissions Context

Provides AMS product permissions for the authenticated user.

### Usage

**Consuming with Mixin**:

```typescript
import { LitElement, html } from 'lit';
import { customElement } from 'lit/decorators.js';
import adminUserContextMixin from '@jack-henry/platform-tools/mixins/admin-user-context-mixin.js';

@customElement('feature-permissions')
class FeaturePermissions extends adminUserContextMixin(LitElement) {
  async connectedCallback() {
    super.connectedCallback();

    // Wait for permissions to load
    const products = await this.adminUserPermissions?.awaitProducts;
    console.log('Products loaded:', products);
  }

  render() {
    const exceptionProcessing = this.adminUserPermissions?.getProduct('exception-processing');

    if (!exceptionProcessing) {
      return html`<p>Exception Processing not available</p>`;
    }

    const canApprove = exceptionProcessing.hasPermission('approve-exceptions');
    const canExport = exceptionProcessing.hasPermission('export-data');

    return html`
      <div>
        <h3>Exception Processing Permissions</h3>
        <ul>
          <li>Can approve: ${canApprove ? 'Yes' : 'No'}</li>
          <li>Can export: ${canExport ? 'Yes' : 'No'}</li>
        </ul>
        ${canApprove ? html`<button>Approve Exceptions</button>` : ''}
      </div>
    `;
  }
}
```

**Consuming Directly**:

```typescript
import { consume } from '@lit/context';
import {
  adminUserPermissionsContext,
  type AdminUserPermissionsContext,
} from '@jack-henry/platform-tools/contexts/admin-user-permissions-context.js';

@customElement('restricted-feature')
class RestrictedFeature extends LitElement {
  @consume({ context: adminUserPermissionsContext, subscribe: true })
  @state()
  permissions?: AdminUserPermissionsContext;

  render() {
    const wiresProduct = this.permissions?.getProduct('wires');

    if (!wiresProduct?.hasPermission('initiate-wire')) {
      return html`<p>You don't have permission to initiate wires</p>`;
    }

    return html`<button @click=${this.initiate}>Initiate Wire</button>`;
  }
}
```

### Type Definition

```typescript
interface AdminUserPermissionsContext {
  state: 'initial' | 'loading' | 'loaded' | 'error';
  products: AmsProduct[];
  getProduct(productCode: string): AmsProduct | undefined;
  awaitProducts: Promise<AmsProduct[]>;
}

interface AmsProduct {
  code: string;
  name: string;
  permissions: Permission[];
  hasPermission(permissionName: string): boolean;
}

interface Permission {
  name: string;
  granted: boolean;
}
```

### Async Loading

Permissions load asynchronously. Use `awaitProducts` for initialization:

```typescript
async connectedCallback() {
  super.connectedCallback();

  try {
    const products = await this.adminUserPermissions?.awaitProducts;
    this.initializeFeatures(products);
  } catch (error) {
    console.error('Failed to load permissions:', error);
  }
}
```

### Checking Permissions

```typescript
// Check if product exists
const product = this.adminUserPermissions?.getProduct('exception-processing');
if (!product) {
  // Product not available to user
  return;
}

// Check specific permission
if (product.hasPermission('approve-exceptions')) {
  // User has permission
}

// Get all permissions for a product
product.permissions.forEach((permission) => {
  console.log(`${permission.name}: ${permission.granted}`);
});
```

### Configuration

Specify which products to load in app config:

```typescript
const appConfig: AppConfig = {
  basePath: '/my-app',
  requiresInstitutionId: true,
  amsProductCodes: ['exception-processing', 'wires', 'ach'],
};
```

---

## App Routing Context

Provides current route information, router instance, and route configuration.

### Usage

**Consuming with Mixin**:

```typescript
import { LitElement, html } from 'lit';
import { customElement } from 'lit/decorators.js';
import appRoutingMixin from '@jack-henry/platform-tools/mixins/app-routing-mixin.js';

@customElement('nav-breadcrumbs')
class NavBreadcrumbs extends appRoutingMixin(LitElement) {
  render() {
    const routeId = this.appRouting.routeId;
    const params = this.appRouting.context?.params;
    const institutionId = params?.institutionId;

    return html`
      <nav>
        <a href="${this.url('dashboard', { institutionId })}">Dashboard</a>
        <span>/</span>
        <span>${this.currentRoute?.id}</span>
      </nav>
      <p>Current Route ID: ${routeId}</p>
      <p>Institution: ${institutionId}</p>
    `;
  }
}
```

**Consuming Directly**:

```typescript
import { consume } from '@lit/context';
import { appRoutingContext, type AppRouting } from '@jack-henry/platform-tools/contexts/app-routing-context.js';

@customElement('route-debugger')
class RouteDebugger extends LitElement {
  @consume({ context: appRoutingContext, subscribe: true })
  @state()
  appRouting?: AppRouting;

  render() {
    return html`
      <dl>
        <dt>Route ID</dt>
        <dd>${this.appRouting?.routeId}</dd>

        <dt>Base Path</dt>
        <dd>${this.appRouting?.baseRoutingPath}</dd>

        <dt>Institution ID</dt>
        <dd>${this.appRouting?.institutionId}</dd>

        <dt>App ID</dt>
        <dd>${this.appRouting?.appId}</dd>

        <dt>Path</dt>
        <dd>${this.appRouting?.context?.path}</dd>

        <dt>Params</dt>
        <dd>${JSON.stringify(this.appRouting?.context?.params)}</dd>
      </dl>
    `;
  }
}
```

### Type Definition

```typescript
interface AppRouting {
  baseRoutingPath: string | null; // Base path for the app
  config: PTRouteConfig | null; // Full route configuration
  routeId: string; // Current route's ID
  router: Router | null; // Router instance
  institutionId: string | null; // Current institution ID from route
  appId: string; // Application identifier
  context: RouterContext | null; // Current route context with params
}

interface RouterContext {
  path: string; // Current URL path
  params: Record<string, string>; // Route parameters
  query: Record<string, string>; // Query string parameters
  handled: boolean; // Whether route has been handled
}
```

### Provider

Automatically provided by `platformAppMixin`. Updated on every route change.

### Route Parameters

Access parameters from the current route:

```typescript
const params = this.appRouting.context?.params;
const institutionId = params?.institutionId;
const userId = params?.userId;
const tabName = params?.tab;
```

### Route Configuration Access

Access full route tree:

```typescript
const routeConfig = this.appRouting.config;

// Recursively traverse routes
function visitRoutes(route: PTRouteConfig) {
  console.log('Route:', route.id, route.path);
  route.subRoutes?.forEach(visitRoutes);
}

visitRoutes(routeConfig);
```

---

## Entity Context

Provides information about a selected entity (end-user/customer) in multi-entity applications.

### Usage

**Providing Context**:

```typescript
import { LitElement, html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import entityMixin from '@jack-henry/platform-tools/mixins/entity-mixin.js';

@customElement('entity-detail-page')
class EntityDetailPage extends entityMixin(LitElement) {
  @property() institutionId?: string;
  @property() entityId?: string;

  async connectedCallback() {
    super.connectedCallback();

    if (this.institutionId && this.entityId) {
      await this.fetchEntity(this.institutionId, this.entityId);
    }
  }

  render() {
    if (this.entityState === 'loading') {
      return html`<p>Loading entity...</p>`;
    }

    if (this.entityState === 'error') {
      return html`<p>Error loading entity: ${this.entityContext.error}</p>`;
    }

    return html`
      <entity-header></entity-header>
      <entity-accounts></entity-accounts>
      <entity-activity></entity-activity>
    `;
  }
}
```

**Consuming Context**:

```typescript
import { consume } from '@lit/context';
import { entityContext, type EntityContext } from '@jack-henry/platform-tools/contexts/entity-context.js';

@customElement('entity-header')
class EntityHeader extends LitElement {
  @consume({ context: entityContext, subscribe: true })
  @state()
  entityContext?: EntityContext;

  render() {
    const entity = this.entityContext?.entity;
    const primaryName = entity?.names?.[0];
    const primaryEmail = entity?.emails?.find((e) => e.isPrimaryForType);
    const primaryPhone = entity?.phones?.find((p) => p.isPrimaryForType);

    return html`
      <header>
        <h1>${primaryName?.firstName} ${primaryName?.lastName}</h1>
        ${primaryEmail ? html`<p>Email: ${primaryEmail.emailAddress}</p>` : ''}
        ${primaryPhone ? html`<p>Phone: ${primaryPhone.completePhoneNumber}</p>` : ''}
        <p>Entity ID: ${entity?.entityId}</p>
        ${entity?.vip ? html`<span class="badge">VIP</span>` : ''}
      </header>
    `;
  }
}
```

### Type Definition

```typescript
interface EntityContext {
  state: 'initial' | 'loading' | 'loaded' | 'error';
  error?: string;
  entity: Entity;
}

interface Entity {
  entityId: string;
  names: EntityName[];
  preferredContactType: string;
  addresses: EntityAddress[];
  phones: EntityPhone[];
  emails: EntityEmail[];
  digitalContacts: EntityDigitalContact[];
  entityType: string;
  insiderRole: string;
  vip: boolean;
  startDate: string;
  employerName: string;
  occupation: string;
  gender: string;
  pronouns: EntityPronouns[];
  race: string;
  ethnicity: string;
  disability: string;
  timeZone: string;
  military: EntityMilitary[];
  bNoticeStatus: string;
  bNoticeLastSentDate: string;
  taxInfo: EntityTaxInfo[];
  foreignCustomerInfo: EntityForeignCustomerInfo[];
  foreignCertificationInfo: EntityForeignCertificationInfo[];
}

interface EntityName {
  name: string;
  title: string;
  firstName: string;
  middleName: string;
  middleInitial: string;
  lastName: string;
  suffix: string;
  preferredFirstName: string;
  provider: BackOfficeProvider;
}

interface EntityPhone {
  completePhoneNumber: string;
  phoneNumber: string;
  countryCode: string;
  extension: string;
  label: string;
  isPrimaryForType: boolean;
  isPreferredForType: boolean;
  preferSMS: boolean;
  optOut: boolean;
  provider: BackOfficeProvider;
}

interface EntityEmail {
  emailAddress: string;
  label: string;
  isPrimaryForType: boolean;
  isPreferredForType: boolean;
  optOut: boolean;
  provider: BackOfficeProvider;
}
```

### Entity Methods

```typescript
// Fetch entity from API
await this.fetchEntity(institutionId, entityId);

// Search for entities
const results = await this.searchEntities(institutionId, 'John Doe');

// Reset entity state
this.resetEntity();
```

### Finding Primary Contact Info

```typescript
// Primary email
const primaryEmail = entity.emails?.find((e) => e.isPrimaryForType);

// Primary phone
const primaryPhone = entity.phones?.find((p) => p.isPrimaryForType);

// Primary address
const primaryAddress = entity.addresses?.find((a) => a.isPrimaryForType);

// Preferred name
const preferredName =
  entity.names?.find((n) => n.preferredFirstName)?.preferredFirstName || entity.names?.[0]?.firstName;
```

---

## Best Practices

### Context Consumption

**Use mixins when possible** for simpler code:

✅ **Good**: Use mixin

```typescript
class MyComponent extends adminUserContextMixin(LitElement) {
  // Access via this.user, this.userState
}
```

❌ **Verbose**: Direct consumption

```typescript
class MyComponent extends LitElement {
  @consume({ context: adminUserContext, subscribe: true })
  @state()
  userContext?: AdminUserContext;

  get user() {
    return this.userContext?.user;
  }
  get userState() {
    return this.userContext?.state;
  }
}
```

### State Checking

Always check state before accessing context data:

```typescript
render() {
  if (this.userState === 'loading') {
    return html`<loading-spinner></loading-spinner>`;
  }

  if (this.userState === 'error') {
    return html`<error-message></error-message>`;
  }

  // Safe to access user now
  return html`<p>Welcome, ${this.user?.firstName}!</p>`;
}
```

### Subscribe Option

Always use `subscribe: true` for reactive updates:

```typescript
@consume({ context: adminUserContext, subscribe: true })
@state()  // @state() triggers re-render on updates
userContext?: AdminUserContext;
```

### Provider Hierarchy

Provide contexts at the highest appropriate level:

```typescript
// App root - provides user and routing contexts
class MyApp extends platformAppMixin(LitElement, ROUTE_CONFIG) {
  // platformAppMixin provides appRoutingContext
  // AdminUserService provides adminUserContext
}

// Route/page - provides entity context
class EntityPage extends entityMixin(LitElement) {
  // Provides entityContext for this page and children
}

// Leaf component - consumes contexts
class EntityCard extends adminUserContextMixin(LitElement) {
  @consume({ context: entityContext, subscribe: true })
  @state()
  entityContext?: EntityContext;

  // Has both user (from mixin) and entity (from @consume)
}
```

### Avoid Over-Consumption

Don't consume contexts you don't need:

✅ **Good**: Selective consumption

```typescript
// Component only needs route info
class Breadcrumbs extends appRoutingMixin(LitElement) {
  // Access routing only
}
```

❌ **Bad**: Unnecessary contexts

```typescript
// Component consumes everything but only uses routing
class Breadcrumbs extends adminUserContextMixin(appRoutingMixin(entityMixin(LitElement))) {
  // Only uses routing, but gets user and entity too
}
```

### Testing with Contexts

Provide mock contexts in tests:

```typescript
import { provide } from '@lit/context';
import { adminUserContext } from '@jack-henry/platform-tools/contexts/admin-user-context.js';

class TestWrapper extends LitElement {
  @provide({ context: adminUserContext })
  mockUserContext = {
    state: 'authenticated',
    user: {
      firstName: 'Test',
      lastName: 'User',
      email: 'test@example.com',
      userId: '123',
      phone: null,
      institution: { id: '456', name: 'Test Bank', routingNumber: '123456789' },
      canSwitchInstitutions: false,
    },
  };

  render() {
    return html`<my-component></my-component>`;
  }
}
```

### Context Updates

Contexts are immutable - create new objects for updates:

```typescript
// Providing component
this.entityProvider = {
  ...this.entityProvider,
  state: 'loaded',
  entity: newEntity,
};
```

### TypeScript Type Safety

Import and use context types:

```typescript
import type { AdminUserContext } from '@jack-henry/platform-tools/contexts/admin-user-context.js';
import type { AppRouting } from '@jack-henry/platform-tools/contexts/app-routing-context.js';

@consume({ context: adminUserContext, subscribe: true })
@state()
userContext?: AdminUserContext;  // Typed!
```
