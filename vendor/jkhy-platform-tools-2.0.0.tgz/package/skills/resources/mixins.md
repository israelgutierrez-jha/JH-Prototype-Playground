# Platform Mixins

Platform mixins provide reusable functionality that can be added to Lit components through class composition. These mixins handle common concerns like routing, authentication, state management, and UI patterns.

## Platform App Mixin

The core mixin for building platform applications that integrates routing, services, and authentication.

### Usage

```typescript
import { LitElement, html } from 'lit';
import { customElement } from 'lit/decorators.js';
import platformAppMixin from '@jack-henry/platform-tools/mixins/platform-app-mixin.js';
import type { PTRouteConfig } from '@jack-henry/platform-tools';

const ROUTE_CONFIG: PTRouteConfig = {
  id: 'my-app',
  path: 'my-app',
  tagName: 'my-app',
  subRoutes: [
    {
      id: 'layout',
      path: '',
      tagName: 'jh-platform-layout',
      subRoutes: [
        {
          id: 'dashboard',
          path: '/',
          tagName: 'my-dashboard',
        },
      ],
    },
  ],
};

const appConfig = {
  basePath: '/my-app',
  requiresInstitutionId: true,
  unauthenticatedApp: false,
};

const AppElement = platformAppMixin(LitElement, ROUTE_CONFIG, appConfig);

@customElement('my-app')
class MyApp extends AppElement {
  render() {
    return html`<slot></slot>`;
  }
}
```

### Key Features

- **Router Integration**: Automatically creates and starts a `Router` instance from `@jack-henry/web-component-router`
- **Route Configuration**: Builds routes with institution ID parameters when needed
- **Authentication Checking**: Validates authentication before each route navigation
- **Service Initialization**: Provides access to `PlatformAppService` singleton
- **Context Provision**: Provides `appRoutingContext` to child components
- **Lifecycle Management**: Handles router startup and session check cleanup

### Properties

- `router: Router` - The router instance
- `platformAppService: PlatformAppService` - Singleton service for app configuration
- `institutionId: string | undefined` - Current institution ID from route params
- `platformLayoutEl: JhPlatformLayout` - Reference to the platform layout component

### Methods

- `routeEnter()` - Called before each route change to check authentication and update context

### App Configuration

```typescript
interface AppConfig {
  basePath: string; // Base URL path for the app (e.g., '/my-app')
  requiresInstitutionId: boolean; // Whether routes need :institutionId param
  unauthenticatedApp?: boolean; // Skip authentication checks
  bffNagPrefix?: string; // Backend-for-frontend API prefix
  amsProductCodes?: string[]; // AMS product codes for permissions
}
```

---

## Admin User Context Mixin

Provides access to the authenticated admin user and their permissions through Lit context.

### Usage

```typescript
import { LitElement, html } from 'lit';
import { customElement } from 'lit/decorators.js';
import adminUserContextMixin from '@jack-henry/platform-tools/mixins/admin-user-context-mixin.js';

@customElement('user-profile')
class UserProfile extends adminUserContextMixin(LitElement) {
  render() {
    return html`
      <div>
        <h2>Profile</h2>
        <p>Name: ${this.user?.firstName} ${this.user?.lastName}</p>
        <p>Email: ${this.user?.email}</p>
        <p>User ID: ${this.user?.userId}</p>
        ${this.user?.institution ? html`<p>Institution: ${this.user.institution.name}</p>` : ''}
        ${this.user?.canSwitchInstitutions ? html`<button>Switch Institution</button>` : ''}
      </div>
    `;
  }
}
```

### Properties

- `userContext?: AdminUserContext` - Full user context object with state
- `user?: User` - The authenticated user object
- `userState?: 'initial' | 'loading' | 'loaded' | 'error'` - User loading state
- `adminUserPermissions?: AdminUserPermissionsContext` - User's AMS product permissions

### User Type

```typescript
interface User {
  email: string;
  firstName: string;
  lastName: string;
  userId: string;
  phone: string | null;
  institution: Institution | null;
  canSwitchInstitutions: boolean;
}
```

### Best Practices

- Apply this mixin only to components that need user data
- Check `userState` before accessing user data in critical operations
- Use `user?.property` optional chaining since user may be undefined during loading

---

## App Routing Mixin

Provides routing utilities, navigation helpers, and access to current route information.

### Usage

```typescript
import { LitElement, html } from 'lit';
import { customElement } from 'lit/decorators.js';
import appRoutingMixin from '@jack-henry/platform-tools/mixins/app-routing-mixin.js';

@customElement('nav-component')
class NavComponent extends appRoutingMixin(LitElement) {
  handleNavigate() {
    // Navigate using route ID
    this.go('dashboard', { institutionId: this.currentRouteParams.institutionId });
  }

  render() {
    return html`
      <nav>
        <a href="${this.url('dashboard')}">Dashboard</a>
        <a href="${this.url('settings', { tab: 'general' })}">Settings</a>
        <button @click=${this.navigateToParentRoute}>Back</button>
      </nav>
      <p>Current Route: ${this.currentRoute?.id}</p>
    `;
  }
}
```

### Properties

- `appRouting: AppRouting` - Full routing context from `appRoutingContext`
- `routePaths: object` - Map of route IDs to their path patterns
- `routes: { [key: string]: AppRouteConfig }` - All route configs with parent info
- `currentRoute: AppRouteConfig` - The currently active route
- `currentRouteParams: object` - Parameters extracted from the current URL

### Methods

- `getRouteById(routeId: string): string` - Get path pattern for a route ID
- `routerGo(path: string, params?: Record<string, string>): void` - Navigate to a path
- `url(routeId: string, params?: Record<string, string>): string` - Generate URL for route
- `go(routeId: string, params?: Record<string, string>): Promise<RouteContext>` - Navigate by route ID
- `getRouteUrl(path: string, params?: Record<string, string>): string` - Get URL from path
- `navigateToParentRoute(): void` - Navigate to parent of current route
- `redirect(routeId: string, params: object): void` - Redirect to a route

### Navigation Patterns

```typescript
// Navigate programmatically
this.go('user-details', { institutionId: '123', userId: '456' });

// Generate URL for links
const profileUrl = this.url('profile', { institutionId: this.institutionId });

// Navigate using path
this.routerGo('/dashboard', { institutionId: '123' });

// Go back to parent route
this.navigateToParentRoute();
```

---

## Color Scheme Mixin

Detects and tracks the user's color scheme preference (light/dark mode).

### Usage

```typescript
import { LitElement, html, css } from 'lit';
import { customElement } from 'lit/decorators.js';
import colorSchemeMixin from '@jack-henry/platform-tools/mixins/color-scheme-mixin.js';

@customElement('themed-component')
class ThemedComponent extends colorSchemeMixin(LitElement) {
  static styles = css`
    :host {
      display: block;
      background: var(--bg-color);
      color: var(--text-color);
    }
  `;

  render() {
    return html`
      <style>
        :host {
          --bg-color: ${this.isDarkMode ? '#1a1a1a' : '#ffffff'};
          --text-color: ${this.isDarkMode ? '#e0e0e0' : '#333333'};
        }
      </style>
      <p>Current theme: ${this.isDarkMode ? 'Dark' : 'Light'}</p>
    `;
  }
}
```

### Properties

- `isDarkMode: boolean` - `true` when dark mode is preferred

### Lifecycle

- Automatically listens to `prefers-color-scheme` media query changes
- Updates `isDarkMode` property when system preference changes
- Triggers re-render when color scheme changes

### Custom Hook

Override `onColorSchemeChange()` to perform additional actions when the color scheme changes:

```typescript
class MyComponent extends colorSchemeMixin(LitElement) {
  onColorSchemeChange() {
    super.onColorSchemeChange();
    console.log('Color scheme changed to:', this.isDarkMode ? 'dark' : 'light');
    // Perform additional actions
  }
}
```

---

## Entity Mixin

Manages entity (end-user/customer) selection and context for multi-entity platform applications.

### Usage

```typescript
import { LitElement, html } from 'lit';
import { customElement } from 'lit/decorators.js';
import entityMixin from '@jack-henry/platform-tools/mixins/entity-mixin.js';

@customElement('entity-details')
class EntityDetails extends entityMixin(LitElement) {
  async connectedCallback() {
    super.connectedCallback();
    const institutionId = this.getAttribute('institution-id');
    const entityId = this.getAttribute('entity-id');

    if (institutionId && entityId) {
      await this.fetchEntity(institutionId, entityId);
    }
  }

  render() {
    if (this.entityState === 'loading') {
      return html`<p>Loading entity...</p>`;
    }

    if (this.entityState === 'error') {
      return html`<p>Error loading entity</p>`;
    }

    return html`
      <h2>${this.entity.name}</h2>
      <p>ID: ${this.entity.id}</p>
      <p>Email: ${this.entity.email}</p>
      <p>Phone: ${this.entity.phone}</p>
    `;
  }
}
```

### Properties

- `entityProvider: EntityContext` - Context object provided to children
- `entityContext: EntityContext` - Current entity context (getter/setter)
- `entity: Entity` - The current entity object
- `entityState: EntityContextState` - Loading state ('initial' | 'loading' | 'loaded' | 'error')

### Methods

- `fetchEntity(institutionId: string, entityId: string): Promise<void>` - Load entity from API
- `searchEntities(institutionId: string, query: string): Promise<any>` - Search for entities
- `resetEntity(): void` - Clear entity context to initial state

### Entity Type

```typescript
interface Entity {
  name: string;
  id: string;
  email: string;
  phone: string;
}
```

### Providing Context

This mixin provides `entityContext` to child components. Children can consume it:

```typescript
import { consume } from '@lit/context';
import { entityContext } from '@jack-henry/platform-tools/contexts/entity-context.js';

@customElement('entity-consumer')
class EntityConsumer extends LitElement {
  @consume({ context: entityContext, subscribe: true })
  entityContext?: EntityContext;

  render() {
    return html`<p>Entity: ${this.entityContext?.entity?.name}</p>`;
  }
}
```

---

## Toast Mixin

Provides toast notification functionality within a component's shadow DOM.

### Usage

```typescript
import { LitElement, html } from 'lit';
import { customElement } from 'lit/decorators.js';
import toastMixin from '@jack-henry/platform-tools/mixins/toast-mixin.js';

@customElement('form-component')
class FormComponent extends toastMixin(LitElement) {
  handleSubmit() {
    // Show toast by dispatching event
    this.dispatchEvent(
      new CustomEvent('showToast', {
        detail: {
          appearance: 'positive',
          text: 'Form submitted successfully',
          timeout: 3000,
        },
      }),
    );
  }

  handleError() {
    this.dispatchEvent(
      new CustomEvent('showToast', {
        detail: {
          appearance: 'negative',
          text: 'Error submitting form',
          timeout: null, // No auto-dismiss
        },
      }),
    );
  }

  render() {
    return html`
      <form @submit=${this.handleSubmit}>
        <!-- form fields -->
        <button type="submit">Submit</button>
      </form>
    `;
  }
}
```

### Event Details

```typescript
interface ShowToastEventDetails {
  appearance: 'negative' | 'neutral' | 'positive';
  text: string;
  timeout?: number | null; // milliseconds, null for no auto-dismiss
}
```

### Default Timeout

The default timeout is 5000ms (5 seconds).

### How It Works

- Listens for `showToast` custom events
- Dynamically imports `jh-toast-controller` and `jh-toast` components
- Creates a toast controller in the component's shadow DOM if needed
- Appends toast notifications to the controller

### Note on Scope

This mixin creates toasts in the component's shadow DOM. For application-level toasts, use the `show-toast-util` utility instead.

---

## Saved Table Views Mixin

Manages table view persistence, filtering, sorting, and column configuration for advanced tables.

### Usage

```typescript
import { LitElement, html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { SavedTableViewsMixin } from '@jack-henry/platform-tools/mixins/saved-table-views-mixin.js';

const config = {
  productId: 'my-app',
  viewId: 'users-table',
  defaultViewId: 'all-users',
  apiControlled: false,
  disableCaching: false,
};

@customElement('users-table')
class UsersTable extends SavedTableViewsMixin(LitElement, config) {
  render() {
    return html`
      <jha-advanced-table
        .views=${this.tableViews}
        .activeView=${this.activeView}
        @view-change=${this.handleViewChange}
        @view-update=${this.handleViewUpdate}
        @view-delete=${this.handleViewDelete}
        @view-save=${this.handleViewSave}
        @view-create=${this.handleViewCreate}>
        <!-- table columns -->
      </jha-advanced-table>
    `;
  }
}
```

### Configuration

```typescript
interface SavedTableViewsMixinConfig {
  productId: string; // Product/feature identifier
  viewId: string; // Table instance identifier
  defaultViewId?: string; // ID of default view
  apiControlled?: boolean; // True if views come from external API
  disableCaching?: boolean; // True to disable localStorage caching
  disableSavedViews?: boolean; // True to disable API-based saved view CRUD
}
```

### Properties

- `tableViews?: TableView[]` - Available table views
- `activeView: string | null` - Currently selected view ID
- `institutionId?: string` - Current institution ID
- `baseFilters?: Record<string, FilterValue>` - Base filter configuration
- `baseViews?: TableView[]` - Base view definitions

### Methods

- `handleViewChange(evt: CustomEvent<string>): void` - Handle view selection change
- `handleViewUpdate(evt: CustomEvent): Promise<void>` - Handle view updates (filters, sort, columns)
- `cacheTableConfig(): void` - Manually trigger cache of current table state
- `onViewChanged(viewId: string | null): void` - Hook called when active view changes

### Event Handlers

The mixin provides handlers for `jha-advanced-table` events:

- `view-change` - User selects a different view
- `view-update` - User modifies filters, sort, or columns
- `view-save` - User saves changes to an existing view
- `view-create` - User creates a new custom view
- `view-delete` - User deletes a custom view

### Persistence

The mixin uses `PlatformUIConfigService` to persist views at different levels:

- **User level**: Personal customizations and view preferences
- **Institution level**: Shared views for an institution
- **Application level**: App-wide default views

Local storage is used to cache the active view and any unsaved changes for faster page loads.

### API-Controlled Mode

When `apiControlled: true`, the host component must provide `baseFilters` and `baseViews`:

```typescript
@customElement('api-driven-table')
class ApiDrivenTable extends SavedTableViewsMixin(LitElement, {
  productId: 'my-app',
  viewId: 'api-table',
  apiControlled: true,
}) {
  async connectedCallback() {
    super.connectedCallback();

    // Fetch from backend
    const response = await fetch('/api/table-config');
    const config = await response.json();

    this.baseFilters = config.filters;
    this.baseViews = config.views;
  }
}
```

### Disabling Caching

Set `disableCaching: true` to always start with the default clean state:

```typescript
const config = {
  productId: 'reports',
  viewId: 'monthly-report',
  disableCaching: true, // Always start fresh
};
```

### Disabling Saved Views

Set `disableSavedViews: true` to use only base views without API-based CRUD:

```typescript
const config = {
  productId: 'dashboard',
  viewId: 'summary-table',
  disableSavedViews: true, // No API calls, base views only
};
```

`disableCaching` and `disableSavedViews` are independent — you can enable either or both.

---

## Best Practices

### Mixin Composition

Apply mixins in a logical order, with the most foundational first:

```typescript
const AppElement = platformAppMixin(LitElement, ROUTE_CONFIG, appConfig);

class MyPage extends adminUserContextMixin(appRoutingMixin(entityMixin(colorSchemeMixin(AppElement)))) {
  // Component implementation
}
```

### Selective Application

Only apply mixins to components that actually need them:

✅ **Good**: Apply `adminUserContextMixin` to components displaying user info
❌ **Bad**: Apply it to every component "just in case"

### Type Safety

Use TypeScript interfaces for type safety:

```typescript
import type { AdminUserContextMixinInterface } from '@jack-henry/platform-tools/mixins/admin-user-context-mixin.js';
import type { AppRoutingMixinInterface } from '@jack-henry/platform-tools/mixins/app-routing-mixin.js';

class MyComponent
  extends adminUserContextMixin(appRoutingMixin(LitElement))
  implements AdminUserContextMixinInterface, AppRoutingMixinInterface {
  // Full type checking
}
```

### Lifecycle Coordination

Always call `super.connectedCallback()` and `super.disconnectedCallback()`:

```typescript
connectedCallback() {
  super.connectedCallback(); // MUST call first
  // Your initialization
}

disconnectedCallback() {
  // Your cleanup
  super.disconnectedCallback(); // MUST call last
}
```

### Testing Mixins

Test components with mixins by providing mock contexts:

```typescript
import { provide } from '@lit/context';
import { adminUserContext } from '@jack-henry/platform-tools/contexts/admin-user-context.js';

class TestWrapper extends LitElement {
  @provide({ context: adminUserContext })
  mockUser = {
    state: 'loaded',
    user: { firstName: 'Test', lastName: 'User' /* ... */ },
  };

  render() {
    return html`<user-profile></user-profile>`;
  }
}
```
