# Platform Styles

Shared style modules for consistent theming, typography, and color palettes across platform applications.

## Color Palette

A curated 18-color palette with light and dark variants for data visualization and theming.

### Overview

`colorPalette18` provides 18 color pairs optimized for both light and dark color schemes. Each color pair consists of a light mode color and a dark mode color that maintain proper contrast ratios and visual harmony.

### Usage

```typescript
import { LitElement, html, css } from 'lit';
import { customElement } from 'lit/decorators.js';
import { colorPalette18 } from '@jack-henry/platform-tools/styles/color-palette.js';

@customElement('data-chart')
class DataChart extends LitElement {
  static styles = css`
    .chart-bar {
      height: 20px;
      margin: 4px 0;
    }
  `;

  render() {
    const data = [
      { label: 'Category A', value: 75 },
      { label: 'Category B', value: 45 },
      { label: 'Category C', value: 90 },
    ];

    return html`
      <div class="chart">
        ${data.map((item, index) => {
          const colorPair = colorPalette18[index % colorPalette18.length];
          const color = this.isDarkMode ? colorPair.dark : colorPair.light;

          return html`
            <div
              class="chart-bar"
              style="width: ${item.value}%; background-color: ${color};">
              ${item.label}: ${item.value}%
            </div>
          `;
        })}
      </div>
    `;
  }
}
```

### Color Palette Array

Each color in the palette has `dark` and `light` properties with hex color values:

```typescript
const colorPalette18 = [
  { dark: '#8CC3F3FF', light: '#4E93D0FF' }, // Blue
  { dark: '#3A76B6FF', light: '#2F5898FF' }, // Dark Blue
  { dark: '#D179E9FF', light: '#AE63BBFF' }, // Purple
  { dark: '#227C67FF', light: '#1D6957FF' }, // Teal
  { dark: '#79E693FF', light: '#2CA047FF' }, // Green
  { dark: '#8F54C6FF', light: '#6B4A87FF' }, // Deep Purple
  { dark: '#FF974CFF', light: '#D96E20FF' }, // Orange
  { dark: '#C04343FF', light: '#AA3C3CFF' }, // Red
  { dark: '#FB8F8FFF', light: '#D66C6CFF' }, // Light Red
  { dark: '#637279FF', light: '#454545FF' }, // Gray
  { dark: '#E0E0E0FF', light: '#8C8C8CFF' }, // Light Gray
  { dark: '#C16828FF', light: '#98592BFF' }, // Brown
  { dark: '#AEA374FF', light: '#998C56FF' }, // Tan
  { dark: '#71762DFF', light: '#5D6125FF' }, // Olive
  { dark: '#4EDBBAFF', light: '#1DA081FF' }, // Turquoise
  { dark: '#2F8343FF', light: '#306A16FF' }, // Forest Green
  { dark: '#CDD930FF', light: '#87951EFF' }, // Lime
  { dark: '#867527FF', light: '#614F00FF' }, // Gold
];
```

### Integration with Color Scheme

Combine with `colorSchemeMixin` for automatic color scheme detection:

```typescript
import colorSchemeMixin from '@jack-henry/platform-tools/mixins/color-scheme-mixin.js';
import { colorPalette18 } from '@jack-henry/platform-tools/styles/color-palette.js';

@customElement('themed-chart')
class ThemedChart extends colorSchemeMixin(LitElement) {
  getColor(index: number): string {
    const colorPair = colorPalette18[index % colorPalette18.length];
    return this.isDarkMode ? colorPair.dark : colorPair.light;
  }

  render() {
    return html` <div style="background-color: ${this.getColor(0)};">Chart element</div> `;
  }
}
```

### Use Cases

- **Data Visualization**: Charts, graphs, and diagrams
- **Category Indicators**: Color-coded tags, badges, or labels
- **Status Colors**: Different states in workflows
- **Legend Items**: Map colors to data series
- **Accessible Contrast**: Both variants maintain WCAG contrast ratios

### Cycling Through Colors

For dynamic data sets, cycle through the palette:

```typescript
const categories = ['A', 'B', 'C', 'D' /* ... up to 20+ */];

categories.map((category, index) => {
  const colorIndex = index % colorPalette18.length; // Cycles back to start
  const colorPair = colorPalette18[colorIndex];
  const color = isDarkMode ? colorPair.dark : colorPair.light;

  return html` <span style="color: ${color};">${category}</span> `;
});
```

### Color Consistency

Maintain consistent color assignments:

```typescript
// Map categories to consistent colors
const categoryColors = new Map([
  ['Revenue', 0], // Always blue
  ['Expenses', 7], // Always red
  ['Profit', 4], // Always green
]);

function getCategoryColor(category: string, isDarkMode: boolean): string {
  const index = categoryColors.get(category) ?? 0;
  const colorPair = colorPalette18[index];
  return isDarkMode ? colorPair.dark : colorPair.light;
}
```

---

## Page Styles

Base typography and layout styles for consistent page-level styling.

### Overview

`pageStyles` provides a foundational CSS module with typography rules, heading styles, link colors, and basic layout utilities. Import this module for consistent text rendering across your application.

### Usage

```typescript
import { LitElement, html, css } from 'lit';
import { customElement } from 'lit/decorators.js';
import pageStyles from '@jack-henry/platform-tools/styles/page-styles.js';

@customElement('content-page')
class ContentPage extends LitElement {
  static styles = [
    pageStyles,
    css`
      /* Additional component-specific styles */
      .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
      }
    `,
  ];

  render() {
    return html`
      <div class="container">
        <h1>Page Title</h1>
        <h2>Section Heading</h2>
        <p>Body text with <a href="#">a link</a> in it.</p>
        <h3>Subsection</h3>
        <p>More content here.</p>
      </div>
    `;
  }
}
```

### Typography Scale

**Heading Sizes:**

- `<h1>` - 36px, font-weight 700
- `<h2>` - 32px, font-weight 700
- `<h3>` - 26px, font-weight 700
- `<h4>` - 20px, font-weight 700
- `<h5>` - 16px, font-weight 500
- `<h6>` - 14px, font-weight 600

**Body Text:**

- Default font-size: 14px
- Default font-weight: 500
- Line-height: normal
- Color: `var(--jh-color-content-primary-enabled)`

### Host Element

The `:host` selector applies styles to the component itself:

```css
:host {
  display: block;
  color: var(--jh-color-content-primary-enabled);
  font-style: normal;
  line-height: normal;
  font-size: 14px;
  font-weight: 500;
}
```

### Links

Links use platform theme colors:

```css
a {
  color: var(--jh-color-content-link-enabled);
  text-decoration: none;
}

a:visited {
  color: var(--jh-color-content-link-visited);
}

a:hover {
  text-decoration: underline;
}
```

### Combining with Theme Tokens

`pageStyles` references JH Platform design tokens:

- `--jh-color-content-primary-enabled` - Primary text color
- `--jh-color-content-link-enabled` - Link color
- `--jh-color-content-link-visited` - Visited link color

These tokens automatically adapt to light/dark themes.

### Best Practices

**Always include as first style:**

```typescript
static styles = [
  pageStyles,           // Base styles first
  customStyles,         // Component styles second
];
```

This ensures proper cascade and allows overrides.

**Reset heading margins:**

```typescript
h1, h2, h3, h4, h5, h6 {
  margin: 0;  // pageStyles sets this
}

// Add margins as needed
h2 {
  margin-top: 24px;
  margin-bottom: 12px;
}
```

**Use semantic HTML:**

```html
<h1>Main Page Title</h1>
<h2>Section</h2>
<h3>Subsection</h3>
<p>Body content</p>
```

### Extending Page Styles

Override or extend styles as needed:

```typescript
static styles = [
  pageStyles,
  css`
    /* Override h1 size for this component */
    h1 {
      font-size: 48px;
      margin-bottom: 20px;
    }

    /* Add custom paragraph spacing */
    p + p {
      margin-top: 12px;
    }

    /* Custom link styles */
    a.external::after {
      content: ' ↗';
    }
  `,
];
```

### Accessibility

`pageStyles` maintains proper heading hierarchy and semantic HTML. Always:

- Use heading levels in order (don't skip from h2 to h4)
- Ensure sufficient color contrast (handled by theme tokens)
- Provide focus states for interactive elements

---

## Best Practices

### Importing Styles

Import styles at the module level, not in the constructor:

✅ **Good**:

```typescript
import pageStyles from '@jack-henry/platform-tools/styles/page-styles.js';
import { colorPalette18 } from '@jack-henry/platform-tools/styles/color-palette.js';

class MyComponent extends LitElement {
  static styles = [pageStyles /* ... */];
}
```

❌ **Bad**:

```typescript
class MyComponent extends LitElement {
  constructor() {
    super();
    import('./styles/page-styles.js'); // Wrong!
  }
}
```

### Style Array Order

Order matters when combining style modules:

```typescript
static styles = [
  pageStyles,        // 1. Base/reset styles
  componentStyles,   // 2. Component-specific styles
  variantStyles,     // 3. Variant/state styles
];
```

Later styles in the array can override earlier ones.

### Color Palette Selection

Choose colors purposefully:

```typescript
// Semantic color assignment
const statusColors = {
  success: colorPalette18[4], // Green
  warning: colorPalette18[6], // Orange
  error: colorPalette18[7], // Red
  info: colorPalette18[0], // Blue
};

function getStatusColor(status: string, isDarkMode: boolean): string {
  const colorPair = statusColors[status] || colorPalette18[0];
  return isDarkMode ? colorPair.dark : colorPair.light;
}
```

### Responsive Typography

Adjust heading sizes for smaller screens:

```typescript
static styles = [
  pageStyles,
  css`
    @media (max-width: 768px) {
      h1 { font-size: 28px; }
      h2 { font-size: 24px; }
      h3 { font-size: 20px; }
    }
  `,
];
```

### Theme Token Usage

Always use theme tokens for colors:

✅ **Good**:

```css
color: var(--jh-color-content-primary-enabled);
background: var(--jh-color-background-primary-enabled);
```

❌ **Bad**:

```css
color: #333333;
background: #ffffff;
```

Theme tokens ensure automatic light/dark mode support.

### Style Encapsulation

Leverage Shadow DOM encapsulation:

```typescript
// Styles are scoped to component
static styles = css`
  .button {
    /* Only affects buttons in THIS component */
  }
`;
```

No need for BEM or other naming conventions to avoid conflicts.

### CSS Custom Properties

Define component-specific CSS custom properties:

```typescript
static styles = css`
  :host {
    --component-padding: 16px;
    --component-border-radius: 4px;
  }

  .container {
    padding: var(--component-padding);
    border-radius: var(--component-border-radius);
  }
`;
```

Allow consumers to override:

```html
<my-component style="--component-padding: 24px;"></my-component>
```

### Performance

Minimize CSS recalculations:

```typescript
// Cache color calculations
private colorCache = new Map<number, string>();

getColor(index: number): string {
  if (!this.colorCache.has(index)) {
    const colorPair = colorPalette18[index % colorPalette18.length];
    const color = this.isDarkMode ? colorPair.dark : colorPair.light;
    this.colorCache.set(index, color);
  }
  return this.colorCache.get(index)!;
}

// Clear cache when color scheme changes
onColorSchemeChange() {
  super.onColorSchemeChange();
  this.colorCache.clear();
}
```
