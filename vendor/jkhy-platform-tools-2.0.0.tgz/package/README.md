# JH Platform Tools

### Integrate the layout components

In your route config, add an abstract route using `jh-platform-layout` as the first soubRoute of your app component

```javascript
const ROOT_PATH = 'your-app';

/** @enum {string} */
const ROUTE_PATHS = {
  app: ROOT_PATH,
  layout: '',
  dashboard: '/',
};

/** @enum {string} tag name mapping */
const ROUTE_IDS = {
  app: 'your-app',
  layout: 'jh-platform-layout',
  dashboard: 'your-app-dashboard',
};

/** @type {import('@jkhy/platform-tools').PTRouteConfig} */
const ROUTE_CONFIG = {
  id: ROUTE_IDS.app,
  path: ROUTE_PATHS.app,
  tagName: ROUTE_IDS.app,
  subRoutes: [
    {
      id: ROUTE_IDS.layout,
      path: ROUTE_PATHS.layout,
      tagName: ROUTE_IDS.layout,
      subRoutes: [
        {
          id: ROUTE_IDS.dashboard,
          path: ROUTE_PATHS.dashboard,
          tagName: ROUTE_IDS.dashboard,
        },
        // ... other app routes
      ],
    },
  ],
};

export { ROUTE_IDS, ROUTE_PATHS, ROUTE_CONFIG };
```

In your main app component, import the jh-platform-layout component and the platform-app-mixin, then apply the mixin, passing your route config.

```javascript
import platformAppMixin from '@jkhy/platform-tools/mixins/platform-app-mixin.js';
import('@jkhy/platform-tools/components/jh-platform-layout.js');
import {ROUTE_CONFIG} from '../js/routing/route-config.js';

const AppElement = platformAppMixin(LitElement, ROUTE_CONFIG);

class BackOfficeApp extends AppElement {
// ...
```

### Admin user context mixin

In any component(s) where you need access to the logged in Admin user, apply the admin-user-context mixin. Your component will now have a `user` property that will be subscribed to the admin user context provided by the mixin.

```javascript
import { LitElement, html } from 'lit';
import adminUserContextMixin from '@jkhy/platform-tools/mixins/admin-user-context-mixin.js';

class MyApp extends adminUserContextMixin(LitElement) {
  render() {
    return html`<h1>Hello, ${this.user?.firstName}! Welcome to my app!</h1>`;
  }
}
window.customElements.define('my-app', MyApp);
export default MyApp;
```

### Vite config

This package provides a base vite config that should make development within the platform relatively painless. The config enables local development against the [staging](https://platform.banno-staging.com) environment. The config uses vite's dev server to host your local app content while proxying requests for the login screen, other platform apps and api requests to the staging environment. To use the config, create a `vite.config.js` file at the root of your project with the following content, passing your app's name to the config function.

```javascript
import config from '@jkhy/platform-tools/configs/vite.config.js';
export default config('my-app');
```

Then add the following scripts to your `package.json`

```json
"scripts" : {
  "dev": "vite",
  "build": "vite build",
  "preview": "vite preview"
}
```

| Script           | Command      |
| ---------------- | ------------ |
| Start dev server | `yarn dev`   |
| Build            | `yarn build` |
| Lint             | `yarn lint`  |
